'use strict';

const VERSION = '0.8.5';

const DISH_WEIGHTS = {
  taste:0.30,
  consistency:0.17,
  value:0.14,
  speed:0.10,
  innovation:0.12,
  presentation:0.10,
  health:0.07
};

const STORE_WEIGHTS = {
  taste:0.22,
  service:0.14,
  speed:0.13,
  value:0.12,
  hygiene:0.11,
  atmosphere:0.08,
  consistency:0.10,
  innovation:0.10
};

const IMPROVEMENTS = [
  {id:'taste',name:'风味打磨',baseCost:420,effects:{taste:5,consistency:1},desc:'优化调味比例与核心工艺，提升口味，但连续强化会边际递减。'},
  {id:'consistency',name:'标准化改良',baseCost:360,effects:{consistency:6,speed:1},desc:'固化克重、火候和出品步骤，减少厨师状态波动。'},
  {id:'value',name:'成本与份量优化',baseCost:320,effects:{value:6,health:1},desc:'调整食材结构和份量，提升顾客感知价值，不等于简单降价。'},
  {id:'speed',name:'出餐流程改良',baseCost:390,effects:{speed:6,consistency:1},desc:'优化备料与工序顺序，降低高峰期卡单。'},
  {id:'innovation',name:'风味创新',baseCost:520,effects:{innovation:7,taste:1},desc:'增加新的风味记忆点，可能提升传播性与奖项竞争力。'},
  {id:'presentation',name:'摆盘与包装改良',baseCost:280,effects:{presentation:7,innovation:1},desc:'堂食摆盘、外带包装和视觉识别同步改良。'},
  {id:'health',name:'营养结构调整',baseCost:300,effects:{health:7,value:1},desc:'控制油盐与配菜比例，提升长期复购和家庭客接受度。'}
];

const RANK_CATEGORIES = [
  {id:'overall',name:'综合实力'},
  {id:'reputation',name:'顾客口碑'},
  {id:'dish',name:'菜品实力'},
  {id:'value',name:'性价比'},
  {id:'speed',name:'效率'},
  {id:'innovation',name:'创新'},
  {id:'momentum',name:'上升势头'}
];

const AWARDS = [
  {id:'local_new_flavor',name:'本月新味奖',scope:'商圈',period:'month',category:'innovation',minScore:68,minReviews:8,weight:5,ratingBoost:0.01,prestige:5},
  {id:'local_word_of_mouth',name:'街坊口碑奖',scope:'商圈',period:'month',category:'reputation',minScore:72,minReviews:15,weight:6,ratingBoost:0.015,prestige:6},
  {id:'local_lunch_speed',name:'午市效率奖',scope:'商圈',period:'month',category:'speed',minScore:74,minReviews:10,weight:5,ratingBoost:0.01,prestige:5},
  {id:'city_value',name:'城市高性价比餐厅',scope:'城市',period:'quarter',category:'value',minScore:76,minReviews:30,weight:10,ratingBoost:0.02,prestige:10},
  {id:'city_signature_dish',name:'城市招牌菜',scope:'城市',period:'quarter',category:'dish',minScore:79,minReviews:35,weight:14,ratingBoost:0.025,prestige:14},
  {id:'city_service',name:'城市服务星章',scope:'城市',period:'quarter',category:'reputation',minScore:78,minReviews:40,weight:12,ratingBoost:0.02,prestige:12},
  {id:'annual_popular',name:'年度人气餐厅',scope:'城市',period:'year',category:'overall',minScore:82,minReviews:80,weight:24,ratingBoost:0.04,prestige:24},
  {id:'annual_craft',name:'年度匠心菜品',scope:'城市',period:'year',category:'dish',minScore:84,minReviews:70,weight:28,ratingBoost:0.045,prestige:28}
];

const NPC_NAMES = [
  '榆巷小馆','禾木食堂','三里饭铺','桥西厨房','巷口人家','青瓦小厨','拾味餐室','南街饭堂','谷仓食坊','暖灯小馆',
  '白桦餐桌','石桥家常菜','春禾厨房','旧站食堂','沐风餐室','松间饭铺','小满厨房','青禾食集','北窗小馆','长街饭房',
  '喜谷餐厅','河畔饭堂','木棉食坊','午后小厨','新巷食堂','花砖餐室','槐树饭店','烟火小馆','东桥食坊','月台厨房'
];

function clamp(v,min=0,max=100){return Math.max(min,Math.min(max,Number(v)||0));}
function round1(v){return Math.round((Number(v)||0)*10)/10;}
function hash(text){let h=2166136261>>>0;for(const ch of String(text)){h^=ch.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function unit(seed,key){return (hash(String(seed)+'|'+String(key))%1000000)/1000000;}
function weighted(metrics,weights){let n=0,w=0;for(const [k,wt] of Object.entries(weights)){n+=clamp(metrics[k])*wt;w+=wt;}return w?round1(n/w):0;}
function gameState(){return require('../core/gameState.js');}
function timeKey(kind){const t=gameState().getTime();const y=Number(t.year)||1,m=Math.max(1,Number(t.month)||1),d=Math.max(1,Number(t.day)||1);if(kind==='year')return String(y);if(kind==='quarter')return y+'-Q'+(Math.floor((m-1)/3)+1);if(kind==='week')return y+'-W'+Math.ceil((((m-1)*30)+d)/7);return y+'-'+String(m).padStart(2,'0');}
function dayNumber(){const t=gameState().getTime();return (Number(t.year)||1)*360+(Math.max(1,Number(t.month)||1)-1)*30+Math.max(1,Number(t.day)||1);}
function getBusinessRoot(){const b=gameState().getBusiness();b.culinaryPrestigeV085 ||= {version:VERSION,shops:{},awardHistory:[]};b.culinaryPrestigeV085.version=VERSION;b.culinaryPrestigeV085.shops ||= {};b.culinaryPrestigeV085.awardHistory ||= [];return b.culinaryPrestigeV085;}
function getShopState(shopId){const root=getBusinessRoot();root.shops[shopId] ||= {prestige:0,dishes:{},rating:null,rankingHistory:[],awards:{won:[],nominations:[],periods:{}},lastSyncDay:0};const s=root.shops[shopId];s.dishes ||= {};s.rankingHistory ||= [];s.awards ||= {won:[],nominations:[],periods:{}};s.awards.won ||= [];s.awards.nominations ||= [];s.awards.periods ||= {};return s;}

function computeDishScore(metrics){return weighted(metrics,DISH_WEIGHTS);}
function computeStoreScore(metrics,reviewCount){const raw=weighted(metrics,STORE_WEIGHTS);const n=Math.max(0,Number(reviewCount)||0);const confidence=clamp(18+Math.log10(n+1)*34,18,100);const prior=68;const adjusted=(raw*n+prior*28)/(n+28);return {raw:round1(raw),score:round1(adjusted),confidence:round1(confidence)};}

function ensureDishProfile(shopId,item,index=0,cost){const state=getShopState(shopId);const id=String(item.id||item.recipeId||('dish_'+index));if(!state.dishes[id]){const seed=hash(shopId+'|'+id);const price=Math.max(1,Number(item.listPrice||item.price)||18);const c=Math.max(0.1,Number(cost)||price*0.38);const margin=clamp((price-c)/price*100,0,95);state.dishes[id]={id,recipeId:item.recipeId||id,name:item.name||('菜品'+(index+1)),revision:0,level:1,trials:0,taste:clamp(70+(unit(seed,'taste')-.5)*12),consistency:clamp(68+(unit(seed,'consistency')-.5)*12),value:clamp(58+margin*.34+(unit(seed,'value')-.5)*8),speed:clamp(69+(unit(seed,'speed')-.5)*12),innovation:clamp(55+(unit(seed,'innovation')-.5)*18),presentation:clamp(61+(unit(seed,'presentation')-.5)*14),health:clamp(58+(unit(seed,'health')-.5)*14),lastImprovement:null};}
  const d=state.dishes[id];d.name=item.name||d.name;d.recipeId=item.recipeId||d.recipeId;d.score=computeDishScore(d);return d;
}

function improvementPlan(shopId,item,actionId,cost){const d=ensureDishProfile(shopId,item,0,cost);const a=IMPROVEMENTS.find(x=>x.id===actionId);if(!a)return {ok:false,reason:'未知改良方向'};const rev=Math.max(0,Number(d.revision)||0);const price=Math.round(a.baseCost*(1+rev*.22));const diminishing=Math.max(.35,1-rev*.055);const effects={};for(const [k,v] of Object.entries(a.effects))effects[k]=round1(v*diminishing);return {ok:true,action:a,cost:price,effects,before:computeDishScore(d)};}

function applyImprovement(shopId,item,actionId,options={}){const d=ensureDishProfile(shopId,item,0,options.costEstimate);const plan=improvementPlan(shopId,item,actionId,options.costEstimate);if(!plan.ok)return plan;for(const [k,v] of Object.entries(plan.effects))d[k]=clamp((Number(d[k])||0)+v);d.revision=(Number(d.revision)||0)+1;d.level=1+Math.floor(d.revision/3);d.trials=(Number(d.trials)||0)+1;d.lastImprovement={day:dayNumber(),actionId,cost:Number(options.paidCost)||plan.cost};d.score=computeDishScore(d);const s=getShopState(shopId);s.prestige=round1((Number(s.prestige)||0)+Math.max(.3,(d.score-plan.before)*.18));return {ok:true,cost:plan.cost,before:plan.before,after:d.score,dish:d,action:plan.action};}

function reputationValue(rep, keys, fallback) {
  if (!rep || typeof rep !== 'object') return fallback;
  for (const key of keys) {
    const parts = String(key).split('.');
    let cur = rep;
    for (const part of parts) cur = cur && cur[part];
    const n = Number(cur);
    if (Number.isFinite(n)) return n;
  }
  return fallback;
}
function reputationMetric(rep,key,fallback){return clamp(reputationValue(rep,[key,'metrics.'+key,'dimensions.'+key,'scores.'+key,'summary.'+key],fallback));}
function reviewCountFrom(shop,rep){
  const direct=[shop&&shop.reviewCount,rep&&rep.reviewCount,rep&&rep.totalReviews,rep&&rep.summary&&rep.summary.reviewCount,rep&&rep.summary&&rep.summary.totalReviews];
  for(const value of direct){const n=Number(value);if(Number.isFinite(n)&&n>=0)return Math.round(n);}
  if(rep&&Array.isArray(rep.reviews))return rep.reviews.length;
  return 0;
}
function publicStarsFrom(shop,rep){
  let n=reputationValue(rep,['rating','averageRating','avgRating','summary.rating','summary.averageRating'],Number(shop&&shop.rating)||4);
  if(n>5)n=n/20;
  return Math.max(1,Math.min(5,n));
}

function deriveMetrics(shopId,runtime,context={}){
  const shop=runtime&&runtime.shop||{};
  const menu=runtime&&Array.isArray(runtime.menu)?runtime.menu:[];
  const costs=context.costByItem||{};
  const rep=context.reputation||null;
  const dishProfiles=menu.map((item,i)=>ensureDishProfile(shopId,item,i,costs[item.id]));
  const dishAvg=dishProfiles.length?dishProfiles.reduce((a,b)=>a+(Number(b.score)||0),0)/dishProfiles.length:68;
  const bestDish=dishProfiles.slice().sort((a,b)=>(b.score||0)-(a.score||0))[0]||null;
  const star=clamp(publicStarsFrom(shop,rep)*20,20,100);
  const reviews=reviewCountFrom(shop,rep);
  const daily=(runtime&&Array.isArray(runtime.dailySnapshots)&&runtime.dailySnapshots.length)?runtime.dailySnapshots[runtime.dailySnapshots.length-1]:null;
  const financial=daily&&daily.financial||{};
  const orders=Number(financial.orders)||0;
  const customers=Number(financial.customers)||orders;
  const profitRate=clamp(Number(financial.profitRate)||Number(context.profitRate)||18,-50,80);
  const activeMenu=menu.filter(x=>x.active!==false).length;
  const state=getShopState(shopId);
  const awardWeight=(state.awards.won||[]).reduce((n,x)=>n+(Number(x.weight)||0),0);
  const fallbackService=clamp(66+star*.18+(unit(shopId,timeKey('week')+'service')-.5)*10);
  const fallbackSpeed=clamp(72-Math.max(0,activeMenu-8)*1.4+(orders>0?Math.min(7,customers/Math.max(1,orders)*3):0)+(unit(shopId,timeKey('week')+'speed')-.5)*7);
  const metrics={
    taste:reputationMetric(rep,'taste',clamp(star*.52+dishAvg*.48)),
    service:reputationMetric(rep,'service',fallbackService),
    speed:reputationMetric(rep,'speed',fallbackSpeed),
    value:reputationMetric(rep,'value',clamp(62+Math.max(-8,Math.min(12,profitRate*.22))+dishProfiles.reduce((n,d)=>n+(d.value||0),0)/Math.max(1,dishProfiles.length)*.28)),
    hygiene:reputationMetric(rep,'hygiene',clamp(78+(unit(shopId,timeKey('month')+'hygiene')-.5)*8)),
    atmosphere:reputationMetric(rep,'atmosphere',clamp(68+star*.12+(unit(shopId,timeKey('month')+'atmosphere')-.5)*8)),
    consistency:reputationMetric(rep,'consistency',clamp(dishProfiles.reduce((n,d)=>n+(d.consistency||0),0)/Math.max(1,dishProfiles.length))),
    innovation:reputationMetric(rep,'innovation',clamp(dishProfiles.reduce((n,d)=>n+(d.innovation||0),0)/Math.max(1,dishProfiles.length)+Math.min(10,awardWeight*.15)))
  };
  const computed=computeStoreScore(metrics,reviews);
  return {metrics,reviewCount:reviews,publicStars:round1(computed.score/20),score:computed.score,rawScore:computed.raw,confidence:computed.confidence,dishes:dishProfiles,bestDish,awardWeight};
}

function syncShop(shopId,runtime,context={}){const s=getShopState(shopId);const rating=deriveMetrics(shopId,runtime,context);s.rating=rating;s.lastSyncDay=dayNumber();s.prestige=round1(Math.max(Number(s.prestige)||0,rating.score*.25+(rating.awardWeight||0)));return {shopId,prestige:s.prestige,rating,dishes:rating.dishes,awards:s.awards};}

function categoryScore(snapshot,category){const r=snapshot.rating||snapshot;const m=r.metrics||{};if(category==='reputation')return round1((r.score||0)*.62+(m.taste||0)*.18+(m.service||0)*.12+(m.consistency||0)*.08);if(category==='dish')return round1((r.bestDish&&r.bestDish.score||r.dishes&&r.dishes[0]&&r.dishes[0].score||r.score||0)*.78+(m.innovation||0)*.22);if(category==='value')return round1((m.value||0)*.82+(m.taste||0)*.18);if(category==='speed')return round1((m.speed||0)*.8+(m.consistency||0)*.2);if(category==='innovation')return round1((m.innovation||0)*.72+(r.bestDish&&r.bestDish.innovation||m.innovation||0)*.28);if(category==='momentum'){const base=r.score||0;return round1(clamp(base*.55+(m.innovation||0)*.18+(m.service||0)*.12+(m.speed||0)*.15+(unit(base,timeKey('week'))-.5)*8));}return round1(r.score||0);}

function buildRanking(shopId,runtime,options={}){
  const scope=options.scope==='city'?'city':'district';
  const category=RANK_CATEGORIES.some(x=>x.id===options.category)?options.category:'overall';
  const snap=syncShop(shopId,runtime,options.context||{});
  const playerScore=categoryScore(snap,category);
  const week=timeKey('week');
  const existing=Array.isArray(options.baseRows)?options.baseRows:[];
  const rows=[];
  for(const row of existing){
    if(row&&row.isPlayer)continue;
    const base=clamp(Number(row.score)||65);
    rows.push({id:row.id||row.name,name:row.name||'竞争门店',score:round1(clamp(base+(unit(row.name,week+'|'+category)-.5)*(scope==='city'?8:6))),isPlayer:false});
  }
  const want=scope==='city'?20:12;
  let i=0;
  while(rows.length<want-1&&i<NPC_NAMES.length){
    const name=NPC_NAMES[i++];
    if(rows.some(x=>x.name===name))continue;
    const seed=hash(name+'|'+scope+'|'+category);
    const center=scope==='city'?72:68;
    const spread=scope==='city'?25:22;
    const score=clamp(center+(unit(seed,week)-.46)*spread+(category==='innovation'?(unit(seed,'innov')-.5)*8:0),42,96);
    rows.push({id:'npc:'+hash(name),name,score:round1(score),isPlayer:false});
  }
  rows.push({id:'player:'+shopId,name:(runtime&&runtime.shop&&runtime.shop.name)||'我的门店',score:playerScore,isPlayer:true});
  rows.sort((a,b)=>b.score-a.score);
  const state=getShopState(shopId);
  const previous=state.rankingHistory.find(x=>x.scope===scope&&x.category===category&&x.week!==week)||null;
  rows.forEach((r,idx)=>{
    r.rank=idx+1;
    r.gapToPrev=idx?round1(rows[idx-1].score-r.score):0;
    r.gapToLeader=idx?round1(rows[0].score-r.score):0;
    r.change=r.isPlayer&&previous?previous.rank-r.rank:0;
  });
  const player=rows.find(x=>x.isPlayer);
  player.percentile=round1((1-(player.rank-1)/Math.max(1,rows.length))*100);
  player.gapToTop3=player.rank<=3?0:round1((rows[2]?rows[2].score:player.score)-player.score);
  const current={week,scope,category,rank:player.rank,score:playerScore};
  const sameIndex=state.rankingHistory.findIndex(x=>x.week===week&&x.scope===scope&&x.category===category);
  if(sameIndex>=0)state.rankingHistory[sameIndex]=current;else state.rankingHistory.unshift(current);
  state.rankingHistory=state.rankingHistory.slice(0,40);
  return {scope,category,categoryName:RANK_CATEGORIES.find(x=>x.id===category).name,rows:rows.slice(0,want),player,thresholdTop3:rows[2]?rows[2].score:null,total:rows.length,reviewConfidence:snap.rating.confidence};
}

function periodKey(period){return timeKey(period==='quarter'?'quarter':period==='year'?'year':'month');}
function awardCandidateScore(snapshot,award){return categoryScore(snapshot,award.category);}
function awardPanel(shopId,snapshot,award,key){
  const m=snapshot.rating.metrics||{};
  const dataScore=awardCandidateScore(snapshot,award);
  const credibility=clamp(snapshot.rating.confidence||0);
  const operations=round1((Number(m.consistency||0)*.38)+(Number(m.hygiene||0)*.34)+(Number(m.service||0)*.28));
  const expertBase=award.category==='dish'||award.category==='innovation'
    ? (Number(m.taste||0)*.42+Number(m.innovation||0)*.38+Number(snapshot.rating.bestDish&&snapshot.rating.bestDish.presentation||m.atmosphere||0)*.20)
    : (dataScore*.62+Number(m.service||0)*.20+Number(m.atmosphere||0)*.18);
  const expert=round1(clamp(expertBase+(unit(shopId,key+'|jury')-.5)*6));
  const finalScore=round1(dataScore*.58+credibility*.14+operations*.14+expert*.14);
  return {dataScore:round1(dataScore),credibility:round1(credibility),operations,expert,finalScore};
}
function applyAwardEffects(shopId,runtime,record){
  const state=getShopState(shopId);
  const award=AWARDS.find(x=>x.id===record.awardId);
  if(!award||record.ceremonyHeld)return false;
  record.ceremonyPending=false;
  record.ceremonyHeld=true;
  record.won=true;
  state.awards.won.unshift({...record,prestige:award.prestige});
  state.awards.won=state.awards.won.slice(0,40);
  state.prestige=round1((Number(state.prestige)||0)+award.prestige);
  if(runtime&&runtime.shop)runtime.shop.rating=clamp((Number(runtime.shop.rating)||4)+award.ratingBoost,1,5);
  try{const p=gameState().getPlayer();if(p&&Number.isFinite(Number(p.reputation)))p.reputation=clamp(Number(p.reputation)+Math.max(1,Math.round(award.weight/10)),0,100);}catch(_){}
  getBusinessRoot().awardHistory.unshift({shopId,...record});
  getBusinessRoot().awardHistory=getBusinessRoot().awardHistory.slice(0,120);
  return true;
}
function evaluateAwards(shopId,runtime,options={}){
  const state=getShopState(shopId);
  const snap=syncShop(shopId,runtime,options.context||{});
  const out=[];
  for(const award of AWARDS){
    const pk=periodKey(award.period);
    const key=award.id+'|'+pk;
    if(state.awards.periods[key]){out.push(state.awards.periods[key]);continue;}
    const panel=awardPanel(shopId,snap,award,key);
    const playerScore=panel.finalScore;
    const names=NPC_NAMES.slice(0,award.scope==='城市'?16:10);
    const candidates=names.map((name,i)=>({name,score:round1(clamp(61+unit(name,key)*32+(i%3)*1.1,45,96)),player:false}));
    candidates.push({name:(runtime&&runtime.shop&&runtime.shop.name)||'我的门店',score:playerScore,player:true});
    candidates.sort((a,b)=>b.score-a.score);
    const eligible=snap.rating.reviewCount>=award.minReviews&&panel.dataScore>=award.minScore;
    const shortList=eligible?candidates:candidates.filter(x=>!x.player);
    const nominees=shortList.slice(0,3);
    const selectedWinner=eligible&&nominees[0]&&nominees[0].player;
    const record={awardId:award.id,name:award.name,scope:award.scope,period:award.period,periodKey:pk,category:award.category,playerScore,panel,eligible,nominees,winner:selectedWinner?nominees[0]:shortList[0],selectedWinner:!!selectedWinner,ceremonyPending:!!selectedWinner,ceremonyHeld:false,won:false,weight:award.weight,reason:eligible?(selectedWinner?'已通过资格审查并在本期评审中排名第一，等待颁奖礼确认':'达到提名门槛，但本期评审未获得最高分'):'尚未同时达到评分与评价样本门槛'};
    state.awards.periods[key]=record;
    state.awards.nominations.unshift(record);
    state.awards.nominations=state.awards.nominations.slice(0,30);
    out.push(record);
  }
  return {shopId,awards:out,won:state.awards.won,nominations:state.awards.nominations,pendingCeremonies:state.awards.nominations.filter(x=>x.ceremonyPending&&!x.ceremonyHeld)};
}
function holdAwardCeremony(shopId,runtime){
  const state=getShopState(shopId);
  const pending=state.awards.nominations.filter(x=>x.ceremonyPending&&!x.ceremonyHeld);
  const granted=[];
  for(const record of pending){if(applyAwardEffects(shopId,runtime,record))granted.push(record);}
  return {ok:true,granted,pending:state.awards.nominations.filter(x=>x.ceremonyPending&&!x.ceremonyHeld),won:state.awards.won};
}

function overview(shopId,runtime,context={}){const snap=syncShop(shopId,runtime,context);return {...snap,rankCategories:RANK_CATEGORIES,improvements:IMPROVEMENTS,awardCatalog:AWARDS,rankingHistory:getShopState(shopId).rankingHistory};}

module.exports={VERSION,DISH_WEIGHTS,STORE_WEIGHTS,IMPROVEMENTS,RANK_CATEGORIES,AWARDS,clamp,weighted,computeDishScore,computeStoreScore,ensureDishProfile,improvementPlan,applyImprovement,deriveMetrics,syncShop,categoryScore,buildRanking,evaluateAwards,holdAwardCeremony,overview,getShopState};
