'use strict';

const gameState = require('../core/gameState.js');
const analytics = require('../analytics/businessDataHub.js');
const reputation = require('./reputationMediaSystemV0827.js');
const regulatory = require('../regulatory/regulatoryFoodSafetySystemV0830.js');
const liveWorld = require('../world/liveWorldSystemV084.js');
const ratingSystem = require('../rating/ratingSystemV104.js');

const VERSION = '1.0.5';

const CATEGORY_DEFS = Object.freeze([
  { id: 'overall', name: '综合榜' },
  { id: 'buzz', name: '热度榜' },
  { id: 'reputation', name: '口碑榜' },
  { id: 'revenue', name: '营收榜' },
  { id: 'potential', name: '潜力榜' }
]);

const AWARD_DEFS = Object.freeze([
  { id:'city_top10', name:'城市十强餐厅', tier:'城市', cadence:'year' },
  { id:'city_champion', name:'城市餐饮冠军', tier:'城市', cadence:'year' },
  { id:'popular_store', name:'年度人气餐厅', tier:'行业', cadence:'year' },
  { id:'word_of_mouth', name:'年度口碑餐厅', tier:'行业', cadence:'year' },
  { id:'service_standard', name:'服务标杆餐厅', tier:'行业', cadence:'year' },
  { id:'signature_gold', name:'招牌菜金奖', tier:'菜品', cadence:'year' },
  { id:'food_safety_model', name:'食品安全示范店', tier:'监管', cadence:'year' },
  { id:'rising_star', name:'本月潜力新星', tier:'月度', cadence:'month' },
  { id:'gold_store', name:'金牌店铺', tier:'认证', cadence:'once' },
  { id:'platinum_store', name:'白金金牌店铺', tier:'认证', cadence:'once' },
  { id:'legend_store', name:'传奇餐厅', tier:'传奇', cadence:'once' }
]);

function clone(value) {
  if (value === undefined) return undefined;
  return JSON.parse(JSON.stringify(value));
}

function clamp(value, min, max) {
  const lo = min == null ? 0 : min;
  const hi = max == null ? 100 : max;
  return Math.max(lo, Math.min(hi, Number(value) || 0));
}

function round(value, digits) {
  const n = Number(value) || 0;
  const p = Math.pow(10, digits == null ? 1 : digits);
  return Math.round(n * p) / p;
}

function currentDay() {
  const t = gameState.getTime ? gameState.getTime() : {};
  return Math.max(1,
    (Number(t.year) || 1) * 372 +
    (Math.max(1, Number(t.month) || 1) - 1) * 31 +
    Math.max(1, Number(t.day) || 1)
  );
}

function currentPeriod() {
  const t = gameState.getTime ? gameState.getTime() : {};
  return {
    year: Math.max(1, Number(t.year) || 1),
    month: Math.max(1, Number(t.month) || 1),
    day: Math.max(1, Number(t.day) || 1)
  };
}

function getRoot() {
  const business = gameState.getBusiness();
  business.prestigeV105 = business.prestigeV105 && typeof business.prestigeV105 === 'object'
    ? business.prestigeV105
    : { version: VERSION, shops: {}, awardLedger: [] };

  business.prestigeV105.version = VERSION;
  business.prestigeV105.shops = business.prestigeV105.shops || {};
  business.prestigeV105.awardLedger = Array.isArray(business.prestigeV105.awardLedger)
    ? business.prestigeV105.awardLedger
    : [];
  return business.prestigeV105;
}

function currentShop() {
  const business = gameState.getBusiness();
  const shops = Array.isArray(business.shops) ? business.shops : [];
  if (!shops.length) return null;
  return shops.find(x => x && x.id === business.currentShopId) || shops[0] || null;
}

function ensureShop(shopId) {
  const root = getRoot();
  const id = String(shopId);
  if (!root.shops[id]) {
    root.shops[id] = {
      version: VERSION,
      shopId: id,
      lastProcessedDay: null,
      qualifiedStreakDays: 0,
      history: [],
      awards: [],
      certification: {
        tier: 'none',
        status: 'unqualified',
        reviewPasses: 0,
        reviewFails: 0,
        lastReviewBlock: null,
        firstGoldYear: null,
        goldYears: 0
      }
    };
  }
  const state = root.shops[id];
  state.version = VERSION;
  state.history = Array.isArray(state.history) ? state.history : [];
  state.awards = Array.isArray(state.awards) ? state.awards : [];
  state.certification = state.certification || {};
  return state;
}

function normalizeRating100(rating) {
  const n = Number(rating) || 0;
  if (n <= 5.5) return clamp(n / 5 * 100);
  return clamp(n);
}

function computeDimensionsFromDashboard(dashboard, extras) {
  const d = dashboard || {};
  const rep = extras && extras.reputation || {};
  const reg = extras && extras.regulatory || {};
  const player = extras && extras.player || {};

  // V104 is the single source of truth for the six visible store-rating dimensions.
  // Prestige/ranking consumes that result instead of inventing a second rating model.
  const operatingRating = ratingSystem.evaluateStoreFromDashboard(d);
  const dimMap = {};
  (operatingRating.dimensions || []).forEach(row => {
    if (row && row.key) dimMap[row.key] = clamp(row.score);
  });

  const dishQuality = clamp(dimMap.dishQuality == null ? 65 : dimMap.dishQuality);
  const service = clamp(dimMap.service == null ? 65 : dimMap.service);
  const environment = clamp(dimMap.environment == null ? 65 : dimMap.environment);
  const hygiene = clamp(dimMap.hygiene == null ? 65 : dimMap.hygiene);
  const value = clamp(dimMap.value == null ? 65 : dimMap.value);
  const waiting = clamp(dimMap.waiting == null ? 65 : dimMap.waiting);
  const operating = clamp(operatingRating.score == null ? 65 : operatingRating.score);

  const safety = clamp(reg.complianceScore == null ? hygiene : reg.complianceScore);
  const reviewCount = Math.max(0, Number(rep.reviewCount) || Number(d.store && d.store.reviewCount) || 0);
  const earnedReach = Math.max(0, Number(rep.earnedReach) || 0);
  const rawPlayerRep = clamp(player.reputation == null ? 0 : player.reputation);
  const consumerScore = normalizeRating100(rep.averageStars || operatingRating.consumerStars || 4);
  const reviewScore = clamp(Math.log10(reviewCount + 1) * 28);
  const reachScore = clamp(Math.log10(earnedReach + 1) * 22);
  const brand = clamp(rawPlayerRep * 0.35 + consumerScore * 0.25 + reviewScore * 0.22 + reachScore * 0.18);
  const feature = clamp(dishQuality * 0.38 + environment * 0.18 + value * 0.22 + brand * 0.22);

  // “行业综合分” is a ranking/certification score, not another store rating.
  // 65% comes directly from V104 operating rating; the rest is industry standing.
  const overall = clamp(operating * 0.65 + safety * 0.15 + brand * 0.12 + feature * 0.08);

  return {
    dishQuality: round(dishQuality, 1),
    service: round(service, 1),
    environment: round(environment, 1),
    hygiene: round(hygiene, 1),
    value: round(value, 1),
    waiting: round(waiting, 1),
    operating: round(operating, 1),
    safety: round(safety, 1),
    brand: round(brand, 1),
    feature: round(feature, 1),
    overall: round(overall, 1),
    grade: operatingRating.grade,
    gradeLabel: operatingRating.gradeLabel,
    consumerStars: operatingRating.consumerStars
  };
}

function hash01(text) {
  let h = 2166136261;
  const s = String(text || '');
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 10000) / 10000;
}

function competitorCategoryScore(competitor, category, day) {
  const brandPower = clamp(competitor && competitor.brandPower == null ? 45 : competitor.brandPower);
  const rep = clamp(competitor && competitor.reputation == null ? 45 : competitor.reputation);
  const stores = Array.isArray(competitor && competitor.stores)
    ? competitor.stores.filter(s => s && s.status !== 'closed').length
    : Math.max(1, Number(competitor && competitor.storeCount) || 1);
  const drift = (hash01((competitor && competitor.id) + ':' + category + ':' + Math.floor(day / 7)) - 0.5) * 12;
  if (category === 'buzz') return clamp(brandPower * 0.60 + rep * 0.25 + stores * 3 + drift);
  if (category === 'reputation') return clamp(rep + drift * 0.35);
  if (category === 'revenue') return clamp(brandPower * 0.66 + stores * 6 + rep * 0.16 + drift);
  if (category === 'potential') return clamp(brandPower * 0.42 + (100 - rep) * 0.18 + 34 + drift);
  return clamp(brandPower * 0.42 + rep * 0.34 + Math.min(100, stores * 8) * 0.24 + drift * 0.25);
}

function playerCategoryScore(category, report) {
  const d = report.dashboard || {};
  const dims = report.dimensions || {};
  const rep = report.reputation || {};
  const last7 = d.last7 || {};
  const revenue = Math.max(0, Number(last7.revenue) || Number(d.today && d.today.revenue) || 0);
  if (category === 'buzz') {
    return clamp(dims.brand * 0.40 + dims.feature * 0.25 + Math.log10((Number(rep.earnedReach) || 0) + 1) * 12 + 20);
  }
  if (category === 'reputation') return clamp(normalizeRating100(rep.averageStars || d.today && d.today.rating || 4) * 0.70 + dims.brand * 0.30);
  if (category === 'revenue') return clamp(18 + Math.log10(revenue + 1) * 17);
  if (category === 'potential') {
    const hist = report.state && report.state.history || [];
    const prev = hist.length > 1 ? Number(hist[hist.length - 2].overall) || dims.overall : dims.overall;
    const growth = clamp((dims.overall - prev) * 5 + 50);
    return clamp(dims.overall * 0.42 + dims.feature * 0.28 + growth * 0.30);
  }
  return clamp(dims.overall);
}

function buildRanking(category, scope, context, preparedReport) {
  const cat = CATEGORY_DEFS.some(x => x.id === category) ? category : 'overall';
  const report = preparedReport || buildReport(context, false);
  const day = currentDay();
  const shop = report.shop;
  liveWorld.initialize(day);
  const state = liveWorld.getState();
  let competitors = Array.isArray(state.competitors) ? state.competitors.slice() : [];
  const districtId = shop && shop.districtId;

  if (scope === 'district' && districtId) {
    competitors = competitors.filter(c => (c.stores || []).some(s => s && s.status !== 'closed' && s.districtId === districtId));
  }

  const rows = competitors.map(c => ({
    id: c.id,
    name: c.name || c.brandName || '竞争餐饮品牌',
    type: 'competitor',
    score: round(competitorCategoryScore(c, cat, day), 1),
    storeCount: Array.isArray(c.stores) ? c.stores.filter(s => s && s.status !== 'closed').length : 1
  }));

  rows.push({
    id: 'player',
    name: (gameState.getPlayer().brandName || (shop && shop.name) || '我的品牌'),
    type: 'player',
    score: round(playerCategoryScore(cat, report), 1),
    storeCount: Math.max(1, (gameState.getBusiness().shops || []).filter(s => s && s.status !== 'closed').length)
  });

  rows.sort((a, b) => b.score - a.score || String(a.name).localeCompare(String(b.name), 'zh-CN'));
  const ranked = rows.map((r, i) => ({ rank: i + 1, ...r }));
  const player = ranked.find(r => r.type === 'player') || null;
  return {
    version: VERSION,
    category: cat,
    categoryName: (CATEGORY_DEFS.find(x => x.id === cat) || CATEGORY_DEFS[0]).name,
    scope: scope === 'district' ? 'district' : 'city',
    districtId: scope === 'district' ? districtId : null,
    total: ranked.length,
    playerRank: player ? player.rank : null,
    playerScore: player ? player.score : null,
    top: ranked.slice(0, 12),
    aroundPlayer: player ? ranked.slice(Math.max(0, player.rank - 4), Math.min(ranked.length, player.rank + 3)) : []
  };
}

function awardKey(def, period) {
  if (def.cadence === 'once') return def.id;
  if (def.cadence === 'month') return def.id + ':' + period.year + '-' + period.month;
  return def.id + ':' + period.year;
}

function grantAward(shop, state, def, period, reason) {
  const key = awardKey(def, period);
  if (state.awards.some(a => a.key === key)) return null;
  const row = {
    key,
    id: def.id,
    name: def.name,
    tier: def.tier,
    year: period.year,
    month: period.month,
    day: period.day,
    reason: String(reason || ''),
    shopId: shop.id,
    shopName: shop.name || '门店'
  };
  state.awards.push(row);
  state.awards = state.awards.slice(-120);
  getRoot().awardLedger.push(clone(row));
  getRoot().awardLedger = getRoot().awardLedger.slice(-500);
  return row;
}

function evaluateCertification(shop, state, dimensions, day, period) {
  const qualified = dimensions.overall >= 85 && dimensions.dishQuality >= 85 && dimensions.safety >= 80;
  const alreadyProcessed = Number(state.lastProcessedDay) === Number(day);
  const cert = state.certification || (state.certification = {});

  cert.tier = cert.tier || 'none';
  cert.status = cert.status || 'unqualified';
  cert.reviewPasses = Math.max(0, Number(cert.reviewPasses) || 0);
  cert.reviewFails = Math.max(0, Number(cert.reviewFails) || 0);

  if (!alreadyProcessed) {
    const previousDay = Number(state.lastProcessedDay);
    const delta = Number.isFinite(previousDay)
      ? Math.max(1, Math.min(31, day - previousDay))
      : 1;
    state.qualifiedStreakDays = qualified
      ? Math.max(0, Number(state.qualifiedStreakDays) || 0) + delta
      : 0;
  }

  // First certification is earned after 30 actual qualified operating days.
  // It is deliberately not tied to the next quarterly boundary.
  if (
    cert.status !== 'active' &&
    cert.status !== 'watch' &&
    state.qualifiedStreakDays >= 30 &&
    qualified
  ) {
    cert.status = 'active';
    cert.tier = 'gold';
    cert.reviewFails = 0;
    cert.firstGoldYear = cert.firstGoldYear == null ? period.year : cert.firstGoldYear;
    cert.lastReviewBlock = Math.floor(day / 90);
  }

  if (cert.firstGoldYear != null) {
    cert.goldYears = Math.max(1, period.year - Number(cert.firstGoldYear) + 1);
  } else {
    cert.goldYears = 0;
  }

  // Once certified, only a new 90-day block can add a review pass/fail.
  // Re-entering a page on the same game day cannot advance certification.
  const reviewBlock = Math.floor(day / 90);
  if (
    !alreadyProcessed &&
    (cert.status === 'active' || cert.status === 'watch' || cert.status === 'suspended') &&
    cert.lastReviewBlock != null &&
    reviewBlock > Number(cert.lastReviewBlock)
  ) {
    if (state.qualifiedStreakDays >= 30 && qualified) {
      cert.reviewPasses += 1;
      cert.reviewFails = 0;
      cert.status = 'active';
    } else {
      cert.reviewFails += 1;
      cert.status = cert.reviewFails >= 2 ? 'suspended' : 'watch';
    }
    cert.lastReviewBlock = reviewBlock;
  }

  if (cert.status === 'active') {
    if (cert.goldYears >= 5 && dimensions.overall >= 95 && state.awards.length >= 5) cert.tier = 'legend';
    else if (cert.goldYears >= 3 && cert.reviewPasses >= 12) cert.tier = 'platinum';
    else cert.tier = 'gold';
  }

  cert.progressDays = Math.min(30, Math.max(0, Number(state.qualifiedStreakDays) || 0));
  cert.qualified = qualified;
  return cert;
}

function evaluateAwards(report) {
  const { shop, state, dimensions, certification } = report;
  if (!shop) return [];
  const period = currentPeriod();
  const cityOverall = buildRanking('overall', 'city', report.context, report);
  const cityBuzz = buildRanking('buzz', 'city', report.context, report);
  const cityPotential = buildRanking('potential', 'city', report.context, report);
  const reg = report.regulatory || {};
  const metrics = reg.metrics || {};
  const newAwards = [];
  const add = (id, reason) => {
    const def = AWARD_DEFS.find(x => x.id === id);
    if (!def) return;
    const row = grantAward(shop, state, def, period, reason);
    if (row) newAwards.push(row);
  };

  if (cityOverall.playerRank != null && cityOverall.playerRank <= 10) add('city_top10', '城市综合榜第' + cityOverall.playerRank + '名');
  if (cityOverall.playerRank === 1) add('city_champion', '城市综合榜第1名');
  if (cityBuzz.playerRank != null && cityBuzz.playerRank <= 10 && cityBuzz.playerScore >= 78) add('popular_store', '城市热度榜前10');
  if (dimensions.brand >= 85 && dimensions.dishQuality >= 85) add('word_of_mouth', '品牌口碑与菜品质量达到优秀标准');
  if (dimensions.service >= 90) add('service_standard', '服务体验达到90分');
  if (dimensions.dishQuality >= 92 && dimensions.value >= 82) add('signature_gold', '菜品质量与顾客价值达到金奖线');
  if (dimensions.safety >= 95 && Number(metrics.inspections || 0) >= 3 && (!reg.openViolations || !reg.openViolations.length)) add('food_safety_model', '食品安全与监管记录优秀');
  if (cityPotential.playerRank != null && cityPotential.playerRank <= 10 && cityPotential.playerScore >= 78) add('rising_star', '潜力榜前10');
  if (certification.tier === 'gold') add('gold_store', '连续达标并通过季度评审');
  if (certification.tier === 'platinum') add('platinum_store', '连续3年金牌认证');
  if (certification.tier === 'legend') add('legend_store', '长期高分、稳定认证并获得多项行业荣誉');
  return newAwards;
}

function certificationLabel(cert) {
  if (!cert) return '未评级';
  if (cert.status === 'suspended') return '金牌认证暂停';
  if (cert.status === 'watch') return '金牌观察期';
  if (cert.tier === 'legend' && cert.status === 'active') return '传奇餐厅';
  if (cert.tier === 'platinum' && cert.status === 'active') return '白金金牌店';
  if (cert.tier === 'gold' && cert.status === 'active') return '金牌店铺';
  if (cert.qualified) return '金牌候选';
  return '普通门店';
}

function buildReport(context, persist) {
  const ctx = context || {};
  analytics.syncFromGame(ctx);
  const dashboard = analytics.getDashboard(ctx);
  const dashboardStore = dashboard.store && dashboard.store.id ? dashboard.store : null;
  const shop = dashboardStore || currentShop();
  if (!shop || !shop.id) {
    return {
      version: VERSION,
      context: ctx,
      shop: null,
      dashboard,
      dimensions: { dishQuality:0, service:0, environment:0, hygiene:0, value:0, waiting:0, operating:0, safety:0, brand:0, feature:0, overall:0, grade:'D', gradeLabel:'待改进', consumerStars:0 },
      certification: { tier:'none', status:'unqualified', progressDays:0, qualified:false },
      awards: [],
      recentAwards: [],
      cityRank: null,
      districtRank: null
    };
  }

  const rep = reputation.overview(shop.id, shop);
  const reg = regulatory.overview(shop.id);
  const player = gameState.getPlayer();
  const dimensions = computeDimensionsFromDashboard(dashboard, { reputation: rep, regulatory: reg, player });
  const persistedState = ensureShop(shop.id);
  const state = persist === false ? clone(persistedState) : persistedState;
  const day = currentDay();
  const period = currentPeriod();
  const certification = evaluateCertification(shop, state, dimensions, day, period);

  const report = {
    version: VERSION,
    context: ctx,
    shop,
    dashboard,
    reputation: rep,
    regulatory: reg,
    dimensions,
    state,
    certification,
    awards: state.awards,
    recentAwards: state.awards.slice(-5).reverse(),
    newAwards: []
  };

  if (persist !== false && state.lastProcessedDay !== day) {
    state.history.push({ day, ...dimensions });
    state.history = state.history.slice(-90);
    state.lastProcessedDay = day;
  }

  report.cityRank = buildRanking('overall', 'city', ctx, report);
  report.districtRank = buildRanking('overall', 'district', ctx, report);
  report.newAwards = persist === false ? [] : evaluateAwards(report);
  report.certificationLabel = certificationLabel(certification);
  report.nextTarget = certification.status === 'active'
    ? (certification.tier === 'gold' ? '保持季度评审通过，累计3年可升级白金' : certification.tier === 'platinum' ? '保持95+综合分并积累5项以上荣誉，冲击传奇' : '维持行业顶级表现')
    : ('金牌要求：行业综合85+、菜品85+、食安80+，连续30天；当前 ' + Math.min(30, state.qualifiedStreakDays) + '/30天');
  return report;
}

function sync(context) {
  return buildReport(context, true);
}

function overview(context) {
  return buildReport(context, true);
}

module.exports = {
  VERSION,
  CATEGORY_DEFS,
  AWARD_DEFS,
  getRoot,
  ensureShop,
  computeDimensionsFromDashboard,
  buildRanking,
  sync,
  overview,
  certificationLabel
};
