'use strict';

const gameState = require('../core/gameState.js');
const timeSystem = require('../core/timeSystem.js');
const demandSystem = require('../city/demandSystem.js');
const { BusinessOperatingSystemV106, SCHEMA_VERSION } = require('./businessOperatingSystemV106.js');

const runtime = globalThis.GameRuntime || {};
const api = runtime.api || {};

function storageGet(key) {
  try {
    if (typeof api.getStorageSync === 'function') {
      const value = api.getStorageSync(key);
      if (value != null) return value;
      if (key === 'cityRestaurant.operating.v106') return api.getStorageSync('cityRestaurant.operating.v105');
      return null;
    }
    if (globalThis.localStorage) {
      let raw = globalThis.localStorage.getItem(key);
      if (raw == null && key === 'cityRestaurant.operating.v106') raw = globalThis.localStorage.getItem('cityRestaurant.operating.v105');
      if (raw == null) return null;
      try { return JSON.parse(raw); } catch (error) { return raw; }
    }
  } catch (error) {}
  return null;
}

function storageSet(key, value) {
  try {
    if (typeof api.setStorageSync === 'function') return api.setStorageSync(key, value);
    if (globalThis.localStorage) return globalThis.localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {}
}

function ordinal(time) {
  time = time || {};
  const y = Math.max(1, Math.floor(Number(time.year) || 1));
  const m = Math.max(1, Math.min(12, Math.floor(Number(time.month) || 1)));
  const d = Math.max(1, Math.floor(Number(time.day) || 1));
  const y0 = y - 1;
  let days = y0 * 365 + Math.floor(y0 / 4) - Math.floor(y0 / 100) + Math.floor(y0 / 400);
  const leap = y % 400 === 0 || (y % 4 === 0 && y % 100 !== 0);
  const monthDays = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  for (let i = 0; i < m - 1; i++) days += monthDays[i];
  return days + d;
}

function findStore(player, world) {
  const candidates = [
    player && player.store,
    player && player.restaurant,
    world && world.store,
    world && world.restaurant,
    globalThis.Game && globalThis.Game.state && globalThis.Game.state.store,
    globalThis.cityRestaurantState && globalThis.cityRestaurantState.store
  ];
  return candidates.find(value => value && typeof value === 'object') || null;
}

function latestDaily(store) {
  if (!store) return null;
  const history = Array.isArray(store.dailyHistory) ? store.dailyHistory : [];
  if (!history.length) return null;
  const x = history[history.length - 1] || {};
  return {
    revenue: Number(x.revenue || x.sales || 0),
    orders: Number(x.orders || x.completedOrders || 0),
    avgTicket: Number(x.avgTicket || x.averageTicket || 0),
    foodCost: Number(x.foodCost || x.ingredientCost || x.cost || 0),
    laborCost: Number(x.laborCost || 0),
    rentCost: Number(x.rentCost || 0),
    utilityCost: Number(x.utilityCost || 0),
    marketingCost: Number(x.marketingCost || 0),
    wasteCost: Number(x.wasteCost || 0),
    maintenanceCost: Number(x.maintenanceCost || 0),
    operatingProfit: Number(x.operatingProfit != null ? x.operatingProfit : x.profit || 0),
    sourceCompleteness: 'legacy-history'
  };
}

function storeDishes(store) {
  if (!store) return [];
  if (Array.isArray(store.dishes)) return store.dishes;
  if (Array.isArray(store.menu)) {
    return store.menu.filter(item => item && typeof item === 'object');
  }
  return [];
}

function buildSnapshot() {
  const player = typeof gameState.getPlayer === 'function' ? (gameState.getPlayer() || {}) : {};
  const world = typeof gameState.getWorld === 'function' ? (gameState.getWorld() || {}) : {};
  const time = typeof gameState.getTime === 'function' ? (gameState.getTime() || {}) : {};
  const store = findStore(player, world);
  const dayOrdinal = ordinal(time);
  const dayKey = [time.year || 1, time.month || 1, time.day || 1].join('-');
  const monthKey = [time.year || 1, time.month || 1].join('-');
  const daily = latestDaily(store) || {};

  let operatingDays = 0;
  if (store) {
    if (Array.isArray(store.dailyHistory)) operatingDays = store.dailyHistory.length;
    else operatingDays = Number(store.operatingDays || store.daysOpen || 1);
  }

  const ratingParts = store && store.ratingParts ? store.ratingParts : null;
  const ranking = store && store.ranking ? store.ranking : null;
  const funnel = store && (store.funnel || store.todayFunnel) ? (store.funnel || store.todayFunnel) : null;

  return {
    time,
    dayKey,
    monthKey,
    dayOrdinal,
    districtId: world.currentDistrictId || (store && store.districtId) || (store && store.district) || null,
    cash: Number(player.cash || 0),
    reputation: Number(player.reputation || 0),
    hasStore: !!store,
    storeOpen: store ? store.open !== false : false,
    operatingDays,
    safeCashLine: store ? Math.max(10000, Number(store.rent || 0) * 2.5) : 10000,
    daily,
    dishes: storeDishes(store),
    ratingParts,
    ranking,
    funnel,
    store
  };
}

let pauseContext = null;
let forcedOverlay = null;
let centerOverlay = null;
let installed = false;
let lastRenderedActiveId = null;
let floatingButton = null;

function isPaused() {
  try { return typeof timeSystem.isPaused === 'function' ? !!timeSystem.isPaused() : false; } catch (error) { return false; }
}

function pauseTimeForForcedEvent() {
  if (!pauseContext) {
    pauseContext = {
      wasPaused: isPaused(),
      speed: typeof timeSystem.getSpeed === 'function' ? timeSystem.getSpeed() : 1
    };
  }
  try {
    if (!isPaused() && typeof timeSystem.pause === 'function') timeSystem.pause();
    else if (!isPaused() && typeof timeSystem.togglePause === 'function') timeSystem.togglePause();
    if (typeof timeSystem.resetAccumulator === 'function') timeSystem.resetAccumulator();
  } catch (error) {}
}

function restoreTimeAfterForcedEvent() {
  if (!pauseContext) return;
  const ctx = pauseContext;
  pauseContext = null;
  try {
    if (typeof timeSystem.setSpeed === 'function' && Number(ctx.speed) > 0) timeSystem.setSpeed(ctx.speed);
    if (!ctx.wasPaused && isPaused()) {
      if (typeof timeSystem.resume === 'function') timeSystem.resume();
      else if (typeof timeSystem.togglePause === 'function') timeSystem.togglePause();
    }
    if (typeof timeSystem.resetAccumulator === 'function') timeSystem.resetAccumulator();
  } catch (error) {}
}

function mutatePlayerField(field, delta) {
  const player = typeof gameState.getPlayer === 'function' ? gameState.getPlayer() : null;
  if (!player || typeof player !== 'object') return false;
  if (!Number.isFinite(Number(player[field]))) player[field] = 0;
  player[field] = Number(player[field]) + Number(delta || 0);
  if (field === 'cash') player[field] = Math.round(player[field] * 100) / 100;
  else player[field] = Math.max(0, Math.min(100, player[field]));
  return true;
}

const system = new BusinessOperatingSystemV106({
  seed: 20260916,
  storage: { get: storageGet, set: storageSet },
  adapter: {
    mutateCash(delta) { return mutatePlayerField('cash', delta); },
    mutateReputation(delta) { return mutatePlayerField('reputation', delta); },
    onForcedEvent() {
      pauseTimeForForcedEvent();
      renderForcedOverlay();
    }
  }
});

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function money(value) {
  return '¥' + Math.round(Number(value) || 0).toLocaleString('zh-CN');
}

function ensureStyles() {
  if (typeof document === 'undefined' || document.getElementById('restaurantOperatingV106Style')) return;
  const style = document.createElement('style');
  style.id = 'restaurantOperatingV106Style';
  style.textContent = `
    .cr105-mask{position:fixed;inset:0;z-index:20000;background:rgba(4,18,28,.72);display:flex;align-items:center;justify-content:center;padding:16px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;color:#1d2b33}
    .cr105-panel{width:min(720px,100%);max-height:88vh;overflow:auto;background:#f8f3e8;border:1px solid rgba(255,255,255,.35);border-radius:18px;box-shadow:0 24px 80px rgba(0,0,0,.38)}
    .cr105-head{position:sticky;top:0;z-index:2;background:#12394f;color:#fff;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;gap:10px;border-radius:18px 18px 0 0}
    .cr105-head b{font-size:17px}.cr105-close{border:0;background:rgba(255,255,255,.13);color:#fff;border-radius:8px;padding:7px 10px}
    .cr105-body{padding:14px}.cr105-alert{background:#fff;border:1px solid #e2d7c4;border-radius:12px;padding:12px;margin-bottom:10px}.cr105-alert.forced{border-left:5px solid #d65442}.cr105-alert.important{border-left:5px solid #e5a72d}.cr105-alert.normal{border-left:5px solid #4d9e71}
    .cr105-title{font-weight:800;font-size:16px;margin-bottom:6px}.cr105-muted{font-size:12px;color:#6e7980;line-height:1.55}.cr105-choice{display:block;width:100%;text-align:left;border:1px solid #d7cbb8;background:#fff;border-radius:11px;padding:11px 12px;margin-top:9px;color:#22323b}.cr105-choice:active{transform:scale(.995);background:#fff7df}.cr105-choice b{display:block;margin-bottom:3px}.cr105-tabs{display:flex;gap:6px;overflow:auto;padding:0 0 10px}.cr105-tab{white-space:nowrap;border:1px solid #d8cfbf;background:#fff;border-radius:999px;padding:7px 10px}.cr105-tab.active{background:#163f59;color:#fff;border-color:#163f59}.cr105-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}.cr105-kpi{background:#fff;border:1px solid #e1d7c6;border-radius:11px;padding:10px}.cr105-kpi span{display:block;font-size:11px;color:#788187}.cr105-kpi b{display:block;font-size:19px;margin-top:3px}.cr105-btn{border:0;border-radius:9px;background:#163f59;color:#fff;padding:9px 11px;margin:5px 5px 0 0}.cr105-btn.gold{background:#e2aa3b;color:#1d2529}.cr105-ledger{width:100%;border-collapse:collapse;font-size:12px}.cr105-ledger td,.cr105-ledger th{padding:7px;border-bottom:1px solid #e6ddce;text-align:right}.cr105-ledger td:first-child,.cr105-ledger th:first-child{text-align:left}.cr105-dot{display:inline-block;min-width:20px;padding:2px 6px;border-radius:999px;background:#d84e3e;color:#fff;font-size:11px;text-align:center}.cr105-good{color:#248052}.cr105-bad{color:#b7463d}
    @media(max-width:520px){.cr105-mask{padding:8px;align-items:flex-end}.cr105-panel{max-height:92vh;border-radius:16px 16px 0 0}.cr105-head{border-radius:16px 16px 0 0}.cr105-grid{grid-template-columns:1fr 1fr}.cr105-body{padding:11px}}
  `;
  document.head.appendChild(style);
}


function updateFloatingButton() {
  if (!floatingButton) return;
  const state = system.getState();
  const unread = system.getUnreadCount();
  const forced = !!state.events.active;
  floatingButton.textContent = forced ? '!' : unread > 0 ? String(Math.min(99, unread)) : '营';
  floatingButton.setAttribute('aria-label', forced ? '必须处理的经营事件' : '打开经营中枢');
  floatingButton.style.background = forced ? '#cf4938' : unread > 0 ? '#e0a52f' : '#153e57';
}

function installFloatingButton() {
  if (typeof document === 'undefined' || floatingButton || document.getElementById('restaurantOperatingV106Button')) return;
  ensureStyles();
  const button = document.createElement('button');
  button.id = 'restaurantOperatingV106Button';
  button.type = 'button';
  button.textContent = '营';
  button.style.position = 'fixed';
  button.style.right = '10px';
  button.style.bottom = '78px';
  button.style.zIndex = '16000';
  button.style.width = '46px';
  button.style.height = '46px';
  button.style.borderRadius = '23px';
  button.style.border = '1px solid rgba(255,255,255,.5)';
  button.style.boxShadow = '0 6px 18px rgba(0,0,0,.28)';
  button.style.color = '#fff';
  button.style.fontWeight = '800';
  button.style.fontSize = '16px';
  button.style.lineHeight = '1';
  button.style.padding = '0';
  button.style.touchAction = 'manipulation';
  button.addEventListener('click', function (event) {
    if (event && typeof event.stopPropagation === 'function') event.stopPropagation();
    const active = system.getState().events.active;
    if (active) renderForcedOverlay();
    else openControlCenter('events');
  });
  document.body.appendChild(button);
  floatingButton = button;
  updateFloatingButton();
}

function installDemandHook() {
  if (!demandSystem || demandSystem.__operatingV106Wrapped) return true;
  if (typeof demandSystem.getTotalDemand !== 'function') {
    throw new Error('[V1.0.6] demandSystem.getTotalDemand 不存在，无法接入事件需求倍率');
  }
  const base = demandSystem.getTotalDemand.bind(demandSystem);
  demandSystem.getTotalDemand = function operatingV106GetTotalDemand(districtId) {
    const raw = Number(base(districtId)) || 0;
    const multiplier = system.getDemandMultiplier(districtId);
    return Math.max(0, Math.floor(raw * multiplier));
  };
  demandSystem.__operatingV106Wrapped = true;
  return true;
}

function removeOverlay(node) {
  if (node && node.parentNode) node.parentNode.removeChild(node);
}

function renderForcedOverlay() {
  if (typeof document === 'undefined') return;
  const active = system.getState().events.active;
  if (!active) {
    removeOverlay(forcedOverlay);
    forcedOverlay = null;
    lastRenderedActiveId = null;
    return;
  }
  if (forcedOverlay && lastRenderedActiveId === active.instanceId) return;
  ensureStyles();
  removeOverlay(forcedOverlay);
  forcedOverlay = document.createElement('div');
  forcedOverlay.className = 'cr105-mask';
  forcedOverlay.innerHTML = `
    <div class="cr105-panel" role="dialog" aria-modal="true">
      <div class="cr105-head"><div><b>必须处理 · ${escapeHtml(active.title)}</b><div style="font-size:11px;opacity:.78">经营时间已自动暂停</div></div></div>
      <div class="cr105-body">
        <div class="cr105-alert forced"><div class="cr105-title">${escapeHtml(active.title)}</div><div>${escapeHtml(active.text)}</div><div class="cr105-muted" style="margin-top:6px">该事件必须选择处理方案后才能继续推进时间。</div></div>
        <div id="cr105Choices"></div>
      </div>
    </div>`;
  const box = forcedOverlay.querySelector('#cr105Choices');
  (active.choices || []).forEach(choice => {
    const button = document.createElement('button');
    button.className = 'cr105-choice';
    button.innerHTML = '<b>' + escapeHtml(choice.label) + '</b><span class="cr105-muted">' + escapeHtml(choice.hint || '选择后立即结算影响') + '</span>';
    button.addEventListener('click', () => {
      const beforeId = active.instanceId;
      const result = system.resolveForcedEvent(choice.id, buildSnapshot());
      if (!result.ok) return;
      const next = system.getState().events.active;
      removeOverlay(forcedOverlay);
      forcedOverlay = null;
      lastRenderedActiveId = null;
      if (next) {
        pauseTimeForForcedEvent();
        renderForcedOverlay();
      } else {
        restoreTimeAfterForcedEvent();
      }
      openBriefToast('事件已处理：' + choice.label);
      if (beforeId) system.persist();
      updateFloatingButton();
    });
    box.appendChild(button);
  });
  document.body.appendChild(forcedOverlay);
  lastRenderedActiveId = active.instanceId;
}

function openBriefToast(text) {
  try {
    if (typeof api.showToast === 'function') api.showToast({ title: text, icon: 'none' });
  } catch (error) {}
}

function eventListHtml() {
  const s = system.getState();
  const active = s.events.active;
  const history = s.events.history.slice(-20).reverse();
  return `
    ${active ? `<div class="cr105-alert forced"><div class="cr105-title">待处理：${escapeHtml(active.title)}</div><div>${escapeHtml(active.text)}</div><div class="cr105-muted">已暂停经营时间，请先处理强制事件。</div></div>` : '<div class="cr105-alert normal"><b>当前没有必须处理的事件</b><div class="cr105-muted">普通/重要事件会进入消息记录，强制事件出现时自动暂停。</div></div>'}
    <div class="cr105-title">最近事件</div>
    ${history.length ? history.map(item => `<div class="cr105-alert ${escapeHtml(item.level || 'normal')}"><b>${escapeHtml(item.title)}</b><div class="cr105-muted">${escapeHtml(item.triggeredDayKey || '')} · ${item.choiceLabel ? '处理：' + escapeHtml(item.choiceLabel) : '自动生效'}</div></div>`).join('') : '<div class="cr105-muted">尚无事件记录。</div>'}
  `;
}

function messagesHtml() {
  const items = system.getState().notifications.items.slice(-40).reverse();
  system.markNotificationsRead();
  updateFloatingButton();
  return items.length ? items.map(item => `<div class="cr105-alert ${item.level === 'forced' ? 'forced' : item.level === 'important' ? 'important' : 'normal'}"><b>${escapeHtml(item.title)}</b><div>${escapeHtml(item.text)}</div><div class="cr105-muted">${escapeHtml(item.dayKey || '')}</div></div>`).join('') : '<div class="cr105-muted">暂无消息。</div>';
}

function financeHtml() {
  const snap = buildSnapshot();
  const d = system.getDashboard(snap);
  const loans = system.getState().finance.loans.filter(x => x.status === 'active' || x.status === 'overdue');
  const ledger = system.getState().finance.ledger.slice(-15).reverse();
  return `
    <div class="cr105-grid">
      <div class="cr105-kpi"><span>当前现金</span><b>${money(d.finance.cash)}</b></div>
      <div class="cr105-kpi"><span>可用授信</span><b>${money(d.finance.availableCredit)}</b></div>
      <div class="cr105-kpi"><span>信用评分</span><b>${Math.round(d.finance.creditScore)}</b></div>
      <div class="cr105-kpi"><span>贷款余额</span><b>${money(d.finance.outstanding)}</b></div>
    </div>
    <div style="margin:10px 0"><button class="cr105-btn gold" data-cr105-loan="10000">申请 ¥10,000</button><button class="cr105-btn gold" data-cr105-loan="20000">申请 ¥20,000</button></div>
    <div class="cr105-title">贷款</div>
    ${loans.length ? loans.map(x => `<div class="cr105-alert normal"><b>${escapeHtml(x.note)} · ${money(x.outstanding + x.accruedInterest)}</b><div class="cr105-muted">年化 ${(x.apr * 100).toFixed(1)}% · 已运行 ${x.daysElapsed} 天 · ${escapeHtml(x.status)}</div><button class="cr105-btn" data-cr105-repay="${escapeHtml(x.id)}">偿还 ¥5,000</button></div>`).join('') : '<div class="cr105-muted">当前无未结贷款。</div>'}
    <div class="cr105-title" style="margin-top:12px">最近资金流水</div>
    <table class="cr105-ledger"><tr><th>事项</th><th>金额</th></tr>${ledger.map(x => `<tr><td>${escapeHtml(x.note || x.type)}</td><td class="${x.amount >= 0 ? 'cr105-good' : 'cr105-bad'}">${x.amount >= 0 ? '+' : ''}${money(x.amount)}</td></tr>`).join('')}</table>`;
}

function settlementHtml() {
  const s = system.getState();
  const d = system.getDashboard(buildSnapshot());
  const daily = s.settlements.daily.slice(-10).reverse();
  return `
    <div class="cr105-grid">
      <div class="cr105-kpi"><span>近7日营业额</span><b>${money(d.last7.revenue)}</b></div>
      <div class="cr105-kpi"><span>近7日经营利润</span><b>${money(d.last7.operatingProfit)}</b></div>
      <div class="cr105-kpi"><span>近7日订单</span><b>${d.last7.orders}</b></div>
      <div class="cr105-kpi"><span>综合评分</span><b>${s.ratings.overall.toFixed(2)}</b></div>
    </div>
    <div class="cr105-title" style="margin-top:12px">日结算</div>
    <table class="cr105-ledger"><tr><th>日期</th><th>订单</th><th>营收</th><th>利润</th></tr>${daily.map(x => `<tr><td>${escapeHtml(x.dayKey)}</td><td>${Math.round(x.orders)}</td><td>${money(x.revenue)}</td><td>${money(x.operatingProfit)}</td></tr>`).join('')}</table>
    <div class="cr105-muted" style="margin-top:8px">旧存档缺少的指标不会伪造；数据源不完整时记录为 minimal/partial。</div>`;
}

function operationsHtml() {
  const s = system.getState();
  const tasks = s.guide.tasks;
  return `
    <div class="cr105-grid">
      <div class="cr105-kpi"><span>员工士气</span><b>${Math.round(s.staff.morale)}</b></div>
      <div class="cr105-kpi"><span>离职风险</span><b>${Math.round(s.staff.turnoverRisk)}%</b></div>
      <div class="cr105-kpi"><span>门店评分</span><b>${s.ratings.overall.toFixed(2)}</b></div>
      <div class="cr105-kpi"><span>食品安全</span><b>${Math.round(s.ratings.safety)}</b></div>
      <div class="cr105-kpi"><span>奖项提名</span><b>${s.awards.nominations.length}</b></div>
      <div class="cr105-kpi"><span>已获奖项</span><b>${s.awards.wins.length}</b></div>
    </div>
    <div class="cr105-title" style="margin-top:12px">经营闭环检查</div>
    ${tasks.map(t => `<div class="cr105-alert ${t.done ? 'normal' : 'important'}"><b>${t.done ? '✓ ' : '○ '}${escapeHtml(t.title)}</b></div>`).join('')}
    <div class="cr105-muted">菜品研发/改良、员工、评分、排行、奖项、漏斗数据均通过统一经营中枢提供接口；已有旧系统数据会自动导入，不重复造第二套账。</div>`;
}

function renderCenterTab(tab) {
  if (!centerOverlay) return;
  centerOverlay.querySelectorAll('.cr105-tab').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tab));
  const content = centerOverlay.querySelector('#cr105CenterContent');
  if (!content) return;
  if (tab === 'messages') content.innerHTML = messagesHtml();
  else if (tab === 'finance') content.innerHTML = financeHtml();
  else if (tab === 'settlement') content.innerHTML = settlementHtml();
  else if (tab === 'operations') content.innerHTML = operationsHtml();
  else content.innerHTML = eventListHtml();
  bindCenterActions();
}

function bindCenterActions() {
  if (!centerOverlay) return;
  centerOverlay.querySelectorAll('[data-cr105-loan]').forEach(btn => {
    btn.onclick = () => {
      const snap = buildSnapshot();
      const result = system.requestLoan(Number(btn.dataset.cr105Loan), 90, 0.12, snap, '经营周转贷');
      openBriefToast(result.ok ? '贷款已放款' : result.reason);
      renderCenterTab('finance');
    };
  });
  centerOverlay.querySelectorAll('[data-cr105-repay]').forEach(btn => {
    btn.onclick = () => {
      const snap = buildSnapshot();
      const loan = system.getState().finance.loans.find(x => x.id === btn.dataset.cr105Repay);
      const amount = loan ? Math.min(5000, loan.outstanding + loan.accruedInterest) : 0;
      const result = system.repayLoan(btn.dataset.cr105Repay, amount, snap);
      openBriefToast(result.ok ? '还款完成' : result.reason);
      renderCenterTab('finance');
    };
  });
}

function openControlCenter(initialTab) {
  if (typeof document === 'undefined') return false;
  ensureStyles();
  removeOverlay(centerOverlay);
  centerOverlay = document.createElement('div');
  centerOverlay.className = 'cr105-mask';
  const unread = system.getUnreadCount();
  centerOverlay.innerHTML = `
    <div class="cr105-panel">
      <div class="cr105-head"><div><b>经营中枢 V${SCHEMA_VERSION}</b><div style="font-size:11px;opacity:.78">事件 · 消息 · 金融 · 结算 · 经营健康</div></div><button class="cr105-close" id="cr105Close">关闭</button></div>
      <div class="cr105-body">
        <div class="cr105-tabs">
          <button class="cr105-tab" data-tab="events">事件</button>
          <button class="cr105-tab" data-tab="messages">消息${unread ? ' <span class="cr105-dot">' + unread + '</span>' : ''}</button>
          <button class="cr105-tab" data-tab="finance">金融</button>
          <button class="cr105-tab" data-tab="settlement">结算</button>
          <button class="cr105-tab" data-tab="operations">经营健康</button>
        </div>
        <div id="cr105CenterContent"></div>
      </div>
    </div>`;
  document.body.appendChild(centerOverlay);
  centerOverlay.querySelector('#cr105Close').onclick = () => { removeOverlay(centerOverlay); centerOverlay = null; };
  centerOverlay.addEventListener('click', event => { if (event.target === centerOverlay) { removeOverlay(centerOverlay); centerOverlay = null; } });
  centerOverlay.querySelectorAll('.cr105-tab').forEach(btn => { btn.onclick = () => renderCenterTab(btn.dataset.tab); });
  renderCenterTab(initialTab || 'events');
  return true;
}

function installTimeHook() {
  if (timeSystem.__operatingV106Wrapped) return;
  if (typeof timeSystem.update !== 'function') throw new Error('[V1.0.6] timeSystem.update 不存在，无法安装经营中枢');
  const originalUpdate = timeSystem.update.bind(timeSystem);
  timeSystem.update = function operatingV106Update(deltaMs) {
    if (system.getState().events.active) {
      pauseTimeForForcedEvent();
      renderForcedOverlay();
      return 0;
    }
    const advancedMinutes = originalUpdate(deltaMs);
    if (advancedMinutes > 0) {
      system.onTimeAdvanced(advancedMinutes, buildSnapshot());
      updateFloatingButton();
      if (system.getState().events.active) {
        pauseTimeForForcedEvent();
        renderForcedOverlay();
      }
    }
    return advancedMinutes;
  };
  timeSystem.__operatingV106Wrapped = true;
}

function install() {
  if (installed) return true;
  installDemandHook();
  installTimeHook();
  installFloatingButton();
  system.importSnapshot(buildSnapshot());
  system.persist();
  if (system.getState().events.active) {
    pauseTimeForForcedEvent();
    setTimeout(renderForcedOverlay, 0);
  }
  updateFloatingButton();
  installed = true;
  return true;
}

function openEventCenter() { return openControlCenter('events'); }
function openMessageCenter() { return openControlCenter('messages'); }
function getDemandMultiplier(districtId) { return system.getDemandMultiplier(districtId); }
function getSupplyPriceMultiplier() { return system.getSupplyPriceMultiplier(); }
function recordFunnel(metrics) { const value = system.recordFunnel(metrics, buildSnapshot()); system.persist(); return value; }
function recordDish(dish) { const value = system.recordDish(dish, buildSnapshot()); system.persist(); return value; }
function improveDish(id, dimension, spend) { return system.improveDish(id, dimension, spend, buildSnapshot()); }
function recordRating(parts) { return system.recordRating(parts, buildSnapshot()); }
function recordRanking(value) { return system.recordRanking(value, buildSnapshot()); }
function triggerEventForTest(id) { return system.triggerEvent(id, buildSnapshot(), 'manual'); }

const publicApi = {
  version: SCHEMA_VERSION,
  install,
  system,
  buildSnapshot,
  openEventCenter,
  openMessageCenter,
  openControlCenter,
  installDemandHook,
  getDemandMultiplier,
  getSupplyPriceMultiplier,
  recordFunnel,
  recordDish,
  improveDish,
  recordRating,
  recordRanking,
  triggerEventForTest
};

globalThis.RestaurantOperatingV106 = publicApi;
install();

module.exports = publicApi;
