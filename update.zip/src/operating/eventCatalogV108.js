'use strict';

/**
 * 餐饮经营事件库 V1.0.8
 * level: normal | important | forced
 * cooldownDays: 同类事件冷却天数
 * effects/choices.effects 统一由 businessOperatingSystemV108 解释。
 */

const EVENT_CATALOG = [
  {
    id: 'university_opening_week',
    title: '大学开学周',
    level: 'important',
    weight: 8,
    cooldownDays: 45,
    condition: 'store_open',
    district: 'university',
    text: '学生返校，快餐、饮品和夜宵需求明显上升。',
    autoEffects: { demandMul: 1.18, durationDays: 4, reputation: 1 }
  },
  {
    id: 'heavy_rain',
    title: '连续强降雨',
    level: 'important',
    weight: 9,
    cooldownDays: 20,
    condition: 'store_open',
    district: null,
    text: '步行客流下降，生鲜运输和配送成本上升。',
    autoEffects: { demandMul: 0.86, supplyPriceMul: 1.08, durationDays: 2 }
  },
  {
    id: 'hightech_influx',
    title: '高新区企业集中入驻',
    level: 'normal',
    weight: 5,
    cooldownDays: 60,
    condition: 'store_open',
    district: 'hightech',
    text: '新增办公人口带动午间餐饮需求。',
    autoEffects: { demandMul: 1.15, durationDays: 5 }
  },
  {
    id: 'festival_traffic',
    title: '商圈节庆活动',
    level: 'normal',
    weight: 8,
    cooldownDays: 18,
    condition: 'store_open',
    district: 'current',
    text: '商圈活动吸引额外客流，晚餐时段热度上升。',
    autoEffects: { demandMul: 1.12, durationDays: 1, reputation: 1 }
  },
  {
    id: 'competitor_discount',
    title: '附近竞争店大促',
    level: 'normal',
    weight: 10,
    cooldownDays: 10,
    condition: 'store_open',
    district: 'current',
    text: '同商圈竞争店推出限时低价套餐，本店自然转化受到挤压。',
    autoEffects: { demandMul: 0.93, durationDays: 2 }
  },
  {
    id: 'influencer_visit',
    title: '本地探店博主到店',
    level: 'important',
    weight: 5,
    cooldownDays: 35,
    condition: 'rating_ok',
    district: 'current',
    text: '一名本地探店博主随机到店，评价将放大近期口碑。',
    autoEffects: { demandMul: 1.10, durationDays: 3, reputation: 3, rating: 0.03 }
  },
  {
    id: 'negative_review_wave',
    title: '差评集中出现',
    level: 'important',
    weight: 7,
    cooldownDays: 18,
    condition: 'store_open',
    district: 'current',
    text: '近期出现一批关于等待时间和服务体验的差评。',
    autoEffects: { demandMul: 0.92, durationDays: 3, reputation: -3, rating: -0.05 }
  },
  {
    id: 'group_booking',
    title: '临时团体订餐',
    level: 'normal',
    weight: 8,
    cooldownDays: 8,
    condition: 'store_open',
    district: 'current',
    text: '附近单位临时增加团体订餐需求。',
    autoEffects: { cash: 520, reputation: 1 }
  },
  {
    id: 'food_safety_inspection',
    title: '食品安全突击检查',
    level: 'forced',
    weight: 7,
    cooldownDays: 30,
    condition: 'store_open',
    district: 'current',
    text: '监管人员到店检查后厨留样、卫生记录、冷藏温度与原料票据。必须立即处理。',
    choices: [
      { id: 'cooperate', label: '配合检查并立即整改', hint: '支出整改费用，降低食安风险。', effects: { cash: -900, safety: 8, reputation: 2, rating: 0.02 } },
      { id: 'close_half_day', label: '暂停营业半天彻底整改', hint: '损失营业收入，但大幅降低风险。', effects: { cash: -1500, safety: 14, reputation: 3, demandMul: 0.72, durationDays: 1 } },
      { id: 'minimal', label: '只处理被点名的问题', hint: '成本较低，但后续复查风险更高。', effects: { cash: -350, safety: 2, risk: 8, reputation: -1 }, nextEventId: 'food_safety_recheck' }
    ]
  },
  {
    id: 'food_safety_recheck',
    title: '食品安全复查',
    level: 'forced',
    weight: 0,
    cooldownDays: 90,
    condition: 'never_random',
    district: 'current',
    text: '此前整改事项进入复查。检查人员要求查看完整整改记录。',
    choices: [
      { id: 'full', label: '补齐记录并升级管理', effects: { cash: -1200, safety: 12, reputation: 2, risk: -8 } },
      { id: 'fine', label: '接受处罚并停业整改', effects: { cash: -3200, safety: 8, reputation: -5, rating: -0.08, demandMul: 0.70, durationDays: 2 } }
    ]
  },
  {
    id: 'equipment_failure',
    title: '核心设备突然故障',
    level: 'forced',
    weight: 8,
    cooldownDays: 16,
    condition: 'store_open',
    district: 'current',
    text: '高峰前核心厨房设备故障，当前产能会受到影响。',
    choices: [
      { id: 'repair_now', label: '立即叫维修并加急处理', effects: { cash: -1100, equipment: 8, demandMul: 0.93, durationDays: 1 } },
      { id: 'rent_temp', label: '租临时设备保住高峰', effects: { cash: -1600, equipment: 4, reputation: 1 } },
      { id: 'limited_menu', label: '缩减菜单继续营业', effects: { cash: -350, reputation: -2, demandMul: 0.84, durationDays: 1 } }
    ]
  },
  {
    id: 'freezer_failure',
    title: '冷藏设备异常',
    level: 'forced',
    weight: 5,
    cooldownDays: 25,
    condition: 'store_open',
    district: 'current',
    text: '冷藏柜温度异常，部分高风险食材需要立即处置。',
    choices: [
      { id: 'discard', label: '报废可疑食材并维修', effects: { cash: -1800, safety: 10, reputation: 1 } },
      { id: 'transfer', label: '转移库存并加急维修', effects: { cash: -1250, safety: 6, equipment: 6 } },
      { id: 'keep', label: '继续使用并观察', effects: { cash: 0, safety: -15, risk: 18, reputation: -4 }, nextEventId: 'customer_complaint_safety' }
    ]
  },
  {
    id: 'customer_complaint_safety',
    title: '顾客健康投诉',
    level: 'forced',
    weight: 0,
    cooldownDays: 90,
    condition: 'never_random',
    district: 'current',
    text: '有顾客反馈餐后不适并要求门店解释。需要立刻处理和留存记录。',
    choices: [
      { id: 'support_check', label: '退款、协助检查并封存相关批次', effects: { cash: -2200, safety: 6, reputation: -2, risk: -6 } },
      { id: 'deny', label: '拒绝承担并等待证据', effects: { cash: -300, reputation: -9, rating: -0.12, risk: 15 }, nextEventId: 'public_opinion_crisis' }
    ]
  },
  {
    id: 'public_opinion_crisis',
    title: '本地舆情发酵',
    level: 'forced',
    weight: 0,
    cooldownDays: 120,
    condition: 'never_random',
    district: 'current',
    text: '相关投诉在本地社交平台扩散，门店口碑和客流正在快速受损。',
    choices: [
      { id: 'transparent', label: '公开说明、提交检测并补偿', effects: { cash: -3500, reputation: -3, rating: -0.06, risk: -12, demandMul: 0.90, durationDays: 3 } },
      { id: 'ignore', label: '不回应继续营业', effects: { reputation: -14, rating: -0.20, risk: 20, demandMul: 0.72, durationDays: 5 } }
    ]
  },
  {
    id: 'chef_resignation',
    title: '核心厨师提出离职',
    level: 'forced',
    weight: 6,
    cooldownDays: 35,
    condition: 'store_open',
    district: 'current',
    text: '一名核心厨师提出离职，近期出餐稳定性可能受影响。',
    choices: [
      { id: 'retain', label: '加薪并安排晋升留人', effects: { cash: -1800, staffMorale: 9, turnoverRisk: -12 } },
      { id: 'replace', label: '启动招聘并安排交接', effects: { cash: -900, staffMorale: -2, turnoverRisk: -4, demandMul: 0.95, durationDays: 2 } },
      { id: 'let_go', label: '同意离职，暂不补人', effects: { staffMorale: -6, turnoverRisk: 8, demandMul: 0.88, durationDays: 4 } }
    ]
  },
  {
    id: 'wage_dispute',
    title: '排班与加班争议',
    level: 'forced',
    weight: 5,
    cooldownDays: 28,
    condition: 'staff_stressed',
    district: 'current',
    text: '员工对高峰排班和加班补偿产生集中意见。',
    choices: [
      { id: 'compensate', label: '补发加班并调整排班', effects: { cash: -1300, staffMorale: 12, turnoverRisk: -10 } },
      { id: 'meeting', label: '开员工会协商新排班', effects: { cash: -450, staffMorale: 7, turnoverRisk: -5 } },
      { id: 'refuse', label: '维持原排班', effects: { staffMorale: -14, turnoverRisk: 18, reputation: -2 }, nextEventId: 'chef_resignation' }
    ]
  },
  {
    id: 'landlord_raise_rent',
    title: '房东提出续租涨价',
    level: 'forced',
    weight: 4,
    cooldownDays: 70,
    condition: 'store_mature',
    district: 'current',
    text: '房东提出下一周期提高租金，需要决定谈判、接受或准备搬迁。',
    choices: [
      { id: 'negotiate', label: '拿经营数据谈判', effects: { cash: -200, reputation: 1, rentPressure: 4 } },
      { id: 'accept', label: '接受涨租，保住位置', effects: { cash: -1200, rentPressure: 10 } },
      { id: 'prepare_move', label: '开始寻找替代铺面', effects: { cash: -500, rentPressure: -4, risk: 4 } }
    ]
  },
  {
    id: 'cashflow_crunch',
    title: '现金流预警',
    level: 'forced',
    weight: 12,
    cooldownDays: 12,
    condition: 'cash_low',
    district: 'current',
    text: '当前现金接近安全线，下一轮采购、工资和房租可能出现资金缺口。',
    choices: [
      { id: 'cut_cost', label: '压缩非核心支出', effects: { cash: 700, staffMorale: -3, reputation: -1 } },
      { id: 'loan', label: '申请短期经营贷款', action: 'auto_loan', effects: { reputation: -1 } },
      { id: 'promotion', label: '做现金回笼促销', effects: { cash: 950, demandMul: 1.10, durationDays: 2, rating: -0.02 } }
    ]
  },
  {
    id: 'supplier_shortage',
    title: '核心原料临时缺货',
    level: 'forced',
    weight: 7,
    cooldownDays: 20,
    condition: 'store_open',
    district: 'current',
    text: '常用供应商通知部分原料无法按时到货。',
    choices: [
      { id: 'backup', label: '启用备用供应商', effects: { cash: -650, supplyPriceMul: 1.10, durationDays: 2 } },
      { id: 'menu_adjust', label: '临时调整菜单', effects: { demandMul: 0.92, durationDays: 2, reputation: -1 } },
      { id: 'premium', label: '高价现采保供应', effects: { cash: -1300, reputation: 1 } }
    ]
  },
  {
    id: 'power_outage',
    title: '片区临时停电',
    level: 'forced',
    weight: 4,
    cooldownDays: 30,
    condition: 'store_open',
    district: 'current',
    text: '门店所在街区突发停电，冷藏、照明和部分厨房设备停止工作。',
    choices: [
      { id: 'close', label: '立即停业并保护库存', effects: { cash: -900, safety: 5, demandMul: 0.65, durationDays: 1 } },
      { id: 'generator', label: '租应急电源维持营业', effects: { cash: -1500, equipment: 3 } }
    ]
  },
  {
    id: 'drain_blockage',
    title: '后厨排水堵塞',
    level: 'forced',
    weight: 6,
    cooldownDays: 18,
    condition: 'store_open',
    district: 'current',
    text: '后厨排水异常，继续满负荷营业会提高卫生与设备风险。',
    choices: [
      { id: 'repair', label: '立即疏通并深度清洁', effects: { cash: -750, safety: 5, equipment: 3 } },
      { id: 'slow', label: '降负荷营业后再维修', effects: { cash: -350, demandMul: 0.78, durationDays: 1, risk: 5 } }
    ]
  },
  {
    id: 'license_renewal',
    title: '证照续期提醒',
    level: 'forced',
    weight: 3,
    cooldownDays: 120,
    condition: 'store_mature',
    district: 'current',
    text: '部分经营证照进入续期窗口，逾期会影响正常营业。',
    choices: [
      { id: 'renew', label: '立即提交续期材料', effects: { cash: -600, safety: 3, risk: -4 } },
      { id: 'delay', label: '暂缓办理', effects: { risk: 10 }, nextEventId: 'license_deadline' }
    ]
  },
  {
    id: 'license_deadline',
    title: '证照即将逾期',
    level: 'forced',
    weight: 0,
    cooldownDays: 180,
    condition: 'never_random',
    district: 'current',
    text: '证照已到最后办理期限，必须在继续营业前处理。',
    choices: [
      { id: 'urgent', label: '加急办理', effects: { cash: -1200, risk: -8 } },
      { id: 'close', label: '停业等待办理完成', effects: { cash: -800, demandMul: 0.55, durationDays: 2, reputation: -2 } }
    ]
  },
  {
    id: 'award_nomination',
    title: '本地餐饮榜单提名',
    level: 'important',
    weight: 4,
    cooldownDays: 60,
    condition: 'award_ready',
    district: 'current',
    text: '门店进入本地餐饮榜单候选，近期评分与经营稳定性将决定最终结果。',
    autoEffects: { reputation: 3, awardNomination: 1 }
  },
  {
    id: 'platform_campaign',
    title: '平台流量活动开放',
    level: 'normal',
    weight: 7,
    cooldownDays: 16,
    condition: 'store_open',
    district: 'current',
    text: '本地生活平台开放短期流量活动，门店获得额外曝光。',
    autoEffects: { demandMul: 1.08, durationDays: 2 }
  }
];

module.exports = {
  EVENT_CATALOG
};
