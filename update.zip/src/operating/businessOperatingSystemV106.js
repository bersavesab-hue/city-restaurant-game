'use strict';

const { EVENT_CATALOG } = require('./eventCatalogV106.js');

const STORAGE_KEY = 'cityRestaurant.operating.v106';
const SCHEMA_VERSION = '1.0.6';

function clamp(n, min, max) {
  n = Number(n);
  if (!Number.isFinite(n)) n = 0;
  return Math.max(min, Math.min(max, n));
}

function round(n, digits) {
  const p = Math.pow(10, digits || 0);
  return Math.round((Number(n) || 0) * p) / p;
}

function deepCopy(value) {
  return JSON.parse(JSON.stringify(value));
}

function sum(list, key) {
  return (list || []).reduce((total, item) => total + (Number(item && item[key]) || 0), 0);
}

function average(list, key) {
  if (!Array.isArray(list) || !list.length) return 0;
  return sum(list, key) / list.length;
}

function uid(prefix, seed) {
  return String(prefix || 'id') + '_' + String(seed || Date.now()) + '_' + Math.floor(Math.random() * 1000000);
}

function safeArray(value) {
  return Array.isArray(value) ? value : [];
}

function buildDefaultState(seed) {
  return {
    schemaVersion: SCHEMA_VERSION,
    revision: 1,
    rngSeed: (Number(seed) || 20260916) >>> 0,
    simMinutes: 0,
    lastDayKey: null,
    lastMonthKey: null,
    lastSnapshot: null,
    events: {
      active: null,
      queue: [],
      history: [],
      cooldowns: {},
      nextCheckMinute: 180,
      chainQueue: [],
      totalTriggered: 0,
      totalResolved: 0
    },
    notifications: {
      nextId: 1,
      items: []
    },
    effects: [],
    finance: {
      ledger: [],
      loans: [],
      creditScore: 68,
      creditLimit: 30000,
      accruedInterest: 0,
      overdueCount: 0,
      lastInterestDayKey: null
    },
    staff: {
      morale: 70,
      turnoverRisk: 18,
      training: 50,
      service: 66,
      shortageRisk: 15,
      history: []
    },
    dishes: {
      records: {},
      projects: [],
      improvements: [],
      lastImportDayKey: null
    },
    ratings: {
      overall: 4.20,
      taste: 78,
      service: 70,
      environment: 68,
      value: 72,
      speed: 70,
      safety: 82,
      history: []
    },
    rankings: {
      current: null,
      history: []
    },
    awards: {
      season: 1,
      nominations: [],
      wins: [],
      history: [],
      lastEvaluationMonth: null
    },
    funnel: {
      today: null,
      history: []
    },
    settlements: {
      daily: [],
      weekly: [],
      monthly: []
    },
    guide: {
      tasks: [
        { id: 'open_store', title: '拥有并经营一家门店', done: false },
        { id: 'first_dish', title: '完成一次菜品研发或改良', done: false },
        { id: 'first_event', title: '处理一次强制经营事件', done: false },
        { id: 'seven_days', title: '形成7天经营记录', done: false },
        { id: 'healthy_cash', title: '保持正现金流并建立安全垫', done: false }
      ]
    },
    audit: {
      createdAt: new Date().toISOString(),
      lastSavedAt: null,
      lastBridgeVersion: SCHEMA_VERSION,
      migrations: []
    }
  };
}

class BusinessOperatingSystemV106 {
  constructor(options) {
    options = options || {};
    this.storage = options.storage || null;
    this.adapter = options.adapter || {};
    this.catalog = options.catalog || EVENT_CATALOG;
    this.storageKey = options.storageKey || STORAGE_KEY;
    this.state = this._load(options.seed);
    this._normalize();
  }

  _load(seed) {
    let loaded = null;
    try {
      loaded = this.storage && typeof this.storage.get === 'function'
        ? this.storage.get(this.storageKey)
        : null;
    } catch (error) {
      loaded = null;
    }

    if (loaded && typeof loaded === 'string') {
      try { loaded = JSON.parse(loaded); } catch (error) { loaded = null; }
    }

    if (!loaded || typeof loaded !== 'object') return buildDefaultState(seed);
    return this._migrate(loaded, seed);
  }

  _migrate(oldState, seed) {
    const fresh = buildDefaultState(seed || oldState.rngSeed);
    const merged = Object.assign(fresh, oldState);

    merged.events = Object.assign(fresh.events, oldState.events || {});
    merged.notifications = Object.assign(fresh.notifications, oldState.notifications || {});
    merged.finance = Object.assign(fresh.finance, oldState.finance || {});
    merged.staff = Object.assign(fresh.staff, oldState.staff || {});
    merged.dishes = Object.assign(fresh.dishes, oldState.dishes || {});
    merged.ratings = Object.assign(fresh.ratings, oldState.ratings || {});
    merged.rankings = Object.assign(fresh.rankings, oldState.rankings || {});
    merged.awards = Object.assign(fresh.awards, oldState.awards || {});
    merged.funnel = Object.assign(fresh.funnel, oldState.funnel || {});
    merged.settlements = Object.assign(fresh.settlements, oldState.settlements || {});
    merged.guide = Object.assign(fresh.guide, oldState.guide || {});
    merged.audit = Object.assign(fresh.audit, oldState.audit || {});
    merged.schemaVersion = SCHEMA_VERSION;
    merged.audit.migrations = safeArray(merged.audit.migrations);
    if (!merged.audit.migrations.includes(SCHEMA_VERSION)) {
      merged.audit.migrations.push(SCHEMA_VERSION);
    }
    return merged;
  }

  _normalize() {
    const s = this.state;
    s.events.queue = safeArray(s.events.queue);
    s.events.history = safeArray(s.events.history).slice(-300);
    s.events.chainQueue = safeArray(s.events.chainQueue);
    s.notifications.items = safeArray(s.notifications.items).slice(-300);
    s.effects = safeArray(s.effects).slice(-200);
    s.finance.ledger = safeArray(s.finance.ledger).slice(-1000);
    s.finance.loans = safeArray(s.finance.loans);
    s.staff.history = safeArray(s.staff.history).slice(-180);
    s.dishes.records = s.dishes.records && typeof s.dishes.records === 'object' ? s.dishes.records : {};
    s.dishes.projects = safeArray(s.dishes.projects).slice(-100);
    s.dishes.improvements = safeArray(s.dishes.improvements).slice(-300);
    s.ratings.history = safeArray(s.ratings.history).slice(-365);
    s.rankings.history = safeArray(s.rankings.history).slice(-365);
    s.awards.nominations = safeArray(s.awards.nominations);
    s.awards.wins = safeArray(s.awards.wins);
    s.awards.history = safeArray(s.awards.history).slice(-200);
    s.funnel.history = safeArray(s.funnel.history).slice(-365);
    s.settlements.daily = safeArray(s.settlements.daily).slice(-365);
    s.settlements.weekly = safeArray(s.settlements.weekly).slice(-104);
    s.settlements.monthly = safeArray(s.settlements.monthly).slice(-60);
  }

  setAdapter(adapter) {
    this.adapter = adapter || {};
    return this;
  }

  _random() {
    let seed = this.state.rngSeed >>> 0;
    seed = (1664525 * seed + 1013904223) >>> 0;
    this.state.rngSeed = seed;
    return seed / 4294967296;
  }

  _pickWeighted(items) {
    if (!items.length) return null;
    const total = items.reduce((n, item) => n + Math.max(0, Number(item.weight) || 0), 0);
    if (total <= 0) return null;
    let cursor = this._random() * total;
    for (const item of items) {
      cursor -= Math.max(0, Number(item.weight) || 0);
      if (cursor <= 0) return item;
    }
    return items[items.length - 1];
  }

  persist() {
    this.state.revision = (Number(this.state.revision) || 0) + 1;
    this.state.audit.lastSavedAt = new Date().toISOString();
    this.state.audit.lastBridgeVersion = SCHEMA_VERSION;
    try {
      if (this.storage && typeof this.storage.set === 'function') {
        this.storage.set(this.storageKey, deepCopy(this.state));
      }
    } catch (error) {
      // 存档失败不能把主游戏打崩；桥接层会在审计里显示。
    }
    return this.state;
  }

  getState() {
    return this.state;
  }

  getPublicState() {
    return deepCopy(this.state);
  }

  _dayKey(snapshot) {
    if (!snapshot) return null;
    if (snapshot.dayKey) return String(snapshot.dayKey);
    const t = snapshot.time || {};
    if (t.year != null && t.month != null && (t.day != null || t.date != null)) {
      return [t.year, t.month, t.day != null ? t.day : t.date].join('-');
    }
    if (snapshot.dayOrdinal != null) return 'ordinal-' + snapshot.dayOrdinal;
    return null;
  }

  _monthKey(snapshot) {
    if (!snapshot) return null;
    if (snapshot.monthKey) return String(snapshot.monthKey);
    const t = snapshot.time || {};
    if (t.year != null && t.month != null) return [t.year, t.month].join('-');
    return null;
  }

  _currentDistrict(event, snapshot) {
    if (!event) return null;
    if (event.district === 'current') return snapshot && snapshot.districtId ? snapshot.districtId : null;
    return event.district || null;
  }

  _conditionAllowed(key, snapshot) {
    snapshot = snapshot || {};
    switch (key || 'store_open') {
      case 'never_random': return false;
      case 'store_open': return !!snapshot.hasStore && snapshot.storeOpen !== false;
      case 'store_mature': return !!snapshot.hasStore && (Number(snapshot.operatingDays) || 0) >= 20;
      case 'cash_low': return !!snapshot.hasStore && Number(snapshot.cash) < Math.max(6000, Number(snapshot.safeCashLine) || 10000);
      case 'staff_stressed': return !!snapshot.hasStore && (this.state.staff.morale < 58 || this.state.staff.turnoverRisk > 35);
      case 'rating_ok': return !!snapshot.hasStore && this.state.ratings.overall >= 4.15;
      case 'award_ready': return !!snapshot.hasStore && this.state.ratings.overall >= 4.35 && this.state.settlements.daily.length >= 14;
      default: return !!snapshot.hasStore;
    }
  }

  _isCooling(event, dayOrdinal) {
    const last = this.state.events.cooldowns[event.id];
    if (last == null) return false;
    const cooldown = Math.max(0, Number(event.cooldownDays) || 0);
    return Number(dayOrdinal || 0) - Number(last) < cooldown;
  }

  _eligibleEvents(snapshot) {
    const dayOrdinal = Number(snapshot && snapshot.dayOrdinal) || this.state.settlements.daily.length + 1;
    return this.catalog.filter(event => {
      if (!event || (Number(event.weight) || 0) <= 0) return false;
      if (this._isCooling(event, dayOrdinal)) return false;
      return this._conditionAllowed(event.condition, snapshot);
    });
  }

  _notification(title, text, level, meta) {
    const id = this.state.notifications.nextId++;
    const item = {
      id,
      title: String(title || '经营消息'),
      text: String(text || ''),
      level: level || 'normal',
      read: false,
      minute: this.state.simMinutes,
      dayKey: this.state.lastDayKey,
      meta: meta || null
    };
    this.state.notifications.items.push(item);
    this.state.notifications.items = this.state.notifications.items.slice(-300);
    return item;
  }

  getUnreadCount() {
    return this.state.notifications.items.filter(item => !item.read).length;
  }

  markNotificationsRead() {
    this.state.notifications.items.forEach(item => { item.read = true; });
    this.persist();
  }

  _enqueueForced(event, snapshot, source) {
    const districtId = this._currentDistrict(event, snapshot);
    const instance = {
      instanceId: uid(event.id, this.state.events.totalTriggered + 1),
      eventId: event.id,
      title: event.title,
      level: 'forced',
      text: event.text,
      districtId,
      choices: deepCopy(event.choices || []),
      triggeredMinute: this.state.simMinutes,
      triggeredDayKey: this._dayKey(snapshot),
      source: source || 'random'
    };
    this.state.events.queue.push(instance);
    this._activateNextForced();
    return instance;
  }

  _activateNextForced() {
    if (this.state.events.active || !this.state.events.queue.length) return this.state.events.active;
    this.state.events.active = this.state.events.queue.shift();
    this._notification(
      this.state.events.active.title,
      '出现必须处理的经营事件，游戏时间已暂停。',
      'forced',
      { eventInstanceId: this.state.events.active.instanceId }
    );
    if (this.adapter && typeof this.adapter.onForcedEvent === 'function') {
      try { this.adapter.onForcedEvent(deepCopy(this.state.events.active)); } catch (error) {}
    }
    return this.state.events.active;
  }

  _addEffect(kind, value, durationDays, districtId, sourceEventId) {
    const days = Math.max(1, Number(durationDays) || 1);
    const expiresAt = this.state.simMinutes + days * 1440;
    this.state.effects.push({
      id: uid('fx', this.state.effects.length + this.state.simMinutes),
      kind,
      value: Number(value),
      districtId: districtId || null,
      sourceEventId: sourceEventId || null,
      createdAt: this.state.simMinutes,
      expiresAt
    });
    this.state.effects = this.state.effects.slice(-200);
  }

  _ledger(type, amount, note, meta) {
    const entry = {
      id: uid('ledger', this.state.finance.ledger.length + this.state.simMinutes),
      dayKey: this.state.lastDayKey,
      minute: this.state.simMinutes,
      type: type || '经营',
      amount: round(amount, 2),
      note: String(note || ''),
      meta: meta || null
    };
    this.state.finance.ledger.push(entry);
    this.state.finance.ledger = this.state.finance.ledger.slice(-1000);
    return entry;
  }

  _mutateCash(delta, reason) {
    delta = round(delta, 2);
    if (!delta) return 0;
    let applied = false;
    if (this.adapter && typeof this.adapter.mutateCash === 'function') {
      try { applied = this.adapter.mutateCash(delta, reason) !== false; } catch (error) { applied = false; }
    }
    this._ledger(delta >= 0 ? '流入' : '流出', delta, reason, { appliedToGame: applied });
    return delta;
  }

  _mutateReputation(delta, reason) {
    delta = Number(delta) || 0;
    if (!delta) return 0;
    if (this.adapter && typeof this.adapter.mutateReputation === 'function') {
      try { this.adapter.mutateReputation(delta, reason); } catch (error) {}
    }
    return delta;
  }

  _applyEffects(effects, snapshot, sourceEventId) {
    effects = effects || {};
    const districtId = effects.districtId || (snapshot && snapshot.districtId) || null;

    if (effects.cash) this._mutateCash(effects.cash, '事件：' + sourceEventId);
    if (effects.reputation) this._mutateReputation(effects.reputation, '事件：' + sourceEventId);

    if (effects.rating) {
      this.state.ratings.overall = clamp(this.state.ratings.overall + Number(effects.rating), 1, 5);
    }
    if (effects.safety) {
      this.state.ratings.safety = clamp(this.state.ratings.safety + Number(effects.safety), 0, 100);
    }
    if (effects.staffMorale) {
      this.state.staff.morale = clamp(this.state.staff.morale + Number(effects.staffMorale), 0, 100);
    }
    if (effects.turnoverRisk) {
      this.state.staff.turnoverRisk = clamp(this.state.staff.turnoverRisk + Number(effects.turnoverRisk), 0, 100);
    }
    if (effects.risk) {
      this.state.staff.shortageRisk = clamp(this.state.staff.shortageRisk + Number(effects.risk) * 0.35, 0, 100);
      this.state.ratings.safety = clamp(this.state.ratings.safety - Math.max(0, Number(effects.risk) * 0.25), 0, 100);
    }
    if (effects.equipment) {
      this.state.ratings.speed = clamp(this.state.ratings.speed + Number(effects.equipment) * 0.35, 0, 100);
    }
    if (effects.rentPressure) {
      this._addEffect('rentPressure', effects.rentPressure, 30, districtId, sourceEventId);
    }
    if (effects.demandMul && Number(effects.demandMul) !== 1) {
      this._addEffect('demandMul', effects.demandMul, effects.durationDays, districtId, sourceEventId);
    }
    if (effects.supplyPriceMul && Number(effects.supplyPriceMul) !== 1) {
      this._addEffect('supplyPriceMul', effects.supplyPriceMul, effects.durationDays, districtId, sourceEventId);
    }
    if (effects.awardNomination) {
      this._addNomination('城市餐饮关注榜', '事件提名');
    }

    this._recalculateRating();
  }

  _recalculateRating() {
    const r = this.state.ratings;
    const score100 =
      r.taste * 0.30 +
      r.service * 0.18 +
      r.environment * 0.12 +
      r.value * 0.14 +
      r.speed * 0.10 +
      r.safety * 0.16;
    const calculated = clamp(score100 / 20, 1, 5);
    // 事件对 overall 的直接增减保留一部分，不让分项重算完全覆盖。
    r.overall = round(clamp(r.overall * 0.35 + calculated * 0.65, 1, 5), 2);
    return r.overall;
  }

  triggerRandomEvent(snapshot) {
    const candidates = this._eligibleEvents(snapshot);
    if (!candidates.length) return null;
    const event = this._pickWeighted(candidates);
    if (!event) return null;
    return this.triggerEvent(event.id, snapshot, 'random');
  }

  triggerEvent(eventId, snapshot, source) {
    const event = this.catalog.find(item => item.id === eventId);
    if (!event) return null;

    const dayOrdinal = Number(snapshot && snapshot.dayOrdinal) || this.state.settlements.daily.length + 1;
    this.state.events.cooldowns[event.id] = dayOrdinal;
    this.state.events.totalTriggered++;

    if (event.level === 'forced') {
      const instance = this._enqueueForced(event, snapshot, source);
      this.persist();
      return instance;
    }

    this._applyEffects(
      Object.assign({}, event.autoEffects || {}, { districtId: this._currentDistrict(event, snapshot) }),
      snapshot,
      event.id
    );

    const record = {
      instanceId: uid(event.id, this.state.events.totalTriggered),
      eventId: event.id,
      title: event.title,
      level: event.level || 'normal',
      text: event.text,
      districtId: this._currentDistrict(event, snapshot),
      triggeredMinute: this.state.simMinutes,
      triggeredDayKey: this._dayKey(snapshot),
      resolvedMinute: this.state.simMinutes,
      choiceId: 'automatic',
      source: source || 'random'
    };
    this.state.events.history.push(record);
    this.state.events.history = this.state.events.history.slice(-300);
    this._notification(event.title, event.text, event.level || 'normal', { eventId: event.id });
    this.persist();
    return record;
  }

  resolveForcedEvent(choiceId, snapshot) {
    const active = this.state.events.active;
    if (!active) return { ok: false, reason: '当前没有待处理强制事件' };

    const event = this.catalog.find(item => item.id === active.eventId);
    const choice = event && safeArray(event.choices).find(item => item.id === choiceId);
    if (!choice) return { ok: false, reason: '事件选项不存在' };

    if (choice.action === 'auto_loan') {
      const currentCash = Number(snapshot && snapshot.cash) || 0;
      const target = Math.max(5000, Math.min(this.state.finance.creditLimit, Math.max(8000, 18000 - currentCash)));
      this.requestLoan(target, 90, 0.12, snapshot, '事件应急贷款');
    }

    this._applyEffects(choice.effects || {}, snapshot, event.id);

    const history = {
      instanceId: active.instanceId,
      eventId: active.eventId,
      title: active.title,
      level: 'forced',
      text: active.text,
      districtId: active.districtId,
      triggeredMinute: active.triggeredMinute,
      triggeredDayKey: active.triggeredDayKey,
      resolvedMinute: this.state.simMinutes,
      resolvedDayKey: this._dayKey(snapshot),
      choiceId: choice.id,
      choiceLabel: choice.label,
      source: active.source
    };

    this.state.events.history.push(history);
    this.state.events.history = this.state.events.history.slice(-300);
    this.state.events.totalResolved++;
    this.state.events.active = null;

    if (choice.nextEventId) {
      this.state.events.chainQueue.push({
        eventId: choice.nextEventId,
        dueMinute: this.state.simMinutes + 360 + Math.floor(this._random() * 900),
        sourceEventId: event.id
      });
    }

    this._notification(active.title + '已处理', '处理方案：' + choice.label, 'resolved', { eventId: active.eventId });
    this._activateNextForced();
    this._updateGuide(snapshot);
    this.persist();
    return { ok: true, history, nextActive: this.state.events.active };
  }

  _processChains(snapshot) {
    const due = [];
    const future = [];
    for (const item of this.state.events.chainQueue) {
      if (Number(item.dueMinute) <= this.state.simMinutes) due.push(item);
      else future.push(item);
    }
    this.state.events.chainQueue = future;
    for (const item of due) this.triggerEvent(item.eventId, snapshot, 'chain:' + item.sourceEventId);
  }

  _expireEffects() {
    this.state.effects = this.state.effects.filter(effect => Number(effect.expiresAt) > this.state.simMinutes);
  }

  getDemandMultiplier(districtId) {
    this._expireEffects();
    return this.state.effects
      .filter(effect => effect.kind === 'demandMul' && (!effect.districtId || effect.districtId === districtId))
      .reduce((value, effect) => value * (Number(effect.value) || 1), 1);
  }

  getSupplyPriceMultiplier() {
    this._expireEffects();
    return this.state.effects
      .filter(effect => effect.kind === 'supplyPriceMul')
      .reduce((value, effect) => value * (Number(effect.value) || 1), 1);
  }

  requestLoan(amount, termDays, apr, snapshot, note) {
    amount = Math.max(1000, Math.round(Number(amount) || 0));
    termDays = Math.max(30, Math.round(Number(termDays) || 90));
    apr = clamp(Number(apr) || 0.12, 0.01, 0.36);

    const available = this.getAvailableCredit(snapshot);
    if (amount > available) return { ok: false, reason: '超过当前可用授信额度' };

    const loan = {
      id: uid('loan', this.state.finance.loans.length + this.state.simMinutes),
      originalPrincipal: amount,
      outstanding: amount,
      accruedInterest: 0,
      apr,
      termDays,
      startDayKey: this._dayKey(snapshot),
      daysElapsed: 0,
      status: 'active',
      note: note || '经营贷款'
    };
    this.state.finance.loans.push(loan);
    this._mutateCash(amount, '贷款放款：' + loan.note);
    this.state.finance.creditScore = clamp(this.state.finance.creditScore - 1, 0, 100);
    this.persist();
    return { ok: true, loan: deepCopy(loan) };
  }

  getAvailableCredit(snapshot) {
    const totalOutstanding = this.state.finance.loans
      .filter(loan => loan.status === 'active')
      .reduce((n, loan) => n + Number(loan.outstanding || 0), 0);
    const reputation = Number(snapshot && snapshot.reputation) || 0;
    const historyBonus = Math.min(30000, this.state.settlements.daily.length * 350);
    const ratingBonus = Math.max(0, this.state.ratings.overall - 3.5) * 16000;
    const baseLimit = 15000 + reputation * 180 + historyBonus + ratingBonus;
    this.state.finance.creditLimit = Math.round(clamp(baseLimit, 10000, 180000));
    return Math.max(0, this.state.finance.creditLimit - totalOutstanding);
  }

  repayLoan(loanId, amount, snapshot) {
    const loan = this.state.finance.loans.find(item => item.id === loanId && item.status === 'active');
    if (!loan) return { ok: false, reason: '贷款不存在或已结清' };
    const cash = Number(snapshot && snapshot.cash);
    amount = Math.max(0, Math.min(Number(amount) || 0, loan.outstanding + loan.accruedInterest));
    if (amount <= 0) return { ok: false, reason: '还款金额无效' };
    if (Number.isFinite(cash) && cash < amount) return { ok: false, reason: '现金不足' };

    this._mutateCash(-amount, '偿还经营贷款');
    let remaining = amount;
    const interestPaid = Math.min(remaining, loan.accruedInterest);
    loan.accruedInterest = round(loan.accruedInterest - interestPaid, 2);
    remaining -= interestPaid;
    loan.outstanding = round(Math.max(0, loan.outstanding - remaining), 2);
    if (loan.outstanding <= 0.01 && loan.accruedInterest <= 0.01) {
      loan.outstanding = 0;
      loan.accruedInterest = 0;
      loan.status = 'repaid';
      this.state.finance.creditScore = clamp(this.state.finance.creditScore + 3, 0, 100);
    }
    this.persist();
    return { ok: true, loan: deepCopy(loan) };
  }

  _accrueDailyInterest(dayKey, snapshot) {
    if (!dayKey || this.state.finance.lastInterestDayKey === dayKey) return;
    this.state.finance.lastInterestDayKey = dayKey;
    let total = 0;
    for (const loan of this.state.finance.loans) {
      if (loan.status !== 'active') continue;
      const interest = round(Number(loan.outstanding || 0) * Number(loan.apr || 0) / 365, 2);
      loan.accruedInterest = round(Number(loan.accruedInterest || 0) + interest, 2);
      loan.daysElapsed = Number(loan.daysElapsed || 0) + 1;
      total += interest;
      if (loan.daysElapsed > loan.termDays && loan.outstanding > 0) {
        loan.status = 'overdue';
        this.state.finance.overdueCount++;
        this.state.finance.creditScore = clamp(this.state.finance.creditScore - 8, 0, 100);
        this._notification('贷款逾期', '有经营贷款超过约定期限，请尽快处理。', 'forced', { loanId: loan.id });
      }
    }
    this.state.finance.accruedInterest = round(this.state.finance.accruedInterest + total, 2);
    if (total > 0) this._ledger('应计利息', -total, '经营贷款每日应计利息', { nonCash: true });
    this.getAvailableCredit(snapshot);
  }

  recordFunnel(metrics, snapshot) {
    metrics = metrics || {};
    const potential = Math.max(0, Number(metrics.potential || metrics.demand || 0));
    const actual = Math.max(0, Number(metrics.actualOrders || metrics.orders || 0));
    const lost = Math.max(0, Number(metrics.lostOrders != null ? metrics.lostOrders : potential - actual));
    const record = {
      dayKey: this._dayKey(snapshot) || this.state.lastDayKey,
      demand: Math.max(0, Number(metrics.demand || potential)),
      potential,
      actualOrders: actual,
      lostOrders: lost,
      conversionRate: potential > 0 ? round(actual / potential, 4) : 0,
      loss: Object.assign({ inventory: 0, kitchen: 0, seats: 0, wait: 0, price: 0, quality: 0, other: 0 }, metrics.loss || {})
    };
    this.state.funnel.today = record;
    return record;
  }

  recordDish(dish, snapshot) {
    if (!dish || !dish.id) return null;
    const existing = this.state.dishes.records[dish.id] || {};
    const normalized = Object.assign({}, existing, {
      id: dish.id,
      name: dish.name || existing.name || dish.id,
      rating: Number(dish.rating != null ? dish.rating : existing.rating || 0),
      price: Number(dish.price != null ? dish.price : existing.price || 0),
      cost: Number(dish.cost != null ? dish.cost : existing.cost || 0),
      sales: Number(dish.sales != null ? dish.sales : existing.sales || 0),
      quality: Number(dish.quality != null ? dish.quality : dish.taste != null ? dish.taste : existing.quality || 50),
      lifecycle: Number(dish.lifecycle != null ? dish.lifecycle : existing.lifecycle || 1),
      lastUpdatedDayKey: this._dayKey(snapshot) || this.state.lastDayKey
    });
    this.state.dishes.records[dish.id] = normalized;
    return normalized;
  }

  startDishProject(name, budget, snapshot) {
    budget = Math.max(0, Math.round(Number(budget) || 0));
    if (budget > 0) this._mutateCash(-budget, '菜品研发预算');
    const project = {
      id: uid('dishproject', this.state.dishes.projects.length + this.state.simMinutes),
      name: String(name || '新菜研发'),
      budget,
      progress: 0,
      qualityGain: 0,
      status: 'active',
      startedDayKey: this._dayKey(snapshot) || this.state.lastDayKey
    };
    this.state.dishes.projects.push(project);
    this._updateGuide(snapshot, { dishAction: true });
    this.persist();
    return deepCopy(project);
  }

  improveDish(dishId, dimension, spend, snapshot) {
    const dish = this.state.dishes.records[dishId];
    if (!dish) return { ok: false, reason: '菜品尚未进入经营中枢' };
    spend = Math.max(0, Math.round(Number(spend) || 0));
    if (spend > 0) this._mutateCash(-spend, '菜品改良：' + dish.name);
    const gain = Math.max(1, Math.min(8, Math.round(1 + spend / 700)));
    if (dimension === 'cost') dish.cost = round(Math.max(0, dish.cost * (1 - gain * 0.008)), 2);
    else if (dimension === 'price') dish.price = round(Math.max(1, dish.price * (1 + gain * 0.005)), 2);
    else dish.quality = clamp(dish.quality + gain, 0, 100);
    const entry = { dishId, dimension: dimension || 'quality', spend, gain, dayKey: this._dayKey(snapshot) || this.state.lastDayKey };
    this.state.dishes.improvements.push(entry);
    this._updateGuide(snapshot, { dishAction: true });
    this.persist();
    return { ok: true, dish: deepCopy(dish), improvement: entry };
  }

  recordRating(parts, snapshot) {
    parts = parts || {};
    const r = this.state.ratings;
    for (const key of ['taste', 'service', 'environment', 'value', 'speed', 'safety']) {
      if (parts[key] != null) r[key] = clamp(Number(parts[key]), 0, 100);
    }
    this._recalculateRating();
    r.history.push({ dayKey: this._dayKey(snapshot) || this.state.lastDayKey, overall: r.overall, taste: r.taste, service: r.service, environment: r.environment, value: r.value, speed: r.speed, safety: r.safety });
    r.history = r.history.slice(-365);
    this.persist();
    return deepCopy(r);
  }

  recordRanking(ranking, snapshot) {
    if (!ranking) return null;
    const record = Object.assign({ dayKey: this._dayKey(snapshot) || this.state.lastDayKey }, ranking);
    this.state.rankings.current = record;
    this.state.rankings.history.push(record);
    this.state.rankings.history = this.state.rankings.history.slice(-365);
    this.persist();
    return deepCopy(record);
  }

  _addNomination(name, reason) {
    const exists = this.state.awards.nominations.some(item => item.name === name && item.status === 'pending');
    if (exists) return null;
    const item = { id: uid('nom', this.state.awards.nominations.length + this.state.simMinutes), name, reason, status: 'pending', dayKey: this.state.lastDayKey };
    this.state.awards.nominations.push(item);
    this.state.awards.history.push(Object.assign({ type: 'nomination' }, item));
    this._notification('获得奖项提名', name + '：' + reason, 'important', { awardId: item.id });
    return item;
  }

  _evaluateAwards(snapshot) {
    const monthKey = this._monthKey(snapshot);
    if (!monthKey || this.state.awards.lastEvaluationMonth === monthKey) return;
    this.state.awards.lastEvaluationMonth = monthKey;
    if (!snapshot || !snapshot.hasStore || this.state.settlements.daily.length < 14) return;

    const r = this.state.ratings;
    const daily30 = this.state.settlements.daily.slice(-30);
    const avgProfit = average(daily30, 'operatingProfit');
    const avgOrders = average(daily30, 'orders');
    if (r.overall >= 4.35) this._addNomination('月度高口碑餐厅', '综合评分达到 ' + r.overall.toFixed(2));
    if (r.safety >= 90) this._addNomination('安心餐饮示范店', '食品安全指标保持优秀');
    if (avgProfit > 800 && avgOrders > 70) this._addNomination('成长餐厅榜', '经营利润与订单稳定增长');

    for (const nomination of this.state.awards.nominations) {
      if (nomination.status !== 'pending') continue;
      const score = r.overall * 15 + r.safety * 0.20 + Math.max(0, avgProfit) / 120 + Math.max(0, avgOrders) / 8;
      const threshold = 92 + this._random() * 18;
      if (score >= threshold) {
        nomination.status = 'won';
        const win = { id: uid('award', this.state.awards.wins.length + this.state.simMinutes), name: nomination.name, dayKey: this.state.lastDayKey, score: round(score, 1) };
        this.state.awards.wins.push(win);
        this.state.awards.history.push(Object.assign({ type: 'win' }, win));
        this._mutateReputation(5, '获得奖项：' + win.name);
        this._notification('获奖', '门店获得「' + win.name + '」', 'important', { awardId: win.id });
      } else {
        nomination.status = 'not_selected';
        this.state.awards.history.push({ type: 'result', name: nomination.name, result: '未获奖', dayKey: this.state.lastDayKey, score: round(score, 1) });
      }
    }
    this.state.awards.season++;
  }

  _snapshotSettlement(snapshot, dayKey) {
    const daily = snapshot && snapshot.daily ? snapshot.daily : {};
    const record = {
      dayKey,
      revenue: Number(daily.revenue || 0),
      orders: Number(daily.orders || 0),
      avgTicket: Number(daily.avgTicket || (daily.orders ? daily.revenue / daily.orders : 0)),
      foodCost: Number(daily.foodCost || daily.ingredientCost || 0),
      laborCost: Number(daily.laborCost || 0),
      rentCost: Number(daily.rentCost || 0),
      utilityCost: Number(daily.utilityCost || 0),
      marketingCost: Number(daily.marketingCost || 0),
      wasteCost: Number(daily.wasteCost || 0),
      maintenanceCost: Number(daily.maintenanceCost || 0),
      operatingProfit: Number(daily.operatingProfit != null ? daily.operatingProfit : daily.profit || 0),
      cash: Number(snapshot && snapshot.cash || 0),
      reputation: Number(snapshot && snapshot.reputation || 0),
      rating: this.state.ratings.overall,
      demandMultiplier: this.getDemandMultiplier(snapshot && snapshot.districtId),
      sourceCompleteness: daily.sourceCompleteness || (Object.keys(daily).length ? 'partial' : 'minimal')
    };
    if (this.state.funnel.today && (!this.state.funnel.today.dayKey || this.state.funnel.today.dayKey === dayKey)) {
      record.funnel = deepCopy(this.state.funnel.today);
      this.state.funnel.history.push(deepCopy(this.state.funnel.today));
      this.state.funnel.history = this.state.funnel.history.slice(-365);
      this.state.funnel.today = null;
    }
    return record;
  }

  _aggregateSettlement(records, key) {
    if (!records.length) return null;
    const revenue = sum(records, 'revenue');
    const orders = sum(records, 'orders');
    const profit = sum(records, 'operatingProfit');
    return {
      key,
      days: records.length,
      revenue: round(revenue, 2),
      orders: Math.round(orders),
      avgTicket: orders > 0 ? round(revenue / orders, 2) : 0,
      operatingProfit: round(profit, 2),
      profitMargin: revenue > 0 ? round(profit / revenue, 4) : 0,
      avgRating: round(average(records, 'rating'), 2),
      endingCash: Number(records[records.length - 1].cash || 0)
    };
  }

  _settlePreviousDay(snapshot, previousDayKey) {
    if (!previousDayKey) return;
    if (this.state.settlements.daily.some(item => item.dayKey === previousDayKey)) return;
    const record = this._snapshotSettlement(snapshot, previousDayKey);
    this.state.settlements.daily.push(record);
    this.state.settlements.daily = this.state.settlements.daily.slice(-365);

    const days = this.state.settlements.daily;
    if (days.length % 7 === 0) {
      const weekly = this._aggregateSettlement(days.slice(-7), 'week-' + Math.ceil(days.length / 7));
      if (weekly) this.state.settlements.weekly.push(weekly);
      this.state.settlements.weekly = this.state.settlements.weekly.slice(-104);
    }

    this.state.staff.history.push({ dayKey: previousDayKey, morale: this.state.staff.morale, turnoverRisk: this.state.staff.turnoverRisk, shortageRisk: this.state.staff.shortageRisk });
    this.state.staff.history = this.state.staff.history.slice(-180);
    this.state.ratings.history.push({ dayKey: previousDayKey, overall: this.state.ratings.overall, safety: this.state.ratings.safety });
    this.state.ratings.history = this.state.ratings.history.slice(-365);
  }

  _settlePreviousMonth(previousMonthKey) {
    if (!previousMonthKey) return;
    if (this.state.settlements.monthly.some(item => item.key === previousMonthKey)) return;
    const records = this.state.settlements.daily.filter(item => String(item.dayKey || '').startsWith(previousMonthKey + '-'));
    if (!records.length) return;
    const monthly = this._aggregateSettlement(records, previousMonthKey);
    if (monthly) this.state.settlements.monthly.push(monthly);
    this.state.settlements.monthly = this.state.settlements.monthly.slice(-60);
  }

  _updateGuide(snapshot, hints) {
    hints = hints || {};
    const tasks = this.state.guide.tasks;
    const set = (id, done) => {
      const item = tasks.find(task => task.id === id);
      if (item && done) item.done = true;
    };
    set('open_store', snapshot && snapshot.hasStore);
    set('first_dish', hints.dishAction || Object.keys(this.state.dishes.records).length > 0 || this.state.dishes.improvements.length > 0);
    set('first_event', this.state.events.totalResolved > 0);
    set('seven_days', this.state.settlements.daily.length >= 7);
    set('healthy_cash', snapshot && Number(snapshot.cash) >= Math.max(20000, Number(snapshot.safeCashLine) || 0));
  }

  importSnapshot(snapshot) {
    snapshot = snapshot || {};
    this.state.lastSnapshot = {
      dayKey: this._dayKey(snapshot),
      districtId: snapshot.districtId || null,
      cash: Number(snapshot.cash || 0),
      reputation: Number(snapshot.reputation || 0),
      hasStore: !!snapshot.hasStore,
      storeOpen: snapshot.storeOpen !== false,
      operatingDays: Number(snapshot.operatingDays || 0)
    };

    if (snapshot.ratingParts) this.recordRating(snapshot.ratingParts, snapshot);
    if (Array.isArray(snapshot.dishes)) snapshot.dishes.forEach(dish => this.recordDish(dish, snapshot));
    if (snapshot.funnel) this.recordFunnel(snapshot.funnel, snapshot);
    if (snapshot.ranking) this.recordRanking(snapshot.ranking, snapshot);
    this._updateGuide(snapshot);
  }

  onTimeAdvanced(advancedMinutes, snapshot) {
    advancedMinutes = Math.max(0, Number(advancedMinutes) || 0);
    if (!advancedMinutes) return { changed: false, activeEvent: this.state.events.active };

    this.state.simMinutes += advancedMinutes;
    this.importSnapshot(snapshot);
    this._expireEffects();
    this._processChains(snapshot);

    const dayKey = this._dayKey(snapshot);
    const monthKey = this._monthKey(snapshot);

    if (this.state.lastDayKey == null) this.state.lastDayKey = dayKey;
    else if (dayKey && dayKey !== this.state.lastDayKey) {
      const previous = this.state.lastDayKey;
      this._settlePreviousDay(snapshot, previous);
      this.state.lastDayKey = dayKey;
      this._accrueDailyInterest(dayKey, snapshot);
      this._updateGuide(snapshot);
    }

    if (this.state.lastMonthKey == null) this.state.lastMonthKey = monthKey;
    else if (monthKey && monthKey !== this.state.lastMonthKey) {
      const previousMonth = this.state.lastMonthKey;
      this._settlePreviousMonth(previousMonth);
      this.state.lastMonthKey = monthKey;
      this._evaluateAwards(snapshot);
    }

    if (!this.state.events.active && this.state.simMinutes >= Number(this.state.events.nextCheckMinute || 0)) {
      // 每个检查周期不是必出事件：控制弹窗密度，避免“事件模拟器”。
      const shouldTrigger = this._random() < 0.46;
      if (shouldTrigger) this.triggerRandomEvent(snapshot);
      this.state.events.nextCheckMinute = this.state.simMinutes + 240 + Math.floor(this._random() * 540);
    }

    this.persist();
    return { changed: true, activeEvent: this.state.events.active };
  }

  getDashboard(snapshot) {
    const daily = this.state.settlements.daily;
    const last7 = daily.slice(-7);
    const revenue7 = sum(last7, 'revenue');
    const profit7 = sum(last7, 'operatingProfit');
    const orders7 = sum(last7, 'orders');
    return {
      schemaVersion: SCHEMA_VERSION,
      unread: this.getUnreadCount(),
      activeEvent: this.state.events.active ? deepCopy(this.state.events.active) : null,
      queuedEvents: this.state.events.queue.length,
      demandMultiplier: this.getDemandMultiplier(snapshot && snapshot.districtId),
      supplyPriceMultiplier: this.getSupplyPriceMultiplier(),
      finance: {
        cash: Number(snapshot && snapshot.cash || 0),
        creditScore: this.state.finance.creditScore,
        creditLimit: this.state.finance.creditLimit,
        availableCredit: this.getAvailableCredit(snapshot),
        outstanding: round(this.state.finance.loans.filter(x => x.status === 'active' || x.status === 'overdue').reduce((n, x) => n + Number(x.outstanding || 0) + Number(x.accruedInterest || 0), 0), 2)
      },
      staff: deepCopy(this.state.staff),
      ratings: deepCopy(this.state.ratings),
      awards: { nominations: this.state.awards.nominations.length, wins: this.state.awards.wins.length },
      last7: { revenue: round(revenue7, 2), operatingProfit: round(profit7, 2), orders: Math.round(orders7) },
      guide: deepCopy(this.state.guide.tasks)
    };
  }
}

module.exports = {
  BusinessOperatingSystemV106,
  STORAGE_KEY,
  SCHEMA_VERSION,
  buildDefaultState,
  clamp
};
