'use strict';

const { clamp, safeNumber, round, softmaxAllocate, deepClone } = require('./utils.js');

function normalizeCompetitor(row = {}, index = 0) {
  return {
    id: row.id || `npc-${index + 1}`,
    name: row.name || `竞争店${index + 1}`,
    rating: clamp(row.rating == null ? 3.8 : row.rating, 1, 5),
    reputation: clamp(row.reputation == null ? 50 : row.reputation, 0, 100),
    quality: clamp(row.quality == null ? 62 : row.quality, 0, 100),
    priceFit: clamp(row.priceFit == null ? 0.8 : row.priceFit, 0.1, 1.3),
    visibility: clamp(row.visibility == null ? 60 : row.visibility, 0, 100),
    marketing: clamp(row.marketing == null ? 20 : row.marketing, 0, 100),
    brandHeat: clamp(row.brandHeat == null ? 35 : row.brandHeat, 0, 100),
    capacityCovers: Math.max(0, Math.floor(safeNumber(row.capacityCovers, 99999))),
    cashStress: clamp(row.cashStress == null ? 0.2 : row.cashStress, 0, 1),
    active: row.active !== false
  };
}

function playerAttractiveness(store = {}, menuAnalysis = {}, context = {}) {
  const rating = clamp(store.rating == null ? 3.7 : store.rating, 1, 5);
  const reputation = clamp(store.reputation == null ? 45 : store.reputation, 0, 100);
  const visibility = clamp(store.visibility == null ? store.property && store.property.visibility == null ? 55 : store.property.visibility : store.visibility, 0, 100);
  const marketing = clamp(store.marketing == null ? 15 : store.marketing, 0, 100);
  const brandHeat = clamp(store.brandHeat == null ? 25 : store.brandHeat, 0, 100);
  const quality = clamp(menuAnalysis.averageQuality == null ? 65 : menuAnalysis.averageQuality, 0, 100);
  const priceFit = clamp(menuAnalysis.priceFit == null ? 0.8 : menuAnalysis.priceFit, 0.1, 1.3);
  const score = rating * 7.5 + reputation * 0.18 + visibility * 0.12 + marketing * 0.055 + brandHeat * 0.08 + quality * 0.13 + priceFit * 15 + safeNumber(context.locationBonus, 0);
  return round(score, 4);
}

function npcAttractiveness(npc) {
  return round(npc.rating * 7.2 + npc.reputation * 0.17 + npc.visibility * 0.11 + npc.marketing * 0.05 + npc.brandHeat * 0.08 + npc.quality * 0.13 + npc.priceFit * 14, 4);
}

function allocateFiniteDemand(totalDemand, store, menuAnalysis, competitorsInput = [], context = {}) {
  const competitors = competitorsInput.map(normalizeCompetitor).filter(row => row.active);
  const participants = [
    { id: 'player', name: store.name || '玩家门店', score: playerAttractiveness(store, menuAnalysis, context), capacityCovers: Math.max(0, safeNumber(context.playerMarketCapacity, Number.MAX_SAFE_INTEGER)), player: true },
    ...competitors.map(npc => ({ id: npc.id, name: npc.name, score: npcAttractiveness(npc), capacityCovers: npc.capacityCovers, player: false }))
  ];
  const allocations = softmaxAllocate(totalDemand, participants, 'score', safeNumber(context.temperature, 16));
  let overflow = 0;
  const rows = participants.map((participant, index) => {
    const raw = allocations[index];
    const served = Math.min(raw, participant.capacityCovers);
    overflow += raw - served;
    return { ...participant, rawAllocation: raw, allocatedCovers: served };
  });

  if (overflow > 0) {
    const receivers = rows.filter(row => row.capacityCovers > row.allocatedCovers);
    let remaining = overflow;
    let guard = 0;
    while (remaining > 0 && receivers.length && guard < 6) {
      const extra = softmaxAllocate(remaining, receivers, 'score', safeNumber(context.temperature, 16));
      let moved = 0;
      receivers.forEach((row, index) => {
        const room = Math.max(0, row.capacityCovers - row.allocatedCovers);
        const add = Math.min(room, extra[index]);
        row.allocatedCovers += add;
        moved += add;
      });
      remaining -= moved;
      if (!moved) break;
      guard += 1;
    }
    overflow = Math.max(0, remaining);
  }

  const player = rows.find(row => row.player) || { allocatedCovers: 0, rawAllocation: 0, score: 0 };
  return {
    totalDemand: Math.max(0, Math.floor(safeNumber(totalDemand))),
    playerDemand: player.allocatedCovers,
    playerRawShare: totalDemand > 0 ? round(player.rawAllocation / totalDemand, 4) : 0,
    playerFinalShare: totalDemand > 0 ? round(player.allocatedCovers / totalDemand, 4) : 0,
    unmetMarketDemand: overflow,
    participants: rows,
    conserved: rows.reduce((acc, row) => acc + row.allocatedCovers, 0) + overflow <= totalDemand
  };
}

function evolveCompetitors(competitorsInput = [], outcome = {}, seedRng) {
  const competitors = competitorsInput.map(normalizeCompetitor);
  const marketDemand = Math.max(1, safeNumber(outcome.totalDemand, 1));
  const shares = new Map((outcome.participants || []).map(row => [row.id, row.allocatedCovers / marketDemand]));
  return competitors.map(npc => {
    const share = safeNumber(shares.get(npc.id), 0);
    const expected = 1 / Math.max(2, competitors.length + 1);
    const relative = expected > 0 ? share / expected : 1;
    const next = deepClone(npc);
    next.brandHeat = round(clamp(next.brandHeat + (relative - 1) * 1.5, 0, 100), 2);
    next.reputation = round(clamp(next.reputation + (relative - 1) * 0.7, 0, 100), 2);
    next.cashStress = round(clamp(next.cashStress + (relative < 0.55 ? 0.025 : -0.012), 0, 1), 4);
    if (next.cashStress > 0.92 && relative < 0.45) next.active = false;
    return next;
  });
}

module.exports = {
  normalizeCompetitor,
  playerAttractiveness,
  npcAttractiveness,
  allocateFiniteDemand,
  evolveCompetitors
};
