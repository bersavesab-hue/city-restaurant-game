'use strict';

const core = require('./restaurantCore.js');

function install(target = globalThis) {
  if (!target) return core;
  if (!target.RestaurantCoreV090) target.RestaurantCoreV090 = core;
  target.CityRestaurantCore = target.CityRestaurantCore || {};
  target.CityRestaurantCore.v090 = core;
  target.CityRestaurantCore.latest = core;
  return core;
}

module.exports = { install, core };
