'use strict';

const BALANCE = require('./balance.js');
const { clamp, safeNumber, round, sum, normalizeShares } = require('./utils.js');

function buildPartySizeMix(segmentMix = {}) {
  const segments = normalizeShares(segmentMix, 'other');
  const combined = {};
  for (const [segment, segmentShare] of Object.entries(segments)) {
    const mix = BALANCE.segmentPartyMix[segment] || BALANCE.segmentPartyMix.other;
    for (const [partySize, share] of Object.entries(mix)) {
      combined[partySize] = (combined[partySize] || 0) + segmentShare * share;
    }
  }
  return normalizeShares(combined, '2');
}

function partyGroupsFromCovers(covers, partyMix) {
  const totalCovers = Math.max(0, Math.floor(safeNumber(covers)));
  if (!totalCovers) return { groups: {}, covers: 0, groupCount: 0, averagePartySize: 0 };
  const mix = normalizeShares(partyMix || { 2: 1 }, '2');
  let expectedCoversPerGroup = 0;
  for (const [size, share] of Object.entries(mix)) {
    expectedCoversPerGroup += Math.max(1, safeNumber(size, 2)) * share;
  }
  expectedCoversPerGroup = Math.max(1, expectedCoversPerGroup);
  const groupCount = Math.max(1, Math.round(totalCovers / expectedCoversPerGroup));
  const groups = {};
  let assignedGroups = 0;
  const entries = Object.entries(mix);
  entries.forEach(([size, share], index) => {
    const count = index === entries.length - 1
      ? Math.max(0, groupCount - assignedGroups)
      : Math.max(0, Math.floor(groupCount * share));
    groups[size] = count;
    assignedGroups += count;
  });
  let representedCovers = Object.entries(groups)
    .reduce((acc, [size, count]) => acc + safeNumber(size) * count, 0);

  // Rounding the expected number of parties can otherwise create more guests than
  // actually arrived. Trim the largest parties first, then use a final residual
  // party so the aggregate party model conserves covers exactly.
  while (representedCovers > totalCovers) {
    const candidates = Object.keys(groups)
      .map(Number)
      .filter(size => groups[size] > 0)
      .sort((a, b) => b - a);
    if (!candidates.length) break;
    const size = candidates[0];
    groups[size] -= 1;
    representedCovers -= size;
  }
  let residual = totalCovers - representedCovers;
  while (residual > 0) {
    const size = Math.min(8, residual);
    groups[size] = (groups[size] || 0) + 1;
    representedCovers += size;
    residual -= size;
  }
  const exactGroupCount = Object.values(groups).reduce((acc, count) => acc + count, 0);
  return {
    groups,
    covers: representedCovers,
    requestedCovers: totalCovers,
    groupCount: exactGroupCount,
    averagePartySize: round(representedCovers / Math.max(1, exactGroupCount), 3)
  };
}

function effectiveTurns(options = {}) {
  const openMinutes = Math.max(120, safeNumber(options.openMinutes, BALANCE.defaultOpenMinutes));
  const dwell = Math.max(20, safeNumber(options.averageDwellMinutes, BALANCE.defaultDwellMinutes));
  const peak = clamp(options.peakConcurrencyFactor, 0.25, 0.95);
  const raw = (openMinutes / dwell) * peak;
  return clamp(raw, 1.5, safeNumber(options.maxTurns, 7.5));
}

function expandSlots(tableMix, turns) {
  const slots = [];
  for (const [seatsKey, countValue] of Object.entries(tableMix || {})) {
    const seats = Math.max(1, Math.floor(safeNumber(seatsKey, 0)));
    const count = Math.max(0, Math.floor(safeNumber(countValue)));
    const tableTurns = Math.max(0, count * turns);
    const whole = Math.floor(tableTurns);
    const fraction = tableTurns - whole;
    for (let i = 0; i < whole; i++) slots.push({ seats, fractional: false });
    if (fraction >= 0.45) slots.push({ seats, fractional: true });
  }
  return slots.sort((a, b) => a.seats - b.seats);
}

function seatParties(tableMix, partyGroups, options = {}) {
  const turns = effectiveTurns(options);
  const slots = expandSlots(tableMix, turns);
  const requested = Object.entries(partyGroups || {})
    .map(([size, count]) => ({ size: Math.max(1, Math.floor(safeNumber(size))), count: Math.max(0, Math.floor(safeNumber(count))) }))
    .filter(row => row.count > 0)
    .sort((a, b) => b.size - a.size);

  let seatedGroups = 0;
  let seatedCovers = 0;
  let requestedGroups = 0;
  let requestedCovers = 0;
  let wastedSeats = 0;
  const rejected = {};
  const assigned = {};

  for (const row of requested) {
    requestedGroups += row.count;
    requestedCovers += row.size * row.count;
    for (let i = 0; i < row.count; i++) {
      let slotIndex = slots.findIndex(slot => slot.seats >= row.size);
      if (slotIndex === -1 && options.allowCombineTables) {
        const first = slots.findIndex(slot => slot.seats >= Math.ceil(row.size / 2));
        if (first !== -1) {
          const firstSlot = slots[first];
          const second = slots.findIndex((slot, idx) => idx !== first && slot.seats + firstSlot.seats >= row.size);
          if (second !== -1) {
            const secondSlot = slots[second];
            const indices = [first, second].sort((a, b) => b - a);
            indices.forEach(index => slots.splice(index, 1));
            seatedGroups += 1;
            seatedCovers += row.size;
            wastedSeats += firstSlot.seats + secondSlot.seats - row.size;
            assigned[row.size] = (assigned[row.size] || 0) + 1;
            continue;
          }
        }
      }
      if (slotIndex === -1) {
        rejected[row.size] = (rejected[row.size] || 0) + 1;
        continue;
      }
      const slot = slots.splice(slotIndex, 1)[0];
      seatedGroups += 1;
      seatedCovers += row.size;
      wastedSeats += Math.max(0, slot.seats - row.size);
      assigned[row.size] = (assigned[row.size] || 0) + 1;
    }
  }

  const totalSeatTurns = Object.entries(tableMix || {})
    .reduce((acc, [seats, count]) => acc + safeNumber(seats) * safeNumber(count) * turns, 0);
  const seatUtilization = totalSeatTurns > 0 ? seatedCovers / totalSeatTurns : 0;
  const rejectionRate = requestedGroups > 0 ? (requestedGroups - seatedGroups) / requestedGroups : 0;
  const wasteRatio = seatedCovers + wastedSeats > 0 ? wastedSeats / (seatedCovers + wastedSeats) : 0;

  return {
    turns: round(turns, 3),
    requestedGroups,
    requestedCovers,
    seatedGroups,
    seatedCovers,
    rejectedGroups: requestedGroups - seatedGroups,
    rejectedCovers: Math.max(0, requestedCovers - seatedCovers),
    rejectedByPartySize: rejected,
    assignedByPartySize: assigned,
    wastedSeats,
    wasteRatio: round(wasteRatio, 4),
    seatUtilization: round(clamp(seatUtilization, 0, 1.5), 4),
    rejectionRate: round(clamp(rejectionRate, 0, 1), 4),
    remainingSeatSlots: slots.length,
    bottleneck: rejectionRate > 0.12 || seatUtilization > 0.92,
    mismatch: wasteRatio > 0.3 && rejectionRate > 0.03
  };
}

function recommendTableMix(partyMix, totalTables = 8) {
  const mix = normalizeShares(partyMix || { 2: 1 }, '2');
  const counts = { 2: 0, 4: 0, 6: 0, 8: 0 };
  const groups = [
    { seats: 2, demand: (mix[1] || 0) + (mix[2] || 0) },
    { seats: 4, demand: (mix[3] || 0) + (mix[4] || 0) },
    { seats: 6, demand: (mix[5] || 0) + (mix[6] || 0) },
    { seats: 8, demand: (mix[7] || 0) + (mix[8] || 0) + (mix[9] || 0) + (mix[10] || 0) }
  ];
  let assigned = 0;
  groups.forEach((row, index) => {
    const count = index === groups.length - 1
      ? Math.max(0, totalTables - assigned)
      : Math.max(0, Math.round(totalTables * row.demand));
    counts[row.seats] = count;
    assigned += count;
  });
  while (sum(Object.values(counts)) > totalTables) {
    const key = Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
    counts[key] -= 1;
  }
  while (sum(Object.values(counts)) < totalTables) counts[4] += 1;
  return counts;
}

module.exports = {
  buildPartySizeMix,
  partyGroupsFromCovers,
  effectiveTurns,
  seatParties,
  recommendTableMix
};
