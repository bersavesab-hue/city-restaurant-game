'use strict';

const { clamp, safeNumber, round, deepClone, SeededRandom, assertFiniteObject } = require('./utils.js');
const spaceModel = require('./spaceModel.js');
const tableModel = require('./tableModel.js');
const staffModel = require('./staffModel.js');
const dishModel = require('./dishModel.js');
const inventoryModel = require('./inventoryModel.js');
const supplyModel = require('./supplyModel.js');
const districtMarketModel = require('./districtMarketModel.js');
const competitorModel = require('./competitorModel.js');
const customerJourney = require('./customerJourney.js');
const kitchenModel = require('./kitchenModel.js');
const financeModel = require('./financeModel.js');
const dailyReport = require('./dailyReport.js');
const saveMigration = require('./saveMigration.js');

function effectiveTableMix(store, areaPlan) {
  const source = deepClone(store.layout && (store.layout.tables || store.layout.tableMix) || store.tableMix || { 2: 3, 4: 3 });
  if (!areaPlan || areaPlan.valid || areaPlan.requiredDiningArea <= 0) return source;
  const factor = clamp(areaPlan.property.usableDiningArea / Math.max(1, areaPlan.requiredDiningArea), 0.2, 1);
  const result = {};
  for (const [seats, count] of Object.entries(source)) result[seats] = Math.max(0, Math.floor(safeNumber(count) * factor));
  if (Object.values(result).reduce((a, b) => a + b, 0) === 0 && areaPlan.property.usableDiningArea >= 3.5) result[2] = 1;
  return result;
}

function estimateSatisfaction(menu, journey, kitchen, service, staffCapacity) {
  const quality = clamp(menu.averageQuality || 65, 0, 100) * (1 - safeNumber(kitchen.qualityPenalty));
  const priceScore = clamp((menu.priceFit || 0.8) * 100, 0, 100);
  const ticketPenalty = Math.max(0, safeNumber(kitchen.avgTicketMinutes) - 12) * 1.1;
  const servicePenalty = Math.max(0, safeNumber(service.avgServiceDelayMinutes) - 4) * 1.45;
  const waitPenalty = Math.max(0, safeNumber(journey.wait && journey.wait.averageWaitMinutes) - 8) * 0.7;
  const cleanliness = clamp(safeNumber(staffCapacity.cleaningFactor, 1) * 82, 55, 92);
  return round(clamp(quality * 0.42 + priceScore * 0.18 + cleanliness * 0.12 + 32 - ticketPenalty - servicePenalty - waitPenalty, 0, 100), 2);
}

function ratingFromSatisfaction(score) {
  return round(clamp(1.3 + score / 26, 1, 5), 2);
}

function calculateProjectedIngredientUsage(menuAnalysis, fulfilledDishUnits) {
  const usage = {};
  for (const row of menuAnalysis.rows || []) {
    const units = Math.max(0, safeNumber(fulfilledDishUnits[row.dish.id]));
    for (const ingredient of row.dish.ingredients || []) {
      usage[ingredient.id] = (usage[ingredient.id] || 0) + units * safeNumber(ingredient.qty, 0.12);
    }
  }
  return usage;
}

function simulateDay(input = {}) {
  const seed = input.seed == null ? `${input.day && input.day.day || 1}:${input.store && input.store.id || 'store'}` : input.seed;
  const rng = seed instanceof SeededRandom ? seed : new SeededRandom(seed);
  const store = deepClone(input.store || {});
  const districtInput = deepClone(input.district || {});
  const competitors = deepClone(input.competitors || []);
  const dayContext = deepClone(input.context || {});
  dayContext.day = input.day || dayContext.day || {};

  store.property = store.property || { grossArea: store.area || 60 };
  store.layout = store.layout || { tables: store.tableMix || { 2: 3, 4: 3 } };
  store.inventory = store.inventory || {};
  store.staff = store.staff || [];
  store.menu = store.menu || [];
  store.cash = Math.max(0, safeNumber(store.cash, 0));

  const marketDemand = districtMarketModel.demandForDay(districtInput, dayContext);
  const menuAnalysis = dishModel.weightedMenu(store.menu, marketDemand.segmentMix, marketDemand.district.avgSpend);
  const areaPlan = spaceModel.evaluateAreaPlan(store.property, store.layout);
  const actualTableMix = effectiveTableMix(store, areaPlan);
  const staffCapacity = staffModel.calculateCapacity(store.staff, store);

  const open = store.open !== false && store.isOpen !== false;
  const theoreticalSeatTurns = Object.entries(actualTableMix).reduce((acc, [seats, count]) => acc + safeNumber(seats) * safeNumber(count) * tableModel.effectiveTurns(dayContext), 0);
  const playerMarketCapacity = open && menuAnalysis.menu.length
    ? Math.floor(Math.max(0, theoreticalSeatTurns * 1.35))
    : 0;

  const competition = competitorModel.allocateFiniteDemand(
    marketDemand.totalDemand,
    store,
    menuAnalysis,
    competitors,
    { ...dayContext, playerMarketCapacity }
  );

  const journeyBaseStore = { ...store, layout: { ...store.layout, tables: actualTableMix } };
  const journeyBase = customerJourney.createJourney(
    open ? competition.playerDemand : 0,
    journeyBaseStore,
    menuAnalysis,
    marketDemand.segmentMix,
    dayContext
  );

  const service = kitchenModel.processService(journeyBase.seatedCovers, staffCapacity, dayContext);
  const serviceAcceptedCovers = service.acceptedCovers;
  const dishesPerCover = dishModel.dishesPerCover(menuAnalysis, { avgSpend: marketDemand.district.avgSpend, dishesPerCover: dayContext.dishesPerCover });
  const requestedDishUnits = Math.ceil(serviceAcceptedCovers * dishesPerCover);
  const kitchen = kitchenModel.processKitchen(requestedDishUnits, menuAnalysis, staffCapacity, store);
  const kitchenCoverRatio = requestedDishUnits > 0 ? kitchen.acceptedDishUnits / requestedDishUnits : 1;
  const kitchenAcceptedCovers = Math.floor(serviceAcceptedCovers * clamp(kitchenCoverRatio, 0, 1));

  const plannedUnits = dishModel.plannedDishUnits(menuAnalysis, kitchenAcceptedCovers, {
    avgSpend: marketDemand.district.avgSpend,
    dishesPerCover
  });
  const fulfillment = inventoryModel.fulfillDishPlan(store.inventory, menuAnalysis, plannedUnits);
  const inventoryAcceptedCovers = Math.floor(kitchenAcceptedCovers * clamp(fulfillment.fulfillmentRate, 0, 1));
  const journey = customerJourney.finalizeJourney(journeyBase, {
    serviceAcceptedCovers,
    kitchenAcceptedCovers,
    inventoryAcceptedCovers
  });

  const actualFulfilledUnits = {};
  const paidRatio = kitchenAcceptedCovers > 0 ? journey.paidCovers / kitchenAcceptedCovers : 0;
  for (const [dishId, units] of Object.entries(fulfillment.fulfilled)) actualFulfilledUnits[dishId] = Math.floor(units * paidRatio);

  // Re-run consumption from the original stock for the actual paid sales so accounting and inventory stay consistent.
  const finalFulfillment = inventoryModel.fulfillDishPlan(store.inventory, menuAnalysis, actualFulfilledUnits);
  const aged = inventoryModel.ageInventory(finalFulfillment.inventory, 1, dayContext.inventory || {});
  const revenue = financeModel.calculateRevenue(menuAnalysis, actualFulfilledUnits, store);
  const finance = financeModel.calculateDailyFinance({
    store,
    revenue,
    paidCovers: journey.paidCovers,
    laborCost: staffCapacity.laborCost,
    cogs: finalFulfillment.cogs,
    spoilageCost: aged.spoilageCost,
    purchaseCashOut: safeNumber(input.purchaseCashOut, 0),
    capitalExpenditure: safeNumber(input.capitalExpenditure, 0)
  });

  const satisfaction = journey.paidCovers > 0 ? estimateSatisfaction(menuAnalysis, journey, kitchen, service, staffCapacity) : null;
  const dayRating = satisfaction == null ? null : ratingFromSatisfaction(satisfaction);
  const oldRating = clamp(store.rating == null ? 3.7 : store.rating, 1, 5);
  const oldReputation = clamp(store.reputation == null ? 45 : store.reputation, 0, 100);
  const nextStore = deepClone(store);
  nextStore.cash = finance.endingCash;
  nextStore.inventory = aged.inventory;
  nextStore.staff = staffModel.updateAfterDay(store.staff, { kitchen: kitchen.utilization, service: service.utilization });
  if (dayRating != null) {
    const ratingWeight = clamp(journey.paidCovers / 120, 0.04, 0.22);
    nextStore.rating = round(oldRating * (1 - ratingWeight) + dayRating * ratingWeight, 3);
    nextStore.reputation = round(clamp(oldReputation + (dayRating - 3.7) * 0.8 + Math.min(0.7, journey.paidCovers / 400), 0, 100), 3);
  } else {
    nextStore.rating = oldRating;
    nextStore.reputation = round(clamp(oldReputation - (open ? 0.08 : 0.02), 0, 100), 3);
  }
  nextStore.brandHeat = round(clamp(safeNumber(store.brandHeat, 25) * 0.985 + journey.paidCovers * 0.012 + Math.max(0, (dayRating || 3.5) - 3.8) * 0.8, 0, 100), 3);

  const ingredientUsage = calculateProjectedIngredientUsage(menuAnalysis, actualFulfilledUnits);
  const reorderPlan = supplyModel.buildReorderPlan(
    nextStore.inventory,
    ingredientUsage,
    store.suppliers || input.suppliers || [],
    input.reorderPolicy || {}
  );

  const evolvedCompetitors = competitorModel.evolveCompetitors(competitors, competition, rng);
  const updatedDistrict = districtMarketModel.updateDistrictAfterDay(marketDemand.district, {
    demandPressure: marketDemand.totalDemand / Math.max(1, marketDemand.district.baseDemand),
    vacancyPressure: competition.unmetMarketDemand > 0 ? 0.02 : 0,
    newEntrants: 0,
    exits: evolvedCompetitors.filter((npc, index) => competitors[index] && competitors[index].active !== false && npc.active === false).length
  });

  const report = dailyReport.buildDailyReport({
    journey,
    seating: journey.seating,
    kitchen,
    service,
    finance,
    inventory: { spoilageCost: aged.spoilageCost, shortages: finalFulfillment.shortages },
    menu: menuAnalysis,
    market: competition
  });
  report.date = deepClone(input.day || null);
  report.satisfaction = satisfaction;
  report.dayRating = dayRating;
  report.space = {
    valid: areaPlan.valid,
    grossArea: areaPlan.property.grossArea,
    usableDiningArea: areaPlan.property.usableDiningArea,
    requiredDiningArea: areaPlan.requiredDiningArea,
    remainingArea: areaPlan.remainingArea,
    warnings: areaPlan.warnings
  };
  report.finance = finance;
  report.inventory = {
    spoilageCost: aged.spoilageCost,
    spoiled: aged.spoiled,
    shortages: finalFulfillment.shortages,
    reorderPlan
  };
  report.staff = {
    headcount: staffCapacity.headcount,
    laborCost: staffCapacity.laborCost,
    averageFatigue: staffCapacity.averageFatigue,
    averageMorale: staffCapacity.averageMorale,
    turnoverRisk: staffModel.turnoverRisk(nextStore.staff)
  };

  const output = {
    version: '0.9.0',
    seed: typeof seed === 'object' ? null : seed,
    nextStore,
    nextDistrict: updatedDistrict,
    nextCompetitors: evolvedCompetitors,
    report,
    diagnostics: {
      marketDemand,
      menu: menuAnalysis,
      areaPlan,
      staffCapacity,
      competition,
      journey,
      kitchen,
      service,
      fulfillment: finalFulfillment,
      ingredientUsage,
      reorderPlan
    }
  };

  assertFiniteObject(output);
  return output;
}

function simulateDays(input = {}, days = 7) {
  let store = deepClone(input.store || {});
  let district = deepClone(input.district || {});
  let competitors = deepClone(input.competitors || []);
  const reports = [];
  const count = Math.max(1, Math.floor(safeNumber(days, 7)));
  for (let i = 0; i < count; i++) {
    const day = { ...(input.day || {}), day: safeNumber(input.day && input.day.day, 1) + i, weekday: ((safeNumber(input.day && input.day.weekday, 1) - 1 + i) % 7) + 1 };
    const result = simulateDay({ ...input, store, district, competitors, day, seed: `${input.seed || 'v090'}:${day.day}` });
    store = result.nextStore;
    district = result.nextDistrict;
    competitors = result.nextCompetitors;
    reports.push(result.report);
  }
  return { store, district, competitors, reports };
}

function migrateState(state) {
  return saveMigration.migrateState(state);
}

function simulateLegacyDay(state, options = {}) {
  // Lazy require avoids a circular dependency during module initialization.
  return require('./legacyAdapter.js').simulateLegacyDay(state, options);
}

module.exports = {
  version: '0.9.0',
  simulateDay,
  simulateDays,
  migrateState,
  simulateLegacyDay,
  modules: {
    spaceModel,
    tableModel,
    staffModel,
    dishModel,
    inventoryModel,
    supplyModel,
    districtMarketModel,
    competitorModel,
    customerJourney,
    kitchenModel,
    financeModel,
    dailyReport,
    saveMigration
  }
};
