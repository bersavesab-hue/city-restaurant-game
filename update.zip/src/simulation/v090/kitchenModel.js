'use strict';

const BALANCE = require('./balance.js');
const { clamp, safeNumber, round } = require('./utils.js');

function calculateKitchen(menuAnalysis, staffCapacity, store = {}) {
  const averageCookMinutes = Math.max(2, safeNumber(menuAnalysis.averageCookMinutes, 12));
  const skillQuality = clamp(safeNumber(store.kitchenSkillFactor, 1), 0.6, 1.45);
  const stations = Math.max(1, Math.floor(safeNumber(store.stoves || store.stations || store.kitchenStations, 2)));
  const stationFactor = clamp(0.68 + Math.log2(stations + 1) * 0.28, 0.8, 1.7);
  const prepFactor = clamp(safeNumber(store.prepReadiness, 0.82), 0.45, 1.15);
  const productiveMinutes = Math.max(0, safeNumber(staffCapacity.cookProductiveMinutes));
  const dishCapacity = productiveMinutes * stationFactor * prepFactor * skillQuality / averageCookMinutes;
  return {
    averageCookMinutes: round(averageCookMinutes, 2),
    stations,
    stationFactor: round(stationFactor, 4),
    prepFactor: round(prepFactor, 4),
    skillQuality: round(skillQuality, 4),
    dishCapacity: Math.max(0, Math.floor(dishCapacity))
  };
}

function processKitchen(requestedDishUnits, menuAnalysis, staffCapacity, store = {}) {
  const kitchen = calculateKitchen(menuAnalysis, staffCapacity, store);
  const requested = Math.max(0, Math.floor(safeNumber(requestedDishUnits)));
  const accepted = Math.min(requested, kitchen.dishCapacity);
  const utilization = kitchen.dishCapacity > 0 ? requested / kitchen.dishCapacity : requested > 0 ? 2 : 0;
  const overload = Math.max(0, utilization - BALANCE.cookUtilizationSoftCap);
  const baseTicket = Math.max(4, kitchen.averageCookMinutes * 0.72);
  const avgTicketMinutes = baseTicket * (1 + overload * overload * 3.2 + Math.max(0, utilization - 1) * 1.8);
  const qualityPenalty = clamp(overload * 0.18, 0, 0.35);

  return {
    ...kitchen,
    requestedDishUnits: requested,
    acceptedDishUnits: accepted,
    rejectedDishUnits: requested - accepted,
    utilization: round(utilization, 4),
    avgTicketMinutes: round(avgTicketMinutes, 2),
    qualityPenalty: round(qualityPenalty, 4),
    bottleneck: utilization > 0.95,
    severeOverload: utilization > 1.15
  };
}

function processService(requestedCovers, staffCapacity, options = {}) {
  const requested = Math.max(0, Math.floor(safeNumber(requestedCovers)));
  const capacity = Math.max(0, Math.floor(safeNumber(staffCapacity.serviceCoverCapacity)));
  const accepted = Math.min(requested, capacity);
  const utilization = capacity > 0 ? requested / capacity : requested > 0 ? 2 : 0;
  const overload = Math.max(0, utilization - BALANCE.waiterUtilizationSoftCap);
  const avgServiceDelayMinutes = Math.max(1.5, 3.5 * (1 + overload * overload * 4 + Math.max(0, utilization - 1) * 2.2));
  const cleaningFactor = clamp(safeNumber(staffCapacity.cleaningFactor, 1), 0.7, 1.1);
  return {
    requestedCovers: requested,
    serviceCoverCapacity: capacity,
    acceptedCovers: accepted,
    rejectedCovers: requested - accepted,
    utilization: round(utilization, 4),
    avgServiceDelayMinutes: round(avgServiceDelayMinutes / cleaningFactor, 2),
    bottleneck: utilization > 0.96
  };
}

module.exports = {
  calculateKitchen,
  processKitchen,
  processService
};
