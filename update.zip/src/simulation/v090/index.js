'use strict';
module.exports = require('./restaurantCore.js');
