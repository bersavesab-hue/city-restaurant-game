'use strict';

const { clamp, safeNumber, round, deepClone } = require('./utils.js');

function normalizeInventory(inventory = {}) {
  const result = {};
  for (const [id, itemValue] of Object.entries(inventory || {})) {
    const item = typeof itemValue === 'number' ? { qty: itemValue } : itemValue || {};
    result[id] = {
      id,
      qty: Math.max(0, safeNumber(item.qty, 0)),
      unitCost: Math.max(0, safeNumber(item.unitCost || item.cost, 0)),
      freshness: clamp(item.freshness == null ? 1 : item.freshness > 1 ? item.freshness / 100 : item.freshness, 0, 1),
      shelfLifeDays: Math.max(1, safeNumber(item.shelfLifeDays, 4)),
      ageDays: Math.max(0, safeNumber(item.ageDays, 0)),
      quality: clamp(item.quality == null ? 0.8 : item.quality > 1 ? item.quality / 100 : item.quality, 0.2, 1.2)
    };
  }
  return result;
}

function ingredientNeedPerDish(dish) {
  const requirements = {};
  for (const ing of dish.ingredients || []) {
    requirements[ing.id] = (requirements[ing.id] || 0) + Math.max(0, safeNumber(ing.qty, 0.12));
  }
  return requirements;
}

function maxDishUnits(inventory, dish) {
  const requirements = ingredientNeedPerDish(dish);
  const keys = Object.keys(requirements);
  if (!keys.length) return Number.POSITIVE_INFINITY;
  let maxUnits = Number.POSITIVE_INFINITY;
  for (const key of keys) {
    const item = inventory[key];
    if (!item) return 0;
    maxUnits = Math.min(maxUnits, Math.floor(item.qty / Math.max(0.0001, requirements[key])));
  }
  return maxUnits;
}

function fulfillDishPlan(inventoryInput, menuAnalysis, plannedUnits = {}) {
  const inventory = normalizeInventory(inventoryInput);
  const fulfilled = {};
  const shortages = [];
  let cogs = 0;
  let fulfilledUnits = 0;
  let requestedUnits = 0;

  for (const row of menuAnalysis.rows || []) {
    const dish = row.dish;
    const requested = Math.max(0, Math.floor(safeNumber(plannedUnits[dish.id])));
    requestedUnits += requested;
    const possible = Math.min(requested, maxDishUnits(inventory, dish));
    fulfilled[dish.id] = possible;
    fulfilledUnits += possible;
    if (possible < requested) shortages.push({ dishId: dish.id, dishName: dish.name, requested, fulfilled: possible, lost: requested - possible });
    const requirements = ingredientNeedPerDish(dish);
    for (const [ingredientId, qtyPerDish] of Object.entries(requirements)) {
      const item = inventory[ingredientId];
      if (!item) continue;
      const used = qtyPerDish * possible;
      item.qty = Math.max(0, item.qty - used);
      cogs += used * item.unitCost;
    }
    if (dish.foodCost != null && !Object.keys(requirements).length) cogs += dish.foodCost * possible;
  }

  return {
    inventory,
    requestedUnits,
    fulfilledUnits,
    fulfillmentRate: requestedUnits > 0 ? round(fulfilledUnits / requestedUnits, 4) : 1,
    fulfilled,
    shortages,
    cogs: round(cogs, 2)
  };
}

function ageInventory(inventoryInput, days = 1, options = {}) {
  const inventory = normalizeInventory(inventoryInput);
  let spoilageCost = 0;
  let spoiledQty = 0;
  const spoiled = [];
  const elapsed = Math.max(0, safeNumber(days, 1));
  for (const item of Object.values(inventory)) {
    const before = item.qty;
    item.ageDays += elapsed;
    const decay = elapsed / Math.max(1, item.shelfLifeDays);
    item.freshness = clamp(item.freshness - decay * safeNumber(options.freshnessDecayFactor, 0.55), 0, 1);
    let spoilRatio = 0;
    if (item.ageDays > item.shelfLifeDays) spoilRatio = clamp(0.25 + (item.ageDays - item.shelfLifeDays) * 0.18, 0, 1);
    else if (item.freshness < 0.25) spoilRatio = clamp((0.25 - item.freshness) * 1.5, 0, 0.35);
    const loss = before * spoilRatio;
    if (loss > 0) {
      item.qty = Math.max(0, before - loss);
      spoiledQty += loss;
      spoilageCost += loss * item.unitCost;
      spoiled.push({ id: item.id, qty: round(loss, 3), cost: round(loss * item.unitCost, 2) });
    }
  }
  return { inventory, spoiled, spoiledQty: round(spoiledQty, 3), spoilageCost: round(spoilageCost, 2) };
}

function inventoryValue(inventoryInput) {
  const inventory = normalizeInventory(inventoryInput);
  return round(Object.values(inventory).reduce((acc, item) => acc + item.qty * item.unitCost, 0), 2);
}

module.exports = {
  normalizeInventory,
  ingredientNeedPerDish,
  maxDishUnits,
  fulfillDishPlan,
  ageInventory,
  inventoryValue
};
