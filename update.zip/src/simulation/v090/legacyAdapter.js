'use strict';

const { safeNumber, clamp, deepClone } = require('./utils.js');
const core = require('./restaurantCore.js');

function mapLegacyMenu(state) {
  const store = state.store || {};
  const globalDishes = Array.isArray(state.dishes) ? state.dishes : [];
  const storeMenu = Array.isArray(store.menu) ? store.menu : [];
  const source = storeMenu.length ? storeMenu : globalDishes;
  return source.map((dish, index) => {
    if (typeof dish === 'string') {
      const match = globalDishes.find(row => row.id === dish || row.name === dish);
      if (match) dish = match;
      else dish = { id: dish, name: dish };
    }
    return {
      id: dish.id || `legacy-dish-${index + 1}`,
      name: dish.name || `菜品${index + 1}`,
      price: safeNumber(dish.price || dish.sellPrice, 28),
      foodCost: dish.cost == null ? null : safeNumber(dish.cost),
      cookMinutes: safeNumber(dish.cookMinutes || dish.cook || dish.time, 12),
      quality: safeNumber(dish.quality == null ? dish.taste : dish.quality, 68),
      popularity: safeNumber(dish.popularity == null ? dish.viral : dish.popularity, 50),
      ingredients: Array.isArray(dish.ingredients)
        ? dish.ingredients.map(item => typeof item === 'string' ? { id: item, qty: 0.12 } : item)
        : [],
      segmentFit: dish.segmentFit || { other: 1 },
      enabled: dish.enabled !== false && dish.status !== '下架'
    };
  });
}

function mapLegacyInventory(state) {
  const store = state.store || {};
  const inventory = store.inventory || state.inventory || {};
  const result = {};
  for (const [id, value] of Object.entries(inventory)) {
    if (typeof value === 'number') {
      result[id] = { qty: value, unitCost: 0, freshness: 0.85, shelfLifeDays: 4 };
      continue;
    }
    result[id] = {
      qty: safeNumber(value.qty, 0),
      unitCost: safeNumber(value.unitCost || value.cost, 0),
      freshness: value.freshness == null ? 0.85 : value.freshness,
      shelfLifeDays: safeNumber(value.shelfLifeDays, 4),
      ageDays: safeNumber(value.ageDays, 0),
      quality: value.quality == null ? 0.8 : value.quality
    };
  }
  return result;
}

function inferStaff(state) {
  const store = state.store || {};
  if (Array.isArray(store.staff) && store.staff.length) return deepClone(store.staff);
  if (Array.isArray(state.staff) && state.staff.length) return deepClone(state.staff);
  const staffCount = Math.max(0, Math.floor(safeNumber(store.staffCount || state.staffCount, 0)));
  const rows = [];
  for (let i = 0; i < staffCount; i++) rows.push({ id: `legacy-staff-${i + 1}`, role: i < Math.max(1, Math.ceil(staffCount * 0.35)) ? 'cook' : 'waiter', skill: 0.8, dailyWage: 160 });
  return rows;
}

function inferTableMix(store) {
  if (store.layout && (store.layout.tables || store.layout.tableMix)) return deepClone(store.layout.tables || store.layout.tableMix);
  if (store.tableMix) return deepClone(store.tableMix);
  const seats = Math.max(4, Math.floor(safeNumber(store.seats || store.seatCount, 24)));
  const four = Math.floor(seats / 6);
  const two = Math.max(1, Math.floor((seats - four * 4) / 2));
  return { 2: two, 4: four };
}

function inferProperty(store) {
  const source = store.property || store.propertyListing || store.lease || {};
  return {
    grossArea: safeNumber(source.grossArea || source.area || store.area, 60),
    frontage: safeNumber(source.frontage || store.frontage, 5.5),
    visibility: safeNumber(source.visibility || store.visibility, 60),
    layout: source.layout || 'rectangular',
    fixedAreas: deepClone(source.fixedAreas || {})
  };
}

function adaptState(stateInput, options = {}) {
  const state = stateInput || {};
  const storeSource = state.store || {};
  const district = options.district || state.district || {
    id: storeSource.district || state.selectedDistrict || state.currentDistrict || 'legacy',
    name: options.districtName || '当前商圈',
    baseDemand: safeNumber(options.baseDemand, 1600),
    avgSpend: safeNumber(options.avgSpend, 30),
    saturation: safeNumber(options.saturation, 70),
    restaurantCount: safeNumber(options.restaurantCount, 60),
    rentIndex: safeNumber(options.rentIndex, 0.7),
    segmentMix: options.segmentMix || { other: 1 }
  };

  const store = {
    id: storeSource.id || 'player-store',
    name: storeSource.name || '玩家门店',
    cash: safeNumber(state.cash == null ? storeSource.cash : state.cash, 0),
    rating: clamp(safeNumber(storeSource.rating, 3.7), 1, 5),
    reputation: clamp(safeNumber(storeSource.reputation, 45), 0, 100),
    brandHeat: clamp(safeNumber(storeSource.brandHeat, 25), 0, 100),
    visibility: safeNumber(storeSource.visibility, 60),
    open: storeSource.open !== false,
    rentMonthly: safeNumber(storeSource.rentMonthly || storeSource.rent, 0),
    propertyFeeMonthly: safeNumber(storeSource.propertyFeeMonthly, 0),
    utilitiesBaseDaily: safeNumber(storeSource.utilitiesBaseDaily, 32),
    utilitiesPerCover: safeNumber(storeSource.utilitiesPerCover, 0.8),
    property: inferProperty(storeSource),
    layout: { tables: inferTableMix(storeSource) },
    stoves: safeNumber(storeSource.stoves, 2),
    prepReadiness: safeNumber(storeSource.prepReadiness, 0.8),
    staff: inferStaff(state),
    menu: mapLegacyMenu(state),
    inventory: mapLegacyInventory(state),
    suppliers: deepClone(storeSource.suppliers || state.suppliers || [])
  };

  return {
    seed: options.seed || `legacy:${safeNumber(state.day, 1)}`,
    day: { day: safeNumber(state.day, 1), weekday: safeNumber(options.weekday, 1) },
    context: {
      weather: options.weather || state.weather || 'sunny',
      eventMultiplier: safeNumber(options.eventMultiplier, 1),
      openMinutes: safeNumber(options.openMinutes, 660)
    },
    district,
    store,
    competitors: deepClone(options.competitors || state.competitors || state.npcRestaurants || [])
  };
}

function simulateLegacyDay(state, options = {}) {
  const adapted = adaptState(state, options);
  return core.simulateDay(adapted);
}

module.exports = { adaptState, simulateLegacyDay };
