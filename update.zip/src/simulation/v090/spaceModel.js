'use strict';

const BALANCE = require('./balance.js');
const { clamp, safeNumber, round, sum, deepClone } = require('./utils.js');

function defaultZoneRatios(grossArea) {
  const area = Math.max(12, safeNumber(grossArea, 60));
  if (area < 35) {
    return { kitchen: 0.24, storage: 0.06, wash: 0.05, toilet: 0.06, cashierWaiting: 0.06, structure: 0.06 };
  }
  if (area < 80) {
    return { kitchen: 0.25, storage: 0.07, wash: 0.05, toilet: 0.06, cashierWaiting: 0.07, structure: 0.05 };
  }
  return { kitchen: 0.27, storage: 0.07, wash: 0.05, toilet: 0.06, cashierWaiting: 0.07, structure: 0.05 };
}

function normalizeProperty(property = {}) {
  const grossArea = Math.max(8, safeNumber(property.grossArea || property.area, 60));
  const ratios = { ...defaultZoneRatios(grossArea), ...(property.zoneRatios || {}) };
  const fixedAreas = property.fixedAreas || {};

  const zones = {};
  const zoneKeys = ['kitchen', 'storage', 'wash', 'toilet', 'cashierWaiting', 'structure'];
  for (const key of zoneKeys) {
    const explicit = safeNumber(fixedAreas[key], NaN);
    zones[key] = Number.isFinite(explicit)
      ? Math.max(0, explicit)
      : Math.max(0, grossArea * clamp(ratios[key], 0, 0.7));
  }

  const fixedTotal = sum(Object.values(zones));
  const rawFront = Math.max(0, grossArea - fixedTotal);
  const circulationRatio = clamp(
    property.circulationRatio == null ? (grossArea < 50 ? 0.14 : 0.16) : property.circulationRatio,
    0.08,
    0.35
  );
  const circulationArea = rawFront * circulationRatio;
  const usableDiningArea = Math.max(0, rawFront - circulationArea);

  const frontage = Math.max(1.5, safeNumber(property.frontage, Math.sqrt(grossArea) * 0.8));
  const depth = Math.max(2, safeNumber(property.depth, grossArea / frontage));

  return {
    grossArea: round(grossArea),
    frontage: round(frontage),
    depth: round(depth),
    shape: property.shape || property.layout || 'rectangular',
    zones: Object.fromEntries(Object.entries(zones).map(([key, value]) => [key, round(value)])),
    fixedTotal: round(fixedTotal),
    frontOfHouseArea: round(rawFront),
    circulationArea: round(circulationArea),
    usableDiningArea: round(usableDiningArea),
    circulationRatio: round(circulationRatio, 4),
    constraints: deepClone(property.constraints || {})
  };
}

function tableOperationalFootprint(seats, spec = {}) {
  const base = BALANCE.tableDefaults[seats] || BALANCE.tableDefaults[4];
  const width = Math.max(0.4, safeNumber(spec.width, base.width));
  const depth = Math.max(0.4, safeNumber(spec.depth, base.depth));
  const clearance = Math.max(0.3, safeNumber(spec.clearance, base.clearance));
  const operationalWidth = width + clearance * 2;
  const operationalDepth = depth + clearance * 2;
  return {
    seats: Number(seats),
    width: round(width),
    depth: round(depth),
    clearance: round(clearance),
    physicalArea: round(width * depth),
    operationalArea: round(operationalWidth * operationalDepth),
    operationalWidth: round(operationalWidth),
    operationalDepth: round(operationalDepth)
  };
}

function estimateLayoutArea(tableMix = {}, customTableSpecs = {}) {
  const details = [];
  let physicalArea = 0;
  let operationalArea = 0;
  let seats = 0;
  let tables = 0;

  for (const [seatKey, countValue] of Object.entries(tableMix || {})) {
    const seatCount = Math.max(1, Math.floor(safeNumber(seatKey, 0)));
    const count = Math.max(0, Math.floor(safeNumber(countValue)));
    if (!count) continue;
    const footprint = tableOperationalFootprint(seatCount, customTableSpecs[seatKey] || {});
    details.push({ ...footprint, count, area: round(footprint.operationalArea * count) });
    physicalArea += footprint.physicalArea * count;
    operationalArea += footprint.operationalArea * count;
    seats += seatCount * count;
    tables += count;
  }

  return {
    tables,
    seats,
    physicalArea: round(physicalArea),
    operationalArea: round(operationalArea),
    details
  };
}

function evaluateAreaPlan(property, layout = {}) {
  const normalized = normalizeProperty(property);
  const tableArea = estimateLayoutArea(layout.tables || layout.tableMix || {}, layout.tableSpecs || {});
  const looseFurnitureArea = (layout.furniture || [])
    .filter(item => !item.tableSeats)
    .reduce((acc, item) => {
      const w = Math.max(0, safeNumber(item.width));
      const d = Math.max(0, safeNumber(item.depth));
      const clearance = Math.max(0, safeNumber(item.clearance, 0.25));
      return acc + (w + clearance * 2) * (d + clearance * 2) * Math.max(1, safeNumber(item.count, 1));
    }, 0);
  const requiredDiningArea = tableArea.operationalArea + looseFurnitureArea;
  const remainingArea = normalized.usableDiningArea - requiredDiningArea;
  const utilization = normalized.usableDiningArea > 0
    ? requiredDiningArea / normalized.usableDiningArea
    : 1;

  const warnings = [];
  if (remainingArea < 0) {
    warnings.push({
      code: 'AREA_OVERFLOW',
      severity: 'error',
      message: `前厅有效可摆面积不足 ${round(Math.abs(remainingArea), 1)}㎡`
    });
  } else if (utilization > 0.9) {
    warnings.push({
      code: 'AREA_TIGHT',
      severity: 'warning',
      message: '家具使用空间已超过前厅有效面积的90%，高峰期动线容易拥堵'
    });
  }
  if (normalized.usableDiningArea < normalized.grossArea * 0.3) {
    warnings.push({
      code: 'LOW_DINING_SHARE',
      severity: 'warning',
      message: '该房源前厅有效面积偏小，更适合外卖、快取或高翻台业态'
    });
  }

  return {
    property: normalized,
    tables: tableArea,
    looseFurnitureArea: round(looseFurnitureArea),
    requiredDiningArea: round(requiredDiningArea),
    remainingArea: round(remainingArea),
    utilization: round(utilization, 4),
    valid: warnings.every(item => item.severity !== 'error'),
    warnings
  };
}

function rectanglesOverlap(a, b, clearance = 0) {
  const ax1 = safeNumber(a.x) - clearance;
  const ay1 = safeNumber(a.y) - clearance;
  const ax2 = ax1 + safeNumber(a.width) + clearance * 2;
  const ay2 = ay1 + safeNumber(a.depth) + clearance * 2;
  const bx1 = safeNumber(b.x);
  const by1 = safeNumber(b.y);
  const bx2 = bx1 + safeNumber(b.width);
  const by2 = by1 + safeNumber(b.depth);
  return ax1 < bx2 && ax2 > bx1 && ay1 < by2 && ay2 > by1;
}

function validateCoordinateLayout(room = {}, objects = [], options = {}) {
  const width = Math.max(0.5, safeNumber(room.width));
  const depth = Math.max(0.5, safeNumber(room.depth));
  const minAisle = Math.max(0.5, safeNumber(options.minimumAisleMeters, BALANCE.minimumSecondaryAisleMeters));
  const errors = [];
  const warnings = [];

  for (const item of objects || []) {
    const x = safeNumber(item.x);
    const y = safeNumber(item.y);
    const w = Math.max(0, safeNumber(item.width));
    const d = Math.max(0, safeNumber(item.depth));
    if (x < 0 || y < 0 || x + w > width || y + d > depth) {
      errors.push({ code: 'OUT_OF_BOUNDS', id: item.id, message: `${item.name || item.id || '家具'}超出房间边界` });
    }
  }

  for (let i = 0; i < objects.length; i++) {
    for (let j = i + 1; j < objects.length; j++) {
      const a = objects[i];
      const b = objects[j];
      if (a.allowOverlap || b.allowOverlap) continue;
      if (rectanglesOverlap(a, b, 0)) {
        errors.push({
          code: 'COLLISION',
          ids: [a.id, b.id],
          message: `${a.name || a.id || '家具'}与${b.name || b.id || '家具'}发生碰撞`
        });
      } else if (a.requiresAisle || b.requiresAisle) {
        if (rectanglesOverlap(a, b, minAisle / 2)) {
          warnings.push({
            code: 'AISLE_TIGHT',
            ids: [a.id, b.id],
            message: `家具间距可能低于${round(minAisle, 2)}m，影响服务动线`
          });
        }
      }
    }
  }

  const doors = (room.doors || []).map((door, index) => ({ id: door.id || `door-${index}`, ...door }));
  for (const door of doors) {
    const doorZone = {
      x: safeNumber(door.x) - minAisle * 0.5,
      y: safeNumber(door.y) - minAisle * 0.5,
      width: Math.max(minAisle, safeNumber(door.width, 0.9) + minAisle),
      depth: Math.max(minAisle, safeNumber(door.depth, 0.2) + minAisle)
    };
    for (const item of objects || []) {
      if (rectanglesOverlap(doorZone, item, 0)) {
        errors.push({
          code: 'BLOCKED_DOOR',
          id: item.id,
          doorId: door.id,
          message: `${item.name || item.id || '家具'}占用了出入口通行空间`
        });
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    room: { width: round(width), depth: round(depth), area: round(width * depth) }
  };
}

function suggestTableMix(usableDiningArea, customerProfile = {}, options = {}) {
  const area = Math.max(0, safeNumber(usableDiningArea));
  const familyShare = clamp(customerProfile.familyShare, 0, 1);
  const businessShare = clamp(customerProfile.businessShare, 0, 1);
  const soloShare = clamp(customerProfile.soloShare, 0, 1);
  const mix = { 2: 0, 4: 0, 6: 0, 8: 0 };
  let remaining = area;
  const target = [
    ...(businessShare > 0.15 ? [8, 6] : []),
    ...(familyShare > 0.25 ? [4, 4, 6] : []),
    ...(soloShare > 0.35 ? [2, 2, 2] : [4, 2]),
    4,
    2
  ];
  let cursor = 0;
  while (remaining > 3.3 && cursor < 100) {
    const seats = target[cursor % target.length];
    const footprint = tableOperationalFootprint(seats, (options.tableSpecs || {})[seats] || {});
    if (footprint.operationalArea <= remaining) {
      mix[seats] += 1;
      remaining -= footprint.operationalArea;
    } else {
      const fallback = [4, 2].find(value => tableOperationalFootprint(value).operationalArea <= remaining);
      if (!fallback) break;
      mix[fallback] += 1;
      remaining -= tableOperationalFootprint(fallback).operationalArea;
    }
    cursor += 1;
  }
  return {
    tableMix: mix,
    estimated: estimateLayoutArea(mix, options.tableSpecs || {}),
    remainingArea: round(remaining)
  };
}

module.exports = {
  normalizeProperty,
  tableOperationalFootprint,
  estimateLayoutArea,
  evaluateAreaPlan,
  validateCoordinateLayout,
  suggestTableMix
};
