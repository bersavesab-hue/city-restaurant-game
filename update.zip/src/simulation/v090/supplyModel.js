'use strict';

const { clamp, safeNumber, round, deepClone, SeededRandom } = require('./utils.js');
const { normalizeInventory } = require('./inventoryModel.js');

function normalizeSupplier(supplier = {}, index = 0) {
  return {
    id: supplier.id || `supplier-${index + 1}`,
    name: supplier.name || `供应商${index + 1}`,
    reliability: clamp(supplier.reliability == null ? 0.88 : supplier.reliability > 1 ? supplier.reliability / 100 : supplier.reliability, 0.2, 1),
    quality: clamp(supplier.quality == null ? 0.82 : supplier.quality > 1 ? supplier.quality / 100 : supplier.quality, 0.2, 1.2),
    leadTimeDays: Math.max(0, Math.ceil(safeNumber(supplier.leadTimeDays, 1))),
    minOrder: Math.max(0, safeNumber(supplier.minOrder, 0)),
    priceMultiplier: clamp(supplier.priceMultiplier == null ? 1 : supplier.priceMultiplier, 0.55, 1.8),
    catalog: deepClone(supplier.catalog || {}),
    paymentTermsDays: Math.max(0, Math.floor(safeNumber(supplier.paymentTermsDays, 0)))
  };
}

function selectSupplier(suppliers = [], ingredientId, priorities = {}) {
  const rows = suppliers.map(normalizeSupplier).filter(supplier => supplier.catalog && supplier.catalog[ingredientId]);
  if (!rows.length) return null;
  const priceWeight = clamp(priorities.price == null ? 0.45 : priorities.price, 0, 1);
  const qualityWeight = clamp(priorities.quality == null ? 0.3 : priorities.quality, 0, 1);
  const reliabilityWeight = clamp(priorities.reliability == null ? 0.25 : priorities.reliability, 0, 1);
  return rows
    .map(supplier => {
      const item = supplier.catalog[ingredientId] || {};
      const basePrice = Math.max(0.01, safeNumber(item.unitCost || item.price, 1));
      const priceScore = 1 / Math.max(0.2, basePrice * supplier.priceMultiplier);
      const score = priceScore * priceWeight + supplier.quality * qualityWeight + supplier.reliability * reliabilityWeight;
      return { supplier, score, unitCost: basePrice * supplier.priceMultiplier };
    })
    .sort((a, b) => b.score - a.score)[0];
}

function buildReorderPlan(inventoryInput, projectedUsage = {}, suppliers = [], policy = {}) {
  const inventory = normalizeInventory(inventoryInput);
  const daysCover = Math.max(1, safeNumber(policy.targetDaysCover, 4));
  const safetyDays = Math.max(0, safeNumber(policy.safetyDays, 1.5));
  const orders = [];

  for (const [ingredientId, dailyUsageValue] of Object.entries(projectedUsage || {})) {
    const dailyUsage = Math.max(0, safeNumber(dailyUsageValue));
    if (!dailyUsage) continue;
    const current = inventory[ingredientId] ? inventory[ingredientId].qty : 0;
    const choice = selectSupplier(suppliers, ingredientId, policy.priorities || {});
    if (!choice) continue;
    const lead = choice.supplier.leadTimeDays;
    const reorderPoint = dailyUsage * (lead + safetyDays);
    if (current > reorderPoint) continue;
    let qty = dailyUsage * daysCover - current;
    qty = Math.max(qty, safeNumber(choice.supplier.minOrder, 0));
    const item = choice.supplier.catalog[ingredientId] || {};
    const pack = Math.max(0.001, safeNumber(item.packSize, 1));
    qty = Math.ceil(qty / pack) * pack;
    orders.push({
      id: `po-${ingredientId}-${choice.supplier.id}`,
      ingredientId,
      supplierId: choice.supplier.id,
      supplierName: choice.supplier.name,
      qty: round(qty, 3),
      unitCost: round(choice.unitCost, 3),
      totalCost: round(qty * choice.unitCost, 2),
      expectedLeadTimeDays: choice.supplier.leadTimeDays,
      reliability: choice.supplier.reliability,
      quality: choice.supplier.quality,
      paymentTermsDays: choice.supplier.paymentTermsDays
    });
  }

  return orders;
}

function progressPurchaseOrders(ordersInput = [], inventoryInput = {}, seed = 1) {
  const orders = deepClone(ordersInput || []);
  const inventory = normalizeInventory(inventoryInput);
  const rng = seed instanceof SeededRandom ? seed : new SeededRandom(seed);
  const delivered = [];
  const delayed = [];
  const remaining = [];

  for (const order of orders) {
    order.daysRemaining = order.daysRemaining == null
      ? Math.max(0, Math.ceil(safeNumber(order.expectedLeadTimeDays, 1)))
      : Math.max(0, safeNumber(order.daysRemaining));
    order.daysRemaining -= 1;
    if (order.daysRemaining > 0) {
      remaining.push(order);
      continue;
    }
    const reliability = clamp(order.reliability == null ? 0.9 : order.reliability, 0, 1);
    if (!rng.chance(reliability)) {
      order.daysRemaining = 1;
      order.delayCount = Math.max(0, safeNumber(order.delayCount)) + 1;
      delayed.push(deepClone(order));
      remaining.push(order);
      continue;
    }
    const qty = Math.max(0, safeNumber(order.qty));
    const unitCost = Math.max(0, safeNumber(order.unitCost));
    const existing = inventory[order.ingredientId] || {
      id: order.ingredientId,
      qty: 0,
      unitCost,
      freshness: 1,
      shelfLifeDays: 4,
      ageDays: 0,
      quality: order.quality || 0.8
    };
    const oldValue = existing.qty * existing.unitCost;
    const newValue = qty * unitCost;
    existing.qty += qty;
    existing.unitCost = existing.qty > 0 ? (oldValue + newValue) / existing.qty : unitCost;
    existing.freshness = clamp((existing.freshness + clamp(order.quality || 0.8, 0.2, 1.2)) / 2, 0, 1);
    existing.ageDays = Math.min(existing.ageDays, 0.5);
    existing.quality = clamp((existing.quality + (order.quality || 0.8)) / 2, 0.2, 1.2);
    inventory[order.ingredientId] = existing;
    delivered.push(order);
  }

  return { inventory, remainingOrders: remaining, delivered, delayed };
}

module.exports = {
  normalizeSupplier,
  selectSupplier,
  buildReorderPlan,
  progressPurchaseOrders
};
