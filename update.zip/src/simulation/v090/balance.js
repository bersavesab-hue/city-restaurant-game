'use strict';

const BALANCE = Object.freeze({
  schemaVersion: 1,
  simulationVersion: '0.9.0',
  daysPerMonth: 30,
  defaultOpenMinutes: 660,
  defaultDwellMinutes: 54,
  peakConcurrencyFactor: 0.56,
  minimumMainAisleMeters: 0.9,
  minimumSecondaryAisleMeters: 0.75,
  defaultGrossMarginTarget: 0.62,
  defaultTaxRate: 0,
  serviceCoversPerWaiterShift: 58,
  cookProductiveMinutesPerShift: 360,
  cookUtilizationSoftCap: 0.82,
  waiterUtilizationSoftCap: 0.86,
  kitchenOverloadPenalty: 0.62,
  waitToleranceMinutes: {
    quick: 8,
    normal: 14,
    relaxed: 22
  },
  dayTypeMultipliers: {
    weekday: 1,
    weekend: 1.06,
    holiday: 1.18
  },
  weatherMultipliers: {
    sunny: 1,
    cloudy: 0.98,
    rain: 0.9,
    heavyRain: 0.76,
    hot: 0.94,
    cold: 1.03
  },
  segmentPartyMix: {
    student: { 1: 0.28, 2: 0.52, 3: 0.13, 4: 0.07 },
    teacher: { 1: 0.24, 2: 0.47, 3: 0.15, 4: 0.14 },
    resident: { 1: 0.16, 2: 0.43, 3: 0.18, 4: 0.18, 5: 0.05 },
    elderly: { 1: 0.2, 2: 0.52, 3: 0.15, 4: 0.1, 5: 0.03 },
    family: { 2: 0.13, 3: 0.31, 4: 0.37, 5: 0.13, 6: 0.06 },
    office: { 1: 0.27, 2: 0.49, 3: 0.16, 4: 0.08 },
    business: { 1: 0.08, 2: 0.26, 3: 0.18, 4: 0.24, 5: 0.11, 6: 0.09, 8: 0.04 },
    tourist: { 1: 0.12, 2: 0.35, 3: 0.2, 4: 0.21, 5: 0.07, 6: 0.05 },
    vendor: { 1: 0.31, 2: 0.48, 3: 0.14, 4: 0.07 },
    worker: { 1: 0.36, 2: 0.46, 3: 0.12, 4: 0.06 },
    tenant: { 1: 0.34, 2: 0.46, 3: 0.13, 4: 0.07 },
    driver: { 1: 0.51, 2: 0.34, 3: 0.1, 4: 0.05 },
    staff: { 1: 0.31, 2: 0.48, 3: 0.14, 4: 0.07 },
    tech: { 1: 0.27, 2: 0.49, 3: 0.15, 4: 0.09 },
    other: { 1: 0.25, 2: 0.45, 3: 0.15, 4: 0.12, 5: 0.03 }
  },
  tableDefaults: {
    2: { width: 0.75, depth: 0.75, clearance: 0.55 },
    4: { width: 1.2, depth: 0.8, clearance: 0.6 },
    6: { width: 1.5, depth: 0.9, clearance: 0.65 },
    8: { width: 1.65, depth: 1.65, clearance: 0.7 }
  }
});

module.exports = BALANCE;
