'use strict';

const BALANCE = require('./balance.js');
const { safeNumber, round, clamp, sum } = require('./utils.js');

function calculateRevenue(menuAnalysis, fulfilledDishUnits = {}, store = {}) {
  const byDish = [];
  let grossRevenue = 0;
  for (const row of menuAnalysis.rows || []) {
    const units = Math.max(0, Math.floor(safeNumber(fulfilledDishUnits[row.dish.id])));
    const revenue = units * row.dish.price;
    grossRevenue += revenue;
    byDish.push({ id: row.dish.id, name: row.dish.name, units, unitPrice: row.dish.price, revenue: round(revenue, 2) });
  }
  const discountRate = clamp(store.discountRate || 0, 0, 0.5);
  const discount = grossRevenue * discountRate;
  const refundRate = clamp(store.refundRate || 0, 0, 0.2);
  const refunds = Math.max(0, grossRevenue - discount) * refundRate;
  return {
    grossRevenue: round(grossRevenue, 2),
    discount: round(discount, 2),
    refunds: round(refunds, 2),
    netRevenue: round(grossRevenue - discount - refunds, 2),
    byDish
  };
}

function calculateDailyFinance(input = {}) {
  const store = input.store || {};
  const revenue = input.revenue || { netRevenue: 0 };
  const paidCovers = Math.max(0, safeNumber(input.paidCovers, 0));
  const labor = Math.max(0, safeNumber(input.laborCost, 0));
  const cogs = Math.max(0, safeNumber(input.cogs, 0));
  const spoilage = Math.max(0, safeNumber(input.spoilageCost, 0));
  const monthlyRent = Math.max(0, safeNumber(store.rentMonthly || store.rent, 0));
  const monthlyProperty = Math.max(0, safeNumber(store.propertyFeeMonthly || store.propertyFee, 0));
  const dailyRent = monthlyRent / BALANCE.daysPerMonth;
  const dailyProperty = monthlyProperty / BALANCE.daysPerMonth;
  const utilitiesBase = Math.max(0, safeNumber(store.utilitiesBaseDaily, 32));
  const utilitiesPerCover = Math.max(0, safeNumber(store.utilitiesPerCover, 0.9));
  const utilities = utilitiesBase + utilitiesPerCover * paidCovers;
  const marketing = Math.max(0, safeNumber(store.marketingDaily || store.marketingSpendDaily, 0));
  const maintenance = Math.max(0, safeNumber(store.maintenanceDaily, 18));
  const insurance = Math.max(0, safeNumber(store.insuranceDaily, 0));
  const loanInterest = Math.max(0, safeNumber(store.loanInterestDaily, 0));
  const deliveryShare = clamp(store.deliveryShare || 0, 0, 1);
  const platformRate = clamp(store.platformCommissionRate || 0, 0, 0.4);
  const platformCommission = revenue.netRevenue * deliveryShare * platformRate;
  const variableCosts = cogs + utilities + platformCommission;
  const fixedCosts = labor + dailyRent + dailyProperty + marketing + maintenance + insurance + loanInterest;
  const operatingProfitBeforeTax = revenue.netRevenue - variableCosts - fixedCosts - spoilage;
  const taxRate = clamp(store.taxRate == null ? BALANCE.defaultTaxRate : store.taxRate, 0, 0.35);
  const tax = operatingProfitBeforeTax > 0 ? operatingProfitBeforeTax * taxRate : 0;
  const netProfit = operatingProfitBeforeTax - tax;
  const grossProfit = revenue.netRevenue - cogs - platformCommission;
  const startingCash = Math.max(0, safeNumber(store.cash, 0));
  const purchaseCashOut = Math.max(0, safeNumber(input.purchaseCashOut, 0));
  const capitalExpenditure = Math.max(0, safeNumber(input.capitalExpenditure, 0));
  const netCashFlow = netProfit - purchaseCashOut - capitalExpenditure;
  const endingCash = startingCash + netCashFlow;
  const fixedDailyBurn = Math.max(1, fixedCosts + spoilage + utilitiesBase);

  return {
    revenue: round(revenue.netRevenue, 2),
    grossRevenue: round(revenue.grossRevenue || revenue.netRevenue, 2),
    cogs: round(cogs, 2),
    labor: round(labor, 2),
    rentAccrual: round(dailyRent, 2),
    propertyFeeAccrual: round(dailyProperty, 2),
    utilities: round(utilities, 2),
    marketing: round(marketing, 2),
    maintenance: round(maintenance, 2),
    insurance: round(insurance, 2),
    loanInterest: round(loanInterest, 2),
    platformCommission: round(platformCommission, 2),
    spoilage: round(spoilage, 2),
    tax: round(tax, 2),
    variableCosts: round(variableCosts, 2),
    fixedCosts: round(fixedCosts, 2),
    grossProfit: round(grossProfit, 2),
    operatingProfitBeforeTax: round(operatingProfitBeforeTax, 2),
    netProfit: round(netProfit, 2),
    grossMargin: revenue.netRevenue > 0 ? round(grossProfit / revenue.netRevenue, 4) : 0,
    netMargin: revenue.netRevenue > 0 ? round(netProfit / revenue.netRevenue, 4) : 0,
    purchaseCashOut: round(purchaseCashOut, 2),
    capitalExpenditure: round(capitalExpenditure, 2),
    netCashFlow: round(netCashFlow, 2),
    startingCash: round(startingCash, 2),
    endingCash: round(endingCash, 2),
    estimatedRunwayDays: netProfit >= 0 ? null : Math.max(0, Math.floor(startingCash / fixedDailyBurn)),
    costBreakdown: {
      food: round(cogs, 2),
      labor: round(labor, 2),
      occupancy: round(dailyRent + dailyProperty, 2),
      utilities: round(utilities, 2),
      platform: round(platformCommission, 2),
      marketing: round(marketing, 2),
      spoilage: round(spoilage, 2),
      maintenance: round(maintenance + insurance + loanInterest, 2),
      tax: round(tax, 2)
    }
  };
}

function breakEvenRevenue(store = {}, ratios = {}) {
  const monthlyRent = Math.max(0, safeNumber(store.rentMonthly || store.rent, 0));
  const monthlyProperty = Math.max(0, safeNumber(store.propertyFeeMonthly || store.propertyFee, 0));
  const labor = Math.max(0, safeNumber(ratios.laborCost, 0));
  const fixed = labor + monthlyRent / 30 + monthlyProperty / 30 + Math.max(0, safeNumber(store.utilitiesBaseDaily, 32)) + Math.max(0, safeNumber(store.marketingDaily, 0)) + Math.max(0, safeNumber(store.maintenanceDaily, 18));
  const foodCostRate = clamp(ratios.foodCostRate == null ? 0.35 : ratios.foodCostRate, 0.05, 0.75);
  const platformRate = clamp((store.deliveryShare || 0) * (store.platformCommissionRate || 0), 0, 0.4);
  const contributionRate = Math.max(0.08, 1 - foodCostRate - platformRate - Math.max(0, safeNumber(store.utilitiesPerRevenueRate, 0.025)));
  return round(fixed / contributionRate, 2);
}

module.exports = {
  calculateRevenue,
  calculateDailyFinance,
  breakEvenRevenue
};
