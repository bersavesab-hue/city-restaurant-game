'use strict';

const { clamp, safeNumber, round } = require('./utils.js');

function pushDriver(list, condition, driver) {
  if (condition) list.push(driver);
}

function buildDailyReport(input = {}) {
  const journey = input.journey || { losses: {} };
  const seating = input.seating || journey.seating || {};
  const kitchen = input.kitchen || {};
  const service = input.service || {};
  const finance = input.finance || {};
  const inventory = input.inventory || {};
  const menu = input.menu || {};
  const market = input.market || {};
  const paid = Math.max(0, safeNumber(journey.paidCovers));
  const eligible = Math.max(0, safeNumber(journey.eligibleDemand));
  const arrived = Math.max(0, safeNumber(journey.arrivedCovers));
  const drivers = [];

  pushDriver(drivers, safeNumber(seating.rejectionRate) > 0.12, {
    code: 'SEATING_BOTTLENECK', severity: 'high',
    title: '座位承载不足',
    evidence: `约${Math.round(safeNumber(journey.seatingLoss))}位顾客因座位与等待问题流失`,
    action: '优先调整桌型组合或增加高峰期有效翻台，不要只盲目增加总座位。'
  });
  pushDriver(drivers, !!seating.mismatch || safeNumber(seating.wasteRatio) > 0.3, {
    code: 'TABLE_MISMATCH', severity: 'medium',
    title: '桌型与客群不匹配',
    evidence: `无效空座占比约${Math.round(safeNumber(seating.wasteRatio) * 100)}%`,
    action: '根据1-2人、3-4人及多人聚餐比例重配桌型。'
  });
  pushDriver(drivers, safeNumber(kitchen.utilization) > 0.95, {
    code: 'KITCHEN_BOTTLENECK', severity: safeNumber(kitchen.utilization) > 1.15 ? 'high' : 'medium',
    title: '后厨成为瓶颈',
    evidence: `后厨负荷${Math.round(safeNumber(kitchen.utilization) * 100)}%，平均出餐约${round(kitchen.avgTicketMinutes, 1)}分钟`,
    action: '增加有效厨师产能、备菜效率或降低高峰菜单复杂度。'
  });
  pushDriver(drivers, safeNumber(service.utilization) > 0.96, {
    code: 'SERVICE_BOTTLENECK', severity: 'medium',
    title: '前厅服务吃紧',
    evidence: `服务负荷${Math.round(safeNumber(service.utilization) * 100)}%，平均服务延迟约${round(service.avgServiceDelayMinutes, 1)}分钟`,
    action: '调整服务员排班与分区，必要时增加高峰临时人手。'
  });
  pushDriver(drivers, safeNumber(journey.stockoutLoss) > Math.max(2, paid * 0.04), {
    code: 'STOCKOUT', severity: safeNumber(journey.stockoutLoss) > paid * 0.12 ? 'high' : 'medium',
    title: '缺货造成真实订单流失',
    evidence: `约${Math.round(safeNumber(journey.stockoutLoss))}位顾客因原料不足未能完成消费`,
    action: '提高关键原料安全库存，并结合交货周期设置补货点。'
  });
  pushDriver(drivers, safeNumber(inventory.spoilageCost) > Math.max(40, safeNumber(finance.revenue) * 0.04), {
    code: 'SPOILAGE', severity: 'medium',
    title: '库存损耗偏高',
    evidence: `今日食材损耗约¥${round(inventory.spoilageCost, 0)}`,
    action: '降低易腐品采购批量，提高采购频率，并减少低销量菜品备货。'
  });
  pushDriver(drivers, safeNumber(menu.priceFit) < 0.68, {
    code: 'PRICE_MISMATCH', severity: 'medium',
    title: '菜单价格与商圈不匹配',
    evidence: `价格适配度仅${Math.round(safeNumber(menu.priceFit) * 100)}%`,
    action: '不要只降价；应调整价格带、份量和菜品组合以贴近核心客群。'
  });
  pushDriver(drivers, safeNumber(finance.netMargin) < -0.05 && safeNumber(finance.fixedCosts) > safeNumber(finance.revenue) * 0.45, {
    code: 'HIGH_FIXED_COST', severity: 'high',
    title: '固定成本过重',
    evidence: `固定成本约占营业额${Math.round(safeNumber(finance.fixedCosts) / Math.max(1, safeNumber(finance.revenue)) * 100)}%`,
    action: '优先检查租金、人工排班和低效营业时段，而不是用促销掩盖亏损。'
  });
  pushDriver(drivers, safeNumber(finance.grossMargin) > 0.58 && safeNumber(finance.netMargin) > 0.08 && paid > 0, {
    code: 'HEALTHY_MARGIN', severity: 'positive',
    title: '当前毛利与净利结构健康',
    evidence: `毛利率${Math.round(safeNumber(finance.grossMargin) * 100)}%，净利率${Math.round(safeNumber(finance.netMargin) * 100)}%`,
    action: '保持成本纪律，下一步优先解决容量瓶颈而不是无序扩张。'
  });

  if (!drivers.length) {
    drivers.push({
      code: 'STABLE', severity: 'info', title: '经营暂未出现单一明显瓶颈',
      evidence: '客流、产能与成本暂时处于相对均衡状态',
      action: '继续观察至少3-7个营业日，再根据趋势做结构性调整。'
    });
  }

  const healthScore = clamp(
    68
    + clamp(safeNumber(finance.netMargin), -0.5, 0.5) * 45
    - Math.max(0, safeNumber(kitchen.utilization) - 0.9) * 28
    - Math.max(0, safeNumber(service.utilization) - 0.9) * 24
    - safeNumber(seating.rejectionRate) * 25
    - (eligible > 0 ? safeNumber(journey.stockoutLoss) / eligible : 0) * 35,
    0,
    100
  );

  const riskLabel = healthScore >= 82 ? '良好' : healthScore >= 68 ? '稳定' : healthScore >= 52 ? '偏紧' : healthScore >= 35 ? '危险' : '严重危险';

  return {
    version: '0.9.0',
    health: { score: round(healthScore, 1), label: riskLabel },
    funnel: {
      marketAllocated: eligible,
      arrived,
      seated: Math.max(0, Math.floor(safeNumber(journey.seatedCovers))),
      serviceAccepted: Math.max(0, Math.floor(safeNumber(journey.serviceAcceptedCovers))),
      kitchenAccepted: Math.max(0, Math.floor(safeNumber(journey.kitchenAcceptedCovers))),
      inventoryAccepted: Math.max(0, Math.floor(safeNumber(journey.inventoryAcceptedCovers))),
      paidCovers: paid,
      completedRate: round(safeNumber(journey.completedRate), 4)
    },
    losses: { ...(journey.losses || {}) },
    metrics: {
      marketShare: round(safeNumber(market.playerFinalShare), 4),
      entranceConversion: round(safeNumber(journey.entranceConversion), 4),
      seatUtilization: round(safeNumber(seating.seatUtilization), 4),
      tableWasteRatio: round(safeNumber(seating.wasteRatio), 4),
      kitchenUtilization: round(safeNumber(kitchen.utilization), 4),
      serviceUtilization: round(safeNumber(service.utilization), 4),
      avgTicketMinutes: round(safeNumber(kitchen.avgTicketMinutes), 2),
      avgWaitMinutes: round(safeNumber(journey.wait && journey.wait.averageWaitMinutes), 2),
      revenue: round(safeNumber(finance.revenue), 2),
      grossMargin: round(safeNumber(finance.grossMargin), 4),
      netMargin: round(safeNumber(finance.netMargin), 4),
      netProfit: round(safeNumber(finance.netProfit), 2),
      cash: round(safeNumber(finance.endingCash), 2)
    },
    drivers,
    primaryDriver: drivers.find(item => item.severity === 'high') || drivers.find(item => item.severity === 'medium') || drivers[0]
  };
}

module.exports = { buildDailyReport };
