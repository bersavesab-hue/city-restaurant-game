'use strict';

function clamp(value, min, max) {
  value = Number.isFinite(Number(value)) ? Number(value) : min;
  return Math.max(min, Math.min(max, value));
}

function safeNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function round(value, digits = 2) {
  const factor = Math.pow(10, digits);
  return Math.round((safeNumber(value) + Number.EPSILON) * factor) / factor;
}

function sum(values) {
  return (values || []).reduce((acc, value) => acc + safeNumber(value), 0);
}

function average(values) {
  if (!values || !values.length) return 0;
  return sum(values) / values.length;
}

function deepClone(value) {
  if (value == null) return value;
  return JSON.parse(JSON.stringify(value));
}

function normalizeShares(object, fallbackKey = 'other') {
  const src = object && typeof object === 'object' ? object : {};
  const positive = Object.entries(src)
    .map(([key, value]) => [key, Math.max(0, safeNumber(value))])
    .filter(([, value]) => value > 0);
  const total = positive.reduce((acc, [, value]) => acc + value, 0);
  if (!total) return { [fallbackKey]: 1 };
  return Object.fromEntries(positive.map(([key, value]) => [key, value / total]));
}

function weightedAverage(rows, valueKey, weightKey) {
  const list = rows || [];
  let weighted = 0;
  let weight = 0;
  for (const row of list) {
    const w = Math.max(0, safeNumber(row && row[weightKey]));
    weighted += safeNumber(row && row[valueKey]) * w;
    weight += w;
  }
  return weight > 0 ? weighted / weight : 0;
}

function stableHash(input) {
  const str = String(input == null ? '' : input);
  let hash = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

class SeededRandom {
  constructor(seed = 1) {
    const numeric = typeof seed === 'number' ? seed : stableHash(seed);
    this.state = (numeric >>> 0) || 0x6d2b79f5;
  }

  next() {
    let t = (this.state += 0x6d2b79f5) >>> 0;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    const result = ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    this.state >>>= 0;
    return result;
  }

  between(min, max) {
    return min + (max - min) * this.next();
  }

  int(min, max) {
    return Math.floor(this.between(min, max + 1));
  }

  chance(probability) {
    return this.next() < clamp(probability, 0, 1);
  }

  pick(values) {
    if (!values || !values.length) return null;
    return values[Math.min(values.length - 1, Math.floor(this.next() * values.length))];
  }
}

function softmaxAllocate(total, rows, scoreKey = 'score', temperature = 18) {
  const count = Math.max(0, Math.floor(safeNumber(total)));
  if (!rows || !rows.length || count === 0) return [];
  const temp = Math.max(1, safeNumber(temperature, 18));
  const maxScore = Math.max(...rows.map(row => safeNumber(row[scoreKey])));
  const weights = rows.map(row => Math.exp((safeNumber(row[scoreKey]) - maxScore) / temp));
  const weightSum = sum(weights) || 1;
  const raw = weights.map(weight => (count * weight) / weightSum);
  const allocated = raw.map(Math.floor);
  let remaining = count - sum(allocated);
  const fractional = raw
    .map((value, index) => ({ index, frac: value - Math.floor(value) }))
    .sort((a, b) => b.frac - a.frac || a.index - b.index);
  let cursor = 0;
  while (remaining > 0 && fractional.length) {
    allocated[fractional[cursor % fractional.length].index] += 1;
    remaining -= 1;
    cursor += 1;
  }
  return allocated;
}

function assertFiniteObject(obj, path = 'root') {
  if (obj == null) return;
  if (typeof obj === 'number') {
    if (!Number.isFinite(obj)) throw new Error(`Non-finite number at ${path}`);
    return;
  }
  if (Array.isArray(obj)) {
    obj.forEach((value, index) => assertFiniteObject(value, `${path}[${index}]`));
    return;
  }
  if (typeof obj === 'object') {
    for (const [key, value] of Object.entries(obj)) {
      assertFiniteObject(value, `${path}.${key}`);
    }
  }
}

module.exports = {
  clamp,
  safeNumber,
  round,
  sum,
  average,
  deepClone,
  normalizeShares,
  weightedAverage,
  stableHash,
  SeededRandom,
  softmaxAllocate,
  assertFiniteObject
};
