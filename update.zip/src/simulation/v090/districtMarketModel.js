'use strict';

const BALANCE = require('./balance.js');
const { clamp, safeNumber, round, normalizeShares } = require('./utils.js');

function normalizeDistrict(district = {}) {
  return {
    id: district.id || 'unknown',
    name: district.name || '未命名商圈',
    baseDemand: Math.max(0, safeNumber(district.baseDemand || district.dailyDemand, 1000)),
    avgSpend: Math.max(5, safeNumber(district.avgSpend, 30)),
    saturation: clamp(district.saturation == null ? 65 : district.saturation, 0, 120),
    restaurantCount: Math.max(0, Math.floor(safeNumber(district.restaurantCount, 20))),
    rentIndex: Math.max(0.1, safeNumber(district.rentIndex, 0.7)),
    segmentMix: normalizeShares(district.segmentMix || district.customerMix || district.mix || { other: 1 }, 'other'),
    mealDemand: district.mealDemand || null,
    trend: clamp(district.trend == null ? 0 : district.trend, -0.5, 0.8)
  };
}

function dayTypeFromInput(day = {}) {
  if (day.type) return day.type;
  if (day.holiday) return 'holiday';
  const weekday = safeNumber(day.weekday, 1);
  return weekday === 0 || weekday === 6 || weekday === 7 ? 'weekend' : 'weekday';
}

function demandForDay(districtInput, context = {}) {
  const district = normalizeDistrict(districtInput);
  const dayType = dayTypeFromInput(context.day || {});
  const weather = context.weather || 'sunny';
  const dayMultiplier = safeNumber(BALANCE.dayTypeMultipliers[dayType], 1);
  const weatherMultiplier = context.weatherMultiplier == null
    ? safeNumber(BALANCE.weatherMultipliers[weather], 1)
    : clamp(context.weatherMultiplier, 0.4, 1.8);
  const eventMultiplier = clamp(context.eventMultiplier == null ? 1 : context.eventMultiplier, 0.4, 2.5);
  const trendMultiplier = 1 + district.trend;
  const saturationDrag = clamp(1 - Math.max(0, district.saturation - 85) * 0.0018, 0.88, 1);
  const totalDemand = Math.max(0, Math.round(district.baseDemand * dayMultiplier * weatherMultiplier * eventMultiplier * trendMultiplier * saturationDrag));
  return {
    district,
    dayType,
    weather,
    dayMultiplier: round(dayMultiplier, 4),
    weatherMultiplier: round(weatherMultiplier, 4),
    eventMultiplier: round(eventMultiplier, 4),
    trendMultiplier: round(trendMultiplier, 4),
    saturationDrag: round(saturationDrag, 4),
    totalDemand,
    segmentMix: district.segmentMix
  };
}

function updateDistrictAfterDay(districtInput, marketOutcome = {}) {
  const district = normalizeDistrict(districtInput);
  const demandPressure = safeNumber(marketOutcome.demandPressure, 1);
  const vacancyPressure = safeNumber(marketOutcome.vacancyPressure, 0);
  const newEntrants = Math.max(0, Math.floor(safeNumber(marketOutcome.newEntrants, 0)));
  const exits = Math.max(0, Math.floor(safeNumber(marketOutcome.exits, 0)));
  district.restaurantCount = Math.max(0, district.restaurantCount + newEntrants - exits);
  district.saturation = round(clamp(district.saturation + (demandPressure - 1) * 1.3 + newEntrants * 0.12 - exits * 0.16, 20, 110), 2);
  district.rentIndex = round(Math.max(0.15, district.rentIndex * (1 + (demandPressure - 1) * 0.015 - vacancyPressure * 0.01)), 4);
  return district;
}

module.exports = {
  normalizeDistrict,
  dayTypeFromInput,
  demandForDay,
  updateDistrictAfterDay
};
