'use strict';

const { clamp, safeNumber, round } = require('./utils.js');
const tableModel = require('./tableModel.js');

function entranceConversion(store = {}, menuAnalysis = {}, context = {}) {
  const visibility = clamp(store.visibility == null ? store.property && store.property.visibility == null ? 55 : store.property.visibility : store.visibility, 0, 100);
  const rating = clamp(store.rating == null ? 3.7 : store.rating, 1, 5);
  const reputation = clamp(store.reputation == null ? 45 : store.reputation, 0, 100);
  const priceFit = clamp(menuAnalysis.priceFit == null ? 0.8 : menuAnalysis.priceFit, 0.1, 1.3);
  const frontage = Math.max(2, safeNumber(store.property && store.property.frontage, 5));
  const access = clamp(store.accessibility == null ? 0.8 : store.accessibility, 0.3, 1.2);
  const openReliability = clamp(store.openReliability == null ? 0.96 : store.openReliability, 0, 1);
  const raw = 0.48
    + visibility / 500
    + (rating - 3) * 0.08
    + reputation / 1000
    + (priceFit - 0.7) * 0.18
    + Math.min(0.07, frontage / 100)
    + (access - 0.8) * 0.12
    + safeNumber(context.eventEntranceBonus, 0);
  return round(clamp(raw * openReliability, 0.35, 0.98), 4);
}

function estimateWaitAbandonment(tableResult, context = {}) {
  const rejected = Math.max(0, safeNumber(tableResult.rejectedCovers));
  if (!rejected) return { abandonCovers: 0, waitingRecoveredCovers: 0, averageWaitMinutes: 0 };
  const queueRecovery = clamp(context.queueRecovery == null ? 0.18 : context.queueRecovery, 0, 0.65);
  const averageWaitMinutes = Math.max(4, 8 + tableResult.rejectionRate * 24 + tableResult.seatUtilization * 6);
  const tolerance = Math.max(5, safeNumber(context.waitToleranceMinutes, 14));
  const survival = clamp(queueRecovery * (tolerance / Math.max(tolerance, averageWaitMinutes)), 0, 0.5);
  const recovered = Math.floor(rejected * survival);
  return {
    abandonCovers: rejected - recovered,
    waitingRecoveredCovers: recovered,
    averageWaitMinutes: round(averageWaitMinutes, 2)
  };
}

function createJourney(marketAllocatedCovers, store, menuAnalysis, segmentMix, options = {}) {
  const eligibleDemand = Math.max(0, Math.floor(safeNumber(marketAllocatedCovers)));
  const conversion = entranceConversion(store, menuAnalysis, options);
  const arrivedCovers = Math.max(0, Math.floor(eligibleDemand * conversion));
  const entranceLoss = eligibleDemand - arrivedCovers;
  const partyMix = options.partyMix || tableModel.buildPartySizeMix(segmentMix);
  const parties = tableModel.partyGroupsFromCovers(arrivedCovers, partyMix);
  const tableResult = tableModel.seatParties(
    store.layout && (store.layout.tables || store.layout.tableMix) || store.tableMix || { 2: 3, 4: 3 },
    parties.groups,
    {
      openMinutes: options.openMinutes,
      averageDwellMinutes: options.averageDwellMinutes,
      peakConcurrencyFactor: options.peakConcurrencyFactor,
      allowCombineTables: options.allowCombineTables !== false
    }
  );
  const wait = estimateWaitAbandonment(tableResult, options);
  const seatedCovers = Math.min(arrivedCovers, tableResult.seatedCovers + wait.waitingRecoveredCovers);
  return {
    eligibleDemand,
    entranceConversion: conversion,
    arrivedCovers,
    entranceLoss,
    partyMix,
    parties,
    seating: tableResult,
    wait,
    seatedCovers,
    seatingLoss: Math.max(0, arrivedCovers - seatedCovers)
  };
}

function finalizeJourney(baseJourney, flow = {}) {
  const seated = Math.max(0, safeNumber(baseJourney.seatedCovers));
  const serviceAccepted = Math.min(seated, Math.max(0, safeNumber(flow.serviceAcceptedCovers, seated)));
  const serviceLoss = seated - serviceAccepted;
  const kitchenAcceptedCovers = Math.min(serviceAccepted, Math.max(0, safeNumber(flow.kitchenAcceptedCovers, serviceAccepted)));
  const kitchenLoss = serviceAccepted - kitchenAcceptedCovers;
  const inventoryAcceptedCovers = Math.min(kitchenAcceptedCovers, Math.max(0, safeNumber(flow.inventoryAcceptedCovers, kitchenAcceptedCovers)));
  const stockoutLoss = kitchenAcceptedCovers - inventoryAcceptedCovers;
  const paidCovers = Math.max(0, Math.floor(inventoryAcceptedCovers));
  const completedRate = baseJourney.eligibleDemand > 0 ? paidCovers / baseJourney.eligibleDemand : 0;
  return {
    ...baseJourney,
    serviceAcceptedCovers: serviceAccepted,
    serviceLoss,
    kitchenAcceptedCovers,
    kitchenLoss,
    inventoryAcceptedCovers,
    stockoutLoss,
    paidCovers,
    completedRate: round(completedRate, 4),
    losses: {
      notEntered: baseJourney.entranceLoss,
      seating: baseJourney.seatingLoss,
      service: serviceLoss,
      kitchen: kitchenLoss,
      stockout: stockoutLoss,
      total: Math.max(0, baseJourney.eligibleDemand - paidCovers)
    }
  };
}

module.exports = {
  entranceConversion,
  estimateWaitAbandonment,
  createJourney,
  finalizeJourney
};
