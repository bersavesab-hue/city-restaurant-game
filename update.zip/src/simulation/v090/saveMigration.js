'use strict';

const { deepClone, safeNumber } = require('./utils.js');

const SCHEMA = 1;

function defaults() {
  return {
    schema: SCHEMA,
    version: '0.9.0',
    installedAtDay: null,
    lastSimulatedDay: null,
    dailyReports: [],
    purchaseOrders: [],
    diagnostics: [],
    featureFlags: {
      causalDailyReport: true,
      finiteMarketDemand: true,
      spaceValidation: true,
      realFixedCosts: true,
      staffFatigue: true,
      npcEvolution: true
    }
  };
}

function migrateState(input) {
  const state = deepClone(input || {});
  const existing = state.simulationCoreV090 || {};
  state.simulationCoreV090 = {
    ...defaults(),
    ...existing,
    featureFlags: { ...defaults().featureFlags, ...(existing.featureFlags || {}) }
  };
  state.simulationCoreV090.schema = SCHEMA;
  state.simulationCoreV090.version = '0.9.0';
  if (state.simulationCoreV090.installedAtDay == null) state.simulationCoreV090.installedAtDay = safeNumber(state.day, 0) || null;
  if (!Array.isArray(state.simulationCoreV090.dailyReports)) state.simulationCoreV090.dailyReports = [];
  if (!Array.isArray(state.simulationCoreV090.purchaseOrders)) state.simulationCoreV090.purchaseOrders = [];
  if (!Array.isArray(state.simulationCoreV090.diagnostics)) state.simulationCoreV090.diagnostics = [];
  return state;
}

function appendDailyReport(stateInput, report, maxReports = 120) {
  const state = migrateState(stateInput);
  state.simulationCoreV090.dailyReports.unshift(deepClone(report));
  state.simulationCoreV090.dailyReports = state.simulationCoreV090.dailyReports.slice(0, Math.max(7, maxReports));
  return state;
}

module.exports = { SCHEMA, migrateState, appendDailyReport };
