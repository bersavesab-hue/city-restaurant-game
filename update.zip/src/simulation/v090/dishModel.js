'use strict';

const { clamp, safeNumber, round, sum, normalizeShares } = require('./utils.js');

function normalizeDish(dish = {}, index = 0) {
  const price = Math.max(1, safeNumber(dish.price, 28));
  const explicitCost = safeNumber(dish.foodCost, NaN);
  const ingredients = Array.isArray(dish.ingredients) ? dish.ingredients.map(item => {
    if (typeof item === 'string') return { id: item, qty: 0.12 };
    return { id: item.id || item.ingredientId, qty: Math.max(0, safeNumber(item.qty, 0.12)) };
  }).filter(item => item.id) : [];
  return {
    id: dish.id || `dish-${index + 1}`,
    name: dish.name || `菜品${index + 1}`,
    price: round(price, 2),
    foodCost: Number.isFinite(explicitCost) ? Math.max(0, explicitCost) : null,
    cookMinutes: Math.max(2, safeNumber(dish.cookMinutes || dish.cook, 12)),
    complexity: clamp(dish.complexity == null ? dish.diff ? safeNumber(dish.diff) / 3 : 0.5 : dish.complexity, 0.05, 1.5),
    quality: clamp(dish.quality == null ? dish.taste == null ? 70 : safeNumber(dish.taste) : dish.quality, 0, 100),
    popularity: clamp(dish.popularity == null ? dish.viral == null ? 50 : safeNumber(dish.viral) : dish.popularity, 0, 100),
    segmentFit: normalizeShares(dish.segmentFit || { other: 1 }, 'other'),
    ingredients,
    enabled: dish.enabled !== false && dish.active !== false,
    channel: dish.channel || 'dineIn',
    tags: Array.isArray(dish.tags) ? dish.tags.slice() : []
  };
}

function normalizeMenu(menu = []) {
  return (menu || []).map(normalizeDish).filter(dish => dish.enabled);
}

function weightedMenu(menuInput, segmentMix = {}, districtAvgSpend = 30) {
  const menu = normalizeMenu(menuInput);
  const segments = normalizeShares(segmentMix, 'other');
  if (!menu.length) return { menu: [], rows: [], averagePrice: 0, averageCookMinutes: 0, averageQuality: 0, priceFit: 0 };

  const rows = menu.map(dish => {
    let fit = dish.segmentFit.other || 0.45;
    for (const [segment, share] of Object.entries(segments)) {
      fit += share * safeNumber(dish.segmentFit[segment], dish.segmentFit.other || 0.45);
    }
    const priceDistance = Math.abs(dish.price - districtAvgSpend) / Math.max(8, districtAvgSpend);
    const priceFit = clamp(1 - priceDistance * 0.72, 0.2, 1.15);
    const qualityFactor = 0.55 + dish.quality / 180;
    const popularityFactor = 0.55 + dish.popularity / 180;
    const score = Math.max(0.001, fit * priceFit * qualityFactor * popularityFactor);
    return { dish, fit: round(fit, 4), priceFit: round(priceFit, 4), score };
  });
  const scoreSum = sum(rows.map(row => row.score)) || 1;
  rows.forEach(row => { row.share = row.score / scoreSum; });
  const averagePrice = sum(rows.map(row => row.dish.price * row.share));
  const averageCookMinutes = sum(rows.map(row => row.dish.cookMinutes * row.share));
  const averageQuality = sum(rows.map(row => row.dish.quality * row.share));
  const averagePopularity = sum(rows.map(row => row.dish.popularity * row.share));
  const averagePriceFit = sum(rows.map(row => row.priceFit * row.share));
  return {
    menu,
    rows,
    averagePrice: round(averagePrice, 2),
    averageCookMinutes: round(averageCookMinutes, 2),
    averageQuality: round(averageQuality, 2),
    averagePopularity: round(averagePopularity, 2),
    priceFit: round(averagePriceFit, 4)
  };
}

function dishesPerCover(menuAnalysis, options = {}) {
  const base = Math.max(0.6, safeNumber(options.dishesPerCover, 1.18));
  const price = menuAnalysis && menuAnalysis.averagePrice || 30;
  const spend = Math.max(10, safeNumber(options.avgSpend, price));
  return round(clamp(base * (0.9 + Math.min(0.25, spend / Math.max(price, 1) * 0.08)), 0.75, 1.7), 3);
}

function plannedDishUnits(menuAnalysis, covers, options = {}) {
  const totalUnits = Math.max(0, safeNumber(covers)) * dishesPerCover(menuAnalysis, options);
  const result = {};
  let assigned = 0;
  const rows = menuAnalysis.rows || [];
  rows.forEach((row, index) => {
    const units = index === rows.length - 1 ? Math.max(0, Math.round(totalUnits - assigned)) : Math.max(0, Math.round(totalUnits * row.share));
    result[row.dish.id] = units;
    assigned += units;
  });
  return result;
}

module.exports = {
  normalizeDish,
  normalizeMenu,
  weightedMenu,
  dishesPerCover,
  plannedDishUnits
};
