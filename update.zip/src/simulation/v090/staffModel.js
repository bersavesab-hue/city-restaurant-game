'use strict';

const BALANCE = require('./balance.js');
const { clamp, safeNumber, round, sum } = require('./utils.js');

const ROLE_BASE = Object.freeze({
  cook: { capacity: 1, wage: 180, fatigueRate: 1 },
  chef: { capacity: 1.25, wage: 260, fatigueRate: 0.95 },
  prep: { capacity: 0.65, wage: 140, fatigueRate: 0.92 },
  waiter: { capacity: 1, wage: 150, fatigueRate: 1 },
  cashier: { capacity: 0.55, wage: 150, fatigueRate: 0.85 },
  manager: { capacity: 0.35, wage: 240, fatigueRate: 0.78 },
  cleaner: { capacity: 0.25, wage: 130, fatigueRate: 0.9 },
  delivery: { capacity: 0.45, wage: 160, fatigueRate: 0.95 }
});

function normalizeStaff(staff = []) {
  return (staff || []).map((person, index) => {
    const role = person.role || 'waiter';
    const base = ROLE_BASE[role] || ROLE_BASE.waiter;
    const skill = clamp(person.skill == null ? person.level ? 0.72 + (safeNumber(person.level) - 1) * 0.08 : 0.8 : person.skill, 0.45, 1.35);
    const fatigue = clamp(person.fatigue, 0, 100);
    const morale = clamp(person.morale == null ? 70 : person.morale, 0, 100);
    const attendance = person.absent ? 0 : clamp(person.attendance == null ? 1 : person.attendance, 0, 1);
    const fatiguePenalty = 1 - Math.max(0, fatigue - 55) / 170;
    const moraleFactor = 0.82 + morale / 500;
    const efficiency = clamp(base.capacity * skill * fatiguePenalty * moraleFactor * attendance, 0, 1.75);
    return {
      id: person.id || `staff-${index + 1}`,
      name: person.name || `员工${index + 1}`,
      role,
      skill: round(skill, 4),
      fatigue: round(fatigue, 2),
      morale: round(morale, 2),
      attendance: round(attendance, 3),
      efficiency: round(efficiency, 4),
      dailyWage: Math.max(0, safeNumber(person.dailyWage || person.wage, base.wage)),
      shiftMinutes: Math.max(120, safeNumber(person.shiftMinutes, 540)),
      experience: Math.max(0, safeNumber(person.experience, 0)),
      traits: Array.isArray(person.traits) ? person.traits.slice() : []
    };
  });
}

function roleEfficiency(staff, roles) {
  const roleSet = new Set(Array.isArray(roles) ? roles : [roles]);
  return sum(staff.filter(person => roleSet.has(person.role)).map(person => person.efficiency));
}

function calculateCapacity(staffInput, store = {}) {
  const staff = normalizeStaff(staffInput);
  const cooks = staff.filter(person => ['cook', 'chef', 'prep'].includes(person.role));
  const waiters = staff.filter(person => ['waiter', 'cashier', 'manager'].includes(person.role));
  const cookProductiveMinutes = cooks.reduce((acc, person) => {
    const roleFactor = person.role === 'prep' ? 0.72 : person.role === 'chef' ? 1.16 : 1;
    return acc + Math.min(person.shiftMinutes, BALANCE.cookProductiveMinutesPerShift) * person.efficiency * roleFactor;
  }, 0);
  const waiterCovers = waiters.reduce((acc, person) => {
    const roleFactor = person.role === 'cashier' ? 0.45 : person.role === 'manager' ? 0.4 : 1;
    return acc + BALANCE.serviceCoversPerWaiterShift * person.efficiency * roleFactor * (person.shiftMinutes / 540);
  }, 0);
  const managementFactor = 1 + Math.min(0.12, roleEfficiency(staff, 'manager') * 0.045);
  const cleaningFactor = clamp(0.88 + roleEfficiency(staff, 'cleaner') * 0.12, 0.88, 1.06);
  const laborCost = sum(staff.map(person => person.dailyWage));

  return {
    staff,
    headcount: staff.length,
    cooks: cooks.length,
    frontOfHouse: waiters.length,
    cookProductiveMinutes: round(cookProductiveMinutes),
    serviceCoverCapacity: round(waiterCovers * managementFactor),
    managementFactor: round(managementFactor, 4),
    cleaningFactor: round(cleaningFactor, 4),
    laborCost: round(laborCost),
    averageFatigue: staff.length ? round(sum(staff.map(person => person.fatigue)) / staff.length, 2) : 0,
    averageMorale: staff.length ? round(sum(staff.map(person => person.morale)) / staff.length, 2) : 0
  };
}

function updateAfterDay(staffInput, utilization = {}) {
  const staff = normalizeStaff(staffInput);
  const kitchenUtil = clamp(utilization.kitchen, 0, 1.5);
  const serviceUtil = clamp(utilization.service, 0, 1.5);
  return staff.map(person => {
    const roleLoad = ['cook', 'chef', 'prep'].includes(person.role) ? kitchenUtil : serviceUtil;
    const overtime = Math.max(0, roleLoad - 0.85);
    const fatigueDelta = 4 + roleLoad * 7 + overtime * 14;
    const moraleDelta = roleLoad > 1 ? -3.5 : roleLoad > 0.88 ? -1.2 : roleLoad < 0.45 ? -0.4 : 0.4;
    const xpGain = 1 + Math.min(2.5, roleLoad * 1.5);
    return {
      ...person,
      fatigue: round(clamp(person.fatigue + fatigueDelta - 3, 0, 100), 2),
      morale: round(clamp(person.morale + moraleDelta, 0, 100), 2),
      experience: round(person.experience + xpGain, 2)
    };
  });
}

function turnoverRisk(staffInput) {
  const staff = normalizeStaff(staffInput);
  return staff.map(person => {
    const fatigueRisk = Math.max(0, person.fatigue - 70) * 0.006;
    const moraleRisk = Math.max(0, 50 - person.morale) * 0.008;
    const risk = clamp(0.003 + fatigueRisk + moraleRisk, 0, 0.65);
    return { id: person.id, name: person.name, role: person.role, risk: round(risk, 4) };
  });
}

module.exports = {
  ROLE_BASE,
  normalizeStaff,
  calculateCapacity,
  updateAfterDay,
  turnoverRisk
};
