'use strict';

// V0866_MATURE_STARTER_SHOP
// Fresh players take over a small operating restaurant instead of being forced
// through property search before they have seen the core restaurant loop.

const globalGameState = require('./gameState.js');
const VERSION = '0.8.66';
const STARTER_ID = 'starter_shop_1';

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function starterShop() {
  return {
    id: STARTER_ID,
    name: '街角小馆',
    status: 'open',
    lifecycleStage: 'formal_open',
    districtId: 'oldtown',
    streetId: 'old_changle',
    address: '长乐街18号',
    origin: 'starter_mature_shop',
    matureAtStart: true,

    grossArea: 46,
    usableArea: 42,
    frontage: 4.8,
    frontageWidth: 4.8,
    depth: 9.1,

    monthlyRent: 6800,
    footfall: 5200,
    visibility: 64,
    exposureScore: 64,
    rating: 3.7,
    reputationScore: 42,
    priceFit: 68,
    menuAppeal: 61,

    exhaust: true,
    drainage: true,
    greaseTrap: true,
    gas: true,
    threePhase: true,
    fireSprinkler: true,
    fireSafety: true,

    // Only used before renovation for property-market estimates.
    seatEstimate: 18,
    actualSeatCapacity: 16,

    ownerOperatedRoles: ['manager', 'cashier'],
    operatingFormat: 'small_restaurant',
    trialOpenedDay: 1,
    formalOpenedDay: 1
  };
}

function starterPlan() {
  return {
    shopId: STARTER_ID,
    status: 'completed',
    activeFloor: 0,
    hallStyle: 'wood',
    materialGrade: 'budget',
    lightingLevel: 'basic',
    freeBuildVersion: 1,
    editorPlacementVersion: 4,
    editorPlacementSeq: 12,
    editorPlacementSignature: null,
    decorCounts: {
      plant: 2,
      pendant: 0,
      screen: 0,
      sofa: 0
    },
    floors: [
      {
        index: 0,
        name: '第1层',
        area: 42,
        freeBuildVersion: 1,
        kitchenRatio: 0.27,
        storageRatio: 0.08,
        serviceRatio: 0.11,
        aisleMode: 'standard',
        tables: {
          2: 4,
          4: 2,
          6: 0,
          8: 0
        },
        editorWalls: [],
        editorDoors: [],
        editorPlacements: [
          { id:'starter_table2_1', kind:'table2', mx:1.00, my:4.90, rotation:0 },
          { id:'starter_table2_2', kind:'table2', mx:3.80, my:4.90, rotation:0 },
          { id:'starter_table2_3', kind:'table2', mx:1.00, my:6.40, rotation:0 },
          { id:'starter_table2_4', kind:'table2', mx:3.80, my:6.40, rotation:0 },
          { id:'starter_table4_1', kind:'table4', mx:1.25, my:3.00, rotation:0 },
          { id:'starter_table4_2', kind:'table4', mx:3.55, my:3.00, rotation:0 },

          { id:'starter_stove', kind:'stove', mx:0.95, my:0.80, rotation:0 },
          { id:'starter_prep', kind:'prep', mx:2.20, my:0.80, rotation:0 },
          { id:'starter_sink', kind:'sink', mx:3.35, my:0.80, rotation:0 },
          { id:'starter_fridge', kind:'fridge', mx:4.15, my:1.65, rotation:90 },
          { id:'starter_cashier', kind:'cashier', mx:0.70, my:7.75, rotation:90 },
          { id:'starter_plant_1', kind:'plant', mx:4.35, my:7.80, rotation:0 },
          { id:'starter_plant_2', kind:'plant', mx:0.45, my:4.00, rotation:0 }
        ],
        privateRooms: []
      }
    ],
    selectedContractorId: null,
    construction: {
      completed: true,
      completedDay: 1,
      starterInherited: true
    }
  };
}

function starterEquipment() {
  return {
    status: 'installed',
    items: {
      cooking: { id:'cooking', quantity:1, grade:'standard' },
      cold: { id:'cold', quantity:1, grade:'standard' },
      prep: { id:'prep', quantity:1, grade:'standard' },
      dishwash: { id:'dishwash', quantity:1, grade:'standard' },
      pos: { id:'pos', quantity:1, grade:'standard' }
    },
    orderDay: 0,
    deliveryDay: 0,
    paid: 0,
    inherited: true
  };
}

function starterPermits() {
  const ids = ['business','food','fire','sign'];
  const items = {};
  for (const id of ids) {
    items[id] = {
      id,
      status: 'approved',
      appliedDay: 0,
      finishDay: 0,
      paid: 0,
      issue: null
    };
  }
  return {
    items,
    remediated: {},
    inherited: true
  };
}

function starterStaff() {
  return {
    hired: [
      {
        id:'starter_staff_chef',
        personId:'starter_staff_chef',
        name:'周启明',
        age:31,
        roleId:'chef',
        roleName:'厨师',
        wage:6500,
        skill:63,
        stability:72,
        experience:7,
        active:true,
        hiredDay:0
      },
      {
        id:'starter_staff_server',
        personId:'starter_staff_server',
        name:'陈婉宁',
        age:26,
        roleId:'server',
        roleName:'前厅',
        wage:4300,
        skill:58,
        stability:68,
        experience:4,
        active:true,
        hiredDay:0
      }
    ],
    candidateDay:null,
    candidates:[],
    starterOwnerRoles:['manager','cashier']
  };
}

function initializeRuntime(state, shop) {
  if (state !== globalGameState) return;

  // Lazy requires avoid a startup cycle:
  // newGameFlow -> starterShop -> operationsStore -> gameplayFlow -> newGameFlow.
  const operations =
    require('../operations/operationsStoreV080.js');
  const runtimeEngine =
    require('../operations/restaurantRuntimeV10.js');
  const serviceEngine =
    require('../service/serviceEngineV10.js');

  const runtime = operations.getRuntime(shop.id);
  if (!runtime) return;

  runtime.menu = (runtime.menu || []).slice(0, 6);
  runtime.shop.rating = 3.7;
  runtime.shop.reviewCount = 37;
  runtime.shop.wordOfMouth = 0.18;
  runtime.shop.actualSeatCapacity = 16;

  runtime.diningRoom = serviceEngine.createDiningRoom({
    tableCounts: {
      two:4,
      four:2,
      six:0,
      eight:0
    }
  });

  runtime.kitchen.stations.wok = 2;
  runtime.kitchen.stations.fryer = 1;
  runtime.kitchen.stations.boil = 2;
  runtime.kitchen.stations.assembly = 1;
  runtime.kitchen.staffSkill = 61;
  runtime.kitchen.equipmentScore = 66;

  const hasInventory = runtime.inventory &&
    Array.isArray(runtime.inventory.lots) &&
    runtime.inventory.lots.some(lot => Number(lot.grams) > 0);

  if (!hasInventory) {
    runtimeEngine.bootstrapInventory(runtime, 2);
  }

  runtime.simulation = runtime.simulation || {};
  runtime.simulation.starterShop = true;
  runtime.simulation.starterProblems = {
    lunchCapacityPressure: true,
    weakDinnerTraffic: true,
    lowMarginMenuItem: true
  };

  operations.persist(shop.id);
}

function ensureStarterShop(options) {
  const opts = options || {};
  const state = opts.gameState || globalGameState;
  const business = state.getBusiness();

  if (business.hasShop && Array.isArray(business.shops) && business.shops.length) {
    return {
      created:false,
      shop:clone(
        business.shops.find(x => x.id === business.currentShopId) ||
        business.shops[0]
      )
    };
  }

  const shop = starterShop();

  business.shops = Array.isArray(business.shops) ? business.shops : [];
  business.shops.push(clone(shop));
  business.hasShop = true;
  business.currentShopId = shop.id;

  const world = state.getWorld();
  if (world) {
    world.currentDistrictId = shop.districtId;
  }

  const renovations = state.getRenovations();
  renovations[shop.id] = starterPlan();

  const prep = state.getOpeningPrep();
  prep.equipment[shop.id] = starterEquipment();
  prep.permits[shop.id] = starterPermits();
  prep.staffing[shop.id] = starterStaff();

  const data = state.getData();
  data.progress = data.progress || {};
  data.progress.starterShop = {
    version:1,
    shopId:shop.id,
    inherited:true,
    createdAtStart:true
  };

  initializeRuntime(state, shop);

  return {
    created:true,
    shop:clone(shop)
  };
}

module.exports = {
  VERSION,
  STARTER_ID,
  starterShop,
  starterPlan,
  ensureStarterShop
};
