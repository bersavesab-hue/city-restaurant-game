'use strict';

const sceneManager =
  require('./sceneManager.js');

const ROUTES = Object.freeze({
  city:{
    id:'city',
    label:'城市地图',
    group:'world',
    scene:'city'
  },
  shop:{
    id:'shop',
    label:'门店 / 选址',
    group:'shop',
    scene:'shop'
  },
  store:{
    id:'store',
    label:'现场经营',
    group:'shop',
    scene:'store'
  },
  research:{
    id:'research',
    label:'菜单 / 菜品',
    group:'operation',
    scene:'research'
  },
  supply:{
    id:'supply',
    label:'供应链 / 采购',
    group:'operation',
    scene:'supply'
  },
  staff:{
    id:'staff',
    label:'员工招聘',
    group:'team',
    scene:'staff'
  },
  schedule:{
    id:'schedule',
    label:'营业 / 排班',
    group:'team',
    scene:'schedule'
  },
  staffCareer:{
    id:'staffCareer',
    label:'团队成长',
    group:'team',
    scene:'staffCareer'
  },
  business:{
    id:'business',
    label:'经营 / 财务数据',
    group:'management',
    scene:'business'
  },
  dynamicWorld:{
    id:'dynamicWorld',
    label:'城市动态',
    group:'world',
    scene:'dynamicWorld'
  },
  system:{
    id:'system',
    label:'系统设置',
    group:'system',
    scene:'system'
  },
  featureHub:{
    id:'featureHub',
    label:'功能中心',
    group:'system',
    scene:'featureHub'
  }
});

const ALIASES = Object.freeze({
  menu:'research',
  dishes:'research',
  purchase:'supply',
  procurement:'supply',
  operation:'store',
  operations:'store',
  employees:'staff',
  team:'staffCareer',
  finance:'business',
  data:'business',
  world:'dynamicWorld',
  settings:'system',
  hub:'featureHub'
});

const HISTORY_LIMIT = 32;
const history = [];
const lastParams = Object.create(null);
let lastError = null;

function cloneParams(value) {
  if (
    !value ||
    typeof value !== 'object' ||
    Array.isArray(value)
  ) {
    return {};
  }

  return Object.assign(
    {},
    value
  );
}

function getCurrentId() {
  if (
    sceneManager &&
    typeof sceneManager.getCurrentId ===
      'function'
  ) {
    return (
      sceneManager.getCurrentId() ||
      null
    );
  }

  return null;
}

function routeByScene(sceneId) {
  const values =
    Object.values(
      ROUTES
    );

  for (
    let i = 0;
    i < values.length;
    i++
  ) {
    if (
      values[i].scene ===
      sceneId
    ) {
      return values[i];
    }
  }

  return null;
}

function pushHistory(sceneId) {
  if (!sceneId) {
    return;
  }

  const previous =
    history[
      history.length - 1
    ];

  if (
    previous &&
    previous.scene ===
      sceneId
  ) {
    return;
  }

  history.push({
    scene:sceneId,
    params:cloneParams(
      lastParams[sceneId]
    )
  });

  if (
    history.length >
      HISTORY_LIMIT
  ) {
    history.splice(
      0,
      history.length -
        HISTORY_LIMIT
    );
  }
}

function resolve(routeId) {
  if (
    routeId &&
    ROUTES[routeId]
  ) {
    return ROUTES[routeId];
  }

  if (
    routeId &&
    ALIASES[routeId] &&
    ROUTES[ALIASES[routeId]]
  ) {
    return ROUTES[ALIASES[routeId]];
  }

  const byScene =
    routeByScene(
      routeId
    );

  return byScene;
}

function open(
  routeId,
  params,
  options
) {
  const route =
    resolve(
      routeId
    );

  if (!route) {
    lastError =
      '未知功能入口：' +
      String(routeId || '');

    return false;
  }

  const opts =
    options &&
    typeof options === 'object'
      ? options
      : {};

  const current =
    getCurrentId();

  const payload =
    Object.assign(
      {},
      cloneParams(
        lastParams[route.scene]
      ),
      cloneParams(
        params
      )
    );

  let pushed =
    false;

  if (
    opts.record !== false &&
    current &&
    current !== route.scene
  ) {
    pushHistory(
      current
    );

    pushed =
      true;
  }

  let switched =
    false;

  try {
    switched =
      Boolean(
        sceneManager &&
        typeof sceneManager.switchTo ===
          'function' &&
        sceneManager.switchTo(
          route.scene,
          payload
        )
      );
  } catch (error) {
    switched =
      false;

    lastError =
      error &&
      error.message
        ? error.message
        : String(error);
  }

  if (!switched) {
    if (pushed) {
      history.pop();
    }

    if (!lastError) {
      lastError =
        '页面尚未注册：' +
        route.scene;
    }

    return false;
  }

  lastParams[route.scene] =
    payload;

  lastError =
    null;

  return true;
}

function back(fallback) {
  const current =
    getCurrentId();

  while (
    history.length > 0
  ) {
    const target =
      history.pop();

    if (
      !target ||
      !target.scene ||
      target.scene ===
        current
    ) {
      continue;
    }

    let switched =
      false;

    try {
      switched =
        Boolean(
          sceneManager &&
          typeof sceneManager.switchTo ===
            'function' &&
          sceneManager.switchTo(
            target.scene,
            cloneParams(
              target.params
            )
          )
        );
    } catch (error) {
      switched =
        false;
    }

    if (switched) {
      lastError =
        null;

      return true;
    }
  }

  return open(
    fallback ||
      'city',
    null,
    {
      record:false
    }
  );
}

function remember(
  routeId,
  params
) {
  const route =
    resolve(
      routeId
    );

  if (!route) {
    return false;
  }

  lastParams[route.scene] =
    Object.assign(
      {},
      cloneParams(
        lastParams[route.scene]
      ),
      cloneParams(
        params
      )
    );

  return true;
}

function clearHistory() {
  history.length =
    0;

  lastError =
    null;
}

function entries() {
  return Object
    .values(
      ROUTES
    )
    .map(
      item =>
        Object.assign(
          {},
          item
        )
    );
}

function getHistory() {
  return history.map(
    item => ({
      scene:item.scene,
      params:cloneParams(
        item.params
      )
    })
  );
}

function getLastError() {
  return lastError;
}

function diagnose() {
  const has =
    sceneManager &&
    typeof sceneManager.has ===
      'function'
      ? sceneId =>
          Boolean(
            sceneManager.has(
              sceneId
            )
          )
      : null;

  return {
    version:'0.8.9',
    current:getCurrentId(),
    historyDepth:history.length,
    lastError,
    routes:entries().map(
      item =>
        Object.assign(
          {},
          item,
          {
            registered:has
              ? has(
                  item.scene
                )
              : null
          }
        )
    )
  };
}

module.exports = {
  version:'0.8.9',
  routes:ROUTES,
  aliases:ALIASES,
  resolve,
  open,
  back,
  remember,
  clearHistory,
  entries,
  getHistory,
  getLastError,
  diagnose
};
