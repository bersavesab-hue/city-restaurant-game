'use strict';

/**
 * V0.9.2 render pacing governor
 *
 * Important: this version deliberately does NOT throttle simulation updates.
 * It only limits expensive full-canvas redraws at high game speed.
 * That keeps all legacy timing/scene semantics intact while reducing GPU/Canvas work.
 */

const MAX_FRAME_DELTA_MS = 100;

function normalizeSpeed(speed) {
  const n = Number(speed);
  if (!Number.isFinite(n) || n <= 0) return 1;
  return n;
}

function clampFrameDelta(deltaMs) {
  const n = Number(deltaMs);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.min(MAX_FRAME_DELTA_MS, n);
}

function getRenderIntervalMs(speed, paused, animationChanged) {
  if (animationChanged) return 1000 / 60;
  if (paused) return 100;
  const s = normalizeSpeed(speed);
  if (s >= 10) return 50;      // 20 FPS UI at 10x
  if (s >= 5) return 40;       // 25 FPS UI at 5x
  if (s >= 2) return 25;       // 40 FPS UI at 2x
  return 1000 / 60;            // 60 FPS UI at 1x
}

function shouldRender(elapsedSinceRenderMs, speed, paused, animationChanged, force) {
  if (force) return true;
  return Number(elapsedSinceRenderMs || 0) >=
    getRenderIntervalMs(speed, paused, animationChanged);
}

module.exports = {
  MAX_FRAME_DELTA_MS,
  normalizeSpeed,
  clampFrameDelta,
  getRenderIntervalMs,
  shouldRender
};
