'use strict';

/**
 * V0.9.1 frame pacing governor
 *
 * Goal:
 * - High game speed should advance simulation faster without forcing the phone
 *   to perform a full scene update + full canvas render at 60 FPS.
 * - Large resume/background deltas are clamped so the app does not attempt an
 *   expensive catch-up burst in one frame.
 * - Short interaction animations are still allowed to render smoothly.
 */

const MAX_FRAME_DELTA_MS = 100;

function normalizeSpeed(speed) {
  const n = Number(speed);
  if (!Number.isFinite(n) || n <= 0) return 1;
  return n;
}

function clampFrameDelta(deltaMs) {
  const n = Number(deltaMs);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.min(MAX_FRAME_DELTA_MS, n);
}

function getSimulationIntervalMs(speed, paused) {
  if (paused) return 100;
  const s = normalizeSpeed(speed);
  if (s >= 10) return 50;       // 20 simulation updates / second
  if (s >= 5) return 40;        // 25 updates / second
  if (s >= 2) return 25;        // 40 updates / second
  return 1000 / 60;             // normal speed stays responsive
}

function getRenderIntervalMs(speed, paused, animationChanged) {
  // Tap/transition animations should not look sluggish even when time is fast.
  if (animationChanged) return 1000 / 60;
  if (paused) return 100;        // paused HUD only needs redraws when dirty
  const s = normalizeSpeed(speed);
  if (s >= 10) return 50;        // 20 FPS at 10x
  if (s >= 5) return 40;         // 25 FPS at 5x
  if (s >= 2) return 25;         // 40 FPS at 2x
  return 1000 / 60;              // 60 FPS at 1x
}

function shouldRunSimulation(accumulatorMs, speed, paused) {
  return Number(accumulatorMs || 0) >= getSimulationIntervalMs(speed, paused);
}

function shouldRender(elapsedSinceRenderMs, speed, paused, animationChanged, force) {
  if (force) return true;
  return Number(elapsedSinceRenderMs || 0) >=
    getRenderIntervalMs(speed, paused, animationChanged);
}

module.exports = {
  MAX_FRAME_DELTA_MS,
  normalizeSpeed,
  clampFrameDelta,
  getSimulationIntervalMs,
  getRenderIntervalMs,
  shouldRunSimulation,
  shouldRender
};
