'use strict';

// AUTO_GENERATED_RESOURCE_POOLS_V1
module.exports = {
  schemaVersion: 1,
  pools: {}
};
