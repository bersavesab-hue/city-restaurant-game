'use strict';

const catalog = require('./assetCatalogV2.js');

const loadedGroups = new Set();
const loadedAtlases = new Set();

function loadImage(resourceManager, id, path, group) {
  if (!resourceManager || typeof resourceManager.loadImage !== 'function') {
    return Promise.reject(new Error('resourceManager.loadImage 不可用'));
  }
  return resourceManager.loadImage(id, path, group);
}

function loadGroup(resourceManager, groupName) {
  const items = catalog.getGroup(groupName);
  if (!items.length) return Promise.resolve([]);
  if (loadedGroups.has(groupName)) return Promise.resolve(items.map((x) => x.id));

  return Promise.all(items.map((item) =>
    loadImage(resourceManager, item.id, item.path, 'home:' + groupName)
  )).then(() => {
    loadedGroups.add(groupName);
    return items.map((x) => x.id);
  });
}

function loadAtlas(resourceManager, atlasId) {
  const atlas = catalog.getAtlas(atlasId);
  if (!atlas) return Promise.reject(new Error('未找到图集：' + atlasId));
  if (loadedAtlases.has(atlasId)) return Promise.resolve(atlasId);

  return loadImage(resourceManager, atlasId, atlas.path, 'home:atlas')
    .then(() => {
      loadedAtlases.add(atlasId);
      return atlasId;
    });
}

function preloadHomeEssential(resourceManager) {
  const list = (catalog.manifest.assetPolicy && catalog.manifest.assetPolicy.preloadAtlases) || [];
  return Promise.all(list.map((atlasId) => loadAtlas(resourceManager, atlasId)));
}

function loadHomeScene(resourceManager, sceneName) {
  const sceneGroups = {
    city: ['backgrounds', 'districts'],
    store: ['storefronts', 'store_states'],
    empty: ['empty_states']
  };
  const groups = sceneGroups[sceneName] || [];
  return Promise.all(groups.map((group) => loadGroup(resourceManager, group)));
}

function releaseGroup(resourceManager, groupName) {
  const rm = resourceManager || {};
  const runtimeGroup = 'home:' + groupName;
  if (typeof rm.releaseGroup === 'function') rm.releaseGroup(runtimeGroup);
  else if (typeof rm.clearGroup === 'function') rm.clearGroup(runtimeGroup);
  else if (typeof rm.unloadGroup === 'function') rm.unloadGroup(runtimeGroup);
  loadedGroups.delete(groupName);
}

function resetTracking() {
  loadedGroups.clear();
  loadedAtlases.clear();
}

module.exports = {
  loadGroup,
  loadAtlas,
  preloadHomeEssential,
  loadHomeScene,
  releaseGroup,
  resetTracking,
  getSprite: catalog.getSprite,
  getAsset: catalog.getAsset
};
