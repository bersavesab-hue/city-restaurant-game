'use strict';

const manifest = require('../../assets/ui/home/manifest.json');

function getAsset(id) {
  return manifest.index && manifest.index[id] ? manifest.index[id] : null;
}

function getGroup(groupName) {
  return (manifest.entries || []).filter((item) => item.group === groupName);
}

function getAtlas(atlasId) {
  return manifest.atlases && manifest.atlases[atlasId] ? manifest.atlases[atlasId] : null;
}

function getSprite(spriteId) {
  const atlases = manifest.atlases || {};
  for (const atlasId of Object.keys(atlases)) {
    const atlas = atlases[atlasId];
    if (atlas.sprites && atlas.sprites[spriteId]) {
      return {
        atlasId,
        path: atlas.path,
        region: atlas.sprites[spriteId]
      };
    }
  }
  return null;
}

module.exports = {
  manifest,
  getAsset,
  getGroup,
  getAtlas,
  getSprite
};
