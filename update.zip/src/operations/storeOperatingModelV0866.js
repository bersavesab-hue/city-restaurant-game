'use strict';

// V0866_UNIFIED_STORE_OPERATING_MODEL
// One source of truth for store format, actual seats, allowed service channels
// and practical kitchen throughput.

const gameState = require('../core/gameState.js');
const demandSystem = require('../city/demandSystem.js');
const trafficSystem = require('../city/customerTrafficSystem.js');
const openingConfig = require('../opening/openingConfig.js');

const VERSION = '0.8.66';

const PERIOD_MINUTES = {
  breakfast: 150,
  lunch: 150,
  afternoon: 180,
  dinner: 180,
  night: 180
};

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, Number(value) || 0));
}

function getPlan(shopId) {
  const store = gameState.getRenovations();
  return store && store[shopId] || null;
}

function tableCounts(shop) {
  const counts = { two:0, four:0, six:0, eight:0 };
  const plan = shop && getPlan(shop.id);

  if (plan && Array.isArray(plan.floors)) {
    for (const floor of plan.floors) {
      const tables = floor && floor.tables || {};
      counts.two += Math.max(0, Number(tables[2] ?? tables['2']) || 0);
      counts.four += Math.max(0, Number(tables[4] ?? tables['4']) || 0);
      counts.six += Math.max(0, Number(tables[6] ?? tables['6']) || 0);
      counts.eight += Math.max(0, Number(tables[8] ?? tables['8']) || 0);
    }
  }

  return counts;
}

function seatsFromCounts(counts) {
  return (
    (Number(counts.two) || 0) * 2 +
    (Number(counts.four) || 0) * 4 +
    (Number(counts.six) || 0) * 6 +
    (Number(counts.eight) || 0) * 8
  );
}

function actualSeatCapacity(shop) {
  if (!shop) return 0;

  const counts = tableCounts(shop);
  const real = seatsFromCounts(counts);

  if (real > 0 || getPlan(shop.id)) {
    return {
      seats: real,
      counts,
      source: 'renovation'
    };
  }

  // Old saves may have an operating shop but no persisted renovation plan.
  // Keep them playable until the player next edits the layout.
  const legacy = shop.status === 'open' || shop.status === 'trial_opening'
    ? Math.max(0, Number(shop.actualSeatCapacity ?? shop.seats ?? shop.seatEstimate) || 0)
    : 0;

  return {
    seats: legacy,
    counts: legacy > 0 ? legacyCounts(legacy) : counts,
    source: legacy > 0 ? 'legacy_migration' : 'none'
  };
}

function legacyCounts(seats) {
  let remaining = Math.max(0, Math.floor(Number(seats) || 0));
  const out = { two:0, four:0, six:0, eight:0 };

  while (remaining >= 4) {
    out.four++;
    remaining -= 4;
  }
  if (remaining >= 2) {
    out.two++;
    remaining -= 2;
  }
  if (remaining === 1) {
    out.two++;
  }
  return out;
}

function format(shop) {
  const seats = actualSeatCapacity(shop);
  const profile = trafficSystem.classifyStore({
    ...(shop || {}),
    actualSeatCapacity: seats.seats
  });

  if (seats.seats <= 0) {
    profile.dineInAllowed = false;
    profile.seatCapacity = 0;
    profile.serviceModes = (profile.serviceModes || [])
      .filter(mode => mode !== 'dinein');
  } else {
    profile.seatCapacity = seats.seats;
  }

  return {
    ...profile,
    seatSource: seats.source,
    tableCounts: seats.counts
  };
}

function serviceChannels(shop) {
  const f = format(shop);
  const modes = new Set(f.serviceModes || []);
  const out = [];

  if (f.dineInAllowed && f.seatCapacity > 0 && modes.has('dinein')) {
    out.push('dine_in');
  }
  if (modes.has('takeaway')) {
    out.push('pickup');
  }
  if (modes.has('delivery')) {
    out.push('delivery');
  }

  if (!out.length) out.push('pickup');
  return out;
}

function equipmentState(shopId) {
  const prep = gameState.getOpeningPrep();
  return prep && prep.equipment && prep.equipment[shopId] || null;
}

function equipmentQuantity(shopId, id) {
  const plan =
    getPlan(
      shopId
    );

  const kindByGroup = {
    cooking:'stove',
    cold:'fridge',
    prep:'prep',
    dishwash:'sink',
    pos:'cashier'
  };

  const kind =
    kindByGroup[
      id
    ];

  if (
    plan &&
    kind &&
    Array.isArray(
      plan.floors
    )
  ) {
    const placed =
      plan.floors
        .reduce(
          (sum,floor) =>
            sum +
            (
              floor.editorPlacements ||
              []
            ).filter(
              item =>
                item.kind ===
                kind
            ).length,
          0
        );

    if (placed > 0) {
      return placed;
    }
  }

  const state = equipmentState(shopId);
  const row = state && state.items && state.items[id];
  return Math.max(0, Number(row && row.quantity) || 0);
}

function kitchenPeriodCapacity(shop) {
  if (!shop) return 1;

  const cooking = equipmentQuantity(shop.id, 'cooking');
  const prep = equipmentQuantity(shop.id, 'prep');
  const cold = equipmentQuantity(shop.id, 'cold');
  const dishwash = equipmentQuantity(shop.id, 'dishwash');

  if (cooking + prep + cold + dishwash > 0) {
    const cookingBase = openingConfig.equipment.find(x => x.id === 'cooking');
    const prepBase = openingConfig.equipment.find(x => x.id === 'prep');
    const coldBase = openingConfig.equipment.find(x => x.id === 'cold');
    const washBase = openingConfig.equipment.find(x => x.id === 'dishwash');

    const capacities = [
      cooking > 0 ? cooking * cookingBase.capacityPerUnit : Infinity,
      prep > 0 ? prep * prepBase.capacityPerUnit : Infinity,
      cold > 0 ? cold * coldBase.capacityPerUnit : Infinity,
      dishwash > 0 ? dishwash * washBase.capacityPerUnit : Infinity
    ].filter(Number.isFinite);

    return Math.max(1, Math.floor(Math.min(...capacities)));
  }

  // Legacy operating saves without equipment records retain a bounded fallback.
  return Math.max(
    8,
    Math.floor(Math.max(12, Number(shop.usableArea || shop.grossArea) || 30) * 1.15)
  );
}

function staffCount(shopId) {
  const prep = gameState.getOpeningPrep();
  const state = prep && prep.staffing && prep.staffing[shopId];
  return Array.isArray(state && state.hired)
    ? state.hired.filter(x => x && x.active !== false).length
    : 0;
}

function marketingScore(runtime) {
  const campaigns = runtime && Array.isArray(runtime.campaigns)
    ? runtime.campaigns.filter(x => x && x.status === 'active')
    : [];
  if (!campaigns.length) return 0;
  return clamp(
    campaigns.reduce((sum, row) => sum + Math.min(25, (Number(row.budget) || 0) / 120), 0),
    0,
    100
  );
}

function trafficStore(shop, runtime) {
  const cap = actualSeatCapacity(shop);
  return {
    ...(shop || {}),
    actualSeatCapacity: cap.seats,
    seatCapacity: cap.seats,
    seats: cap.seats,
    kitchenCapacity: kitchenPeriodCapacity(shop),
    serviceStaffCount: Math.max(1, staffCount(shop && shop.id)),
    rating: clamp(runtime && runtime.shop && runtime.shop.rating || shop && shop.rating || 3.7, 1, 5),
    reputation: clamp(
      runtime && runtime.brand && runtime.brand.awareness ||
      shop && shop.reputationScore ||
      45,
      0,
      100
    ),
    marketingBoost: marketingScore(runtime)
  };
}

function trafficSnapshot(shop, runtime, mealPeriod) {
  if (!shop || !shop.districtId) return null;

  const result = demandSystem.getTrafficFunnel(
    shop.districtId,
    trafficStore(shop, runtime),
    {
      mealPeriod
    }
  );

  if (!result) return null;

  const cap = actualSeatCapacity(shop);
  result.format = {
    ...result.format,
    seatCapacity: cap.seats,
    dineInAllowed: cap.seats > 0 && result.format.dineInAllowed,
    serviceModes: serviceChannels(shop).map(channel => (
      channel === 'dine_in' ? 'dinein' :
      channel === 'pickup' ? 'takeaway' :
      'delivery'
    ))
  };

  return result;
}

function attemptedArrivalsPerMinute(shop, runtime, mealPeriod) {
  const snapshot = trafficSnapshot(shop, runtime, mealPeriod);

  if (!snapshot) {
    return {
      rate: 0,
      snapshot: null
    };
  }

  const minutes = PERIOD_MINUTES[mealPeriod] || 180;
  const attempted = Math.max(0, Number(snapshot.funnel && snapshot.funnel.attempted) || 0);

  return {
    rate: attempted / Math.max(1, minutes),
    snapshot
  };
}

function syncRuntimeCapacity(runtime, shop) {
  if (!runtime || !shop) return null;

  const actual = actualSeatCapacity(shop);
  const channels = serviceChannels(shop);
  const cooking = equipmentQuantity(shop.id, 'cooking');
  const prep = equipmentQuantity(shop.id, 'prep');

  runtime.shop = runtime.shop || {};
  runtime.shop.actualSeatCapacity = actual.seats;
  runtime.shop.operatingFormat = format(shop).id;
  runtime.shop.serviceChannels = channels.slice();

  runtime.kitchen = runtime.kitchen || {};
  runtime.kitchen.stations = runtime.kitchen.stations || {};

  if (cooking > 0) {
    runtime.kitchen.stations.wok = Math.max(1, cooking * 2);
    runtime.kitchen.stations.fryer = Math.max(1, cooking);
    runtime.kitchen.stations.boil = Math.max(1, cooking + 1);
    runtime.kitchen.stations.griddle = Math.max(1, cooking);
  }

  if (prep > 0) {
    runtime.kitchen.stations.assembly = Math.max(1, prep);
    runtime.kitchen.stations.cold = Math.max(1, prep);
  }

  return {
    seats: actual.seats,
    tableCounts: actual.counts,
    channels,
    kitchenCapacity: kitchenPeriodCapacity(shop),
    format: format(shop)
  };
}

function requiredStaff(shop) {
  const f = format(shop);
  const seats = Math.max(0, Number(f.seatCapacity) || 0);
  const ownerRoles = new Set(
    Array.isArray(shop && shop.ownerOperatedRoles)
      ? shop.ownerOperatedRoles
      : []
  );

  return {
    manager: ownerRoles.has('manager') ? 0 : 1,
    chef: f.hotKitchenReady ? 1 : 0,
    server: f.dineInAllowed && seats > 0
      ? Math.max(1, Math.ceil(seats / 22))
      : 0,
    cashier: ownerRoles.has('cashier') ? 0 : 1
  };
}

module.exports = {
  VERSION,
  PERIOD_MINUTES,
  actualSeatCapacity,
  tableCounts,
  seatsFromCounts,
  format,
  serviceChannels,
  kitchenPeriodCapacity,
  trafficStore,
  trafficSnapshot,
  attemptedArrivalsPerMinute,
  syncRuntimeCapacity,
  requiredStaff
};
