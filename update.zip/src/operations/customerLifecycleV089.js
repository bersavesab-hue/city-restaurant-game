'use strict';

const gameState =
  require('../core/gameState.js');

const customerEngine =
  require('../customer/customerEngineV10.js');

const { SeededRng } =
  require('../foundation/rng.js');

function clamp(
  value,
  min=0,
  max=100
) {
  return Math.max(
    min,
    Math.min(
      max,
      Number(value) || 0
    )
  );
}

function clone(value) {
  return JSON.parse(
    JSON.stringify(value)
  );
}

function getShop(
  shopId
) {
  return (
    gameState
      .getBusiness()
      .shops
      .find(
        row =>
          row.id ===
          shopId
      ) ||
    null
  );
}

function getRoot() {
  const business =
    gameState.getBusiness();

  business.customerLifecycle =
    business.customerLifecycle &&
    typeof business.customerLifecycle ===
      'object'
      ? business.customerLifecycle
      : {
          version:'0.8.9',
          shops:{}
        };

  business.customerLifecycle.version =
    '0.8.9';

  business.customerLifecycle.shops =
    business.customerLifecycle.shops ||
    {};

  return business
    .customerLifecycle;
}

function defaultShopState(
  shopId
) {
  return {
    shopId,
    membershipEnabled:false,
    profiles:{},
    reviews:[],
    dailyHistory:[],
    stats:{
      knownCustomers:0,
      activeCustomers:0,
      members:0,
      favorites:0,
      churned:0,
      repeatRate:0,
      avgSatisfaction:0,
      reviewCount:0,
      avgRating:0,
      wordOfMouth:0,
      demandMultiplier:1
    },
    lastProcessedDay:null
  };
}

function ensureShop(
  shopId
) {
  const root =
    getRoot();

  if (
    !root.shops[
      shopId
    ]
  ) {
    root.shops[
      shopId
    ] =
      defaultShopState(
        shopId
      );
  }

  const state =
    root.shops[
      shopId
    ];

  state.membershipEnabled =
    !!state.membershipEnabled;

  state.profiles =
    state.profiles &&
    typeof state.profiles ===
      'object'
      ? state.profiles
      : {};

  state.reviews =
    Array.isArray(
      state.reviews
    )
      ? state.reviews
      : [];

  state.dailyHistory =
    Array.isArray(
      state.dailyHistory
    )
      ? state.dailyHistory
      : [];

  state.stats =
    state.stats ||
    defaultShopState(
      shopId
    ).stats;

  return state;
}

function seedFor(
  shopId,
  day,
  extra
) {
  const seed =
    gameState
      .getSimulation()
      .seed ||
    'city';

  return [
    'customer-life-v089',
    seed,
    shopId,
    day,
    extra
  ].join(
    ':'
  );
}

function createPersistentCustomer(
  shop,
  state,
  day,
  index
) {
  const rng =
    new SeededRng(
      seedFor(
        shop.id,
        day,
        'new:' +
          index +
          ':' +
          Object.keys(
            state.profiles
          ).length
      )
    );

  const profile =
    customerEngine
      .createSegmentProfile(
        rng,
        {
          districtId:
            shop.districtId
        }
      );

  const id =
    profile.id;

  state.profiles[
    id
  ] = {
    id,
    profile,
    firstVisitDay:day,
    lastVisitDay:null,
    visits:0,
    totalSpend:0,
    avgSatisfaction:0,
    repeatProbability:0.42,
    member:false,
    favorite:false,
    disliked:false,
    churned:false,
    reviewCount:0,
    lastReviewStars:null,
    wordOfMouth:0
  };

  return state
    .profiles[
      id
    ];
}

function activeRows(
  state
) {
  return Object
    .values(
      state.profiles
    )
    .filter(
      row =>
        !row.churned
    );
}

function pickReturning(
  state,
  rng
) {
  const rows =
    activeRows(
      state
    );

  if (!rows.length) {
    return null;
  }

  const weights =
    rows.map(
      row => {
        const favorite =
          row.favorite
            ? 1.35
            : 1;

        const member =
          row.member
            ? 1.22
            : 1;

        const repeat =
          0.35 +
          clamp(
            row.repeatProbability,
            0,
            1
          );

        return {
          row,
          weight:
            Math.max(
              0.05,
              favorite *
              member *
              repeat
            )
        };
      }
    );

  const total =
    weights.reduce(
      (
        sum,
        item
      ) =>
        sum +
        item.weight,
      0
    );

  let cursor =
    rng.next() *
    total;

  for (
    const item
    of weights
  ) {
    cursor -=
      item.weight;

    if (
      cursor <=
      0
    ) {
      return item.row;
    }
  }

  return weights[
    weights.length -
    1
  ].row;
}

function buildExperience(
  closed,
  rng
) {
  const financial =
    closed &&
    closed.financial ||
    {};

  const customers =
    Math.max(
      1,
      Number(
        financial.customers
      ) ||
      1
    );

  const paidPerPerson =
    Math.max(
      1,
      (
        Number(
          financial.revenue
        ) ||
        0
      ) /
      customers
    );

  const base =
    clamp(
      (
        Number(
          closed &&
          closed.shopRating
        ) ||
        4
      ) *
      20,
      30,
      98
    );

  const noise =
    () =>
      (
        rng.next() -
        0.5
      ) *
      10;

  return {
    paidPerPerson,
    taste:
      clamp(
        base +
        noise()
      ),
    portion:
      clamp(
        66 +
        noise()
      ),
    speed:
      clamp(
        base -
        3 +
        noise()
      ),
    service:
      clamp(
        base +
        noise()
      ),
    hygiene:
      clamp(
        74 +
        (
          base -
          70
        ) *
        0.35 +
        noise()
      ),
    environment:
      clamp(
        68 +
        (
          base -
          70
        ) *
        0.25 +
        noise()
      ),
    stability:
      clamp(
        base -
        2 +
        noise()
      )
  };
}

function processCustomerVisit(
  shop,
  state,
  row,
  closed,
  day,
  index
) {
  const rng =
    new SeededRng(
      seedFor(
        shop.id,
        day,
        'visit:' +
          row.id +
          ':' +
          index
      )
    );

  const visit =
    customerEngine
      .generateVisit(
        row.profile,
        rng,
        {
          day,
          hour:
            11 +
            (
              index %
              10
            )
        }
      );

  const experience =
    buildExperience(
      closed,
      rng
    );

  const result =
    customerEngine
      .postVisit(
        row.profile,
        visit,
        {
          id:
            shop.id
        },
        experience,
        rng
      );

  row.visits +=
    1;

  row.lastVisitDay =
    day;

  row.totalSpend +=
    experience
      .paidPerPerson;

  row.avgSatisfaction =
    row.visits ===
      1
      ? result
          .experience
          .overall
      : (
          row
            .avgSatisfaction *
            (
              row.visits -
              1
            ) +
          result
            .experience
            .overall
        ) /
        row.visits;

  row.repeatProbability =
    result
      .repeatProbability;

  row.favorite =
    !!result.favorite;

  row.disliked =
    !!result.disliked;

  row.wordOfMouth =
    Number(
      result.wordOfMouth
    ) ||
    0;

  if (
    state
      .membershipEnabled &&
    row.visits >=
      3 &&
    row.avgSatisfaction >=
      68
  ) {
    row.member =
      true;
  }

  if (
    result.willReview
  ) {
    row.reviewCount +=
      1;

    row.lastReviewStars =
      result.reviewStars;

    state.reviews.unshift({
      id:
        'review_' +
        day +
        '_' +
        row.id +
        '_' +
        row.reviewCount,
      day,
      customerId:
        row.id,
      segmentId:
        row.profile
          .segmentId,
      stars:
        result.reviewStars,
      satisfaction:
        Math.round(
          result
            .experience
            .overall
        ),
      wordOfMouth:
        Number(
          result.wordOfMouth
        ) ||
        0
    });

    state.reviews =
      state.reviews
        .slice(
          0,
          120
        );
  }

  if (
    row.disliked &&
    row.visits >=
      2
  ) {
    row.churned =
      true;
  }

  return result;
}

function ageProfiles(
  state,
  day
) {
  for (
    const row
    of Object.values(
      state.profiles
    )
  ) {
    if (
      row.churned ||
      row.lastVisitDay ==
        null
    ) {
      continue;
    }

    const daysAway =
      day -
      Number(
        row.lastVisitDay
      );

    if (
      daysAway >=
        60 &&
      Number(
        row.repeatProbability
      ) <
        0.48
    ) {
      row.churned =
        true;
    }
  }
}

function rebuildStats(
  state
) {
  const rows =
    Object.values(
      state.profiles
    );

  const active =
    rows.filter(
      row =>
        !row.churned
    );

  const members =
    active.filter(
      row =>
        row.member
    );

  const favorites =
    active.filter(
      row =>
        row.favorite
    );

  const totalVisits =
    rows.reduce(
      (
        sum,
        row
      ) =>
        sum +
        (
          Number(
            row.visits
          ) ||
          0
        ),
      0
    );

  const repeatVisits =
    rows.reduce(
      (
        sum,
        row
      ) =>
        sum +
        Math.max(
          0,
          (
            Number(
              row.visits
            ) ||
            0
          ) -
          1
        ),
      0
    );

  const repeatRate =
    totalVisits >
      0
      ? repeatVisits /
        totalVisits
      : 0;

  const avgSatisfaction =
    active.length
      ? active.reduce(
          (
            sum,
            row
          ) =>
            sum +
            (
              Number(
                row.avgSatisfaction
              ) ||
              0
            ),
          0
        ) /
        active.length
      : 0;

  const reviewCount =
    state.reviews
      .length;

  const avgRating =
    reviewCount
      ? state.reviews
          .reduce(
            (
              sum,
              row
            ) =>
              sum +
              (
                Number(
                  row.stars
                ) ||
                0
              ),
            0
          ) /
          reviewCount
      : 0;

  const wordOfMouth =
    active.length
      ? active.reduce(
          (
            sum,
            row
          ) =>
            sum +
            (
              Number(
                row.wordOfMouth
              ) ||
              0
            ),
          0
        ) /
        active.length
      : 0;

  const memberShare =
    active.length
      ? members.length /
        active.length
      : 0;

  let demandMultiplier =
    1;

  if (
    rows.length >
    0
  ) {
    demandMultiplier =
      clamp(
        0.91 +
        repeatRate *
          0.18 +
        memberShare *
          0.08 +
        wordOfMouth *
          0.10 +
        (
          avgRating
            ? (
                avgRating -
                3
              ) *
              0.035
            : 0
        ),
        0.78,
        1.20
      );
  }

  state.stats = {
    knownCustomers:
      rows.length,
    activeCustomers:
      active.length,
    members:
      members.length,
    favorites:
      favorites.length,
    churned:
      rows.length -
      active.length,
    repeatRate:
      Math.round(
        repeatRate *
        1000
      ) /
      10,
    avgSatisfaction:
      Math.round(
        avgSatisfaction *
        10
      ) /
      10,
    reviewCount,
    avgRating:
      Math.round(
        avgRating *
        100
      ) /
      100,
    wordOfMouth:
      Math.round(
        wordOfMouth *
        1000
      ) /
      1000,
    demandMultiplier:
      Math.round(
        demandMultiplier *
        1000
      ) /
      1000
  };

  return state.stats;
}

function pruneProfiles(
  state
) {
  const rows =
    Object.values(
      state.profiles
    );

  if (
    rows.length <=
    240
  ) {
    return;
  }

  const removable =
    rows
      .filter(
        row =>
          row.churned &&
          !row.member &&
          !row.favorite
      )
      .sort(
        (
          a,
          b
        ) =>
          (
            Number(
              a.lastVisitDay
            ) ||
            -1
          ) -
          (
            Number(
              b.lastVisitDay
            ) ||
            -1
          )
      );

  while (
    Object.keys(
      state.profiles
    ).length >
      240 &&
    removable.length
  ) {
    const row =
      removable.shift();

    delete state
      .profiles[
        row.id
      ];
  }
}

function onDayClosed(
  shop,
  runtime,
  closed
) {
  if (
    !shop ||
    !closed
  ) {
    return null;
  }

  const state =
    ensureShop(
      shop.id
    );

  const day =
    Number(
      closed.day
    ) ||
    0;

  if (
    state.lastProcessedDay ===
      day
  ) {
    return getDashboard(
      shop.id
    );
  }

  ageProfiles(
    state,
    day
  );

  const financial =
    closed.financial ||
    {};

  const customers =
    Math.max(
      0,
      Math.round(
        Number(
          financial.customers
        ) ||
        0
      )
    );

  const sampleCount =
    customers >
      0
      ? Math.min(
          16,
          Math.max(
            1,
            Math.ceil(
              customers /
              9
            )
          )
        )
      : 0;

  const rng =
    new SeededRng(
      seedFor(
        shop.id,
        day,
        'day'
      )
    );

  let returningSamples =
    0;

  let newSamples =
    0;

  for (
    let i = 0;
    i < sampleCount;
    i++
  ) {
    const stats =
      rebuildStats(
        state
      );

    const preferredReturn =
      clamp(
        0.30 +
        (
          stats.repeatRate /
          100
        ) *
          0.40 +
        (
          stats.members /
          Math.max(
            1,
            stats.activeCustomers
          )
        ) *
          0.18,
        0.25,
        0.76
      );

    let row =
      rng.next() <
        preferredReturn
        ? pickReturning(
            state,
            rng
          )
        : null;

    if (row) {
      returningSamples +=
        1;
    } else {
      row =
        createPersistentCustomer(
          shop,
          state,
          day,
          i
        );

      newSamples +=
        1;
    }

    const result =
      processCustomerVisit(
        shop,
        state,
        row,
        closed,
        day,
        i
      );

    if (
      runtime &&
      runtime.customers &&
      row.profile
    ) {
      runtime.customers[
        row.profile.id
      ] =
        row.profile;
    }

    if (
      result &&
      result.favorite
    ) {
      row.favorite =
        true;
    }
  }

  pruneProfiles(
    state
  );

  const stats =
    rebuildStats(
      state
    );

  state.dailyHistory.unshift({
    day,
    customers,
    sampleCount,
    returningSamples,
    newSamples,
    repeatRate:
      stats.repeatRate,
    avgRating:
      stats.avgRating,
    wordOfMouth:
      stats.wordOfMouth,
    demandMultiplier:
      stats.demandMultiplier
  });

  state.dailyHistory =
    state.dailyHistory
      .slice(
        0,
        60
      );

  state.lastProcessedDay =
    day;

  return getDashboard(
    shop.id
  );
}

function setMembershipEnabled(
  shopId,
  enabled
) {
  const state =
    ensureShop(
      shopId
    );

  state.membershipEnabled =
    !!enabled;

  if (
    state.membershipEnabled
  ) {
    for (
      const row
      of Object.values(
        state.profiles
      )
    ) {
      if (
        !row.churned &&
        row.visits >=
          3 &&
        row.avgSatisfaction >=
          68
      ) {
        row.member =
          true;
      }
    }
  }

  rebuildStats(
    state
  );

  return {
    ok:true,
    enabled:
      state.membershipEnabled
  };
}

function toggleMembership(
  shopId
) {
  const state =
    ensureShop(
      shopId
    );

  return setMembershipEnabled(
    shopId,
    !state.membershipEnabled
  );
}

function getDemandMultiplier(
  shopId
) {
  const state =
    ensureShop(
      shopId
    );

  return Number(
    rebuildStats(
      state
    ).demandMultiplier
  ) || 1;
}

function segmentSummary(
  state
) {
  const result = {};

  for (
    const row
    of Object.values(
      state.profiles
    )
  ) {
    const id =
      row.profile &&
      row.profile
        .segmentId ||
      'unknown';

    if (
      !result[
        id
      ]
    ) {
      result[
        id
      ] = {
        segmentId:id,
        known:0,
        active:0,
        visits:0
      };
    }

    result[
      id
    ].known +=
      1;

    if (
      !row.churned
    ) {
      result[
        id
      ].active +=
        1;
    }

    result[
      id
    ].visits +=
      Number(
        row.visits
      ) ||
      0;
  }

  return Object
    .values(
      result
    )
    .sort(
      (
        a,
        b
      ) =>
        b.visits -
        a.visits
    )
    .slice(
      0,
      5
    );
}

function getDashboard(
  shopId
) {
  const state =
    ensureShop(
      shopId
    );

  const stats =
    rebuildStats(
      state
    );

  const topCustomers =
    Object
      .values(
        state.profiles
      )
      .filter(
        row =>
          !row.churned
      )
      .sort(
        (
          a,
          b
        ) =>
          (
            Number(
              b.visits
            ) ||
            0
          ) -
          (
            Number(
              a.visits
            ) ||
            0
          )
      )
      .slice(
        0,
        5
      )
      .map(
        row => ({
          id:
            row.id,
          segmentId:
            row.profile
              .segmentId,
          visits:
            row.visits,
          member:
            row.member,
          favorite:
            row.favorite,
          satisfaction:
            Math.round(
              row
                .avgSatisfaction
            ),
          repeatProbability:
            Math.round(
              (
                Number(
                  row.repeatProbability
                ) ||
                0
              ) *
              100
            )
        })
      );

  const shop =
    getShop(
      shopId
    );

  return {
    shopId,
    shopName:
      shop &&
      shop.name ||
      '门店',
    membershipEnabled:
      state.membershipEnabled,
    stats:
      clone(
        stats
      ),
    recentReviews:
      clone(
        state.reviews
          .slice(
            0,
            6
          )
      ),
    segments:
      segmentSummary(
        state
      ),
    topCustomers,
    dailyHistory:
      clone(
        state.dailyHistory
          .slice(
            0,
            14
          )
      )
  };
}

module.exports = {
  getRoot,
  ensureShop,
  createPersistentCustomer,
  processCustomerVisit,
  ageProfiles,
  rebuildStats,
  onDayClosed,
  setMembershipEnabled,
  toggleMembership,
  getDemandMultiplier,
  getDashboard
};
