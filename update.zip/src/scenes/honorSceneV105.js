'use strict';

const DataSceneBase = require('./dataSceneBase.js');
const sceneManager = require('../core/sceneManager.js');
const gameState = require('../core/gameState.js');
const citySystem = require('../city/citySystem.js');
const demandSystem = require('../city/demandSystem.js');
const prestige = require('../reputation/restaurantPrestigeSystemV105.js');
const ui = require('../ui/dataWidgets.js');

class HonorSceneV105 extends DataSceneBase {
  constructor() { super('honors'); }
  context() { return { gameState, citySystem, demandSystem }; }

  render(ctx) {
    if (!ctx) return;
    this.begin(ctx);
    const report = prestige.sync(this.context());
    const player = gameState.getPlayer();
    ui.header(ctx, '荣誉与金牌店铺', '认证会复审，奖项永久进入门店履历', 390, ui.money(player.cash));

    if (!report.shop) {
      ui.rect(ctx, 14, 92, 362, 160, { fill:ui.COLORS.panel, stroke:ui.COLORS.line });
      ui.text(ctx, '开店后才会进入行业评价体系', 195, 160, 10, ui.COLORS.muted, '700', 'center');
      this.end(ctx);
      return;
    }

    ui.rect(ctx, 10, 82, 370, 92, { fill:ui.COLORS.paleGold, stroke:'#E0BE70' });
    ui.text(ctx, report.certificationLabel, 24, 108, 14, ui.COLORS.navy, '800');
    ui.text(ctx, '经营评级 ' + report.dimensions.grade + ' ' + ui.number(report.dimensions.operating, 1) + ' · 行业综合 ' + ui.number(report.dimensions.overall, 1), 24, 137, 7.0, ui.COLORS.text, '700');
    ui.progress(ctx, 24, 154, 210, Math.min(1, (report.certification.progressDays || 0) / 30), { fill:ui.COLORS.gold, height:8 });
    ui.text(ctx, '金牌稳定期 ' + (report.certification.progressDays || 0) + '/30天', 365, 158, 6.6, ui.COLORS.muted, '600', 'right');

    ui.sectionTitle(ctx, '六维评分', 194, '评分不是单纯看营业额', 390);
    const dims = [
      ['菜品', report.dimensions.dishQuality], ['服务', report.dimensions.service], ['环境', report.dimensions.environment],
      ['卫生', report.dimensions.hygiene], ['性价比', report.dimensions.value], ['等位', report.dimensions.waiting]
    ];
    dims.forEach((d, i) => {
      const col = i % 3;
      const row = Math.floor(i / 3);
      const x = 10 + col * 127;
      const y = 210 + row * 78;
      ui.metricCard(ctx, x, y, 116, 68, d[0], ui.number(d[1], 1), d[1] >= 85 ? '优秀' : d[1] >= 70 ? '良好' : '需提升', { valueColor:d[1] >= 85 ? ui.COLORS.green : d[1] < 60 ? ui.COLORS.red : ui.COLORS.text });
    });

    ui.sectionTitle(ctx, '评审进度', 382, '', 390);
    ui.rect(ctx, 10, 398, 370, 64, { fill:ui.COLORS.panel, stroke:ui.COLORS.line });
    ui.text(ctx, report.nextTarget, 24, 423, 6.7, ui.COLORS.text, '600');
    ui.text(ctx, '季度通过 ' + (report.certification.reviewPasses || 0) + ' 次 · 失败 ' + (report.certification.reviewFails || 0) + ' 次', 24, 447, 6.4, ui.COLORS.muted, '600');

    ui.sectionTitle(ctx, '最近荣誉', 488, '共 ' + report.awards.length + ' 项', 390);
    const awards = report.recentAwards.slice(0, 4);
    if (!awards.length) {
      ui.rect(ctx, 10, 504, 370, 66, { fill:ui.COLORS.panel, stroke:ui.COLORS.line });
      ui.text(ctx, '还没有正式奖项，先从城市十强、潜力新星和金牌候选开始。', 24, 537, 6.8, ui.COLORS.muted, '600');
    } else {
      awards.forEach((a, i) => {
        const y = 514 + i * 33;
        ui.text(ctx, '★ ' + a.name, 20, y, 7.4, ui.COLORS.text, '700');
        ui.text(ctx, a.year + '年' + a.month + '月', 365, y, 6.3, ui.COLORS.muted, '600', 'right');
      });
    }

    const y = Math.min(this.contentBottom - 45, 638);
    ui.rect(ctx, 10, y, 178, 36, { radius:10, fill:'#EEE7DC', stroke:ui.COLORS.line });
    ui.text(ctx, '‹ 更多管理', 99, y + 18, 7.5, ui.COLORS.navy, '700', 'center');
    this.addButton('go:more', 10, y, 178, 36);
    ui.rect(ctx, 202, y, 178, 36, { radius:10, fill:ui.COLORS.navy, stroke:'#315D75' });
    ui.text(ctx, '查看排行榜', 291, y + 18, 7.5, ui.COLORS.white, '700', 'center');
    this.addButton('go:ranking', 202, y, 178, 36);
    this.end(ctx);
  }

  handleTap(x, y) {
    const hit = this.handleBaseTap(x, y);
    if (hit === true) return true;
    if (!hit || !hit.id) return false;
    if (hit.id === 'go:more') return sceneManager.switchTo('more');
    if (hit.id === 'go:ranking') return sceneManager.switchTo('ranking');
    return false;
  }
}

module.exports = new HonorSceneV105();
