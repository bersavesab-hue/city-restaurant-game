'use strict';

const runtime =
  globalThis.GameRuntime;

if (!runtime) {
  throw new Error(
    'StoreScene：GameRuntime 未初始化'
  );
}

const api =
  runtime.api || {};

const gameState =
  require('../core/gameState.js');

const citySystem =
  require('../city/citySystem.js');

const sceneManager =
  require('../core/sceneManager.js');

const renovationSystem =
  require('../renovation/renovationSystem.js');

const customizationSystem =
  require('../ui/customizationSystem.js');

const textInput =
  require('../ui/textInput.js');

const visualAssetSystem =
  require('../ui/visualAssetSystem.js');

const ui =
  require('../ui/premiumUi.js');

const DESIGN_W =
  390;

const COLORS = {
  navy:
    '#07344B',
  navy2:
    '#082A3D',
  paper:
    '#F7EEDD',
  panel:
    'rgba(255,252,246,0.96)',
  text:
    '#14334A',
  muted:
    '#6A7B82',
  gold:
    '#F3B12B',
  orange:
    '#E98827',
  red:
    '#D04D45',
  green:
    '#269D67',
  blue:
    '#2D8EB6',
  white:
    '#FFFFFF'
};

function money(value) {
  return (
    '¥' +
    Math.max(
      0,
      Math.round(
        Number(value) ||
        0
      )
    ).toLocaleString()
  );
}

class StoreScene {
  constructor() {
    this.id =
      'shop';

    this.viewH =
      780;

    this.navH =
      64;

    this.contentBottom =
      716;

    this.buttons =
      [];
  }

  getLayout() {
    let height =
      780;

    if (
      api &&
      typeof api
        .getSystemInfoSync ===
        'function'
    ) {
      const info =
        api
          .getSystemInfoSync();

      const w =
        Math.max(
          1,
          Number(
            info.windowWidth
          ) ||
          DESIGN_W
        );

      const h =
        Math.max(
          1,
          Number(
            info.windowHeight
          ) ||
          780
        );

      height =
        h /
        (
          w /
          DESIGN_W
        );
    }

    this.viewH =
      height;

    this.navH =
      height <
        740
        ? 60
        : 64;

    this.contentBottom =
      height -
      this.navH;
  }

  enter() {
    visualAssetSystem
      .loadGroup(
        'premiumStore'
      );
  }

  exit() {
    this.buttons =
      [];
  }

  update() {
    const shop =
      this.getCurrentShop();

    if (shop) {
      renovationSystem
        .updateShop(
          shop.id
        );
    }
  }

  addButton(
    id,
    x,
    y,
    w,
    h
  ) {
    this.buttons.push({
      id,
      x,
      y,
      w,
      h
    });
  }

  hitButton(
    x,
    y
  ) {
    for (
      let i =
        this.buttons.length -
        1;
      i >= 0;
      i--
    ) {
      const b =
        this.buttons[i];

      if (
        x >= b.x &&
        x <= b.x + b.w &&
        y >= b.y &&
        y <= b.y + b.h
      ) {
        return b;
      }
    }

    return null;
  }

  getCurrentShop() {
    const business =
      gameState
        .getBusiness();

    if (
      !business.hasShop ||
      !business.shops.length
    ) {
      return null;
    }

    return (
      business.shops.find(
        item =>
          item.id ===
          business.currentShopId
      ) ||
      business.shops[0]
    );
  }

  getRooms(shopId) {
    const plan =
      renovationSystem
        .ensurePlan(
          shopId
        );

    if (!plan) {
      return [];
    }

    const rooms =
      [];

    for (
      const floor of
      plan.floors
    ) {
      for (
        const room of
        floor.privateRooms
      ) {
        rooms.push(room);
      }
    }

    return rooms;
  }

  drawHeader(
    ctx,
    shop
  ) {
    const district =
      shop
        ? citySystem
            .getDistrict(
              shop.districtId
            )
        : null;

    const gradient =
      ctx.createLinearGradient(
        0,
        0,
        390,
        0
      );

    gradient.addColorStop(
      0,
      COLORS.navy2
    );
    gradient.addColorStop(
      1,
      '#0E526D'
    );

    ctx.fillStyle =
      gradient;

    ctx.fillRect(
      0,
      0,
      390,
      73
    );

    ui.text(
      ctx,
      shop
        ? (
            shop.name ||
            '我的酒楼'
          )
        : '门店筹备',
      15,
      21,
      16,
      COLORS.white,
      '800'
    );

    ui.text(
      ctx,
      shop
        ? (
            (
              district
                ? district.name
                : '经营区域'
            ) +
            ' · ' +
            shop.address
          )
        : '从选址到开业，打造自己的餐饮品牌',
      15,
      47,
      7.2,
      '#CFE0E7',
      '500'
    );

    ui.text(
      ctx,
      money(
        gameState
          .getPlayer()
          .cash
      ),
      376,
      21,
      13,
      '#FFE6A3',
      '800',
      'right'
    );

    ui.text(
      ctx,
      '可用资金',
      376,
      46,
      6.5,
      '#CFE0E7',
      '500',
      'right'
    );
  }

  drawProgress(
    ctx,
    active
  ) {
    ui.card(
      ctx,
      9,
      362,
      372,
      91,
      {
        radius:
          14
      }
    );

    ui.text(
      ctx,
      '开店进度',
      21,
      382,
      10,
      COLORS.text,
      '800'
    );

    const labels = [
      '选址',
      '签约',
      '装修',
      '证照',
      '招聘',
      '开业'
    ];

    const startX =
      36;

    const gap =
      62;

    for (
      let i = 0;
      i < 6;
      i++
    ) {
      const x =
        startX +
        i *
        gap;

      if (
        i <
        5
      ) {
        ctx.fillStyle =
          i <
            active - 1
            ? '#38A56F'
            : '#D7D0C5';

        ctx.fillRect(
          x + 14,
          412,
          gap - 28,
          3
        );
      }

      const done =
        i <
        active - 1;

      const current =
        i ===
        active - 1;

      ctx.beginPath();
      ctx.arc(
        x,
        413,
        12,
        0,
        Math.PI *
        2
      );

      ctx.fillStyle =
        done
          ? '#38A56F'
          : current
            ? COLORS.gold
            : '#E4DED4';

      ctx.fill();

      ui.text(
        ctx,
        done
          ? '✓'
          : String(
              i + 1
            ),
        x,
        413,
        8,
        done
          ? COLORS.white
          : COLORS.text,
        '800',
        'center'
      );

      ui.text(
        ctx,
        labels[i],
        x,
        440,
        6.5,
        COLORS.text,
        '700',
        'center'
      );
    }
  }

  drawRoomStrip(
    ctx,
    shop
  ) {
    const rooms =
      this.getRooms(
        shop.id
      );

    ui.card(
      ctx,
      9,
      230,
      372,
      120,
      {
        radius:
          14
      }
    );

    ui.text(
      ctx,
      '包厢',
      20,
      249,
      10,
      COLORS.text,
      '800'
    );

    ui.text(
      ctx,
      rooms.length
        ? '名称和风格均可在装修页自定义'
        : '新增包厢后会在这里展示',
      59,
      249,
      6.5,
      COLORS.muted,
      '500'
    );

    const images = [
      'premium_room_1',
      'premium_room_2',
      'premium_room_3'
    ];

    for (
      let i = 0;
      i < 3;
      i++
    ) {
      const x =
        18 +
        i *
        112;

      ui.card(
        ctx,
        x,
        263,
        104,
        72,
        {
          radius:
            10,
          fill:
            '#F6F1E8',
          shadow:
            false
        }
      );

      ui.coverImage(
        ctx,
        visualAssetSystem
          .get(
            images[i]
          ),
        x,
        263,
        104,
        51,
        9,
        null
      );

      const name =
        rooms[i]
          ? (
              rooms[i].name ||
              (
                '包厢' +
                (
                  i + 1
                )
              )
            )
          : (
              i <
              2
                ? '待规划'
                : '+ 新增包厢'
            );

      ui.text(
        ctx,
        name,
        x + 7,
        325,
        6.8,
        rooms[i]
          ? COLORS.text
          : COLORS.muted,
        '700'
      );
    }

    this.addButton(
      'module:renovation',
      14,
      258,
      344,
      82
    );
  }

  renderNoShop(
    ctx
  ) {
    this.drawHeader(
      ctx,
      null
    );

    ui.card(
      ctx,
      10,
      88,
      370,
      246,
      {
        radius:
          18
      }
    );

    ui.coverImage(
      ctx,
      visualAssetSystem
        .get(
          'premium_explore_banner'
        ),
      20,
      99,
      350,
      118,
      14,
      'rgba(4,31,46,0.22)'
    );

    ui.text(
      ctx,
      '还没有自己的门店',
      28,
      239,
      15,
      COLORS.text,
      '800'
    );

    ui.text(
      ctx,
      '先选商圈，再看铺、谈判、签约。',
      28,
      268,
      8,
      COLORS.muted,
      '600'
    );

    ui.card(
      ctx,
      28,
      286,
      334,
      37,
      {
        radius:
          18,
        fill:
          '#F6B428',
        stroke:
          '#E6A01B',
        shadow:
          false
      }
    );

    ui.text(
      ctx,
      '去城市地图选择经营区域  ›',
      195,
      304.5,
      8.5,
      COLORS.text,
      '800',
      'center'
    );

    this.addButton(
      'go-city',
      24,
      282,
      342,
      45
    );

    ui.card(
      ctx,
      10,
      350,
      370,
      152,
      {
        radius:
          16
      }
    );

    ui.text(
      ctx,
      '开店流程',
      22,
      373,
      10,
      COLORS.text,
      '800'
    );

    const steps = [
      '① 查看商圈人口、消费人群和需求',
      '② 进入房源市场并实地看铺',
      '③ 谈判租金、转让费和免租期',
      '④ 签约后进入装修与开业筹备'
    ];

    for (
      let i = 0;
      i < steps.length;
      i++
    ) {
      ui.text(
        ctx,
        steps[i],
        24,
        405 +
          i *
          25,
        7.2,
        i === 0
          ? COLORS.orange
          : COLORS.text,
        i === 0
          ? '700'
          : '600'
      );
    }
  }

  renderShop(
    ctx,
    shop
  ) {
    this.drawHeader(
      ctx,
      shop
    );

    const plan =
      renovationSystem
        .ensurePlan(
          shop.id
        );

    ui.card(
      ctx,
      9,
      87,
      372,
      132,
      {
        radius:
          17
      }
    );

    ui.coverImage(
      ctx,
      visualAssetSystem
        .get(
          'premium_store_hero'
        ),
      217,
      95,
      154,
      116,
      13,
      null
    );

    ctx.fillStyle =
      'rgba(34,24,18,0.62)';
    ctx.fillRect(
      265,
      108,
      92,
      26
    );

    ui.text(
      ctx,
      shop.name ||
        '我的酒楼',
      311,
      121,
      7.2,
      '#FFE8B0',
      '800',
      'center'
    );

    const status =
      shop.status ===
        'renovating'
        ? '装修中'
        : plan &&
            plan.status ===
              'completed'
          ? '装修完成'
          : '已签约';

    ui.pill(
      ctx,
      '✓ ' +
        status,
      20,
      101,
      72,
      25,
      '#FFF0C1',
      '#B36B1E'
    );

    ui.text(
      ctx,
      shop.name ||
        shop.address,
      20,
      151,
      17,
      COLORS.text,
      '800'
    );

    ui.text(
      ctx,
      shop.address,
      20,
      177,
      7,
      COLORS.muted,
      '600'
    );

    ui.card(
      ctx,
      20,
      189,
      78,
      24,
      {
        radius:
          12,
        fill:
          '#FFF5D8',
        stroke:
          '#E8C36C',
        shadow:
          false
      }
    );

    ui.text(
      ctx,
      '✎ 改名',
      59,
      201,
      7,
      COLORS.orange,
      '800',
      'center'
    );

    this.addButton(
      'shop:rename',
      16,
      185,
      86,
      32
    );

    this.drawRoomStrip(
      ctx,
      shop
    );

    let active =
      2;

    if (
      shop.status ===
      'renovating'
    ) {
      active =
        3;
    } else if (
      plan &&
      plan.status ===
        'completed'
    ) {
      active =
        4;
    }

    this.drawProgress(
      ctx,
      active
    );

    ui.card(
      ctx,
      9,
      466,
      372,
      152,
      {
        radius:
          15
      }
    );

    ui.text(
      ctx,
      '下一步建议',
      20,
      486,
      11,
      COLORS.text,
      '800'
    );

    const cards = [
      {
        id:
          'renovation',
        key:
          'premium_advice_renovation',
        title:
          '开始店面装修',
        sub:
          '布局、包厢与风格',
        action:
          '去装修'
      },
      {
        id:
          'license',
        key:
          'premium_advice_permit',
        title:
          '办理营业证照',
        sub:
          '经营、消防、食品',
        action:
          '去办证'
      },
      {
        id:
          'staff',
        key:
          'premium_advice_staff',
        title:
          '招聘经营团队',
        sub:
          '店长、厨师、服务',
        action:
          '去招聘'
      }
    ];

    for (
      let i = 0;
      i <
      cards.length;
      i++
    ) {
      const item =
        cards[i];

      const x =
        18 +
        i *
        119;

      ui.card(
        ctx,
        x,
        503,
        111,
        102,
        {
          radius:
            11,
          fill:
            '#FFFBF4',
          shadow:
            false
        }
      );

      ui.coverImage(
        ctx,
        visualAssetSystem
          .get(
            item.key
          ),
        x + 5,
        508,
        42,
        50,
        8,
        null
      );

      ui.text(
        ctx,
        item.title,
        x + 52,
        519,
        6.7,
        COLORS.text,
        '800'
      );

      ui.text(
        ctx,
        item.sub,
        x + 52,
        537,
        5.8,
        COLORS.muted,
        '500'
      );

      ui.card(
        ctx,
        x + 12,
        568,
        87,
        26,
        {
          radius:
            13,
          fill:
            '#F7B628',
          stroke:
            '#E3A21B',
          shadow:
            false
        }
      );

      ui.text(
        ctx,
        item.action +
          ' ›',
        x + 55.5,
        581,
        6.5,
        COLORS.text,
        '800',
        'center'
      );

      this.addButton(
        'module:' +
          item.id,
        x + 6,
        562,
        99,
        38
      );
    }

    if (
      this.contentBottom >
      684
    ) {
      const bannerY =
        Math.min(
          628,
          this.contentBottom -
            71
        );

      ui.coverImage(
        ctx,
        visualAssetSystem
          .get(
            'premium_explore_banner'
        ),
        10,
        bannerY,
        370,
        60,
        13,
        'rgba(4,32,48,0.45)'
      );

      ui.text(
        ctx,
        '探索更多优质商圈',
        28,
        bannerY + 21,
        10,
        COLORS.white,
        '800'
      );

      ui.text(
        ctx,
        '为下一家门店寻找黄金地段',
        28,
        bannerY + 42,
        6.5,
        '#E6F0F4',
        '500'
      );

      ui.card(
        ctx,
        283,
        bannerY + 14,
        78,
        32,
        {
          radius:
            16,
          fill:
            '#F7B628',
          stroke:
            '#E3A21B',
          shadow:
            false
        }
      );

      ui.text(
        ctx,
        '去拓展 ›',
        322,
        bannerY + 30,
        7,
        COLORS.text,
        '800',
        'center'
      );

      this.addButton(
        'go-city',
        278,
        bannerY + 8,
        90,
        44
      );
    }
  }

  render(ctx) {
    if (!ctx) {
      return;
    }

    this.getLayout();

    this.buttons =
      [];

    ctx.save();

    ctx.fillStyle =
      COLORS.paper;

    ctx.fillRect(
      0,
      0,
      DESIGN_W,
      this.viewH
    );

    const shop =
      this.getCurrentShop();

    if (shop) {
      this.renderShop(
        ctx,
        shop
      );
    } else {
      this.renderNoShop(
        ctx
      );
    }

    ctx.restore();
  }

  handleTap(
    x,
    y
  ) {
    const item =
      this.hitButton(
        x,
        y
      );

    if (!item) {
      return false;
    }

    if (
      item.id ===
      'go-city'
    ) {
      sceneManager
        .switchTo(
          'city'
        );

      return true;
    }

    if (
      item.id ===
      'shop:rename'
    ) {
      const shop =
        this.getCurrentShop();

      if (!shop) {
        return true;
      }

      textInput
        .requestText({
          title:
            '修改酒楼名称',
          value:
            shop.name ||
            '',
          placeholder:
            '请输入酒楼名称',
          maxLength:
            12
        })
        .then(
          value => {
            if (!value) {
              return;
            }

            customizationSystem
              .renameShop(
                shop.id,
                value
              );

            textInput
              .requestRender();
          }
        );

      return true;
    }

    if (
      item.id.indexOf(
        'module:'
      ) ===
      0
    ) {
      const moduleId =
        item.id.split(
          ':'
        )[1];

      const shop =
        this.getCurrentShop();

      if (!shop) {
        return true;
      }

      if (
        moduleId ===
        'renovation'
      ) {
        sceneManager
          .switchTo(
            'renovation',
            {
              shopId:
                shop.id
            }
          );

        return true;
      }

      if (
        api &&
        typeof api.showToast ===
          'function'
      ) {
        const names = {
          license:
            '证照办理',
          staff:
            '招聘团队'
        };

        api.showToast({
          title:
            (
              names[
                moduleId
              ] ||
              '筹备模块'
            ) +
            '将在下一阶段接入',
          icon:
            'none'
        });
      }

      return true;
    }

    return false;
  }
}

module.exports =
  new StoreScene();
