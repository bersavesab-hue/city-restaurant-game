'use strict';

const runtime = globalThis.GameRuntime;
if (!runtime) throw new Error('ResearchScene V0.8.5：GameRuntime 未初始化');

const operations = require('../operations/operationsStoreV080.js');
const saveSystem = require('../core/saveSystem.js');
const prestige = require('../reputation/culinaryPrestigeSystemV085.js');
const ui = require('../ui/premiumUi.js');
const opUi = require('../ui/operationsUiV080.js');

const TABS = [
  {id:'menu',name:'菜单'},
  {id:'research',name:'研发'},
  {id:'improve',name:'改良'},
  {id:'rating',name:'评分'},
  {id:'awards',name:'奖项'}
];

function num(v,f=0){const n=Number(v);return Number.isFinite(n)?n:f;}
function priceOf(item){return num(item&&item.listPrice,num(item&&item.price,0));}
function pct(v){return Math.max(0,Math.min(100,num(v)));}
function metricTone(v){return v>=82?'#248B63':v>=70?'#D29A18':v>=58?'#D78A22':'#C85242';}
function nameOf(row,i){return String(row&&row.name||row&&row.title||row&&row.recipeName||('菜品 '+(i+1)));}

class CulinaryLabSceneV085 {
  constructor(){this.id='research';this.tab='menu';this.buttons=[];this.selectedMenuId=null;this.menuPage=0;this.researchPage=0;}
  enter(payload){if(payload&&TABS.some(x=>x.id===payload.tab))this.tab=payload.tab;this.buttons=[];this.ensureSelection();}
  exit(){this.buttons=[];}
  update(){}
  addButton(id,x,y,w,h){this.buttons.push({id,x,y,w,h});}
  hit(x,y){for(let i=this.buttons.length-1;i>=0;i--){const b=this.buttons[i];if(x>=b.x&&x<=b.x+b.w&&y>=b.y&&y<=b.y+b.h)return b;}return null;}
  shop(){return operations.getCurrentShop();}
  runtime(shop){return shop?operations.getRuntime(shop.id):null;}
  ensureSelection(){const shop=this.shop();const rt=this.runtime(shop);const menu=rt&&Array.isArray(rt.menu)?rt.menu:[];if(!menu.length){this.selectedMenuId=null;return;}if(!menu.some(x=>x.id===this.selectedMenuId))this.selectedMenuId=menu[0].id;}
  selected(rt){return rt&&Array.isArray(rt.menu)?rt.menu.find(x=>x.id===this.selectedMenuId)||rt.menu[0]||null:null;}
  snapshot(shop,rt){if(!shop||!rt)return null;if(typeof operations.culinaryPrestigeSnapshot==='function')return operations.culinaryPrestigeSnapshot(shop.id);const costs={};for(const item of rt.menu||[])costs[item.id]=operations.estimateMenuItemCost(shop.id,item);return prestige.overview(shop.id,rt,{costByItem:costs});}
  header(ctx,title,sub){opUi.header(ctx,title,sub);const gap=5;const w=(390-28-gap*(TABS.length-1))/TABS.length;for(let i=0;i<TABS.length;i++){const t=TABS[i],x=14+i*(w+gap);opUi.pill(ctx,t.name,x,94,w,this.tab===t.id);this.addButton('tab:'+t.id,x,92,w,34);}}
  card(ctx,x,y,w,h,title){ui.card(ctx,x,y,w,h,{radius:14,fill:'#FFFDF8',stroke:'#DDD4C7',shadow:false});if(title)ui.text(ctx,title,x+14,y+20,8,'#173D54','800');}
  miniBar(ctx,label,value,x,y,w=160){ui.text(ctx,label,x,y,6.8,'#71858F','700');ui.text(ctx,Math.round(value)+'',x+w,y,6.8,metricTone(value),'800','right');ctx.fillStyle='#E7E1D7';ctx.fillRect(x,y+8,w,5);ctx.fillStyle=metricTone(value);ctx.fillRect(x,y+8,w*pct(value)/100,5);}
  renderNoShop(ctx){ui.text(ctx,'开店后才能进行菜品研发与评分',195,235,11,'#6F838E','800','center');ui.text(ctx,'菜品研发、改良、评分、榜单和奖项都会与真实经营数据联动。',195,265,7.2,'#78909B','600','center');}
  renderMenu(ctx,shop,rt,snap){const menu=rt.menu||[];const pageSize=4;const pages=Math.max(1,Math.ceil(menu.length/pageSize));this.menuPage=Math.max(0,Math.min(this.menuPage,pages-1));const rows=menu.slice(this.menuPage*pageSize,this.menuPage*pageSize+pageSize);this.card(ctx,14,138,362,420,'在售菜单 · 点击菜品进入改良');let y=177;for(const item of rows){const d=(snap.dishes||[]).find(x=>x.id===item.id);const selected=item.id===this.selectedMenuId;ui.card(ctx,22,y-16,346,72,{radius:11,fill:selected?'#FFF4C8':'#FFFFFF',stroke:selected?'#E5B64D':'#E4DED4',shadow:false});ui.text(ctx,item.featured?'★ '+item.name:item.name,32,y+2,8.2,'#173D54','800');ui.text(ctx,(item.active===false?'已停售':'在售')+' · 售价 ¥'+priceOf(item).toFixed(1)+' · 成本约 ¥'+operations.estimateMenuItemCost(shop.id,item).toFixed(1),32,y+23,6.7,'#71858F','600');ui.text(ctx,'菜品评分 '+(d?d.score.toFixed(1):'—')+' · 改良 '+(d?d.revision:0)+' 次',32,y+43,6.8,d?metricTone(d.score):'#71858F','700');this.addButton('select:'+item.id,22,y-16,346,72);y+=82;}
    const sel=this.selected(rt);if(sel){opUi.button(ctx,sel.active===false?'恢复销售':'暂停销售',22,500,82,30);opUi.button(ctx,'设招牌菜',110,500,82,30,'gold');opUi.button(ctx,'- ¥1',198,500,76,30);opUi.button(ctx,'+ ¥1',280,500,76,30);this.addButton('menu:active',22,496,82,38);this.addButton('menu:featured',110,496,82,38);this.addButton('menu:price:-1',198,496,76,38);this.addButton('menu:price:1',280,496,76,38);}
    if(pages>1){opUi.button(ctx,'上一页',88,552,82,30);opUi.button(ctx,(this.menuPage+1)+' / '+pages,176,552,82,30,'ghost');opUi.button(ctx,'下一页',264,552,82,30);this.addButton('menu:prev',88,548,82,38);this.addButton('menu:next',264,548,82,38);}
  }
  renderResearch(ctx,shop,rt){const catalog=operations.getFoodResearchCatalog({})||[];const pageSize=4;const pages=Math.max(1,Math.ceil(catalog.length/pageSize));this.researchPage=Math.max(0,Math.min(this.researchPage,pages-1));const rows=catalog.slice(this.researchPage*pageSize,this.researchPage*pageSize+pageSize);const existing=new Set((rt.menu||[]).map(x=>x.recipeId));this.card(ctx,14,138,362,448,'菜品研发 · 解锁后可加入菜单');let y=178;for(let i=0;i<rows.length;i++){const row=rows[i],id=row.id||row.recipeId;const unlocked=!!row.unlocked;const inMenu=existing.has(id);ui.card(ctx,22,y-16,346,76,{radius:11,fill:'#FFFFFF',stroke:'#E4DED4',shadow:false});ui.text(ctx,nameOf(row,i),32,y+2,8.2,'#173D54','800');const info=unlocked?'研发完成':String(row.status||row.stage||'待研发');ui.text(ctx,info+(row.progress!=null?' · '+Math.round(num(row.progress))+'%':'')+(row.difficulty?' · 难度 '+row.difficulty:''),32,y+23,6.8,unlocked?'#248B63':'#D78A22','700');ui.text(ctx,String(row.desc||row.description||row.category||'通过研发解锁新的菜单可能性').slice(0,25),32,y+43,6.4,'#71858F','600');if(inMenu){opUi.button(ctx,'已上架',284,y+11,70,28,'ghost');}else if(unlocked){opUi.button(ctx,'加入菜单',274,y+11,80,28,'gold');this.addButton('research:add:'+id,270,y+7,88,36);}else{opUi.button(ctx,'开始研发',274,y+11,80,28);this.addButton('research:start:'+id,270,y+7,88,36);}y+=86;}
    if(pages>1){opUi.button(ctx,'上一页',88,554,82,30);opUi.button(ctx,(this.researchPage+1)+' / '+pages,176,554,82,30,'ghost');opUi.button(ctx,'下一页',264,554,82,30);this.addButton('research:prev',88,550,82,38);this.addButton('research:next',264,550,82,38);}
  }
  renderImprove(ctx,shop,rt,snap){const item=this.selected(rt);if(!item){this.renderNoShop(ctx);return;}const d=(snap.dishes||[]).find(x=>x.id===item.id)||prestige.ensureDishProfile(shop.id,item,0,operations.estimateMenuItemCost(shop.id,item));this.card(ctx,14,138,362,112,item.name+' · 第 '+d.level+' 级配方');ui.text(ctx,'综合菜品分 '+d.score.toFixed(1)+' / 100',28,178,11,metricTone(d.score),'800');ui.text(ctx,'已改良 '+d.revision+' 次 · 每次改良成本随版本上升，收益逐渐递减',28,202,6.6,'#71858F','600');
    this.card(ctx,14,262,362,154,'菜品七维评分');const left=[['口味',d.taste],['稳定',d.consistency],['性价比',d.value],['速度',d.speed]];const right=[['创新',d.innovation],['摆盘',d.presentation],['健康',d.health]];let y=292;for(const r of left){this.miniBar(ctx,r[0],r[1],28,y,144);y+=28;}y=292;for(const r of right){this.miniBar(ctx,r[0],r[1],204,y,144);y+=28;}
    this.card(ctx,14,428,362,164,'选择一个明确改良方向');const acts=prestige.IMPROVEMENTS;for(let i=0;i<acts.length;i++){const a=acts[i];const col=i%2,row=Math.floor(i/2);const x=22+col*174,yy=458+row*34;opUi.button(ctx,a.name,x,yy,166,27,i===4?'gold':undefined);this.addButton('improve:'+a.id,x,yy-3,166,33);}
  }
  renderRating(ctx,shop,rt,snap){const r=snap.rating;this.card(ctx,14,138,362,110,'门店综合评分 · 样本可信度');ui.text(ctx,r.publicStars.toFixed(1)+' ★',28,186,18,'#D29A18','800');ui.text(ctx,r.score.toFixed(1)+' / 100',128,182,9,'#173D54','800');ui.text(ctx,'评价样本 '+r.reviewCount+' 条 · 可信度 '+Math.round(r.confidence)+'%',128,204,6.8,'#71858F','600');
    this.card(ctx,14,260,362,244,'八维评分 · 榜单与奖项按维度加权');const labels=[['口味','taste'],['服务','service'],['速度','speed'],['性价比','value'],['卫生','hygiene'],['环境','atmosphere'],['稳定性','consistency'],['创新','innovation']];let y=292;for(let i=0;i<labels.length;i++){const col=i%2,row=Math.floor(i/2),x=28+col*176,yy=y+row*48;this.miniBar(ctx,labels[i][0],r.metrics[labels[i][1]],x,yy,144);}
    const weakest=labels.slice().sort((a,b)=>r.metrics[a[1]]-r.metrics[b[1]])[0];this.card(ctx,14,516,362,76,'当前最值得解决的问题');ui.text(ctx,weakest[0]+' '+Math.round(r.metrics[weakest[1]])+' 分',28,554,9,metricTone(r.metrics[weakest[1]]),'800');ui.text(ctx,'评分不再只看星级，小样本高分会被可信度校正。',158,553,6.5,'#71858F','600');
  }
  renderAwards(ctx,shop,rt,snap){
    const state=prestige.getShopState(shop.id);
    const pending=(state.awards.nominations||[]).filter(x=>x.ceremonyPending&&!x.ceremonyHeld);
    this.card(ctx,14,138,362,102,'奖项机制 · 资格审查 → 提名 → 评审 → 颁奖');
    ui.text(ctx,'已获奖 '+state.awards.won.length+' · 待颁奖 '+pending.length+' · 餐饮声望 '+Math.round(snap.prestige),28,178,8.5,'#173D54','800');
    ui.text(ctx,'奖项按顾客数据、样本可信度、运营稳定与专家评审共同决定',28,201,6.5,'#71858F','600');
    if(pending.length){opUi.button(ctx,'参加颁奖礼',242,166,112,30,'gold');this.addButton('award:ceremony',238,162,120,38);}else{opUi.button(ctx,'进行本期评审',242,166,112,30,'gold');this.addButton('award:evaluate',238,162,120,38);}
    this.card(ctx,14,252,362,336,'最近奖项 / 提名');
    const rows=(state.awards.nominations||[]).slice(0,6);
    let y=288;
    if(!rows.length){
      ui.text(ctx,'尚未进行本期评审。达到评分和评价样本门槛后才有资格进入提名。',28,y,6.8,'#71858F','600');
      y+=30;
      for(const a of prestige.AWARDS.slice(0,5)){
        ui.text(ctx,a.name+' · '+a.scope+' · '+(a.period==='month'?'月度':a.period==='quarter'?'季度':'年度'),28,y,7,'#3A5665','700');
        ui.text(ctx,'门槛 '+a.minScore+'分 / '+a.minReviews+'评',352,y,6.6,'#71858F','700','right');
        y+=38;
      }
    }else{
      for(const a of rows){
        const status=a.won?'已颁奖':a.ceremonyPending?'待颁奖':a.eligible?'入围未获奖':'未入围';
        const icon=a.won?'🏆 ':a.ceremonyPending?'★ ':'○ ';
        ui.text(ctx,icon+a.name,28,y,7.5,a.won||a.ceremonyPending?'#C47C00':'#173D54','800');
        ui.text(ctx,status,352,y,6.5,a.won?'#248B63':a.ceremonyPending?'#C47C00':'#71858F','700','right');
        const jury=a.panel?('数据'+a.panel.dataScore.toFixed(1)+' / 评审'+a.panel.expert.toFixed(1)+' / 总评'+a.panel.finalScore.toFixed(1)):('本店 '+a.playerScore.toFixed(1));
        ui.text(ctx,jury,28,y+17,6.1,'#71858F','600');
        y+=46;
      }
    }
  }

  render(ctx){const h=opUi.viewHeight();this.buttons=[];ctx.save();opUi.background(ctx,h);this.header(ctx,'菜单与菜品实验室','研发、改良、评分与奖项形成同一条经营闭环');const shop=this.shop();const rt=this.runtime(shop);if(!shop||!rt){this.renderNoShop(ctx);ctx.restore();return;}this.ensureSelection();const snap=this.snapshot(shop,rt);if(this.tab==='research')this.renderResearch(ctx,shop,rt);else if(this.tab==='improve')this.renderImprove(ctx,shop,rt,snap);else if(this.tab==='rating')this.renderRating(ctx,shop,rt,snap);else if(this.tab==='awards')this.renderAwards(ctx,shop,rt,snap);else this.renderMenu(ctx,shop,rt,snap);ctx.restore();}
  toast(text){opUi.toast(String(text));}
  save(){if(saveSystem&&typeof saveSystem.autoSave==='function')saveSystem.autoSave(true);}
  handleTap(x,y){const t=this.hit(x,y);if(!t)return false;const id=t.id;if(id.startsWith('tab:')){this.tab=id.slice(4);return true;}const shop=this.shop(),rt=this.runtime(shop);if(!shop||!rt)return true;this.ensureSelection();const item=this.selected(rt);
    if(id.startsWith('select:')){this.selectedMenuId=id.slice(7);this.tab='improve';return true;}
    if(id==='menu:prev'){this.menuPage=Math.max(0,this.menuPage-1);return true;}if(id==='menu:next'){this.menuPage++;return true;}if(id==='research:prev'){this.researchPage=Math.max(0,this.researchPage-1);return true;}if(id==='research:next'){this.researchPage++;return true;}
    if(id==='menu:active'&&item){const r=operations.setMenuActive(shop.id,item.id,item.active===false);this.toast(r.ok?'菜单状态已更新':r.reason||'操作失败');this.save();return true;}
    if(id==='menu:featured'&&item){const r=operations.setMenuFeatured(shop.id,item.id);this.toast(r.ok?'已设为招牌菜':'设置失败');this.save();return true;}
    if(id.startsWith('menu:price:')&&item){const delta=Number(id.split(':')[2]);const r=operations.adjustMenuPrice(shop.id,item.id,delta);this.toast(r.ok?'售价已调整':'调价失败');this.save();return true;}
    if(id.startsWith('research:start:')){const recipeId=id.slice('research:start:'.length);const r=operations.startRecipeResearch(recipeId);this.toast(r&&r.ok===false?(r.reason||'暂时无法研发'):'研发项目已启动');this.save();return true;}
    if(id.startsWith('research:add:')){const recipeId=id.slice('research:add:'.length);const r=operations.addMenuRecipe(shop.id,recipeId,{});this.toast(r.ok?'新菜已加入菜单':r.reason||'加入菜单失败');this.save();return true;}
    if(id.startsWith('improve:')&&item){const action=id.slice(8);const result=typeof operations.improveCulinaryDish==='function'?operations.improveCulinaryDish(shop.id,item.id,action):null;this.toast(result&&result.ok?'改良完成：'+result.before.toFixed(1)+' → '+result.after.toFixed(1):result&&result.reason||'改良失败');this.save();return true;}
    if(id==='award:evaluate'){const result=typeof operations.evaluateCulinaryAwards==='function'?operations.evaluateCulinaryAwards(shop.id):null;const pending=result&&result.pendingCeremonies?result.pendingCeremonies.length:0;this.toast(result?'本期评审完成'+(pending?'，有 '+pending+' 项等待颁奖':'，本期暂无待颁奖项'):'评审系统暂不可用');this.save();return true;}
    if(id==='award:ceremony'){const result=typeof operations.holdCulinaryAwardCeremony==='function'?operations.holdCulinaryAwardCeremony(shop.id):null;const n=result&&result.granted?result.granted.length:0;this.toast(result&&result.ok?'颁奖礼完成，正式获得 '+n+' 项荣誉':result&&result.reason||'颁奖礼暂不可用');this.save();return true;}
    return false;
  }
}

module.exports = new CulinaryLabSceneV085();
