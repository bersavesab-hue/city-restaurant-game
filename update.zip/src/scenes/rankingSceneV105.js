'use strict';

const DataSceneBase = require('./dataSceneBase.js');
const sceneManager = require('../core/sceneManager.js');
const gameState = require('../core/gameState.js');
const citySystem = require('../city/citySystem.js');
const demandSystem = require('../city/demandSystem.js');
const prestige = require('../reputation/restaurantPrestigeSystemV105.js');
const ui = require('../ui/dataWidgets.js');

class RankingSceneV105 extends DataSceneBase {
  constructor() {
    super('ranking');
    this.scope = 'city';
  }

  enter(payload) {
    super.enter(payload);
    this.scope = payload && payload.scope === 'district' ? 'district' : 'city';
  }

  context() {
    return { gameState, citySystem, demandSystem };
  }

  drawScope(ctx) {
    const defs = [
      ['scope:city', '城市榜', 10, this.scope === 'city'],
      ['scope:district', '商圈榜', 199, this.scope === 'district']
    ];
    defs.forEach(d => {
      ui.rect(ctx, d[2], 114, 181, 30, {
        radius: 9,
        fill: d[3] ? ui.COLORS.navy : '#EEE7DC',
        stroke: d[3] ? '#315D75' : ui.COLORS.line
      });
      ui.text(ctx, d[1], d[2] + 90.5, 129, 7.4, d[3] ? ui.COLORS.white : ui.COLORS.text, '700', 'center');
      this.addButton(d[0], d[2], 114, 181, 30);
    });
  }

  render(ctx) {
    if (!ctx) return;
    this.begin(ctx);
    const report = prestige.sync(this.context());
    const player = gameState.getPlayer();
    ui.header(ctx, '餐饮排行榜', 'NPC门店会随经营、口碑和市场变化动态升降', 390, ui.money(player.cash));
    ui.tabBar(ctx, prestige.CATEGORY_DEFS.map(x => ({ label:x.name })), this.tab, 75, this.addButton.bind(this), 390);
    this.drawScope(ctx);

    const cat = prestige.CATEGORY_DEFS[this.tab] || prestige.CATEGORY_DEFS[0];
    const ranking = prestige.buildRanking(cat.id, this.scope, this.context(), report);

    ui.rect(ctx, 10, 154, 370, 66, { fill: ui.COLORS.paleGold, stroke: '#E5C47A' });
    ui.text(ctx, '我的排名', 24, 173, 7, ui.COLORS.muted, '600');
    ui.text(ctx, ranking.playerRank == null ? '—' : ('第 ' + ranking.playerRank + ' 名'), 24, 199, 17, ui.COLORS.text, '800');
    ui.text(ctx, cat.name + ' ' + ui.number(ranking.playerScore, 1) + '分', 365, 178, 8, ui.COLORS.navy, '700', 'right');
    ui.text(ctx, '经营评级 ' + report.dimensions.grade + ' · ' + ui.number(report.dimensions.operating, 1), 365, 196, 6.3, ui.COLORS.muted, '600', 'right');
    ui.text(ctx, '共 ' + ui.number(ranking.total) + ' 个经营主体', 365, 211, 5.8, ui.COLORS.muted, '600', 'right');

    ui.tableHeader(ctx, 234, [
      {label:'名次', x:24}, {label:'餐饮品牌', x:72}, {label:'门店', x:285, align:'right'}, {label:'得分', x:363, align:'right'}
    ]);

    const rows = ranking.top.slice(0, 8);
    rows.forEach((r, i) => {
      const y = 274 + i * 43;
      if (r.type === 'player') ui.rect(ctx, 14, y - 17, 362, 34, { radius:8, fill:ui.COLORS.paleGold, stroke:'#E9D29E' });
      const rankColor = r.rank <= 3 ? ui.COLORS.gold : ui.COLORS.text;
      ui.text(ctx, r.rank, 28, y, 8.5, rankColor, '800', 'center');
      ui.text(ctx, String(r.name).slice(0, 14), 58, y, 7.4, r.type === 'player' ? ui.COLORS.navy : ui.COLORS.text, r.type === 'player' ? '800' : '600');
      ui.text(ctx, r.storeCount + '家', 285, y, 6.8, ui.COLORS.muted, '600', 'right');
      ui.text(ctx, ui.number(r.score, 1), 363, y, 7.8, ui.COLORS.text, '700', 'right');
      if (i < rows.length - 1) ui.divider(ctx, 24, y + 21, 342);
    });

    const y = Math.min(this.contentBottom - 45, 632);
    ui.rect(ctx, 10, y, 178, 36, { radius:10, fill:'#EEE7DC', stroke:ui.COLORS.line });
    ui.text(ctx, '‹ 更多管理', 99, y + 18, 7.5, ui.COLORS.navy, '700', 'center');
    this.addButton('go:more', 10, y, 178, 36);
    ui.rect(ctx, 202, y, 178, 36, { radius:10, fill:ui.COLORS.gold, stroke:'#D2A13E' });
    ui.text(ctx, '查看荣誉中心', 291, y + 18, 7.5, '#26343B', '800', 'center');
    this.addButton('go:honors', 202, y, 178, 36);
    this.end(ctx);
  }

  handleTap(x, y) {
    const hit = this.handleBaseTap(x, y);
    if (hit === true) return true;
    if (!hit || !hit.id) return false;
    if (hit.id === 'scope:city') { this.scope = 'city'; return true; }
    if (hit.id === 'scope:district') { this.scope = 'district'; return true; }
    if (hit.id === 'go:more') return sceneManager.switchTo('more');
    if (hit.id === 'go:honors') return sceneManager.switchTo('honors');
    return false;
  }
}

module.exports = new RankingSceneV105();
