'use strict';

const runtime =
  globalThis.GameRuntime;

const api =
  runtime &&
  runtime.api ||
  {};

const routeHub =
  require('../core/entryRouterV089.js');

const ui =
  require('../ui/premiumUi.js');

const opUi =
  require('../ui/operationsUiV080.js');

const ENTRY_IDS = [
  'city',
  'shop',
  'store',
  'research',
  'supply',
  'staff',
  'schedule',
  'staffCareer',
  'business',
  'dynamicWorld',
  'system'
];

class FeatureHubScene {
  constructor() {
    this.id =
      'featureHub';

    this.buttons =
      [];
  }

  enter() {
  }

  exit() {
    this.buttons =
      [];
  }

  update() {
  }

  addButton(
    id,
    x,
    y,
    w,
    h
  ) {
    this.buttons.push({
      id,
      x,
      y,
      w,
      h
    });
  }

  hitButton(
    x,
    y
  ) {
    for (
      let i =
        this.buttons.length - 1;
      i >= 0;
      i--
    ) {
      const button =
        this.buttons[i];

      if (
        x >= button.x &&
        x <= button.x + button.w &&
        y >= button.y &&
        y <= button.y + button.h
      ) {
        return button;
      }
    }

    return null;
  }

  toast(title) {
    if (
      api &&
      typeof api.showToast ===
        'function'
    ) {
      api.showToast({
        title,
        icon:'none'
      });
    }
  }

  render(ctx) {
    const h =
      opUi.viewHeight();

    this.buttons =
      [];

    ctx.save();

    opUi.background(
      ctx,
      h
    );

    opUi.header(
      ctx,
      '功能中心',
      '统一入口 · 第一阶段只做功能，不做UI精修'
    );

    ui.card(
      ctx,
      14,
      92,
      362,
      52,
      {
        radius:12,
        fill:'#FFFDF8',
        stroke:'#DDD4C7',
        shadow:false
      }
    );

    ui.text(
      ctx,
      '所有入口现在由同一套路由控制；未注册页面不会把游戏卡死。',
      26,
      118,
      6.7,
      '#627985',
      '700'
    );

    const entries =
      ENTRY_IDS
        .map(
          id =>
            routeHub.resolve(
              id
            )
        )
        .filter(Boolean);

    const left =
      14;

    const top =
      158;

    const gapX =
      8;

    const gapY =
      8;

    const width =
      177;

    const height =
      42;

    for (
      let i = 0;
      i < entries.length;
      i++
    ) {
      const entry =
        entries[i];

      const col =
        i % 2;

      const row =
        Math.floor(
          i / 2
        );

      const x =
        left +
        col *
          (
            width +
            gapX
          );

      const y =
        top +
        row *
          (
            height +
            gapY
          );

      ui.card(
        ctx,
        x,
        y,
        width,
        height,
        {
          radius:11,
          fill:'#173D54',
          stroke:false,
          shadow:false
        }
      );

      ui.text(
        ctx,
        entry.label,
        x + width / 2,
        y + height / 2,
        7.4,
        '#FFFFFF',
        '800',
        'center'
      );

      this.addButton(
        'route:' +
          entry.id,
        x,
        y,
        width,
        height
      );
    }

    const backY =
      Math.min(
        h - 118,
        top +
          Math.ceil(
            entries.length / 2
          ) *
          (
            height +
            gapY
          ) +
          10
      );

    ui.card(
      ctx,
      14,
      backY,
      362,
      40,
      {
        radius:11,
        fill:'#F4BE3C',
        stroke:false,
        shadow:false
      }
    );

    ui.text(
      ctx,
      '返回上一页',
      195,
      backY + 20,
      8,
      '#173D54',
      '800',
      'center'
    );

    this.addButton(
      'back',
      14,
      backY,
      362,
      40
    );

    ctx.restore();
  }

  handleTap(
    x,
    y
  ) {
    const button =
      this.hitButton(
        x,
        y
      );

    if (!button) {
      return false;
    }

    if (
      button.id ===
      'back'
    ) {
      routeHub.back(
        'system'
      );

      return true;
    }

    if (
      button.id.indexOf(
        'route:'
      ) ===
      0
    ) {
      const routeId =
        button.id.slice(
          'route:'.length
        );

      if (
        !routeHub.open(
          routeId
        )
      ) {
        this.toast(
          routeHub.getLastError() ||
          '该功能入口暂不可用'
        );
      }

      return true;
    }

    return false;
  }
}

module.exports =
  new FeatureHubScene();
