'use strict';

const PACK = require('./renovationPackV10.js');

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, Number(v) || 0));
}

function round(v, digits) {
  const p = Math.pow(10, digits == null ? 2 : digits);
  return Math.round((Number(v) || 0) * p) / p;
}

function truthy(value, fallback) {
  if (value === undefined || value === null) return !!fallback;
  return !!value;
}

function numberFrom(obj, keys, fallback) {
  for (const key of keys) {
    const value = Number(obj && obj[key]);
    if (Number.isFinite(value) && value > 0) return value;
  }
  return fallback;
}

function normalizeProperty(raw) {
  const item = raw || {};
  const area = numberFrom(item, ['usableArea','grossArea','area'], 42);
  let frontage = numberFrom(item, ['frontage','widthMeters','width'], 0);
  let depth = numberFrom(item, ['depth','depthMeters'], 0);

  if (!(frontage > 0 && depth > 0)) {
    const ratioName = String(item.layoutTypeName || item.layoutName || '').toLowerCase();
    const ratio = /狭长|deep|long/.test(ratioName) ? 0.48 : /转角|corner|双开|wide/.test(ratioName) ? 0.88 : 0.68;
    frontage = Math.sqrt(area * ratio);
    depth = area / frontage;
  }

  // 装修平面必须服从实际可用面积。
  // 保留房源原始面宽/进深的长宽倾向，但始终按 usableArea 做矩形近似归一，
  // 避免大面积房源因来源字段不一致被错误压成几十平方米。
  const currentArea = frontage * depth;
  if (currentArea > 0 && area > 0) {
    const rawRatio = frontage / Math.max(0.1, depth);
    const ratio = clamp(rawRatio, 0.18, 5.5);
    frontage = Math.sqrt(area * ratio);
    depth = area / Math.max(0.1, frontage);
  }

  const nestedFacilities = item.facilities || {};
  const powerKw = numberFrom(item, ['electricCapacityKw','powerKw','electricKw'], Number(nestedFacilities.powerKw) || ((item.threePhase !== undefined ? item.threePhase : nestedFacilities.threePhase) ? 35 : 12));
  const id = String(item.propertyId || item.marketKey || item.id || 'renovation_property');

  return {
    id,
    name: String(item.address || item.name || '当前门店'),
    usableArea: round(area, 1),
    frontage: round(frontage, 1),
    depth: round(depth, 1),
    ceilingHeight: round(numberFrom(item, ['ceilingHeight'], 3.3), 1),
    gridSize: PACK.GRID_SIZE_METERS,
    facilities: {
      exhaust: truthy(item.exhaust !== undefined ? item.exhaust : nestedFacilities.exhaust, true),
      gas: truthy(item.gas !== undefined ? item.gas : nestedFacilities.gas, false),
      threePhase: truthy(item.threePhase !== undefined ? item.threePhase : nestedFacilities.threePhase, powerKw >= 20),
      drain: truthy(item.drainage !== undefined ? item.drainage : nestedFacilities.drain, true),
      water: truthy(item.waterPressure !== undefined ? item.waterPressure : nestedFacilities.water, true),
      greaseTrap: truthy(item.greaseTrap !== undefined ? item.greaseTrap : nestedFacilities.greaseTrap, false),
      fire: truthy(item.fireSprinkler !== undefined ? item.fireSprinkler : (item.fire !== undefined ? item.fire : nestedFacilities.fire), true),
      powerKw
    },
    source: item
  };
}

function createFloorPlan(rawProperty) {
  const property = normalizeProperty(rawProperty);
  const grid = property.gridSize;
  const widthCells = Math.max(6, Math.round(property.frontage / grid));
  const depthCells = Math.max(6, Math.round(property.depth / grid));
  const usableAreaFromGrid = widthCells * depthCells * grid * grid;
  const doorWidthCells = Math.max(2, Math.min(5, Math.round(Math.min(property.frontage, 2.0) / grid)));
  const doorX = Math.max(0, Math.floor((widthCells - doorWidthCells) / 2));
  const backY = depthCells - 1;

  return {
    property,
    gridSize: grid,
    widthCells,
    depthCells,
    usableAreaFromGrid: round(usableAreaFromGrid, 1),
    boundary: { x:0, y:0, w:widthCells, h:depthCells },
    doors: [{ id:'front_door', x:doorX, y:0, w:doorWidthCells, h:1, type:'entrance' }],
    noPlaceZones: [
      { id:'door_clearance', x:Math.max(0, doorX - 1), y:0, w:Math.min(widthCells, doorWidthCells + 2), h:Math.min(3, depthCells), type:'door' }
    ],
    utilityPoints: {
      drain: [{ x:1, y:Math.max(1, backY - 1) }],
      water: [{ x:2, y:Math.max(1, backY - 1) }],
      gas: property.facilities.gas ? [{ x:Math.max(1, Math.floor(widthCells * 0.30)), y:backY }] : [],
      exhaust: property.facilities.exhaust ? [{ x:Math.max(1, Math.floor(widthCells * 0.55)), y:backY }] : [],
      power: [{ x:Math.max(1, widthCells - 2), y:backY }]
    }
  };
}

function rotatedFootprint(asset, rotation) {
  const fp = asset && asset.footprint ? asset.footprint : {w:1,h:1};
  const r = ((Number(rotation) || 0) % 360 + 360) % 360;
  return (r === 90 || r === 270) ? { w:fp.h, h:fp.w } : { w:fp.w, h:fp.h };
}

function rectsOverlap(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function pointDistanceToRect(point, rect) {
  const cx = clamp(point.x, rect.x, rect.x + rect.w - 1);
  const cy = clamp(point.y, rect.y, rect.y + rect.h - 1);
  return Math.abs(point.x - cx) + Math.abs(point.y - cy);
}

function nearestUtilityDistance(plan, kind, rect) {
  const points = (plan.utilityPoints && plan.utilityPoints[kind]) || [];
  if (!points.length) return Infinity;
  return Math.min.apply(null, points.map((p) => pointDistanceToRect(p, rect)));
}

function placementRect(asset, x, y, rotation) {
  const fp = rotatedFootprint(asset, rotation);
  return { x:Math.floor(x), y:Math.floor(y), w:fp.w, h:fp.h };
}

function inBounds(plan, rect) {
  return rect.x >= 0 && rect.y >= 0 && rect.x + rect.w <= plan.widthCells && rect.y + rect.h <= plan.depthCells;
}

function requirementIssues(plan, asset, rect) {
  const req = asset.requirements || {};
  const f = plan.property.facilities;
  const errors = [];
  const warnings = [];

  if (req.exhaust && !f.exhaust) errors.push('房源没有可用排烟条件');
  if (req.gas && !f.gas) errors.push('房源没有燃气条件');
  if (req.threePhase && !f.threePhase) errors.push('房源没有三相电');
  if (req.drain && !f.drain) errors.push('房源没有可用排水');
  if (req.water && !f.water) errors.push('房源供水条件不足');

  if (req.exhaust && f.exhaust && nearestUtilityDistance(plan, 'exhaust', rect) > 6) warnings.push('距离排烟点较远，改造成本和效率会变差');
  if (req.gas && f.gas && nearestUtilityDistance(plan, 'gas', rect) > 7) warnings.push('距离燃气点较远，需要额外改管');
  if ((req.drain || req.water) && nearestUtilityDistance(plan, 'drain', rect) > 8) warnings.push('距离排水点较远，需要额外改造');

  return { errors, warnings };
}

function validatePlacement(plan, placements, asset, x, y, rotation, ignorePlacedId) {
  const rect = placementRect(asset, x, y, rotation);
  const errors = [];
  const warnings = [];

  if (!inBounds(plan, rect)) errors.push('超出房源可用范围');

  for (const zone of plan.noPlaceZones || []) {
    if (rectsOverlap(rect, zone)) errors.push(zone.type === 'door' ? '占用了入口/消防疏散空间' : '占用了禁放区域');
  }

  for (const placed of placements || []) {
    if (placed.id === ignorePlacedId) continue;
    const otherAsset = PACK.ASSET_BY_ID[placed.assetId];
    if (!otherAsset) continue;
    const otherRect = placementRect(otherAsset, placed.x, placed.y, placed.rotation);
    if (rectsOverlap(rect, otherRect)) {
      errors.push('与“' + otherAsset.name + '”发生碰撞');
      break;
    }
  }

  const req = requirementIssues(plan, asset, rect);
  errors.push.apply(errors, req.errors);
  warnings.push.apply(warnings, req.warnings);

  return { ok:errors.length === 0, rect, errors, warnings };
}

function occupancyGrid(plan, placements, ignoreDecor) {
  const grid = Array.from({length:plan.depthCells}, () => Array(plan.widthCells).fill(0));
  for (const zone of plan.noPlaceZones || []) {
    if (zone.type !== 'door') continue;
    // 入口清空，不视为障碍。
  }
  for (const placed of placements || []) {
    const asset = PACK.ASSET_BY_ID[placed.assetId];
    if (!asset || (ignoreDecor && asset.category === 'decor')) continue;
    const rect = placementRect(asset, placed.x, placed.y, placed.rotation);
    for (let y=rect.y; y<rect.y+rect.h; y++) for (let x=rect.x; x<rect.x+rect.w; x++) {
      if (y>=0 && y<plan.depthCells && x>=0 && x<plan.widthCells) grid[y][x] = 1;
    }
  }
  return grid;
}

function hasPath(plan, placements) {
  const grid = occupancyGrid(plan, placements, true);
  const door = plan.doors[0];
  const starts = [];
  const startY = Math.min(plan.depthCells - 1, door.y + 1);
  for (let x=door.x; x<door.x+door.w; x++) if (!grid[startY][x]) starts.push([x,startY]);
  if (!starts.length) return false;

  const targetY = Math.max(1, plan.depthCells - 2);
  const q = starts.slice();
  const seen = new Set(starts.map((p) => p[0] + ':' + p[1]));
  let qi = 0;
  while (qi < q.length) {
    const [x,y] = q[qi++];
    if (y >= targetY) return true;
    const dirs = [[1,0],[-1,0],[0,1],[0,-1]];
    for (const [dx,dy] of dirs) {
      const nx=x+dx, ny=y+dy, key=nx+':'+ny;
      if (nx<0||ny<0||nx>=plan.widthCells||ny>=plan.depthCells||grid[ny][nx]||seen.has(key)) continue;
      seen.add(key); q.push([nx,ny]);
    }
  }
  return false;
}

// 经营主通道按 2 个 0.5m 网格（约 1m）校验，而不是只允许“半米缝”通过。
function hasClearancePath(plan, placements, clearanceCells) {
  const size = Math.max(1, Math.floor(clearanceCells || 2));
  if (size <= 1) return hasPath(plan, placements);
  const grid = occupancyGrid(plan, placements, true);
  const maxX = plan.widthCells - size;
  const maxY = plan.depthCells - size;
  if (maxX < 0 || maxY < 0) return false;
  const clearAt = (x,y) => {
    if (x < 0 || y < 0 || x > maxX || y > maxY) return false;
    for (let yy=y; yy<y+size; yy++) for (let xx=x; xx<x+size; xx++) if (grid[yy][xx]) return false;
    return true;
  };
  const door = plan.doors[0];
  const startY = Math.min(maxY, Math.max(0, door.y + 1));
  const starts=[];
  const sx0=Math.max(0, door.x-size+1), sx1=Math.min(maxX, door.x+door.w-1);
  for(let x=sx0;x<=sx1;x++) if(clearAt(x,startY)) starts.push([x,startY]);
  if(!starts.length) return false;
  const targetY=Math.max(0, plan.depthCells-size-1);
  const q=starts.slice(), seen=new Set(starts.map(p=>p[0]+':'+p[1]));
  let qi=0;
  while(qi<q.length){
    const [x,y]=q[qi++];
    if(y>=targetY) return true;
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){
      const nx=x+dx,ny=y+dy,key=nx+':'+ny;
      if(seen.has(key)||!clearAt(nx,ny)) continue;
      seen.add(key);q.push([nx,ny]);
    }
  }
  return false;
}

function evaluate(plan, placements) {
  let cost=0, power=0, smoke=0, gas=0, water=0, seats=0, kitchen=0, delivery=0, storage=0, wash=0, environment=0, buildHours=0;
  for (const placed of placements || []) {
    const a = PACK.ASSET_BY_ID[placed.assetId];
    if (!a) continue;
    cost += a.price || 0;
    power += a.powerKw || 0;
    smoke += a.smokeLoad || 0;
    gas += a.gasLoad || 0;
    water += a.waterLoad || 0;
    seats += a.seats || 0;
    kitchen += a.kitchenCapacity || 0;
    delivery += a.deliveryCapacity || 0;
    storage += a.storageCapacity || 0;
    wash += a.washCapacity || 0;
    environment += a.environment || 0;
    buildHours += a.buildHours || 0;
  }

  const cellsUsed = (placements || []).reduce((sum,p) => {
    const a=PACK.ASSET_BY_ID[p.assetId]; if(!a) return sum; const fp=rotatedFootprint(a,p.rotation); return sum+fp.w*fp.h;
  },0);
  const totalCells = Math.max(1, plan.widthCells * plan.depthCells);
  const occupancy = cellsUsed / totalCells;
  const pathOk = hasClearancePath(plan, placements, 2);
  const powerRatio = power / Math.max(1, plan.property.facilities.powerKw);
  const smokeLimit = plan.property.facilities.exhaust ? Math.max(3, plan.widthCells / 4) : 0;
  const smokeRatio = smokeLimit > 0 ? smoke / smokeLimit : (smoke > 0 ? 9 : 0);

  const flowScore = clamp(100 - Math.max(0, occupancy - 0.48) * 150 - (pathOk ? 0 : 45), 0, 100);
  const safetyScore = clamp(100 - (pathOk ? 0 : 55) - Math.max(0,powerRatio-1)*70 - Math.max(0,smokeRatio-1)*55, 0, 100);
  const envScore = clamp(45 + environment * 3 - Math.max(0,occupancy-0.60)*80, 0, 100);
  const diningCapacity = Math.round(seats * clamp(0.72 + flowScore/250,0.55,1.10));
  const kitchenCapacity = Math.round(kitchen * clamp(0.70 + flowScore/300,0.55,1.05));
  const deliveryCapacity = Math.round(delivery + kitchenCapacity * 0.28);

  const issues=[];
  if (!pathOk) issues.push('入口到后场动线被阻断');
  if (powerRatio > 1) issues.push('设备总功率超过房源电力容量');
  if (smokeRatio > 1) issues.push('排烟负荷过高');
  if (wash < Math.max(8, seats * 0.45)) issues.push('洗消能力偏弱');
  if (storage < Math.max(10, kitchenCapacity * 0.35)) issues.push('储存能力偏弱');

  return {
    cost:Math.round(cost),
    buildDays:Math.max(1, Math.ceil(buildHours / 18)),
    seats,
    diningCapacity,
    kitchenCapacity,
    deliveryCapacity,
    storageCapacity:Math.round(storage),
    washCapacity:Math.round(wash),
    flowScore:Math.round(flowScore),
    environmentScore:Math.round(envScore),
    safetyScore:Math.round(safetyScore),
    occupancyRate:round(occupancy,3),
    powerKw:round(power,2),
    powerCapacityKw:plan.property.facilities.powerKw,
    powerLoad:round(powerRatio,2),
    smokeLoad:round(smokeRatio,2),
    gasLoad:round(gas,2),
    waterLoad:round(water,2),
    pathOk,
    issues
  };
}

function zSort(placements) {
  return (placements || []).slice().sort((a,b) => {
    const aa=PACK.ASSET_BY_ID[a.assetId], bb=PACK.ASSET_BY_ID[b.assetId];
    const la=PACK.LAYER_ORDER[(aa&&aa.layer)||'equipment']||0;
    const lb=PACK.LAYER_ORDER[(bb&&bb.layer)||'equipment']||0;
    if (la !== lb) return la-lb;
    const af=aa?rotatedFootprint(aa,a.rotation):{h:1};
    const bf=bb?rotatedFootprint(bb,b.rotation):{h:1};
    const ay=(a.y||0)+af.h, by=(b.y||0)+bf.h;
    if (ay !== by) return ay-by;
    return String(a.id).localeCompare(String(b.id));
  });
}

module.exports = {
  clamp,
  round,
  normalizeProperty,
  createFloorPlan,
  rotatedFootprint,
  placementRect,
  rectsOverlap,
  validatePlacement,
  occupancyGrid,
  hasPath,
  hasClearancePath,
  evaluate,
  zSort
};
