'use strict';

const PACK = require('./renovationPackV10.js');
const rules = require('./renovationRulesV10.js');

function clone(v) { return JSON.parse(JSON.stringify(v)); }

class RenovationLayoutEngine {
  constructor(property, savedPlan) {
    this.plan = rules.createFloorPlan(property || {});
    this.placements = [];
    this.sequence = 1;
    this.history = [];
    this.future = [];
    if (savedPlan && Array.isArray(savedPlan.placements)) this.restore(savedPlan);
  }

  snapshotForUndo() {
    this.history.push(clone(this.placements));
    if (this.history.length > 40) this.history.shift();
    this.future = [];
  }

  nextId(assetId) {
    return 'reno_' + String(this.sequence++) + '_' + String(assetId);
  }

  getProperty() { return clone(this.plan.property); }
  getPlan() { return clone(this.plan); }
  getPlacements() { return clone(this.placements); }
  getDrawOrder() { return rules.zSort(this.placements); }
  getMetrics() { return rules.evaluate(this.plan, this.placements); }

  canPlace(assetId, x, y, rotation, ignorePlacedId) {
    const asset = PACK.ASSET_BY_ID[assetId];
    if (!asset) return {ok:false,errors:['未知装修物件'],warnings:[]};
    return rules.validatePlacement(this.plan, this.placements, asset, x, y, rotation, ignorePlacedId);
  }

  place(assetId, x, y, rotation) {
    const asset = PACK.ASSET_BY_ID[assetId];
    if (!asset) return {ok:false,errors:['未知装修物件'],warnings:[]};
    const check = this.canPlace(assetId, x, y, rotation || 0);
    if (!check.ok) return check;
    this.snapshotForUndo();
    const row = { id:this.nextId(assetId), assetId, x:Math.floor(x), y:Math.floor(y), rotation:((rotation||0)%360+360)%360 };
    this.placements.push(row);
    return {ok:true,placed:clone(row),warnings:check.warnings};
  }

  move(placedId, x, y) {
    const row = this.placements.find((p)=>p.id===placedId);
    if (!row) return {ok:false,errors:['找不到已摆放物件'],warnings:[]};
    const check = this.canPlace(row.assetId, x, y, row.rotation, placedId);
    if (!check.ok) return check;
    this.snapshotForUndo(); row.x=Math.floor(x); row.y=Math.floor(y);
    return {ok:true,placed:clone(row),warnings:check.warnings};
  }

  rotate(placedId) {
    const row = this.placements.find((p)=>p.id===placedId);
    if (!row) return {ok:false,errors:['找不到已摆放物件'],warnings:[]};
    const rotation = (row.rotation + 90) % 360;
    const check = this.canPlace(row.assetId,row.x,row.y,rotation,placedId);
    if (!check.ok) return check;
    this.snapshotForUndo(); row.rotation=rotation;
    return {ok:true,placed:clone(row),warnings:check.warnings};
  }

  remove(placedId) {
    const idx=this.placements.findIndex((p)=>p.id===placedId);
    if(idx<0) return false;
    this.snapshotForUndo(); this.placements.splice(idx,1); return true;
  }

  clear() {
    if (!this.placements.length) return;
    this.snapshotForUndo(); this.placements=[];
  }

  undo() {
    if (!this.history.length) return false;
    this.future.push(clone(this.placements));
    this.placements=this.history.pop(); return true;
  }

  redo() {
    if (!this.future.length) return false;
    this.history.push(clone(this.placements));
    this.placements=this.future.pop(); return true;
  }

  findFirstFit(assetId, zone) {
    const a=PACK.ASSET_BY_ID[assetId]; if(!a) return null;
    const yStart=zone==='back'?Math.max(0,Math.floor(this.plan.depthCells*0.55)):2;
    const yEnd=zone==='back'?this.plan.depthCells:Math.max(3,Math.floor(this.plan.depthCells*0.62));
    const ys=[];
    if(zone==='back') for(let y=yEnd-1;y>=yStart;y--) ys.push(y);
    else for(let y=yStart;y<yEnd;y++) ys.push(y);
    const door=this.plan.doors[0];
    const aisleCenter=door.x+door.w/2;
    const aisleX0=Math.max(0,Math.floor(aisleCenter-1));
    const aisleX1=Math.min(this.plan.widthCells,aisleX0+2);
    const blocksAisle=(x,y,rotation)=>{
      const rect=rules.placementRect(a,x,y,rotation);
      if(rect.y<2) return false;
      return rect.x<aisleX1 && rect.x+rect.w>aisleX0;
    };
    for(const y of ys) for(let x=0;x<this.plan.widthCells;x++) {
      if(!blocksAisle(x,y,0)){const c=this.canPlace(assetId,x,y,0); if(c.ok) return {x,y,rotation:0,warnings:c.warnings};}
      if(!blocksAisle(x,y,90)){const c90=this.canPlace(assetId,x,y,90); if(c90.ok) return {x,y,rotation:90,warnings:c90.warnings};}
    }
    return null;
  }

  autoLayout(modeId) {
    const profile=PACK.AUTO_LAYOUTS[modeId]||PACK.AUTO_LAYOUTS.balanced;
    const before=clone(this.placements);
    this.snapshotForUndo(); this.placements=[];
    const placed=[], skipped=[];
    const area=this.plan.property.usableArea;
    const kitchenIds=profile.priorities.filter((id)=>PACK.ASSET_BY_ID[id]&&['kitchen','storage'].includes(PACK.ASSET_BY_ID[id].category));
    const frontIds=profile.priorities.filter((id)=>PACK.ASSET_BY_ID[id]&&['service','dining','decor'].includes(PACK.ASSET_BY_ID[id].category));
    const tryOne=(id,zone)=>{
      const fit=this.findFirstFit(id,zone); if(!fit){skipped.push(id);return false;}
      const row={id:this.nextId(id),assetId:id,x:fit.x,y:fit.y,rotation:fit.rotation}; this.placements.push(row); placed.push(id); return true;
    };
    kitchenIds.forEach((id)=>tryOne(id,'back'));
    frontIds.forEach((id)=>tryOne(id,'front'));

    const tableId=area<30?'dining_table_2':area<90?'dining_table_4':'dining_table_6';
    const targetTables=Math.max(1,Math.min(12,Math.floor(area/(area<30?12:16))));
    for(let i=0;i<targetTables;i++) if(!tryOne(tableId,'front')) break;
    if(modeId==='delivery') { tryOne('service_pack','front'); tryOne('service_pickup','front'); }
    if(area>=55) { tryOne('decor_plant','front'); tryOne('decor_plant','front'); }

    const metrics=this.getMetrics();
    if (!this.placements.length || !metrics.pathOk) {
      this.placements=before;
      this.history.pop();
      return {ok:false,reason:'当前房型无法生成满足基础动线的自动方案',placed:[],skipped};
    }
    return {ok:true,modeId:profile.id,placed,skipped,metrics};
  }

  exportPlan() {
    return {
      version:1,
      propertyId:this.plan.property.id,
      property:this.getProperty(),
      placements:this.getPlacements(),
      metrics:this.getMetrics()
    };
  }

  restore(saved) {
    const next=[];
    for(const row of (saved.placements||[])) {
      const a=PACK.ASSET_BY_ID[row.assetId]; if(!a) continue;
      const check=rules.validatePlacement(this.plan,next,a,row.x,row.y,row.rotation||0,null);
      if(check.ok) next.push({id:String(row.id||this.nextId(row.assetId)),assetId:row.assetId,x:Math.floor(row.x),y:Math.floor(row.y),rotation:Number(row.rotation)||0});
    }
    this.placements=next;
    this.history=[]; this.future=[];
    return this.getMetrics();
  }
}

module.exports = RenovationLayoutEngine;
