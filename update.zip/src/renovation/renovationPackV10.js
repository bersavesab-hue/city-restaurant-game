'use strict';

/**
 * 装修系统 V1.0 素材/设备目录。
 * 说明：这里保存“逻辑占地”和经营属性，不绑定具体图片路径。
 * 后续图片库只要按 assetId 建立映射即可，不影响碰撞与经营计算。
 */

const GRID_SIZE_METERS = 0.5;

const LAYER_ORDER = {
  floor: 0,
  fixed: 10,
  equipment: 20,
  furniture: 30,
  counter: 40,
  wall: 50,
  decor: 60,
  people: 70,
  effect: 80
};

const CATEGORY_ORDER = [
  'kitchen',
  'dining',
  'service',
  'storage',
  'decor'
];

function asset(id, name, category, w, h, extra) {
  return Object.assign({
    id,
    name,
    category,
    footprint: { w, h },
    layer: category === 'dining' ? 'furniture' : category === 'decor' ? 'decor' : category === 'service' ? 'counter' : 'equipment',
    price: 1000,
    buildHours: 2,
    powerKw: 0,
    smokeLoad: 0,
    gasLoad: 0,
    waterLoad: 0,
    seats: 0,
    kitchenCapacity: 0,
    deliveryCapacity: 0,
    storageCapacity: 0,
    washCapacity: 0,
    environment: 0,
    requirements: {},
    draw: { fill: '#D8E3E8', stroke: '#284A5C', text: '#16354A' }
  }, extra || {});
}

const ASSETS = [
  asset('kitchen_fridge_1', '单门冷藏柜', 'storage', 2, 2, { price: 3200, powerKw: 0.45, storageCapacity: 22, draw:{fill:'#DCE8EE',stroke:'#688596',text:'#173A4E'} }),
  asset('kitchen_fridge_2', '双门冷藏柜', 'storage', 3, 2, { price: 5600, powerKw: 0.8, storageCapacity: 42, draw:{fill:'#D7E4EB',stroke:'#5D7D8D',text:'#173A4E'} }),
  asset('kitchen_freezer', '冷冻柜', 'storage', 3, 2, { price: 4800, powerKw: 0.75, storageCapacity: 36, draw:{fill:'#CFE1EC',stroke:'#4F7990',text:'#173A4E'} }),
  asset('storage_dry_rack', '干货货架', 'storage', 2, 1, { price: 980, storageCapacity: 18, draw:{fill:'#D8C5A5',stroke:'#8D714D',text:'#49351D'} }),

  asset('kitchen_wok_2', '双头炒灶', 'kitchen', 3, 2, { price: 4800, buildHours:4, gasLoad:1.8, smokeLoad:2.0, kitchenCapacity:22, requirements:{ gas:true, exhaust:true }, draw:{fill:'#CBD4D8',stroke:'#4E626C',text:'#1C313B'} }),
  asset('kitchen_induction_2', '双头电磁炉', 'kitchen', 3, 2, { price: 4200, buildHours:3, powerKw:7.0, smokeLoad:0.7, kitchenCapacity:16, requirements:{ threePhase:true }, draw:{fill:'#C9D8E0',stroke:'#4A6A7C',text:'#15384A'} }),
  asset('kitchen_fryer', '双篮炸炉', 'kitchen', 2, 2, { price: 4200, buildHours:3, powerKw:5.5, smokeLoad:1.0, kitchenCapacity:18, requirements:{ exhaust:true }, draw:{fill:'#D4D5CF',stroke:'#6F736A',text:'#31352D'} }),
  asset('kitchen_steamer', '蒸柜', 'kitchen', 2, 2, { price: 5200, buildHours:4, powerKw:6.0, waterLoad:0.8, kitchenCapacity:20, requirements:{ threePhase:true, water:true }, draw:{fill:'#D9E0E2',stroke:'#65767C',text:'#263A41'} }),
  asset('kitchen_noodle', '面炉', 'kitchen', 2, 2, { price: 3600, buildHours:3, powerKw:4.5, waterLoad:0.6, kitchenCapacity:17, requirements:{ water:true }, draw:{fill:'#D7D9D5',stroke:'#6B6E68',text:'#343832'} }),
  asset('kitchen_prep', '切配工作台', 'kitchen', 3, 2, { price: 2200, buildHours:2, kitchenCapacity:8, draw:{fill:'#C9D6D5',stroke:'#587372',text:'#1E3E3C'} }),
  asset('kitchen_sink', '双槽水池', 'kitchen', 3, 2, { price: 1800, buildHours:3, waterLoad:0.7, washCapacity:12, requirements:{ drain:true, water:true }, draw:{fill:'#CEE3E8',stroke:'#5B7F88',text:'#173B43'} }),
  asset('kitchen_dishwasher', '商用洗碗机', 'kitchen', 2, 2, { price: 7600, buildHours:4, powerKw:4.2, waterLoad:1.0, washCapacity:30, requirements:{ drain:true, water:true, threePhase:true }, draw:{fill:'#D7E1E6',stroke:'#607A88',text:'#1C3A48'} }),

  asset('service_cashier', '收银台', 'service', 3, 2, { price: 2600, buildHours:2, environment:2, draw:{fill:'#E4C48D',stroke:'#9F7437',text:'#4A3214'} }),
  asset('service_pass', '出餐台', 'service', 3, 2, { price: 2400, buildHours:2, kitchenCapacity:4, draw:{fill:'#DDBD88',stroke:'#9B7139',text:'#493116'} }),
  asset('service_pack', '外卖打包台', 'service', 3, 2, { price: 2200, buildHours:2, deliveryCapacity:16, draw:{fill:'#D7BC8B',stroke:'#97733E',text:'#453218'} }),
  asset('service_pickup', '骑手取餐架', 'service', 2, 1, { price: 1200, buildHours:1, deliveryCapacity:12, draw:{fill:'#E2CFA6',stroke:'#9B8251',text:'#47391F'} }),
  asset('service_wait', '等位长凳', 'service', 3, 1, { price: 900, environment:1, draw:{fill:'#CBAE7E',stroke:'#86643A',text:'#3E2E1B'} }),

  asset('dining_table_2', '双人桌', 'dining', 2, 2, { price: 880, seats:2, environment:1, draw:{fill:'#E4C79A',stroke:'#956E3C',text:'#493117'} }),
  asset('dining_table_4', '四人桌', 'dining', 3, 3, { price: 1480, seats:4, environment:1.5, draw:{fill:'#DFC18E',stroke:'#8F6838',text:'#493117'} }),
  asset('dining_booth_4', '四人卡座', 'dining', 4, 2, { price: 2600, seats:4, environment:3, draw:{fill:'#C78C71',stroke:'#7E4F3B',text:'#3D241A'} }),
  asset('dining_table_6', '六人桌', 'dining', 4, 3, { price: 2300, seats:6, environment:2, draw:{fill:'#D8B37C',stroke:'#8A6134',text:'#422B16'} }),

  asset('decor_plant', '绿植', 'decor', 1, 1, { price: 280, environment:2.0, draw:{fill:'#8FBC82',stroke:'#50764A',text:'#203E1E'} }),
  asset('decor_lamp', '氛围灯', 'decor', 1, 1, { price: 360, powerKw:0.03, environment:1.7, draw:{fill:'#F1D58B',stroke:'#B48C31',text:'#5A4416'} }),
  asset('decor_partition', '装饰隔断', 'decor', 2, 1, { price: 880, environment:1.2, draw:{fill:'#BFA583',stroke:'#755E42',text:'#382D20'} }),
  asset('decor_sign', '品牌装饰牌', 'decor', 2, 1, { price: 1200, environment:2.4, layer:'wall', draw:{fill:'#C97E55',stroke:'#854931',text:'#FFF6E9'} })
];

const ASSET_BY_ID = Object.fromEntries(ASSETS.map((row) => [row.id, row]));

const AUTO_LAYOUTS = {
  economy: {
    id:'economy', name:'经济快餐型',
    priorities:['service_cashier','service_pass','kitchen_prep','kitchen_induction_2','kitchen_fridge_1','kitchen_sink','dining_table_2','dining_table_4','storage_dry_rack']
  },
  balanced: {
    id:'balanced', name:'堂食均衡型',
    priorities:['service_cashier','service_pass','kitchen_prep','kitchen_wok_2','kitchen_fridge_2','kitchen_sink','kitchen_dishwasher','dining_table_4','dining_table_2','decor_plant']
  },
  delivery: {
    id:'delivery', name:'外卖优先型',
    priorities:['service_cashier','service_pass','service_pack','service_pickup','kitchen_prep','kitchen_induction_2','kitchen_fridge_2','kitchen_sink','storage_dry_rack','dining_table_2']
  }
};

module.exports = {
  GRID_SIZE_METERS,
  LAYER_ORDER,
  CATEGORY_ORDER,
  ASSETS,
  ASSET_BY_ID,
  AUTO_LAYOUTS
};
