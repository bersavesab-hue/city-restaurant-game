'use strict';

// V0866_IMMERSIVE_FREE_BUILD_EDITOR
// Player-facing renovation no longer edits kitchen/storage/service percentages.
// The property shell is fixed; the player draws walls, opens doors and places
// furniture/equipment directly. Space use is inferred from the resulting plan.

const spatial = require('./renovationFreeBuildV0866.js');
const v0862 = require('./renovationEditorV0862.js');

const VERSION = 'V0866_IMMERSIVE_FREE_BUILD_EDITOR';

const ASSET_KEYS = {
  table2:'reno_table_2',
  table4:'reno_table_4',
  table6:'reno_table_6',
  table8:'reno_table_8',
  plant:'reno_plant_1',
  sofa:'reno_sofa',
  screen:'reno_screen',
  pendant:'reno_pendant',
  stove:'reno_stove',
  prep:'reno_prep',
  sink:'reno_sink',
  fridge:'reno_fridge',
  storage_shelf:'reno_storage_shelf',
  cashier:'reno_cashier'
};

const FURNITURE_PALETTE = [
  ['table2','2人桌'],
  ['table4','4人桌'],
  ['table6','6人桌'],
  ['table8','8人桌'],
  ['sofa','沙发'],
  ['plant','绿植']
];

const EQUIPMENT_PALETTE = [
  ['stove','灶台'],
  ['prep','操作台'],
  ['sink','水池'],
  ['fridge','冷柜'],
  ['storage_shelf','货架'],
  ['cashier','收银台']
];

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function shortText(value, max) {
  const text = String(value == null ? '' : value);
  return text.length <= max ? text : text.slice(0, Math.max(1, max - 1)) + '…';
}

function money(value) {
  const n = Number(value) || 0;
  const sign = n < 0 ? '-' : '';
  const abs = Math.abs(n);

  if (abs >= 100000000) {
    return sign + '¥' + (abs / 100000000)
      .toFixed(abs >= 1000000000 ? 1 : 2)
      .replace(/\.0+$/, '') + '亿';
  }

  if (abs >= 10000) {
    return sign + '¥' + (abs / 10000)
      .toFixed(abs >= 1000000 ? 0 : 1)
      .replace(/\.0$/, '') + '万';
  }

  return sign + '¥' + Math.round(abs).toLocaleString();
}

function modeOf(scene) {
  const mode = scene._editorMode || 'select';
  if (mode === 'zones') return 'zones'; // legacy test-only fallback
  if (mode === 'rooms') return 'select';
  return mode;
}

function floorContext(scene, deps, floorIndex) {
  const plan = scene.getPlan();
  const shop = scene.getShop();
  const metrics = scene.getMetrics();

  if (!plan || !shop || !metrics) return null;

  const index = clamp(
    Number.isFinite(Number(floorIndex))
      ? Number(floorIndex)
      : Number(plan.activeFloor) || 0,
    0,
    plan.floors.length - 1
  );

  const floor = plan.floors[index];
  const metric = metrics.floors.find(row => row.index === index) || metrics.floors[index];
  const geometry = metric && metric.geometry || deps.floorGeometrySystem.getFloorGeometry(
    shop,
    index,
    floor.area,
    plan.floors.length
  );

  return { plan, shop, metrics, floor, metric, geometry, index };
}

function selectedPlacement(scene) {
  const plan = scene.getPlan();
  if (!plan || !scene._editorSelectedId) return null;

  for (let floorIndex = 0; floorIndex < (plan.floors || []).length; floorIndex++) {
    const item = (plan.floors[floorIndex].editorPlacements || [])
      .find(row => row.id === scene._editorSelectedId);

    if (item) return { item, floorIndex };
  }

  return null;
}

function syncSignature(plan) {
  plan.editorPlacementVersion = 4;
  plan.editorPlacementSignature = v0862.makeSignature(plan);
}

function ensureFreeBuildFloor(floor) {
  if (!floor) return;

  floor.freeBuildVersion = 1;
  if (!Array.isArray(floor.editorWalls)) floor.editorWalls = [];
  if (!Array.isArray(floor.editorDoors)) floor.editorDoors = [];
  if (!Array.isArray(floor.editorPlacements)) floor.editorPlacements = [];
}

function migrateFreeBuild(scene, deps) {
  if (!scene.shopId) return false;

  deps.renovationSystem.mutatePlan(
    scene.shopId,
    plan => {
      plan.freeBuildVersion = 1;
      plan.editorWallSeq = Math.max(0, Number(plan.editorWallSeq) || 0);
      plan.editorDoorSeq = Math.max(0, Number(plan.editorDoorSeq) || 0);

      for (const floor of plan.floors || []) {
        ensureFreeBuildFloor(floor);
      }
    },
    { skipHistory:true }
  );

  return true;
}

function nextId(plan, type, floorIndex) {
  const key = type === 'wall' ? 'editorWallSeq' : type === 'door' ? 'editorDoorSeq' : 'editorPlacementSeq';
  plan[key] = Math.max(0, Number(plan[key]) || 0) + 1;
  return 'reno_' + type + '_' + floorIndex + '_' + plan[key];
}

function updateCountForAdd(plan, floor, kind, delta) {
  if (spatial.isTable(kind)) {
    const key = String(kind).replace('table','');
    floor.tables[key] = Math.max(0, Number(floor.tables[key]) || 0) + delta;
    floor.tables[key] = Math.max(0, floor.tables[key]);
    return;
  }

  if (['plant','sofa','screen','pendant'].includes(kind)) {
    if (!plan.decorCounts) plan.decorCounts = {};
    plan.decorCounts[kind] = Math.max(0, Number(plan.decorCounts[kind]) || 0) + delta;
    plan.decorCounts[kind] = Math.max(0, plan.decorCounts[kind]);
  }
}

function addPlacement(scene, deps, kind) {
  const ctx = floorContext(scene, deps);
  const spec = spatial.specFor(kind);

  if (!ctx || !spec) {
    return { ok:false, message:'当前物品暂不可放置' };
  }

  ensureFreeBuildFloor(ctx.floor);

  const found = spatial.findFirstValidPosition({
    kind,
    floor:ctx.floor,
    geometry:ctx.geometry,
    placements:ctx.floor.editorPlacements || [],
    floorGeometrySystem:deps.floorGeometrySystem,
    clearDepthM:deps.renovationConfig.zoneRules.entranceClearDepthM,
    rotation:kind === 'table6' || kind === 'table8' ? 90 : 0
  });

  if (!found) {
    return {
      ok:false,
      message:'当前没有可放置' + spec.label + '的位置'
    };
  }

  let createdId = null;

  deps.renovationSystem.mutatePlan(
    scene.shopId,
    plan => {
      const floor = plan.floors[ctx.index];
      ensureFreeBuildFloor(floor);

      createdId = nextId(plan, 'item', ctx.index);
      floor.editorPlacements.push({
        id:createdId,
        kind,
        mx:found.x,
        my:found.y,
        rotation:found.rotation || 0
      });

      updateCountForAdd(plan, floor, kind, 1);
      syncSignature(plan);
    }
  );

  scene._editorSelectedId = createdId;
  deps.saveSystem.autoSave(true);
  scene.requestRenderNow();

  return {
    ok:true,
    message:'已放置' + spec.label + '，可以直接拖动'
  };
}

function deleteSelectedPlacement(scene, deps) {
  const selected = selectedPlacement(scene);
  if (!selected) return { ok:false, message:'请先选中一个物品' };

  deps.renovationSystem.mutatePlan(
    scene.shopId,
    plan => {
      const floor = plan.floors[selected.floorIndex];
      const item = (floor.editorPlacements || []).find(row => row.id === selected.item.id);
      if (!item) return;

      updateCountForAdd(plan, floor, item.kind, -1);
      floor.editorPlacements = (floor.editorPlacements || [])
        .filter(row => row.id !== item.id);
      syncSignature(plan);
    }
  );

  scene._editorSelectedId = null;
  deps.saveSystem.autoSave(true);
  scene.requestRenderNow();
  return { ok:true, message:'已删除' };
}

function rotateSelected(scene, deps) {
  const selected = selectedPlacement(scene);
  if (!selected) return { ok:false, message:'请先选中一个物品' };

  const ctx = floorContext(scene, deps, selected.floorIndex);
  const candidate = {
    ...selected.item,
    rotation:((Number(selected.item.rotation) || 0) + 90) % 180
  };

  const state = spatial.validateCandidate({
    item:candidate,
    floor:ctx.floor,
    geometry:ctx.geometry,
    placements:ctx.floor.editorPlacements || [],
    floorGeometrySystem:deps.floorGeometrySystem,
    clearDepthM:deps.renovationConfig.zoneRules.entranceClearDepthM,
    ignoreId:selected.item.id
  });

  if (!state.valid) {
    return {
      ok:false,
      message:state.issues[0] ? state.issues[0].message : '旋转后空间不足'
    };
  }

  deps.renovationSystem.mutatePlan(
    scene.shopId,
    plan => {
      const item = plan.floors[selected.floorIndex].editorPlacements
        .find(row => row.id === selected.item.id);
      if (item) item.rotation = candidate.rotation;
    }
  );

  deps.saveSystem.autoSave(true);
  scene.requestRenderNow();
  return { ok:true, message:'已旋转90°' };
}

function duplicateSelected(scene, deps) {
  const selected = selectedPlacement(scene);
  if (!selected) return { ok:false, message:'请先选中一个物品' };
  return addPlacement(scene, deps, selected.item.kind);
}

function toModel(scene, x, y) {
  const data = scene.floorCanvasInteraction;
  if (!data || !data.frame) return null;

  const frame = data.frame;
  if (
    x < frame.x ||
    x > frame.x + frame.w ||
    y < frame.y ||
    y > frame.y + frame.h
  ) {
    return null;
  }

  return {
    x:spatial.snap((x - frame.x) / Math.max(0.01, frame.scale)),
    y:spatial.snap((y - frame.y) / Math.max(0.01, frame.scale))
  };
}

function screenPoint(frame, point) {
  return {
    x:frame.x + Number(point.x) * frame.scale,
    y:frame.y + Number(point.y) * frame.scale
  };
}

function screenRect(frame, rect) {
  return {
    x:frame.x + rect.x * frame.scale,
    y:frame.y + rect.y * frame.scale,
    w:rect.w * frame.scale,
    h:rect.h * frame.scale
  };
}

function drawRounded(ctx, x, y, w, h, fill, stroke, radius) {
  ctx.save();
  ctx.beginPath();
  if (typeof ctx.roundRect === 'function') ctx.roundRect(x,y,w,h,radius || 8);
  else ctx.rect(x,y,w,h);
  if (fill) {
    ctx.fillStyle = fill;
    ctx.fill();
  }
  if (stroke) {
    ctx.strokeStyle = stroke;
    ctx.lineWidth = 1;
    ctx.stroke();
  }
  ctx.restore();
}

function drawObstacle(scene, ctx, frame, obstacle) {
  if (obstacle.type === 'column') {
    const p = screenPoint(frame, obstacle);
    ctx.save();
    ctx.beginPath();
    ctx.arc(
      p.x,
      p.y,
      Math.max(4, (Number(obstacle.radius)||0.22) * frame.scale),
      0,
      Math.PI*2
    );
    ctx.fillStyle = '#687271';
    ctx.fill();
    ctx.restore();
    return;
  }

  const x = frame.x + Number(obstacle.x) * frame.scale;
  const y = frame.y + Number(obstacle.y) * frame.scale;
  const w = Number(obstacle.w || 0) * frame.scale;
  const h = Number(obstacle.h || 0) * frame.scale;

  drawRounded(ctx,x,y,w,h,'rgba(102,112,110,0.18)','#78837F',4);
  scene.text(
    ctx,
    obstacle.type === 'toilet' ? '卫生间' : obstacle.type === 'stair' ? '楼梯' : '固定',
    x+w/2,
    y+h/2,
    4.2,
    '#526561',
    '800',
    'center'
  );
}

function drawDoors(scene, ctx, frame, floor) {
  const walls = floor.editorWalls || [];

  for (const rawDoor of floor.editorDoors || []) {
    const wall = walls.find(item => item.id === rawDoor.wallId);
    if (!wall) continue;

    const horizontal = spatial.wallOrientation(wall) === 'horizontal';
    const width = Math.max(0.7, Number(rawDoor.width) || 0.9) * frame.scale;
    const p = screenPoint(frame, { x:rawDoor.cx, y:rawDoor.cy });

    ctx.save();
    ctx.strokeStyle = '#B8842D';
    ctx.lineWidth = 2;

    if (horizontal) {
      ctx.beginPath();
      ctx.moveTo(p.x-width/2,p.y);
      ctx.lineTo(p.x-width/2,p.y-12);
      ctx.arc(p.x-width/2,p.y,12,-Math.PI/2,0);
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.moveTo(p.x,p.y-width/2);
      ctx.lineTo(p.x+12,p.y-width/2);
      ctx.arc(p.x,p.y-width/2,12,0,Math.PI/2);
      ctx.stroke();
    }

    ctx.restore();
  }
}

function drawWalls(scene, ctx, frame, floor) {
  for (const wall of floor.editorWalls || []) {
    const a = screenPoint(frame,{x:wall.x1,y:wall.y1});
    const b = screenPoint(frame,{x:wall.x2,y:wall.y2});
    const selected = scene._v0866SelectedWallId === wall.id;

    ctx.save();
    ctx.strokeStyle = selected ? '#E2A72E' : '#384B49';
    ctx.lineWidth = Math.max(3, Number(wall.thickness || 0.12) * frame.scale);
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(a.x,a.y);
    ctx.lineTo(b.x,b.y);
    ctx.stroke();
    ctx.restore();
  }

  // Paint door openings over the wall, then draw the swing symbol.
  for (const rawDoor of floor.editorDoors || []) {
    const wall = (floor.editorWalls || []).find(item => item.id === rawDoor.wallId);
    if (!wall) continue;

    const p = screenPoint(frame,{x:rawDoor.cx,y:rawDoor.cy});
    const width = Math.max(0.7,Number(rawDoor.width)||0.9)*frame.scale;

    ctx.save();
    ctx.strokeStyle = '#F8F4EC';
    ctx.lineWidth = Math.max(5, Number(wall.thickness || 0.12) * frame.scale + 4);
    ctx.beginPath();

    if (spatial.wallOrientation(wall) === 'horizontal') {
      ctx.moveTo(p.x-width/2,p.y);
      ctx.lineTo(p.x+width/2,p.y);
    } else {
      ctx.moveTo(p.x,p.y-width/2);
      ctx.lineTo(p.x,p.y+width/2);
    }

    ctx.stroke();
    ctx.restore();
  }

  drawDoors(scene,ctx,frame,floor);
}

function drawRoomLabels(scene, ctx, frame, spatialResult) {
  const rooms = spatialResult && spatialResult.rooms || [];

  for (const room of rooms) {
    if (!room.center || room.area < 2.0) continue;
    const p = screenPoint(frame, room.center);

    drawRounded(
      ctx,
      p.x-40,
      p.y-10,
      80,
      20,
      'rgba(255,253,248,0.86)',
      'rgba(74,93,88,0.22)',
      8
    );

    scene.text(
      ctx,
      shortText(room.label + ' ' + room.area.toFixed(1) + '㎡', 16),
      p.x,
      p.y,
      4.3,
      '#526763',
      '800',
      'center'
    );
  }
}

function drawPlacements(scene, ctx, frame, floor, spatialResult) {
  const rects = [];

  for (const original of floor.editorPlacements || []) {
    const item = scene._editorDragPreview && scene._editorDragPreview.id === original.id
      ? { ...original, mx:scene._editorDragPreview.mx, my:scene._editorDragPreview.my }
      : original;

    const spec = spatial.specFor(item.kind);
    if (!spec) continue;

    const p = screenPoint(frame,{x:item.mx,y:item.my});
    const dims = spatial.dimensionsFor(item,false);
    const w = Math.max(18,dims.w*frame.scale);
    const h = Math.max(18,dims.d*frame.scale);
    const selected = scene._editorSelectedId === item.id;

    if (selected) {
      const state = scene._v0866PreviewValidation ||
        spatial.validateCandidate({
          item,
          floor,
          geometry:spatialResult.geometry || scene.floorCanvasInteraction.geometry,
          placements:floor.editorPlacements || [],
          floorGeometrySystem:scene._v0866Deps.floorGeometrySystem,
          clearDepthM:scene._v0866Deps.renovationConfig.zoneRules.entranceClearDepthM,
          ignoreId:item.id
        });

      const use = screenRect(frame,state.use);
      drawRounded(
        ctx,
        use.x,
        use.y,
        use.w,
        use.h,
        state.status === 'red'
          ? 'rgba(207,74,61,0.13)'
          : state.status === 'yellow'
            ? 'rgba(224,164,42,0.13)'
            : 'rgba(36,155,101,0.11)',
        state.status === 'red'
          ? '#CC554A'
          : state.status === 'yellow'
            ? '#D39B27'
            : '#2A9A68',
        5
      );
    }

    ctx.save();
    ctx.translate(p.x,p.y);
    ctx.rotate((Number(item.rotation)||0)*Math.PI/180);

    const key = ASSET_KEYS[item.kind];
    if (!key || !scene.drawImageContain(ctx,key,-w/2,-h/2,w,h,1)) {
      drawRounded(ctx,-w/2,-h/2,w,h,'#E7DED0','#85796A',5);
      scene.text(ctx,shortText(spec.label,5),0,0,4.0,'#4E5D59','800','center');
    }

    ctx.restore();

    rects.push({
      id:item.id,
      x:p.x-Math.max(20,w/2+7),
      y:p.y-Math.max(20,h/2+7),
      w:Math.max(40,w+14),
      h:Math.max(40,h+14)
    });
  }

  scene._editorPlacementRects = rects;
}

function wallHit(scene, x, y, floor) {
  const data = scene.floorCanvasInteraction;
  if (!data || !data.frame) return null;
  const frame = data.frame;
  let best = null;

  for (const wall of floor.editorWalls || []) {
    const a = screenPoint(frame,{x:wall.x1,y:wall.y1});
    const b = screenPoint(frame,{x:wall.x2,y:wall.y2});
    let distance;

    if (Math.abs(a.x-b.x) >= Math.abs(a.y-b.y)) {
      const nx = clamp(x,Math.min(a.x,b.x),Math.max(a.x,b.x));
      distance = Math.hypot(x-nx,y-a.y);
    } else {
      const ny = clamp(y,Math.min(a.y,b.y),Math.max(a.y,b.y));
      distance = Math.hypot(x-a.x,y-ny);
    }

    if (distance <= 13 && (!best || distance < best.distance)) {
      best = { wall, distance };
    }
  }

  return best;
}

function drawToolButton(scene, ctx, id, label, x, active, ui) {
  ui.card(ctx,x,51,66,30,{
    radius:9,
    fill:active ? '#214E49' : '#F5F0E7',
    stroke:active ? '#214E49' : '#D6CCBE',
    shadow:false
  });
  scene.text(ctx,label,x+33,66,5.0,active ? '#FFF8EA' : '#49635E','800','center');
  scene.addButton(id,x,51,66,30);
}

function drawPalette(scene, ctx, rows, y, ui) {
  const x0 = 15;
  const gap = 5;
  const w = 55;

  ui.card(ctx,8,y-4,374,57,{
    radius:13,
    fill:'rgba(255,253,248,0.97)',
    stroke:'#D8CEBF',
    shadow:false
  });

  for (let i=0;i<rows.length;i++) {
    const x=x0+i*(w+gap);
    ui.card(ctx,x,y,w,45,{
      radius:9,
      fill:'#F8F3EA',
      stroke:'#D9CEBF',
      shadow:false
    });
    scene.text(ctx,'＋',x+w/2,y+12,7.0,'#B17D24','800','center');
    scene.text(ctx,rows[i][1],x+w/2,y+31,4.2,'#455F5A','800','center');
    scene.addButton('editor:add:'+rows[i][0],x,y,w,45);
  }
}

function install(options) {
  const {
    RenovationScene,
    renovationSystem,
    renovationConfig,
    floorGeometrySystem,
    saveSystem,
    gameState,
    ui,
    COLORS
  } = options || {};

  if (!RenovationScene || RenovationScene.prototype.__v0866Installed) return false;

  const proto = RenovationScene.prototype;
  proto.__v0866Installed = true;

  const deps = {
    renovationSystem,
    renovationConfig,
    floorGeometrySystem,
    saveSystem,
    gameState,
    ui,
    COLORS
  };

  proto._v0866Deps = deps;

  const oldEnter = proto.enter;
  const oldGetLayout = proto.getLayout;
  const oldHandleTap = proto.handleTap;
  const oldTouchStart = proto.handleTouchStart;
  const oldTouchMove = proto.handleTouchMove;
  const oldTouchEnd = proto.handleTouchEnd;

  proto.enter = function enterV0866(payload) {
    oldEnter.call(this,payload);
    migrateFreeBuild(this,deps);

    if (this.page === 'layout') {
      this._editorMode = payload && payload.page === 'furniture' ? 'furniture' : 'select';
    }

    this._v0866WallStart = null;
    this._v0866SelectedWallId = null;
    this._v0866PreviewValidation = null;
    this.requestRenderNow();
  };

  proto.getLayout = function getLayoutV0866() {
    oldGetLayout.call(this);

    // Renovation is a full-screen editor; global bottom navigation is hidden.
    this.navH = 0;
    this.contentBottom = this.viewH;
  };

  proto.getMainGeometry = function getMainGeometryV0866() {
    const y = 94;
    const footerH = 44;
    const planH = Math.max(430,this.contentBottom-y-footerH-5);

    return {
      y,
      planH,
      lowerY:y+planH,
      lowerH:0,
      footerY:this.contentBottom-footerH,
      footerH
    };
  };

  proto.drawHeader = function drawHeaderV0866(ctx, shop) {
    const metrics = this.getMetrics();
    const cash = deps.gameState && deps.gameState.getPlayer
      ? deps.gameState.getPlayer().cash
      : 0;

    ctx.fillStyle='#F8F3EA';
    ctx.fillRect(0,0,390,48);
    ctx.fillStyle='#214E49';
    ctx.fillRect(0,46,390,2);

    ui.card(ctx,7,7,34,34,{
      radius:9,
      fill:'#214E49',
      stroke:false,
      shadow:false
    });
    this.text(ctx,'‹',24,24,17,'#FFF7E7','800','center');
    this.addButton('back',3,3,42,42);

    this.text(ctx,shortText(shop.name||'我的餐厅',9),50,15,8.5,'#193F3B','800');
    this.text(
      ctx,
      '资金 '+money(cash)+' · 装修 '+money(metrics&&metrics.totalCost),
      50,
      34,
      4.7,
      '#6A7A76',
      '700'
    );

    ui.card(ctx,317,8,65,31,{
      radius:9,
      fill:'#FFFDF8',
      stroke:'#CFC4B5',
      shadow:false
    });
    this.text(ctx,'模板/更多',349.5,23.5,4.6,'#455F5A','800','center');
    this.addButton('page:templates',313,4,73,39);
  };

  proto.drawFloorCanvas = function drawFloorCanvasV0866(ctx, metrics, floor, x, y, w, h) {
    const geometry = floor.geometry ||
      deps.floorGeometrySystem.getFloorGeometry(
        this.getShop(),
        floor.index,
        floor.area,
        metrics.plan.floors.length
      );

    const frame = this.getGeometryFrame(
      geometry,
      x+5,
      y+5,
      w-10,
      h-10
    );

    const kitchenRatio = clamp(Number(floor.kitchenRatio)||0,0,1);
    const storageRatio = clamp(Number(floor.storageRatio)||0,0,1);
    const serviceRatio = clamp(Number(floor.serviceRatio)||0,0,1);
    const diningRatio = Math.max(0,1-kitchenRatio-storageRatio-serviceRatio);
    const backRatio = clamp(kitchenRatio+storageRatio,0.01,0.88);
    const lowerRatio = Math.max(0.01,serviceRatio+diningRatio);

    this.floorCanvasInteraction = {
      frame,
      floorIndex:floor.index,
      geometry,
      // Legacy hidden values: only retained so old saves/tests can still
      // complete a historical zone-drag action. The V0.8.66 UI never exposes it.
      backRatio,
      kitchenWidthRatio:clamp(kitchenRatio/backRatio,0.08,0.92),
      serviceWidthRatio:clamp(serviceRatio/lowerRatio,0.05,0.72)
    };

    ctx.save();
    this.geometryPath(ctx,geometry,frame);
    ctx.clip();

    ctx.fillStyle='#F8F4EC';
    ctx.fillRect(frame.x,frame.y,frame.w,frame.h);

    // Visible 0.5m construction grid.
    ctx.strokeStyle='rgba(62,87,82,0.12)';
    ctx.lineWidth=0.7;
    const step=Math.max(6,spatial.VISIBLE_GRID_M*frame.scale);

    for(let gx=frame.x;gx<=frame.x+frame.w;gx+=step){
      ctx.beginPath();
      ctx.moveTo(gx,frame.y);
      ctx.lineTo(gx,frame.y+frame.h);
      ctx.stroke();
    }

    for(let gy=frame.y;gy<=frame.y+frame.h;gy+=step){
      ctx.beginPath();
      ctx.moveTo(frame.x,gy);
      ctx.lineTo(frame.x+frame.w,gy);
      ctx.stroke();
    }

    ctx.restore();

    this.drawGeometryShell(ctx,geometry,frame);

    for (const obstacle of geometry.obstacles || []) {
      drawObstacle(this,ctx,frame,obstacle);
    }

    // External entrance.
    for (const entrance of geometry.entrances || []) {
      const p=screenPoint(frame,entrance);
      const width=Math.max(12,(Number(entrance.width)||1.2)*frame.scale);
      ctx.save();
      ctx.strokeStyle='#C75849';
      ctx.lineWidth=3;
      ctx.beginPath();
      ctx.moveTo(p.x-width/2,p.y);
      ctx.lineTo(p.x+width/2,p.y);
      ctx.stroke();
      ctx.restore();
    }

    drawWalls(this,ctx,frame,floor);

    const spatialResult = (metrics.floors.find(row=>row.index===floor.index)||{}).spatial || {};
    spatialResult.geometry = geometry;
    drawPlacements(this,ctx,frame,floor,spatialResult);
    drawRoomLabels(this,ctx,frame,spatialResult);

    if (this._v0866WallStart) {
      const a=screenPoint(frame,this._v0866WallStart);
      const preview=this._v0866WallPreview || this._v0866WallStart;
      const b=screenPoint(frame,preview);

      ctx.save();
      ctx.strokeStyle='#DAA32D';
      ctx.setLineDash([6,4]);
      ctx.lineWidth=3;
      ctx.beginPath();
      ctx.moveTo(a.x,a.y);
      ctx.lineTo(b.x,b.y);
      ctx.stroke();
      ctx.restore();
    }
  };

  proto.drawFloorPlan = function drawFloorPlanV0866(ctx, metrics, floor, geometry) {
    const mode=modeOf(this);
    const y=geometry.y;
    const h=geometry.planH;

    drawToolButton(this,ctx,'editor:mode:select','选择',8,mode==='select',ui);
    drawToolButton(this,ctx,'editor:mode:wall','建墙',83,mode==='wall',ui);
    drawToolButton(this,ctx,'editor:mode:door','开门',158,mode==='door',ui);
    drawToolButton(this,ctx,'page:furniture','家具',233,mode==='furniture',ui);
    drawToolButton(this,ctx,'editor:mode:equipment','设备',308,mode==='equipment',ui);

    ui.card(ctx,6,y,378,h,{
      radius:13,
      fill:'#FFFDF8',
      stroke:'#D8CEBF',
      shadow:false
    });

    this.drawFloorCanvas(ctx,metrics,floor,10,y+4,370,h-8);

    // Floating floor/history/preview controls.
    ui.card(ctx,17,y+11,54,25,{
      radius:9,
      fill:'rgba(255,253,248,0.92)',
      stroke:'#D5CAB9',
      shadow:false
    });
    this.text(ctx,(metrics.plan.activeFloor+1)+'F',44,y+23.5,4.8,'#355A55','800','center');
    this.addButton('floor:next',14,y+8,60,31);

    const topActions=[
      ['history:undo','↶'],
      ['history:redo','↷'],
      ['preview','预览']
    ];

    let ax=276;
    for(let i=0;i<topActions.length;i++){
      const aw=i===2?55:34;
      ui.card(ctx,ax,y+10,aw,27,{
        radius:9,
        fill:'rgba(255,253,248,0.94)',
        stroke:'#D5CAB9',
        shadow:false
      });
      this.text(ctx,topActions[i][1],ax+aw/2,y+23.5,i===2?4.4:8.0,'#355A55','800','center');
      this.addButton(topActions[i][0],ax-2,y+7,aw+4,33);
      ax+=aw+5;
    }

    const activeFloor = metrics.floors[metrics.plan.activeFloor];
    const roomCount = activeFloor && activeFloor.spatial
      ? Number(activeFloor.spatial.roomCount)||0
      : 0;

    const chips=[
      metrics.totalSeats+'席',
      money(metrics.totalCost),
      roomCount+'空间'
    ];

    let cx=18;
    for(const chip of chips){
      const cw=Math.max(58,22+String(chip).length*7);
      ui.card(ctx,cx,y+43,cw,24,{
        radius:10,
        fill:'rgba(33,78,73,0.88)',
        stroke:false,
        shadow:false
      });
      this.text(ctx,chip,cx+cw/2,y+55,4.4,'#FFF8E8','800','center');
      cx+=cw+5;
    }

    const selected=selectedPlacement(this);

    if (selected) {
      ui.card(ctx,49,y+h-53,292,46,{
        radius:12,
        fill:'rgba(255,253,248,0.97)',
        stroke:'#D8CEBF',
        shadow:false
      });

      const actions=[
        ['editor:rotate','旋转'],
        ['editor:duplicate','复制'],
        ['editor:delete','删除'],
        ['editor:done','完成']
      ];

      for(let i=0;i<actions.length;i++){
        const bx=57+i*70;
        ui.card(ctx,bx,y+h-47,63,34,{
          radius:9,
          fill:actions[i][0]==='editor:delete'?'#FFF0EA':'#F5F0E7',
          stroke:'#D7CCBD',
          shadow:false
        });
        this.text(
          ctx,
          actions[i][1],
          bx+31.5,
          y+h-30,
          4.7,
          actions[i][0]==='editor:delete'?'#B84A42':'#455F5A',
          '800',
          'center'
        );
        this.addButton(actions[i][0],bx,y+h-47,63,34);
      }
    } else if (mode==='furniture') {
      drawPalette(this,ctx,FURNITURE_PALETTE,y+h-58,ui);
    } else if (mode==='equipment') {
      drawPalette(this,ctx,EQUIPMENT_PALETTE,y+h-58,ui);
    } else if (this._v0866SelectedWallId) {
      ui.card(ctx,92,y+h-50,206,42,{
        radius:11,
        fill:'rgba(255,253,248,0.97)',
        stroke:'#D8CEBF',
        shadow:false
      });
      this.text(ctx,'已选中内墙',106,y+h-29,4.7,'#455F5A','800');
      ui.card(ctx,215,y+h-44,74,30,{
        radius:9,
        fill:'#FFF0EA',
        stroke:'#D9B1AA',
        shadow:false
      });
      this.text(ctx,'拆除墙体',252,y+h-29,4.6,'#B84A42','800','center');
      this.addButton('editor:wall:delete',211,y+h-47,82,36);
    } else if (mode==='wall' || mode==='door') {
      const hint = mode==='wall'
        ? (this._v0866WallStart ? '再点一次确定终点 · 自动横/竖吸附' : '在平面图点起点，再点终点建墙')
        : '直接点已有墙体开0.9m室内门';

      ui.card(ctx,52,y+h-43,286,32,{
        radius:11,
        fill:'rgba(255,248,225,0.96)',
        stroke:'#DAB35A',
        shadow:false
      });
      this.text(ctx,hint,195,y+h-27,4.5,'#765B24','800','center');
    }
  };

  // These legacy lower panels consumed 60-68px. Free-build keeps diagnostics
  // as floating chips/messages on the canvas instead.
  proto.drawTablePicker = function drawTablePickerV0866() {};
  proto.drawMetrics = function drawMetricsV0866() {};

  proto.drawFooter = function drawFooterV0866(ctx, metrics, geometry) {
    const y=geometry.footerY+4;
    const floor=metrics.floors[metrics.plan.activeFloor];
    const spatialResult=floor.spatial||{};
    const primary=spatialResult.primaryIssue ||
      (floor.areaWarnings && floor.areaWarnings[0]
        ? {message:floor.areaWarnings[0]}
        : null);

    ui.card(ctx,8,y,76,34,{
      radius:10,
      fill:'#FFFDF8',
      stroke:'#D5CAB9',
      shadow:false
    });
    this.text(ctx,'预览',46,y+17,5.0,'#455F5A','800','center');
    this.addButton('preview',5,y-2,82,38);

    ui.card(ctx,92,y,290,34,{
      radius:10,
      fill:metrics.valid?'#E2BB46':'#E3DED5',
      stroke:metrics.valid?'#C99D29':'#CEC5B8',
      shadow:false
    });

    this.text(
      ctx,
      metrics.valid
        ? '确认装修方案 · 选择施工队  ›'
        : shortText(primary?primary.message:'当前空间需要调整',28),
      237,
      y+17,
      metrics.valid?5.7:4.5,
      metrics.valid?'#304843':'#756D64',
      '800',
      'center'
    );

    if(metrics.valid){
      this.addButton('construction:start',89,y-2,296,38);
    }
  };

  proto.handleTap = function handleTapV0866(x,y) {
    const hit=this.hitButton(x,y);

    if(hit){
      const id=hit.id;

      if(id==='editor:mode:select'){
        this._editorMode='select';
        this._v0866WallStart=null;
        this._v0866SelectedWallId=null;
        this.requestRenderNow();
        return true;
      }

      if(id==='editor:mode:wall'){
        this._editorMode='wall';
        this._editorSelectedId=null;
        this._v0866SelectedWallId=null;
        this._v0866WallStart=null;
        this.requestRenderNow();
        return true;
      }

      if(id==='editor:mode:door'){
        this._editorMode='door';
        this._editorSelectedId=null;
        this._v0866SelectedWallId=null;
        this._v0866WallStart=null;
        this.requestRenderNow();
        return true;
      }

      if(id==='page:furniture'){
        this.page='layout';
        this._editorMode='furniture';
        this._v0866WallStart=null;
        this._v0866SelectedWallId=null;
        this.requestRenderNow();
        return true;
      }

      if(id==='editor:mode:equipment'){
        this._editorMode='equipment';
        this._v0866WallStart=null;
        this._v0866SelectedWallId=null;
        this.requestRenderNow();
        return true;
      }

      if(id.indexOf('editor:add:')===0){
        const result=addPlacement(this,deps,id.slice('editor:add:'.length));
        this.showToast(result.message);
        return true;
      }

      if(id==='editor:rotate'){
        const result=rotateSelected(this,deps);
        this.showToast(result.message);
        return true;
      }

      if(id==='editor:duplicate'){
        const result=duplicateSelected(this,deps);
        this.showToast(result.message);
        return true;
      }

      if(id==='editor:delete'){
        const result=deleteSelectedPlacement(this,deps);
        this.showToast(result.message);
        return true;
      }

      if(id==='editor:done'){
        this._editorSelectedId=null;
        this._v0866PreviewValidation=null;
        this.requestRenderNow();
        return true;
      }

      if(id==='editor:wall:delete' && this._v0866SelectedWallId){
        const wallId=this._v0866SelectedWallId;

        deps.renovationSystem.mutatePlan(
          this.shopId,
          plan=>{
            const floor=plan.floors[Number(plan.activeFloor)||0];
            floor.editorWalls=(floor.editorWalls||[]).filter(row=>row.id!==wallId);
            floor.editorDoors=(floor.editorDoors||[]).filter(row=>row.wallId!==wallId);
          }
        );

        this._v0866SelectedWallId=null;
        deps.saveSystem.autoSave(true);
        this.requestRenderNow();
        this.showToast('墙体已拆除');
        return true;
      }
    }

    if(this.page==='layout'){
      const point=toModel(this,x,y);
      const ctx=floorContext(this,deps);

      if(point && ctx){
        const mode=modeOf(this);

        if(mode==='wall'){
          if(!this._v0866WallStart){
            this._v0866WallStart=point;
            this._v0866WallPreview=point;
            this.requestRenderNow();
            return true;
          }

          const start=this._v0866WallStart;
          const end={
            x:Math.abs(point.x-start.x)>=Math.abs(point.y-start.y)?point.x:start.x,
            y:Math.abs(point.x-start.x)>=Math.abs(point.y-start.y)?start.y:point.y
          };

          const candidate={
            id:'__wall__',
            x1:start.x,
            y1:start.y,
            x2:end.x,
            y2:end.y,
            thickness:spatial.WALL_THICKNESS_M
          };

          const state=spatial.validateWallCandidate({
            wall:candidate,
            floor:ctx.floor,
            geometry:ctx.geometry,
            placements:ctx.floor.editorPlacements||[],
            floorGeometrySystem:deps.floorGeometrySystem
          });

          if(!state.valid){
            this.showToast(state.issues[0]?state.issues[0].message:'这里不能建墙');
          }else{
            deps.renovationSystem.mutatePlan(
              this.shopId,
              plan=>{
                const floor=plan.floors[ctx.index];
                ensureFreeBuildFloor(floor);
                const wall={...state.wall,id:nextId(plan,'wall',ctx.index)};
                floor.editorWalls.push(wall);
              }
            );
            deps.saveSystem.autoSave(true);
            this.showToast('已建墙 '+state.length.toFixed(2)+'m');
          }

          this._v0866WallStart=null;
          this._v0866WallPreview=null;
          this.requestRenderNow();
          return true;
        }

        if(mode==='door'){
          const result=spatial.makeDoorAt(ctx.floor,point,0.90);

          if(!result.ok){
            this.showToast(result.message);
            return true;
          }

          deps.renovationSystem.mutatePlan(
            this.shopId,
            plan=>{
              const floor=plan.floors[ctx.index];
              ensureFreeBuildFloor(floor);
              const door={...result.door,id:nextId(plan,'door',ctx.index)};
              floor.editorDoors.push(door);
            }
          );

          deps.saveSystem.autoSave(true);
          this.requestRenderNow();
          this.showToast('已开0.90m室内门');
          return true;
        }

        if(mode==='select'){
          const found=wallHit(this,x,y,ctx.floor);
          if(found){
            this._v0866SelectedWallId=found.wall.id;
            this._editorSelectedId=null;
            this.requestRenderNow();
            return true;
          }

          this._v0866SelectedWallId=null;
        }
      }
    }

    return oldHandleTap.call(this,x,y);
  };

  proto.handleTouchStart = function handleTouchStartV0866(x,y) {
    const mode=modeOf(this);

    // Keep the old hidden zone drag only for legacy regression tests/saves.
    if(mode==='zones'){
      return oldTouchStart.call(this,x,y);
    }

    if(
      this.page==='layout' &&
      ['select','furniture','equipment'].includes(mode)
    ){
      const rects=this._editorPlacementRects||[];

      for(let i=rects.length-1;i>=0;i--){
        const rect=rects[i];
        if(
          x>=rect.x&&x<=rect.x+rect.w&&
          y>=rect.y&&y<=rect.y+rect.h
        ){
          const ctx=floorContext(this,deps);
          const item=ctx && (ctx.floor.editorPlacements||[]).find(row=>row.id===rect.id);
          if(!item) break;

          this._editorSelectedId=item.id;
          this._v0866SelectedWallId=null;

          deps.renovationSystem.mutatePlan(
            this.shopId,
            ()=>{},
            {skipHistory:false}
          );

          this._editorPlacementDrag={
            id:item.id,
            floorIndex:ctx.index,
            start:{mx:item.mx,my:item.my}
          };

          this._editorDragPreview={id:item.id,mx:item.mx,my:item.my};
          this._v0866PreviewValidation=null;
          this.requestRenderNow();
          return true;
        }
      }
    }

    return false;
  };

  proto.handleTouchMove = function handleTouchMoveV0866(x,y) {
    const mode=modeOf(this);

    if(mode==='zones'){
      return oldTouchMove.call(this,x,y);
    }

    if(this._v0866WallStart && mode==='wall'){
      const point=toModel(this,x,y);
      if(point){
        const start=this._v0866WallStart;
        this._v0866WallPreview={
          x:Math.abs(point.x-start.x)>=Math.abs(point.y-start.y)?point.x:start.x,
          y:Math.abs(point.x-start.x)>=Math.abs(point.y-start.y)?start.y:point.y
        };
        this.requestRenderNow();
        return true;
      }
    }

    if(this._editorPlacementDrag && this.floorCanvasInteraction){
      const selected=selectedPlacement(this);
      const ctx=selected&&floorContext(this,deps,selected.floorIndex);
      const frame=this.floorCanvasInteraction.frame;

      if(!selected||!ctx||!frame) return true;

      const mx=spatial.snap(
        clamp((x-frame.x)/Math.max(0.01,frame.scale),0,ctx.geometry.widthM)
      );
      const my=spatial.snap(
        clamp((y-frame.y)/Math.max(0.01,frame.scale),0,ctx.geometry.depthM)
      );

      const candidate={...selected.item,mx,my};

      this._editorDragPreview={id:selected.item.id,mx,my};
      this._v0866PreviewValidation=spatial.validateCandidate({
        item:candidate,
        floor:ctx.floor,
        geometry:ctx.geometry,
        placements:ctx.floor.editorPlacements||[],
        floorGeometrySystem:deps.floorGeometrySystem,
        clearDepthM:deps.renovationConfig.zoneRules.entranceClearDepthM,
        ignoreId:selected.item.id
      });

      this.requestRenderNow();
      return true;
    }

    return false;
  };

  proto.handleTouchEnd = function handleTouchEndV0866() {
    const mode=modeOf(this);

    if(mode==='zones'){
      return oldTouchEnd.call(this);
    }

    if(this._editorPlacementDrag){
      const selected=selectedPlacement(this);
      const preview=this._editorDragPreview;
      const validation=this._v0866PreviewValidation;

      if(selected&&preview&&validation&&validation.valid){
        deps.renovationSystem.mutatePlan(
          this.shopId,
          plan=>{
            const item=plan.floors[selected.floorIndex].editorPlacements
              .find(row=>row.id===selected.item.id);

            if(item){
              item.mx=spatial.snap(preview.mx);
              item.my=spatial.snap(preview.my);
              syncSignature(plan);
            }
          },
          {skipHistory:true}
        );

        if(validation.status==='yellow'&&validation.issues[0]){
          this.showToast('已放置，但'+validation.issues[0].message);
        }
      }else if(validation&&validation.issues[0]){
        this.showToast('不能放这里：'+validation.issues[0].message);
      }

      this._editorPlacementDrag=null;
      this._editorDragPreview=null;
      this._v0866PreviewValidation=null;
      deps.saveSystem.autoSave(true);
      this.requestRenderNow();
      return true;
    }

    return false;
  };

  return true;
}

module.exports={
  VERSION,
  install,
  addPlacement,
  rotateSelected,
  deleteSelectedPlacement
};
