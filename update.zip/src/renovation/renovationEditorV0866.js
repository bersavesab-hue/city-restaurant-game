'use strict';

// V0866_IMMERSIVE_FREE_BUILD_EDITOR
// Large-canvas mobile editor: select / wall / door / furniture / equipment.
// Player no longer edits kitchen/front-of-house percentages.

const spatial = require('./renovationFreeBuildV0866.js');

const VERSION = '0.8.66';

function clamp(v,min,max){ return Math.max(min,Math.min(max,Number(v)||0)); }
function money(v){
  const n=Number(v)||0,abs=Math.abs(n);
  if(abs>=10000) return (n<0?'-':'')+'¥'+(abs/10000).toFixed(abs>=1000000?0:1).replace(/\.0$/,'')+'万';
  return (n<0?'-':'')+'¥'+Math.round(abs).toLocaleString();
}
function short(v,n){ const s=String(v==null?'':v);return s.length<=n?s:s.slice(0,Math.max(1,n-1))+'…'; }

const IMAGE_KEY = {
  table2:'reno_table_2', table4:'reno_table_4', table6:'reno_table_6', table8:'reno_table_8',
  stove:'reno_stove', prep:'reno_prep', sink:'reno_sink', fridge:'reno_fridge',
  shelf:'reno_storage_shelf', cashier:'reno_cashier',
  plant:'reno_plant_1', sofa:'reno_sofa', screen:'reno_screen'
};

function mode(scene){ return scene._v0866Mode || 'select'; }

function currentContext(scene,deps){
  const plan=scene.getPlan(),shop=scene.getShop(),metrics=scene.getMetrics();
  if(!plan||!shop||!metrics) return null;
  const index=clamp(Number(plan.activeFloor)||0,0,plan.floors.length-1);
  const floor=plan.floors[index];
  const metric=metrics.floors.find(x=>x.index===index)||metrics.floors[index];
  const geometry=metric&&metric.geometry || deps.floorGeometrySystem.getFloorGeometry(shop,index,floor.area,plan.floors.length);
  return {plan,shop,metrics,index,floor,metric,geometry};
}

function ensureFreeBuild(scene,deps){
  if(!scene.shopId) return;
  deps.renovationSystem.mutatePlan(
    scene.shopId,
    plan=>{
      plan.freeBuildVersion=1;
      plan.freeBuildSeq=Math.max(0,Number(plan.freeBuildSeq)||0);
      for(const floor of plan.floors||[]){
        floor.freeBuildVersion=1;
        if(!Array.isArray(floor.editorWalls)) floor.editorWalls=[];
        if(!Array.isArray(floor.editorDoors)) floor.editorDoors=[];
        if(!Array.isArray(floor.editorPlacements)) floor.editorPlacements=[];
      }
    },
    {skipHistory:true}
  );
}

function nextId(plan,prefix){
  plan.freeBuildSeq=Math.max(0,Number(plan.freeBuildSeq)||0)+1;
  return 'v0866_'+prefix+'_'+plan.freeBuildSeq;
}

function screenPoint(frame,p){
  return {x:frame.x+Number(p.x)*frame.scale,y:frame.y+Number(p.y)*frame.scale};
}
function modelPoint(frame,x,y){
  return {
    x:spatial.snap(clamp((x-frame.x)/Math.max(.01,frame.scale),0,frame.geometry.widthM)),
    y:spatial.snap(clamp((y-frame.y)/Math.max(.01,frame.scale),0,frame.geometry.depthM))
  };
}

function bodyScreenRect(frame,item){
  const r=spatial.rectFor(item,false);
  return {
    x:frame.x+r.x*frame.scale,
    y:frame.y+r.y*frame.scale,
    w:r.w*frame.scale,
    h:r.h*frame.scale
  };
}

function addPlacement(scene,deps,kind){
  const ctx=currentContext(scene,deps);
  if(!ctx) return {ok:false,message:'装修数据不可用'};
  const spec=spatial.specFor(kind);
  if(!spec) return {ok:false,message:'未知家具/设备'};

  const found=spatial.findFirstValidPosition({
    kind,
    floor:ctx.floor,
    geometry:ctx.geometry,
    placements:ctx.floor.editorPlacements||[],
    floorGeometrySystem:deps.floorGeometrySystem,
    clearDepthM:deps.renovationConfig.zoneRules.entranceClearDepthM,
    rotation:0
  });
  if(!found) return {ok:false,message:'当前没有合法位置放置'+spec.label};

  let created=null;
  deps.renovationSystem.mutatePlan(scene.shopId,plan=>{
    const floor=plan.floors[ctx.index];
    const id=nextId(plan,kind);
    const item={id,kind,mx:found.x,my:found.y,rotation:0};
    floor.editorPlacements.push(item);
    if(spatial.isTable(kind)){
      const key=kind.replace('table','');
      floor.tables[key]=Math.max(0,Number(floor.tables[key])||0)+1;
    }else if(kind==='plant'||kind==='sofa'||kind==='screen'){
      plan.decorCounts=plan.decorCounts||{};
      plan.decorCounts[kind]=Math.max(0,Number(plan.decorCounts[kind])||0)+1;
    }
    created=id;
  });
  scene._v0866Selected={type:'placement',id:created};
  deps.saveSystem.autoSave(true);
  scene.requestRenderNow();
  return {ok:true,message:'已放置'+spec.label};
}

function findSelectedPlacement(scene){
  const ctx=currentContext(scene,scene._v0866Deps);
  if(!ctx||!scene._v0866Selected||scene._v0866Selected.type!=='placement') return null;
  const item=(ctx.floor.editorPlacements||[]).find(x=>x.id===scene._v0866Selected.id);
  return item?{ctx,item}:null;
}

function rotateSelected(scene,deps){
  const found=findSelectedPlacement(scene);
  if(!found) return {ok:false,message:'请先选中家具或设备'};
  const candidate={...found.item,rotation:((Number(found.item.rotation)||0)+90)%180};
  const v=spatial.validateCandidate({
    item:candidate,floor:found.ctx.floor,geometry:found.ctx.geometry,
    placements:found.ctx.floor.editorPlacements||[],ignoreId:found.item.id,
    floorGeometrySystem:deps.floorGeometrySystem,
    clearDepthM:deps.renovationConfig.zoneRules.entranceClearDepthM
  });
  if(!v.valid) return {ok:false,message:v.issues[0]?v.issues[0].message:'旋转后空间不足'};
  deps.renovationSystem.mutatePlan(scene.shopId,plan=>{
    const item=plan.floors[found.ctx.index].editorPlacements.find(x=>x.id===found.item.id);
    if(item) item.rotation=candidate.rotation;
  });
  deps.saveSystem.autoSave(true);scene.requestRenderNow();
  return {ok:true,message:'已旋转90°'};
}

function deleteSelected(scene,deps){
  const ctx=currentContext(scene,deps),sel=scene._v0866Selected;
  if(!ctx||!sel) return {ok:false,message:'请先选择对象'};

  let removed=false;
  deps.renovationSystem.mutatePlan(scene.shopId,plan=>{
    const floor=plan.floors[ctx.index];
    if(sel.type==='placement'){
      const idx=floor.editorPlacements.findIndex(x=>x.id===sel.id);
      if(idx>=0){
        const item=floor.editorPlacements[idx];
        floor.editorPlacements.splice(idx,1);
        if(spatial.isTable(item.kind)){
          const key=item.kind.replace('table','');
          floor.tables[key]=Math.max(0,(Number(floor.tables[key])||0)-1);
        }else if(item.kind==='plant'||item.kind==='sofa'||item.kind==='screen'){
          plan.decorCounts=plan.decorCounts||{};
          plan.decorCounts[item.kind]=Math.max(0,(Number(plan.decorCounts[item.kind])||0)-1);
        }
        removed=true;
      }
    }else if(sel.type==='wall'){
      const before=floor.editorWalls.length;
      floor.editorWalls=floor.editorWalls.filter(x=>x.id!==sel.id);
      floor.editorDoors=floor.editorDoors.filter(x=>x.wallId!==sel.id);
      removed=floor.editorWalls.length!==before;
    }else if(sel.type==='door'){
      const before=floor.editorDoors.length;
      floor.editorDoors=floor.editorDoors.filter(x=>x.id!==sel.id);
      removed=floor.editorDoors.length!==before;
    }
  });
  scene._v0866Selected=null;
  deps.saveSystem.autoSave(true);scene.requestRenderNow();
  return {ok:removed,message:removed?'已删除':'没有找到对象'};
}

function drawWall(ctx,frame,wall,doors,selected){
  const vertical=Math.abs(wall.x1-wall.x2)<.01;
  const gaps=(doors||[]).filter(d=>d.wallId===wall.id).slice().sort((a,b)=>vertical?a.y-b.y:a.x-b.x);
  ctx.save();
  ctx.strokeStyle=selected?'#F0A51B':'#313B3A';
  ctx.lineWidth=selected?5:4;
  ctx.lineCap='square';

  function seg(a,b){
    const p1=screenPoint(frame,a),p2=screenPoint(frame,b);
    ctx.beginPath();ctx.moveTo(p1.x,p1.y);ctx.lineTo(p2.x,p2.y);ctx.stroke();
  }

  if(!gaps.length){
    seg({x:wall.x1,y:wall.y1},{x:wall.x2,y:wall.y2});
  }else if(vertical){
    let cursor=Math.min(wall.y1,wall.y2),end=Math.max(wall.y1,wall.y2),x=wall.x1;
    for(const d of gaps){
      const half=(Number(d.width)||.9)/2;
      const a=clamp(Number(d.y)-half,cursor,end),b=clamp(Number(d.y)+half,cursor,end);
      if(a>cursor) seg({x,y:cursor},{x,y:a});
      cursor=Math.max(cursor,b);
    }
    if(cursor<end) seg({x,y:cursor},{x,y:end});
  }else{
    let cursor=Math.min(wall.x1,wall.x2),end=Math.max(wall.x1,wall.x2),y=wall.y1;
    for(const d of gaps){
      const half=(Number(d.width)||.9)/2;
      const a=clamp(Number(d.x)-half,cursor,end),b=clamp(Number(d.x)+half,cursor,end);
      if(a>cursor) seg({x:cursor,y},{x:a,y});
      cursor=Math.max(cursor,b);
    }
    if(cursor<end) seg({x:cursor,y},{x:end,y});
  }
  ctx.restore();

  for(const d of gaps){
    const p=screenPoint(frame,{x:d.x,y:d.y});
    ctx.save();
    ctx.strokeStyle='#2D91BD';ctx.lineWidth=2;
    ctx.beginPath();ctx.arc(p.x,p.y,5,0,Math.PI*2);ctx.stroke();ctx.restore();
  }
}

function install(options){
  const o=options||{},RenovationScene=o.RenovationScene;
  if(!RenovationScene||!RenovationScene.prototype||RenovationScene.prototype.__v0866Installed) return false;

  const proto=RenovationScene.prototype;
  proto.__v0866Installed=true;

  const deps={
    renovationSystem:o.renovationSystem,
    renovationConfig:o.renovationConfig,
    floorGeometrySystem:o.floorGeometrySystem,
    saveSystem:o.saveSystem,
    gameState:o.gameState,
    ui:o.ui,
    COLORS:o.COLORS
  };

  const oldEnter=proto.enter;
  const oldGetLayout=proto.getLayout;
  const oldRenderConstruction=proto.renderConstruction;
  const oldRenderPreview=proto.renderPreview;
  const oldHandleTap=proto.handleTap;
  const oldTouchStart=proto.handleTouchStart;
  const oldTouchMove=proto.handleTouchMove;
  const oldTouchEnd=proto.handleTouchEnd;

  proto.enter=function(payload){
    oldEnter.call(this,payload);
    this._v0866Deps=deps;

    const incomingPage =
      this.page;

    this.page =
      ['style','templates','contractors']
        .includes(
          incomingPage
        )
        ? incomingPage
        : 'layout';

    this._v0866Mode=
      incomingPage === 'furniture'
        ? 'furniture'
        : 'select';
    this._v0866Selected=null;
    this._v0866WallStart=null;
    this._v0866Drag=null;
    this._v0866DragPreview=null;
    ensureFreeBuild(this,deps);
  };

  proto.getLayout=function(){
    oldGetLayout.call(this);
    // Immersive editor: global bottom nav is hidden by main.js and no space is reserved here.
    this.navH=0;
    this.contentBottom=this.viewH;
  };

  proto.getMainGeometry=function(){
    const y=84;
    const footerH=48;
    const planH=Math.max(390,this.viewH-y-footerH-6);
    return {y,planH,lowerY:y+planH,lowerH:0,footerY:this.viewH-footerH,footerH};
  };

  proto.drawHeader=function(ctx,shop){
    const metrics=this.getMetrics();
    const cash=deps.gameState.getPlayer().cash;
    ctx.save();
    ctx.fillStyle='#F7F1E7';ctx.fillRect(0,0,390,46);
    ctx.fillStyle='#153E3D';ctx.fillRect(0,44,390,2);

    deps.ui.card(ctx,7,6,34,34,{radius:10,fill:'#153E3D',stroke:false,shadow:false});
    this.text(ctx,'‹',24,23,17,'#FFF7E8','800','center');
    this.addButton('back',3,3,42,40);

    this.text(ctx,short(shop.name||'我的餐厅',9),50,15,8.2,'#173C3B','800');
    this.text(ctx,'资金 '+money(cash)+'  ·  装修 '+money(metrics&&metrics.totalCost),50,33,4.5,'#6F7C78','700');

    deps.ui.card(ctx,302,7,38,30,{radius:9,fill:'#FFFDF7',stroke:'#D2C8B9',shadow:false});
    this.text(ctx,'↶',321,22,8,'#355754','800','center');
    this.addButton('history:undo',299,4,44,36);
    deps.ui.card(ctx,344,7,38,30,{radius:9,fill:'#FFFDF7',stroke:'#D2C8B9',shadow:false});
    this.text(ctx,'↷',363,22,8,'#355754','800','center');
    this.addButton('history:redo',341,4,44,36);
    ctx.restore();
  };

  proto.drawFloorCanvas=function(ctx,metrics,floor,x,y,w,h){
    const floorMetric=metrics.floors.find(row=>row.index===floor.index)||metrics.floors[metrics.plan.activeFloor];
    const geometry=floorMetric.geometry;
    const frame=this.drawGeometryShell(ctx,geometry,x,y,w,h);
    frame.geometry=geometry;
    this.floorCanvasInteraction={frame,floorIndex:floor.index};
    this._v0866Canvas={frame,geometry,floorIndex:floor.index};
    this._v0866ItemRects=[];

    // 0.5m visible grid.
    ctx.save();
    this.geometryPath(ctx,geometry,frame);ctx.clip();
    ctx.strokeStyle='rgba(46,70,67,.11)';ctx.lineWidth=.65;
    const step=Math.max(6,spatial.VISIBLE_GRID_M*frame.scale);
    for(let gx=frame.x;gx<=frame.x+frame.w;gx+=step){ctx.beginPath();ctx.moveTo(gx,frame.y);ctx.lineTo(gx,frame.y+frame.h);ctx.stroke();}
    for(let gy=frame.y;gy<=frame.y+frame.h;gy+=step){ctx.beginPath();ctx.moveTo(frame.x,gy);ctx.lineTo(frame.x+frame.w,gy);ctx.stroke();}
    ctx.restore();

    for(const obs of geometry.obstacles||[]) this.drawGeometryObstacle(ctx,obs,frame);

    for(const entrance of geometry.entrances||[]){
      const p=screenPoint(frame,entrance);
      ctx.save();ctx.fillStyle='#D6534A';ctx.beginPath();ctx.arc(p.x,p.y,4.5,0,Math.PI*2);ctx.fill();ctx.restore();
    }

    for(const wall of floor.editorWalls||[]){
      drawWall(ctx,frame,wall,floor.editorDoors||[],!!(this._v0866Selected&&this._v0866Selected.type==='wall'&&this._v0866Selected.id===wall.id));
    }

    const dragPreview=this._v0866DragPreview;
    for(const item0 of floor.editorPlacements||[]){
      const item=dragPreview&&dragPreview.id===item0.id?{...item0,mx:dragPreview.mx,my:dragPreview.my}:item0;
      const r=bodyScreenRect(frame,item);
      const key=IMAGE_KEY[item.kind];
      if(key) this.drawImageContain(ctx,key,r.x,r.y,r.w,r.h,1);
      else{
        deps.ui.card(ctx,r.x,r.y,r.w,r.h,{radius:4,fill:'#E5D8C0',stroke:'#8A765D',shadow:false});
        this.text(ctx,(spatial.specFor(item.kind)||{}).label||item.kind,r.x+r.w/2,r.y+r.h/2,4,'#294744','800','center');
      }
      const selected=this._v0866Selected&&this._v0866Selected.type==='placement'&&this._v0866Selected.id===item0.id;
      if(selected){
        ctx.save();ctx.strokeStyle='#F0A51B';ctx.lineWidth=2.2;ctx.strokeRect(r.x-2,r.y-2,r.w+4,r.h+4);ctx.restore();
      }
      this._v0866ItemRects.push({id:item0.id,x:r.x-5,y:r.y-5,w:r.w+10,h:r.h+10});
    }

    if(this._v0866WallStart){
      const p=screenPoint(frame,this._v0866WallStart);
      ctx.save();ctx.fillStyle='#F0A51B';ctx.beginPath();ctx.arc(p.x,p.y,5,0,Math.PI*2);ctx.fill();ctx.restore();
    }

    const rooms=spatial.detectRooms({floor,geometry,floorGeometrySystem:deps.floorGeometrySystem});
    const roomText=rooms.slice(0,3).map(r=>r.type+' '+r.area.toFixed(0)+'㎡').join(' · ');
    if(roomText){
      deps.ui.card(ctx,frame.x+6,frame.y+6,Math.min(frame.w-12,285),23,{radius:9,fill:'rgba(255,253,247,.90)',stroke:false,shadow:false});
      this.text(ctx,short(roomText,42),frame.x+14,frame.y+17.5,4.25,'#405F5B','800');
    }
  };

  proto.drawFloorPlan=function(ctx,metrics,floor,geo){
    const tabs=[
      ['select','选择'],['wall','建墙'],['door','开门'],['furniture','家具'],['equipment','设备']
    ];
    const tabY=48,tabW=69,gap=5;
    for(let i=0;i<tabs.length;i++){
      const x=10+i*(tabW+gap),active=mode(this)===tabs[i][0];
      deps.ui.card(ctx,x,tabY,tabW,30,{radius:9,fill:active?'#244E4B':'#F3EEE5',stroke:active?'#244E4B':'#D7CDBE',shadow:false});
      this.text(ctx,tabs[i][1],x+tabW/2,tabY+15,5.2,active?'#FFF8E9':'#4C6662','800','center');
      this.addButton('v0866:mode:'+tabs[i][0],x,tabY,tabW,30);
    }

    deps.ui.card(ctx,6,geo.y,378,geo.planH,{radius:14,fill:'#FFFDF8',stroke:'#D8CEBF',shadow:false});
    const canvasY=geo.y+5;
    const canvasH=geo.planH-10;
    this.drawFloorCanvas(ctx,metrics,floor,11,canvasY,368,canvasH);

    // Compact live result chips overlay the canvas instead of stealing height.
    const spatialResult=(metrics.floors[metrics.plan.activeFloor]||{}).spatial||{};
    const chips=[
      metrics.totalSeats+'席',
      money(metrics.totalCost),
      (spatialResult.roomCount||0)+'空间'
    ];
    let cx=18;
    for(const label of chips){
      const cw=label.length*6+20;
      deps.ui.card(ctx,cx,geo.y+34,cw,24,{radius:10,fill:'rgba(24,61,59,.88)',stroke:false,shadow:false});
      this.text(ctx,label,cx+cw/2,geo.y+46,4.5,'#FFF8E9','800','center');
      cx+=cw+6;
    }

    const selected=this._v0866Selected;
    const modeId=mode(this);
    const drawerY=geo.y+geo.planH-58;

    if(modeId==='furniture' || modeId==='equipment'){
      deps.ui.card(ctx,10,drawerY,370,52,{radius:12,fill:'rgba(250,246,238,.96)',stroke:'#D7CDBE',shadow:false});
      const palette=modeId==='furniture'
        ? [['table2','2人'],['table4','4人'],['table6','6人'],['table8','8人'],['plant','绿植'],['sofa','沙发']]
        : [['stove','灶台'],['prep','操作台'],['sink','水池'],['fridge','冷柜'],['shelf','货架'],['cashier','收银']];
      const bw=56;
      for(let i=0;i<palette.length;i++){
        const x=16+i*60;
        deps.ui.card(ctx,x,drawerY+7,bw,38,{radius:9,fill:'#FFFDF8',stroke:'#D4C8B8',shadow:false});
        this.text(ctx,'＋'+palette[i][1],x+bw/2,drawerY+26,4.25,'#315754','800','center');
        this.addButton('v0866:add:'+palette[i][0],x,drawerY+5,bw,42);
      }
    }else if(selected){
      deps.ui.card(ctx,112,drawerY+9,268,42,{radius:12,fill:'rgba(250,246,238,.97)',stroke:'#D7CDBE',shadow:false});
      if(selected.type==='placement'){
        this.addButton('v0866:rotate',120,drawerY+12,75,36);
        this.text(ctx,'旋转',157.5,drawerY+30,4.8,'#315754','800','center');
      }
      this.addButton('v0866:delete',202,drawerY+12,78,36);
      this.text(ctx,'删除',241,drawerY+30,4.8,'#B54B43','800','center');
      this.addButton('v0866:clear-select',287,drawerY+12,84,36);
      this.text(ctx,'取消选择',329,drawerY+30,4.5,'#315754','800','center');
    }

    if(modeId==='wall'){
      const hint=this._v0866WallStart?'再点一次确定墙体终点':'点画布确定墙体起点';
      deps.ui.card(ctx,89,drawerY+13,212,34,{radius:12,fill:'rgba(255,246,216,.96)',stroke:'#E3BC4C',shadow:false});
      this.text(ctx,hint,195,drawerY+30,4.8,'#765B17','800','center');
    }else if(modeId==='door'){
      deps.ui.card(ctx,93,drawerY+13,204,34,{radius:12,fill:'rgba(235,246,250,.96)',stroke:'#85B4C4',shadow:false});
      this.text(ctx,'直接点内墙 · 自动开0.90m门',195,drawerY+30,4.5,'#315A69','800','center');
    }
  };

  proto.drawTablePicker=function(){};
  proto.drawMetrics=function(){};

  proto.drawFooter=function(ctx,metrics,geo){
    const y=geo.footerY+4;
    const floor=metrics.floors[metrics.plan.activeFloor];
    const issue=floor.spatial&&floor.spatial.primaryIssue;
    deps.ui.card(ctx,8,y,86,38,{radius:11,fill:'#FFFDF8',stroke:'#D5CBBB',shadow:false});
    this.text(ctx,'风格',51,y+19,5.1,'#315754','800','center');
    this.addButton('page:style',6,y-1,90,42);

    deps.ui.card(ctx,101,y,281,38,{radius:11,fill:metrics.valid?'#E1B944':'#E4DED4',stroke:metrics.valid?'#C89B25':'#C9C0B5',shadow:false});
    this.text(
      ctx,
      metrics.valid?'确认施工  ›':short(issue?issue.message:'当前布局需调整',26),
      241.5,y+19,metrics.valid?5.8:4.5,metrics.valid?'#273F3C':'#776F66','800','center'
    );
    if(metrics.valid) this.addButton('construction:start',99,y-1,285,42);
  };

  proto.renderConstruction=function(ctx,shop,plan){
    if(plan.status!=='completed'){
      return oldRenderConstruction.call(this,ctx,shop,plan);
    }

    this.drawHeader(ctx,shop);
    const metrics=this.getMetrics();
    const floor=plan.floors[plan.activeFloor]||plan.floors[0];

    deps.ui.card(ctx,6,52,378,this.viewH-108,{
      radius:14,fill:'#FFFDF8',stroke:'#D8CEBF',shadow:false
    });

    this.text(ctx,'当前营业布局',18,72,8.2,'#193F3D','800');
    this.text(
      ctx,
      metrics.totalSeats+'席 · '+floor.area+'㎡ · 当前装修已投入营业',
      18,91,4.8,'#667A75','700'
    );

    this.drawFloorCanvas(
      ctx,
      metrics,
      floor,
      12,
      103,
      366,
      Math.max(330,this.viewH-220)
    );

    const y=this.viewH-53;
    deps.ui.card(ctx,8,y,112,39,{radius:11,fill:'#FFFDF8',stroke:'#D5CBBB',shadow:false});
    this.text(ctx,'返回门店',64,y+19.5,5.1,'#315754','800','center');
    this.addButton('back',6,y-2,116,43);

    deps.ui.card(ctx,128,y,254,39,{radius:11,fill:'#E1B944',stroke:'#C89B25',shadow:false});
    this.text(ctx,'重新装修 · 进入自由编辑  ›',255,y+19.5,5.6,'#273F3C','800','center');
    this.addButton('renovation:upgrade',126,y-2,258,43);
  };

  proto.renderPreview=function(ctx,metrics){
    const plan=metrics.plan;
    const floor=plan.floors[plan.activeFloor];

    ctx.save();
    ctx.fillStyle='#F7F1E7';
    ctx.fillRect(0,0,390,this.viewH);

    this.text(ctx,'真实平面预览',16,25,9,'#193F3D','800');
    deps.ui.card(ctx,300,8,76,34,{radius:10,fill:'#F4BE3C',stroke:'#D89B27',shadow:false});
    this.text(ctx,'关闭',338,25,5.2,'#273F3C','800','center');
    this.addButton('preview:close',296,4,84,42);

    this.drawFloorCanvas(
      ctx,
      metrics,
      floor,
      10,
      52,
      370,
      Math.max(390,this.viewH-72)
    );
    ctx.restore();
  };

  proto.handleTap=function(x,y){
    const hit=this.hitButton(x,y);
    if(hit){
      const id=hit.id;
      if(id.indexOf('v0866:mode:')===0){
        this.page='layout';this._v0866Mode=id.slice('v0866:mode:'.length);
        this._v0866WallStart=null;this._v0866Selected=null;this.requestRenderNow();return true;
      }
      if(id.indexOf('v0866:add:')===0){
        const res=addPlacement(this,deps,id.slice('v0866:add:'.length));this.showToast(res.message);return true;
      }
      if(id==='v0866:rotate'){const res=rotateSelected(this,deps);this.showToast(res.message);return true;}
      if(id==='v0866:delete'){const res=deleteSelected(this,deps);this.showToast(res.message);return true;}
      if(id==='v0866:clear-select'){this._v0866Selected=null;this.requestRenderNow();return true;}
      return oldHandleTap.call(this,x,y);
    }

    if(this.page!=='layout'||!this._v0866Canvas) return oldHandleTap.call(this,x,y);

    const frame=this._v0866Canvas.frame;
    if(x<frame.x||x>frame.x+frame.w||y<frame.y||y>frame.y+frame.h) return false;
    const p=modelPoint(frame,x,y);
    const ctx0=currentContext(this,deps);
    if(!ctx0) return false;

    if(mode(this)==='wall'){
      if(!this._v0866WallStart){
        this._v0866WallStart=p;this.requestRenderNow();return true;
      }
      const wall=spatial.normalizeWall(this._v0866WallStart,p,'temp');
      const valid=spatial.validateWall({
        wall,floor:ctx0.floor,geometry:ctx0.geometry,
        floorGeometrySystem:deps.floorGeometrySystem,
        clearDepthM:deps.renovationConfig.zoneRules.entranceClearDepthM
      });
      if(!valid.valid){
        this.showToast(valid.issues[0]?valid.issues[0].message:'墙体位置无效');
      }else{
        deps.renovationSystem.mutatePlan(this.shopId,plan=>{
          const target=plan.floors[ctx0.index];
          wall.id=nextId(plan,'wall');
          target.editorWalls.push(wall);
        });
        deps.saveSystem.autoSave(true);
        this.showToast('已建墙 '+spatial.wallLength(wall).toFixed(2)+'m');
      }
      this._v0866WallStart=null;this.requestRenderNow();return true;
    }

    if(mode(this)==='door'){
      const wall=spatial.nearestWall(ctx0.floor,p,.32);
      if(!wall){this.showToast('请点在内墙上开门');return true;}
      const door=spatial.createDoorOnWall(wall,p,.9,'temp');
      if(!door){this.showToast('这段墙太短，无法开0.90m门');return true;}
      deps.renovationSystem.mutatePlan(this.shopId,plan=>{
        door.id=nextId(plan,'door');
        plan.floors[ctx0.index].editorDoors.push(door);
      });
      deps.saveSystem.autoSave(true);this.showToast('已开0.90m门');this.requestRenderNow();return true;
    }

    if(mode(this)==='select'){
      const rects=(this._v0866ItemRects||[]).slice().reverse();
      const item=rects.find(r=>x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h);
      if(item){this._v0866Selected={type:'placement',id:item.id};this.requestRenderNow();return true;}
      const wall=spatial.nearestWall(ctx0.floor,p,.28);
      if(wall){this._v0866Selected={type:'wall',id:wall.id};this.requestRenderNow();return true;}
      this._v0866Selected=null;this.requestRenderNow();return true;
    }

    return true;
  };

  proto.handleTouchStart=function(x,y){
    if(this.page==='layout'&&mode(this)==='select'&&this._v0866Canvas){
      const rects=(this._v0866ItemRects||[]).slice().reverse();
      const hit=rects.find(r=>x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h);
      if(hit){
        this._v0866Selected={type:'placement',id:hit.id};
        this._v0866Drag={id:hit.id};
        return true;
      }
    }
    return oldTouchStart.call(this,x,y);
  };

  proto.handleTouchMove=function(x,y){
    if(this._v0866Drag&&this._v0866Canvas){
      const p=modelPoint(this._v0866Canvas.frame,x,y);
      this._v0866DragPreview={id:this._v0866Drag.id,mx:p.x,my:p.y};
      this.requestRenderNow();return true;
    }
    return oldTouchMove.call(this,x,y);
  };

  proto.handleTouchEnd=function(){
    if(this._v0866Drag){
      const found=findSelectedPlacement(this),preview=this._v0866DragPreview;
      if(found&&preview){
        const candidate={...found.item,mx:preview.mx,my:preview.my};
        const v=spatial.validateCandidate({
          item:candidate,floor:found.ctx.floor,geometry:found.ctx.geometry,
          placements:found.ctx.floor.editorPlacements||[],ignoreId:found.item.id,
          floorGeometrySystem:deps.floorGeometrySystem,
          clearDepthM:deps.renovationConfig.zoneRules.entranceClearDepthM
        });
        if(v.valid){
          deps.renovationSystem.mutatePlan(this.shopId,plan=>{
            const item=plan.floors[found.ctx.index].editorPlacements.find(x=>x.id===found.item.id);
            if(item){item.mx=preview.mx;item.my=preview.my;}
          });
          if(v.status==='yellow'&&v.issues[0]) this.showToast('已放置，但'+v.issues[0].message);
          deps.saveSystem.autoSave(true);
        }else{
          this.showToast('不能放这里：'+(v.issues[0]?v.issues[0].message:'位置无效'));
        }
      }
      this._v0866Drag=null;this._v0866DragPreview=null;this.requestRenderNow();return true;
    }
    return oldTouchEnd.call(this);
  };

  return true;
}

module.exports={VERSION,install,addPlacement,rotateSelected,deleteSelected};
