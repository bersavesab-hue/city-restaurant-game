'use strict';

const gameState = require('../core/gameState.js');
const renovation = require('./index.js');
const PACK = renovation.pack;
const Rules = renovation.rules;
const LayoutEngine = renovation.LayoutEngine;

const runtime = globalThis.GameRuntime || {};
const api = runtime.api || {};
const DESIGN_W = 390;
const COLORS = {
  navy:'#0B3047', navy2:'#08283C', paper:'#F7F0E4', panel:'#FFFDF8', line:'#D8CDBE', text:'#19303C', muted:'#6B7A80',
  gold:'#F2B846', orange:'#E99B2F', green:'#33A66A', red:'#D94E43', blue:'#439CC9', white:'#FFFDF8'
};

function money(v){return '¥'+Math.round(Number(v)||0).toLocaleString();}
function clamp(v,a,b){return Math.max(a,Math.min(b,v));}

class RenovationRuntimeV18 {
  constructor(scene){
    this.scene=scene;
    this.engine=null;
    this.viewH=780;
    this.navH=64;
    this.contentBottom=716;
    this.buttons=[];
    this.category='kitchen';
    this.palettePage=0;
    this.selectedAssetId=null;
    this.selectedPlacedId=null;
    this.toast='';
    this.lastResult=null;
    this.canvasRect={x:16,y:126,w:358,h:370};
  }

  getLayout(){
    let h=780;
    if(api&&typeof api.getSystemInfoSync==='function'){
      const info=api.getSystemInfoSync();
      const sw=Math.max(1,Number(info.windowWidth)||390);
      const sh=Math.max(1,Number(info.windowHeight)||780);
      h=sh/(sw/DESIGN_W);
    }
    this.viewH=h;
    this.navH=h<740?60:64;
    this.contentBottom=h-this.navH;
    this.canvasRect.h=clamp(h-410,300,410);
    return {height:h};
  }

  currentShop(){
    const b=gameState.getBusiness&&gameState.getBusiness();
    if(!b||!Array.isArray(b.shops)||!b.shops.length)return null;
    return b.shops.find((s)=>s.id===b.currentShopId)||b.shops[0];
  }

  propertyFromShop(shop){
    if(!shop)return null;
    return shop.property||shop.propertyData||shop.listing||shop.leaseProperty||shop.site||{
      id:shop.propertyId||shop.id,
      name:shop.name||'当前门店',
      usableArea:shop.usableArea||shop.area,
      grossArea:shop.area,
      frontage:shop.frontage,
      depth:shop.depth,
      ceilingHeight:shop.ceilingHeight,
      exhaust:shop.exhaust,
      gas:shop.gas,
      threePhase:shop.threePhase,
      drainage:shop.drainage,
      greaseTrap:shop.greaseTrap,
      fire:shop.fire,
      electricCapacityKw:shop.electricCapacityKw
    };
  }

  propertyFromScene(){
    const s=this.scene||{};
    return s.property||s.currentProperty||s.propertyData||s.listing||s.selectedProperty||null;
  }

  fallbackProperty(){
    const w=gameState.getWorld?gameState.getWorld():{};
    const d=w.currentDistrictId||'university';
    const presets={
      university:[43,5.6,7.7],cbd:[68,7.2,9.4],oldtown:[38,4.8,7.9],market:[32,4.5,7.1],
      village:[28,4.2,6.7],industry:[58,6.2,9.4],hightech:[72,7.5,9.6]
    };
    const p=presets[d]||presets.university;
    return {id:'preview_'+d,name:'装修预览铺',usableArea:p[0],grossArea:p[0],frontage:p[1],depth:p[2],ceilingHeight:3.3,exhaust:true,gas:d!=='hightech',threePhase:true,drainage:true,greaseTrap:true,fire:true,electricCapacityKw:d==='village'?22:36};
  }

  resolveProperty(payload){
    return (payload&&payload.property)||(payload&&payload.listing)||this.propertyFromScene()||this.propertyFromShop(this.currentShop())||this.fallbackProperty();
  }

  savedPlan(){
    const shop=this.currentShop();
    const b=gameState.getBusiness&&gameState.getBusiness();
    return (shop&&shop.renovation)||(b&&b.renovationDraft)||null;
  }

  init(payload){
    this.getLayout();
    const property=this.resolveProperty(payload);
    const normalized=Rules.normalizeProperty(property);
    const saved=this.savedPlan();
    const savedMatches=!!(saved&&Array.isArray(saved.placements)&&(!saved.propertyId||String(saved.propertyId)===String(normalized.id)));
    this.engine=new LayoutEngine(property,savedMatches?saved:null);
    this.selectedAssetId=null;
    this.selectedPlacedId=null;
    this.palettePage=0;
    if(!savedMatches) this.engine.autoLayout(normalized.usableArea<30?'economy':'balanced');
    return this.engine;
  }

  save(){
    if(!this.engine)return false;
    const data=this.engine.exportPlan();
    const shop=this.currentShop();
    const b=gameState.getBusiness&&gameState.getBusiness();
    if(shop)shop.renovation=data;
    else if(b)b.renovationDraft=data;
    this.toast='装修方案已保存';
    return true;
  }

  rounded(ctx,x,y,w,h,r,fill,stroke){
    const rr=Math.min(r,w/2,h/2);
    ctx.beginPath();ctx.moveTo(x+rr,y);ctx.arcTo(x+w,y,x+w,y+h,rr);ctx.arcTo(x+w,y+h,x,y+h,rr);ctx.arcTo(x,y+h,x,y,rr);ctx.arcTo(x,y,x+w,y,rr);ctx.closePath();
    if(fill){ctx.fillStyle=fill;ctx.fill();}if(stroke){ctx.strokeStyle=stroke;ctx.lineWidth=1;ctx.stroke();}
  }
  text(ctx,t,x,y,size,color,weight,align){ctx.fillStyle=color||COLORS.text;ctx.font=(weight||'500')+' '+size+'px sans-serif';ctx.textAlign=align||'left';ctx.textBaseline='middle';ctx.fillText(String(t),x,y);}
  addButton(id,x,y,w,h){this.buttons.push({id,x,y,w,h});}
  hit(x,y){for(let i=this.buttons.length-1;i>=0;i--){const b=this.buttons[i];if(x>=b.x&&x<=b.x+b.w&&y>=b.y&&y<=b.y+b.h)return b;}return null;}

  fitFloor(){
    const p=this.engine.getPlan(),r=this.canvasRect,pad=14,aw=r.w-pad*2,ah=r.h-pad*2;
    // 大店也必须完整装进画布，不能因为 5px 最小网格把 300㎡+ 平面图撑出屏幕。
    const cell=Math.max(0.65,Math.min(26,Math.min(aw/p.widthCells,ah/p.depthCells)));
    const w=p.widthCells*cell,h=p.depthCells*cell;
    return {x:r.x+(r.w-w)/2,y:r.y+(r.h-h)/2,w,h,cell};
  }
  screenToCell(x,y){const f=this.fitFloor();return{x:Math.floor((x-f.x)/f.cell),y:Math.floor((y-f.y)/f.cell)};}
  placedAtCell(cx,cy){
    if(!this.engine)return null;
    const rows=this.engine.getDrawOrder().slice().reverse();
    for(const row of rows){const a=PACK.ASSET_BY_ID[row.assetId];if(!a)continue;const rect=Rules.placementRect(a,row.x,row.y,row.rotation);if(cx>=rect.x&&cx<rect.x+rect.w&&cy>=rect.y&&cy<rect.y+rect.h)return row;}
    return null;
  }

  drawHeader(ctx){
    ctx.fillStyle=COLORS.navy2;ctx.fillRect(0,0,DESIGN_W,74);
    this.text(ctx,'装修设计',16,21,18,COLORS.white,'700');
    const p=this.engine.getProperty(),m=this.engine.getMetrics();
    this.text(ctx,p.name+' · '+p.usableArea+'㎡ · '+p.frontage+'m×'+p.depth+'m',16,45,7.5,'#D5E4EB','600');
    const player=gameState.getPlayer?gameState.getPlayer():{cash:0};
    this.text(ctx,money(player.cash),374,19,13,'#FFE6A6','700','right');
    this.text(ctx,'方案 '+money(m.cost)+' · '+m.buildDays+'天',374,44,7.5,'#D5E4EB','600','right');
    const metrics=[['座位',m.seats],['后厨',m.kitchenCapacity],['动线',m.flowScore],['安全',m.safetyScore]];
    metrics.forEach((row,i)=>{const x=12+i*94;this.rounded(ctx,x,82,85,32,9,'#FFF9EF',COLORS.line);this.text(ctx,row[0],x+8,93,6.5,COLORS.muted,'600');this.text(ctx,row[1],x+76,101,11,i>1&&row[1]<60?COLORS.red:COLORS.navy,'700','right');});
  }

  drawFloor(ctx){
    const p=this.engine.getPlan(),f=this.fitFloor();
    this.rounded(ctx,this.canvasRect.x,this.canvasRect.y,this.canvasRect.w,this.canvasRect.h,14,'#FCF8F0',COLORS.line);
    ctx.fillStyle='#E9E2D6';ctx.fillRect(f.x,f.y,f.w,f.h);
    ctx.strokeStyle='rgba(45,70,80,.12)';ctx.lineWidth=.6;
    const gridStep=f.cell<1.4?4:(f.cell<2.8?2:1);
    for(let x=0;x<=p.widthCells;x+=gridStep){ctx.beginPath();ctx.moveTo(f.x+x*f.cell,f.y);ctx.lineTo(f.x+x*f.cell,f.y+f.h);ctx.stroke();}
    for(let y=0;y<=p.depthCells;y+=gridStep){ctx.beginPath();ctx.moveTo(f.x,f.y+y*f.cell);ctx.lineTo(f.x+f.w,f.y+y*f.cell);ctx.stroke();}
    ctx.strokeStyle='#29495A';ctx.lineWidth=2;ctx.strokeRect(f.x,f.y,f.w,f.h);

    for(const door of p.doors){ctx.fillStyle='#F4BE58';ctx.fillRect(f.x+door.x*f.cell-1,f.y-2,door.w*f.cell+2,5);}
    const pointColors={drain:'#37A8C7',water:'#4BA9E2',gas:'#E37C3F',exhaust:'#75808A',power:'#F0B62E'};
    Object.keys(p.utilityPoints).forEach((kind)=>{(p.utilityPoints[kind]||[]).forEach((pt)=>{ctx.beginPath();ctx.arc(f.x+(pt.x+.5)*f.cell,f.y+(pt.y+.5)*f.cell,Math.max(3,f.cell*.18),0,Math.PI*2);ctx.fillStyle=pointColors[kind]||'#888';ctx.fill();});});

    for(const row of this.engine.getDrawOrder()){
      const a=PACK.ASSET_BY_ID[row.assetId];if(!a)continue;
      const rr=Rules.placementRect(a,row.x,row.y,row.rotation);
      const x=f.x+rr.x*f.cell,y=f.y+rr.y*f.cell,w=rr.w*f.cell,h=rr.h*f.cell,selected=row.id===this.selectedPlacedId;
      this.rounded(ctx,x+Math.min(1,w*.08),y+Math.min(1,h*.08),Math.max(.5,w-Math.min(2,w*.16)),Math.max(.5,h-Math.min(2,h*.16)),Math.min(6,Math.max(.5,f.cell*.25)),a.draw.fill,selected?COLORS.gold:a.draw.stroke);
      if(f.cell>=4.2&&w>=18&&h>=12)this.text(ctx,a.name.replace('商用',''),x+w/2,y+h/2,clamp(f.cell*.28,4.2,9),a.draw.text,'700','center');
    }

    if(this.selectedAssetId){
      this.text(ctx,'已选：'+PACK.ASSET_BY_ID[this.selectedAssetId].name+'，点击平面图空位放置',this.canvasRect.x+12,this.canvasRect.y+this.canvasRect.h-10,6.5,COLORS.orange,'700');
    } else if(this.selectedPlacedId){
      const selected=this.engine.getPlacements().find((row)=>row.id===this.selectedPlacedId);
      const asset=selected&&PACK.ASSET_BY_ID[selected.assetId];
      if(asset)this.text(ctx,'已选：'+asset.name+'，点击空位移动；也可旋转或删除',this.canvasRect.x+12,this.canvasRect.y+this.canvasRect.h-10,6.5,COLORS.orange,'700');
    }
  }

  drawControls(ctx){
    const y=this.canvasRect.y+this.canvasRect.h+7;
    const actions=[['auto:economy','经济'],['auto:balanced','均衡'],['auto:delivery','外卖'],['undo','撤销'],['rotate','旋转'],['delete','删除'],['save','保存']];
    const gap=4,w=(374-gap*(actions.length-1))/actions.length;
    actions.forEach((a,i)=>{const x=8+i*(w+gap);this.rounded(ctx,x,y,w,28,8,a[0]==='save'?COLORS.gold:'#E9E1D6',COLORS.line);this.text(ctx,a[1],x+w/2,y+14,6.5,COLORS.navy,'700','center');this.addButton(a[0],x,y,w,28);});
  }

  drawPalette(ctx){
    const y=this.canvasRect.y+this.canvasRect.h+43;
    const cats=[['kitchen','后厨'],['dining','桌椅'],['service','前台'],['storage','仓储'],['decor','装饰']];
    const cw=70;
    cats.forEach((c,i)=>{const x=10+i*75;this.rounded(ctx,x,y,cw,25,8,this.category===c[0]?COLORS.navy:'#EFE6D9',COLORS.line);this.text(ctx,c[1],x+cw/2,y+12.5,6.5,this.category===c[0]?COLORS.white:COLORS.text,'700','center');this.addButton('cat:'+c[0],x,y,cw,25);});

    const items=PACK.ASSETS.filter((a)=>a.category===this.category),pageSize=5,maxPage=Math.max(0,Math.ceil(items.length/pageSize)-1);
    this.palettePage=clamp(this.palettePage,0,maxPage);
    const visible=items.slice(this.palettePage*pageSize,this.palettePage*pageSize+pageSize),iy=y+31,iw=70;
    visible.forEach((a,i)=>{const x=10+i*75;this.rounded(ctx,x,iy,iw,54,9,this.selectedAssetId===a.id?'#FFF0C6':'#FFF9EF',this.selectedAssetId===a.id?COLORS.gold:COLORS.line);this.text(ctx,a.name,x+iw/2,iy+14,6.3,COLORS.text,'700','center');this.text(ctx,money(a.price),x+iw/2,iy+31,6.3,COLORS.red,'700','center');this.text(ctx,a.footprint.w+'×'+a.footprint.h+'格',x+iw/2,iy+44,5.6,COLORS.muted,'600','center');this.addButton('asset:'+a.id,x,iy,iw,54);});
    if(maxPage>0){this.addButton('palette:next',350,iy,30,54);this.text(ctx,'›',365,iy+27,19,COLORS.navy,'700','center');}

    const m=this.engine.getMetrics(),sy=Math.min(this.contentBottom-33,iy+63),loadColor=m.safetyScore<60?COLORS.red:COLORS.green;
    this.text(ctx,'电力 '+Math.round(m.powerLoad*100)+'% · 排烟 '+Math.round(m.smokeLoad*100)+'% · 储存 '+m.storageCapacity+' · 洗消 '+m.washCapacity,12,sy,6.2,loadColor,'700');
    if(m.issues.length)this.text(ctx,'⚠ '+m.issues[0],378,sy,6.2,COLORS.red,'700','right');
    else this.text(ctx,'布局可营业',378,sy,6.2,COLORS.green,'700','right');
  }

  render(ctx){
    this.getLayout();this.buttons=[];if(!this.engine)this.init();
    ctx.save();ctx.fillStyle=COLORS.paper;ctx.fillRect(0,0,DESIGN_W,this.viewH);
    this.drawHeader(ctx);this.drawFloor(ctx);this.drawControls(ctx);this.drawPalette(ctx);
    if(this.toast){this.rounded(ctx,100,118,190,26,10,'rgba(9,40,58,.92)');this.text(ctx,this.toast,195,131,7,COLORS.white,'700','center');this.toast='';}
    ctx.restore();
  }

  handleTap(x,y){
    if(!this.engine)return false;
    const b=this.hit(x,y);
    if(b){const id=b.id;
      if(id.indexOf('cat:')===0){this.category=id.split(':')[1];this.palettePage=0;this.selectedAssetId=null;return true;}
      if(id.indexOf('asset:')===0){this.selectedAssetId=id.slice(6);this.selectedPlacedId=null;return true;}
      if(id==='palette:next'){const items=PACK.ASSETS.filter((a)=>a.category===this.category),pages=Math.max(1,Math.ceil(items.length/5));this.palettePage=(this.palettePage+1)%pages;return true;}
      if(id.indexOf('auto:')===0){const r=this.engine.autoLayout(id.split(':')[1]);this.toast=r.ok?'自动布局完成':'自动布局失败';this.selectedPlacedId=null;this.selectedAssetId=null;return true;}
      if(id==='undo'){this.engine.undo();this.selectedPlacedId=null;return true;}
      if(id==='rotate'){if(this.selectedPlacedId){const r=this.engine.rotate(this.selectedPlacedId);this.toast=r.ok?'已旋转':(r.errors&&r.errors[0])||'当前位置无法旋转';}return true;}
      if(id==='delete'){if(this.selectedPlacedId){this.engine.remove(this.selectedPlacedId);this.selectedPlacedId=null;}return true;}
      if(id==='save'){this.save();return true;}
    }
    const r=this.canvasRect;
    if(x>=r.x&&x<=r.x+r.w&&y>=r.y&&y<=r.y+r.h){
      const c=this.screenToCell(x,y);
      if(this.selectedAssetId){const result=this.engine.place(this.selectedAssetId,c.x,c.y,0);this.lastResult=result;if(!result.ok)this.toast=result.errors[0]||'不能放在这里';else if(result.warnings&&result.warnings.length)this.toast=result.warnings[0];else this.toast='已放置';return true;}
      const placed=this.placedAtCell(c.x,c.y);
      if(placed){this.selectedPlacedId=placed.id;return true;}
      if(this.selectedPlacedId){const moved=this.engine.move(this.selectedPlacedId,c.x,c.y);this.lastResult=moved;if(moved.ok){this.toast=(moved.warnings&&moved.warnings[0])||'已移动';}else{this.toast=(moved.errors&&moved.errors[0])||'这里不能放';}return true;}
      this.selectedPlacedId=null;return true;
    }
    return false;
  }
}

function install(scene){
  if(!scene||scene.__v18RenovationLayoutInstalled)return scene;
  scene.__v18RenovationLayoutInstalled=true;
  const original={
    enter:typeof scene.enter==='function'?scene.enter.bind(scene):null,
    exit:typeof scene.exit==='function'?scene.exit.bind(scene):null,
    update:typeof scene.update==='function'?scene.update.bind(scene):null,
    render:typeof scene.render==='function'?scene.render.bind(scene):null,
    handleTap:typeof scene.handleTap==='function'?scene.handleTap.bind(scene):null
  };
  const controller=new RenovationRuntimeV18(scene);
  scene.__v18Layout=controller;

  scene.enter=function(payload){
    try{if(original.enter)original.enter(payload);}catch(error){try{console.error('[V18 renovation][original enter]',error);}catch(_){} }
    try{controller.init(payload);}catch(error){controller.engine=null;try{console.error('[V18 renovation][init]',error);}catch(_){} }
  };
  scene.exit=function(){try{controller.save();}catch(_){} if(original.exit){try{return original.exit();}catch(_){} } };
  scene.update=function(){if(original.update){try{return original.update();}catch(_){} } };
  scene.render=function(ctx){
    try{if(!controller.engine)controller.init();return controller.render(ctx);}catch(error){try{console.error('[V18 renovation][render]',error);}catch(_){} if(original.render)return original.render(ctx);}
  };
  scene.handleTap=function(x,y,target){
    try{if(controller.handleTap(x,y,target))return true;}catch(error){try{console.error('[V18 renovation][tap]',error);}catch(_){} }
    if(original.handleTap){try{return original.handleTap(x,y,target);}catch(_){return false;}}
    return false;
  };
  return scene;
}

module.exports={install,RenovationRuntimeV18};
