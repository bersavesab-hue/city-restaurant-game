'use strict';

// V0866_FREE_BUILD_SPATIAL_MODEL
// Free interior walls + doors + furniture/equipment. No player-facing
// kitchen/storage/front-of-house ratio partition is used for legality.

const VERSION = '0.8.66';
const GRID_M = 0.25;
const VISIBLE_GRID_M = 0.5;
const ROOM_GRID_M = 0.5;

const SPECS = Object.freeze({
  table2:{ label:'2人桌', bodyW:0.75, bodyD:0.75, useW:1.50, useD:1.60, seats:2, floorArea:2.4, type:'table' },
  table4:{ label:'4人桌', bodyW:1.20, bodyD:0.75, useW:2.00, useD:1.80, seats:4, floorArea:3.6, type:'table' },
  table6:{ label:'6人桌', bodyW:1.60, bodyD:0.82, useW:2.40, useD:2.00, seats:6, floorArea:4.8, type:'table' },
  table8:{ label:'8人桌', bodyW:2.10, bodyD:0.88, useW:3.00, useD:2.00, seats:8, floorArea:6.0, type:'table' },

  stove:{ label:'灶台', bodyW:1.20, bodyD:0.75, useW:1.45, useD:1.20, floorArea:1.7, type:'equipment', kitchen:3 },
  prep:{ label:'操作台', bodyW:1.20, bodyD:0.65, useW:1.45, useD:1.10, floorArea:1.6, type:'equipment', kitchen:2 },
  sink:{ label:'水池', bodyW:0.90, bodyD:0.65, useW:1.15, useD:1.05, floorArea:1.2, type:'equipment', kitchen:2 },
  fridge:{ label:'冷柜', bodyW:0.75, bodyD:0.72, useW:0.95, useD:0.95, floorArea:0.9, type:'equipment', kitchen:1, storage:1 },
  shelf:{ label:'货架', bodyW:1.10, bodyD:0.42, useW:1.25, useD:0.72, floorArea:0.9, type:'equipment', storage:3 },
  cashier:{ label:'收银台', bodyW:1.10, bodyD:0.62, useW:1.50, useD:1.05, floorArea:1.6, type:'equipment', reception:3 },

  plant:{ label:'绿植', bodyW:0.45, bodyD:0.45, useW:0.55, useD:0.55, floorArea:0.3, type:'decor' },
  sofa:{ label:'等候沙发', bodyW:1.80, bodyD:0.72, useW:2.00, useD:1.15, floorArea:2.3, type:'decor', reception:2 },
  screen:{ label:'屏风', bodyW:1.50, bodyD:0.18, useW:1.65, useD:0.50, floorArea:0.8, type:'decor' }
});

function clamp(v,min,max){ return Math.max(min,Math.min(max,Number(v)||0)); }
function round2(v){ return Number((Number(v)||0).toFixed(2)); }
function snap(v,step=GRID_M){ return round2(Math.round((Number(v)||0)/step)*step); }
function specFor(kind){ return SPECS[String(kind||'')] || null; }
function isTable(kind){ return !!(specFor(kind) && specFor(kind).type==='table'); }
function isEquipment(kind){ return !!(specFor(kind) && specFor(kind).type==='equipment'); }

function dimensionsFor(item,useEnvelope){
  const spec=specFor(item&&item.kind) || {bodyW:.5,bodyD:.5,useW:.5,useD:.5};
  let w=useEnvelope?spec.useW:spec.bodyW;
  let d=useEnvelope?spec.useD:spec.bodyD;
  const rot=((Number(item&&item.rotation)||0)%180+180)%180;
  if(rot===90){ const t=w;w=d;d=t; }
  return {w,d};
}

function rectFor(item,useEnvelope){
  const size=dimensionsFor(item,useEnvelope);
  const cx=Number(item&&(item.mx??item.x))||0;
  const cy=Number(item&&(item.my??item.y))||0;
  return {x:cx-size.w/2,y:cy-size.d/2,w:size.w,h:size.d,cx,cy};
}

function rectsOverlap(a,b,e=.001){
  return a.x < b.x+b.w-e && a.x+a.w > b.x+e &&
    a.y < b.y+b.h-e && a.y+a.h > b.y+e;
}

function rectPoints(r){
  return [
    {x:r.x,y:r.y},{x:r.x+r.w,y:r.y},{x:r.x+r.w,y:r.y+r.h},{x:r.x,y:r.y+r.h},
    {x:r.cx,y:r.y},{x:r.cx,y:r.y+r.h},{x:r.x,y:r.cy},{x:r.x+r.w,y:r.cy},{x:r.cx,y:r.cy}
  ];
}

function obstacleRect(o){
  return {x:Number(o.x)||0,y:Number(o.y)||0,w:Math.max(0,Number(o.w)||0),h:Math.max(0,Number(o.h)||0)};
}

function entranceRect(entrance,geometry,clearDepthM){
  const width=Math.max(.9,Number(entrance.width)||1.2)+.45;
  const depth=Math.max(1.1,Number(clearDepthM)||1.35);
  const side=entrance.side||'south';
  if(side==='south'){
    return {x:(Number(entrance.x)||geometry.widthM/2)-width/2,y:geometry.depthM-depth,w:width,h:depth};
  }
  if(side==='north'){
    return {x:(Number(entrance.x)||geometry.widthM/2)-width/2,y:0,w:width,h:depth};
  }
  if(side==='west'){
    return {x:0,y:(Number(entrance.y)||geometry.depthM/2)-width/2,w:depth,h:width};
  }
  return {x:geometry.widthM-depth,y:(Number(entrance.y)||geometry.depthM/2)-width/2,w:depth,h:width};
}

function pointInside(point,geometry,floorGeometrySystem){
  return !!floorGeometrySystem.pointInPolygon(point,geometry.polygon);
}

function rectInside(rect,geometry,floorGeometrySystem){
  return rectPoints(rect).every(p=>pointInside(p,geometry,floorGeometrySystem));
}

function doorGapOnWall(wall,doors){
  return (doors||[]).filter(d=>d&&d.wallId===wall.id);
}

function wallLength(wall){
  return round2(Math.hypot((Number(wall.x2)||0)-(Number(wall.x1)||0),(Number(wall.y2)||0)-(Number(wall.y1)||0)));
}

function normalizeWall(a,b,id){
  let x1=snap(a&&a.x), y1=snap(a&&a.y), x2=snap(b&&b.x), y2=snap(b&&b.y);
  if(Math.abs(x2-x1)>=Math.abs(y2-y1)) y2=y1;
  else x2=x1;
  if(x2<x1 || y2<y1){ const tx=x1,ty=y1;x1=x2;y1=y2;x2=tx;y2=ty; }
  return {id:id||null,x1,y1,x2,y2};
}

function pointToSegmentDistance(p,w){
  const x=Number(p.x)||0,y=Number(p.y)||0;
  const x1=Number(w.x1)||0,y1=Number(w.y1)||0,x2=Number(w.x2)||0,y2=Number(w.y2)||0;
  const dx=x2-x1,dy=y2-y1;
  const len2=dx*dx+dy*dy;
  if(len2<=.0001) return Math.hypot(x-x1,y-y1);
  const t=clamp(((x-x1)*dx+(y-y1)*dy)/len2,0,1);
  return Math.hypot(x-(x1+t*dx),y-(y1+t*dy));
}

function wallCrossesRect(wall,rect,doors){
  const vertical=Math.abs(Number(wall.x1)-Number(wall.x2))<.01;
  const gaps=doorGapOnWall(wall,doors);
  if(vertical){
    const x=Number(wall.x1);
    if(x<rect.x-.06 || x>rect.x+rect.w+.06) return false;
    const a=Math.max(Math.min(wall.y1,wall.y2),rect.y);
    const b=Math.min(Math.max(wall.y1,wall.y2),rect.y+rect.h);
    if(b<=a) return false;
    return !gaps.some(d=>{
      const cy=Number(d.y)||0,w=Math.max(.7,Number(d.width)||.9);
      return a>=cy-w/2-.03 && b<=cy+w/2+.03;
    });
  }
  const y=Number(wall.y1);
  if(y<rect.y-.06 || y>rect.y+rect.h+.06) return false;
  const a=Math.max(Math.min(wall.x1,wall.x2),rect.x);
  const b=Math.min(Math.max(wall.x1,wall.x2),rect.x+rect.w);
  if(b<=a) return false;
  return !gaps.some(d=>{
    const cx=Number(d.x)||0,w=Math.max(.7,Number(d.width)||.9);
    return a>=cx-w/2-.03 && b<=cx+w/2+.03;
  });
}

function validateCandidate(options){
  const o=options||{},item=o.item||{},floor=o.floor||{},geometry=o.geometry||{};
  const placements=Array.isArray(o.placements)?o.placements:(floor.editorPlacements||[]);
  const fgs=o.floorGeometrySystem;
  const body=rectFor(item,false), use=rectFor(item,true);
  const issues=[]; let status='green';

  if(!specFor(item.kind)){
    return {valid:false,status:'red',body,use,issues:[{code:'unknown',message:'未知家具/设备'}]};
  }

  if(!rectInside(body,geometry,fgs)){
    issues.push({code:'outside',message:'物体超出房源边界'}); status='red';
  }

  for(const obs of geometry.obstacles||[]){
    const r=obstacleRect(obs);
    if(rectsOverlap(body,r)){
      issues.push({code:'structure',message:'与柱体/楼梯/卫生间冲突'});status='red';break;
    }
  }

  for(const ent of geometry.entrances||[]){
    if(rectsOverlap(body,entranceRect(ent,geometry,o.clearDepthM))){
      issues.push({code:'entrance',message:'占用门口及疏散净空'});status='red';break;
    }
  }

  for(const wall of floor.editorWalls||[]){
    if(wallCrossesRect(wall,body,floor.editorDoors||[])){
      issues.push({code:'wall',message:'与内墙冲突'});status='red';break;
    }
  }

  for(const other of placements){
    if(!other || other.id===o.ignoreId || other.id===item.id) continue;
    const otherBody=rectFor(other,false);
    if(rectsOverlap(body,otherBody)){
      issues.push({code:'collision',message:'与'+((specFor(other.kind)||{}).label||'其他物体')+'重叠'});
      status='red'; break;
    }
  }

  if(status!=='red'){
    for(const other of placements){
      if(!other || other.id===o.ignoreId || other.id===item.id) continue;
      if(rectsOverlap(use,rectFor(other,true))){
        issues.push({code:'tight',message:'使用空间重叠，服务动线偏挤'});
        status='yellow'; break;
      }
    }

    if(status==='green'){
      const near=(floor.editorWalls||[]).some(w=>pointToSegmentDistance({x:body.cx,y:body.cy},w)<.45);
      if(near){
        issues.push({code:'near_wall',message:'靠墙较近，操作空间偏紧'});
        status='yellow';
      }
    }
  }

  return {valid:status!=='red',status,body,use,issues};
}

function findFirstValidPosition(options){
  const o=options||{},geometry=o.geometry||{};
  const kind=o.kind;
  const probe={id:'__probe__',kind,rotation:Number(o.rotation)||0,mx:0,my:0};
  for(let y=.5;y<=Number(geometry.depthM)-.5;y+=GRID_M){
    for(let x=.5;x<=Number(geometry.widthM)-.5;x+=GRID_M){
      probe.mx=snap(x);probe.my=snap(y);
      const v=validateCandidate({...o,item:probe,ignoreId:'__probe__'});
      if(v.valid && v.status==='green') return {x:probe.mx,y:probe.my,rotation:probe.rotation,status:v.status};
    }
  }
  for(let y=.5;y<=Number(geometry.depthM)-.5;y+=GRID_M){
    for(let x=.5;x<=Number(geometry.widthM)-.5;x+=GRID_M){
      probe.mx=snap(x);probe.my=snap(y);
      const v=validateCandidate({...o,item:probe,ignoreId:'__probe__'});
      if(v.valid) return {x:probe.mx,y:probe.my,rotation:probe.rotation,status:v.status};
    }
  }
  return null;
}

function validateWall(options){
  const o=options||{},wall=o.wall||{},floor=o.floor||{},geometry=o.geometry||{},fgs=o.floorGeometrySystem;
  const issues=[];
  if(wallLength(wall)<.5) issues.push({code:'short',message:'墙体至少0.5m'});
  const len=Math.max(.01,wallLength(wall));
  const steps=Math.max(2,Math.ceil(len/.25));
  for(let i=0;i<=steps;i++){
    const t=i/steps;
    const p={x:wall.x1+(wall.x2-wall.x1)*t,y:wall.y1+(wall.y2-wall.y1)*t};
    if(!pointInside(p,geometry,fgs)){issues.push({code:'outside',message:'墙体必须位于房源内部'});break;}
  }
  const probe = Math.abs(wall.x1-wall.x2)<.01
    ? {x:wall.x1-.06,y:Math.min(wall.y1,wall.y2),w:.12,h:Math.abs(wall.y2-wall.y1)}
    : {x:Math.min(wall.x1,wall.x2),y:wall.y1-.06,w:Math.abs(wall.x2-wall.x1),h:.12};

  for(const obs of geometry.obstacles||[]){
    if(rectsOverlap(probe,obstacleRect(obs))){issues.push({code:'structure',message:'墙体不能穿过固定结构'});break;}
  }
  for(const item of floor.editorPlacements||[]){
    if(rectsOverlap(probe,rectFor(item,false))){issues.push({code:'furniture',message:'墙体不能穿过家具/设备'});break;}
  }
  for(const ent of geometry.entrances||[]){
    if(rectsOverlap(probe,entranceRect(ent,geometry,o.clearDepthM))){
      issues.push({code:'entrance',message:'墙体不能封死门店入口'});break;
    }
  }
  return {valid:issues.length===0,issues,wall};
}

function nearestWall(floor,point,maxDistance=.28){
  let best=null,bestD=Infinity;
  for(const wall of floor.editorWalls||[]){
    const d=pointToSegmentDistance(point,wall);
    if(d<bestD){bestD=d;best=wall;}
  }
  return best && bestD<=maxDistance ? best : null;
}

function createDoorOnWall(wall,point,width=.9,id){
  if(!wall) return null;
  const vertical=Math.abs(wall.x1-wall.x2)<.01;
  const len=wallLength(wall);
  if(len<width+.35) return null;

  if(vertical){
    const min=Math.min(wall.y1,wall.y2)+width/2+.12;
    const max=Math.max(wall.y1,wall.y2)-width/2-.12;
    return {id:id||null,wallId:wall.id,x:wall.x1,y:snap(clamp(point.y,min,max)),width:round2(width)};
  }
  const min=Math.min(wall.x1,wall.x2)+width/2+.12;
  const max=Math.max(wall.x1,wall.x2)-width/2-.12;
  return {id:id||null,wallId:wall.id,x:snap(clamp(point.x,min,max)),y:wall.y1,width:round2(width)};
}

function edgeBlocked(a,b,walls,doors,doorsOpen){
  const mx=(a.x+b.x)/2,my=(a.y+b.y)/2;
  for(const wall of walls||[]){
    const vertical=Math.abs(wall.x1-wall.x2)<.01;
    let crosses=false;
    if(vertical && (a.x-wall.x1)*(b.x-wall.x1)<=0 && Math.abs(a.x-b.x)>.01){
      crosses=my>=Math.min(wall.y1,wall.y2)-.02 && my<=Math.max(wall.y1,wall.y2)+.02;
    } else if(!vertical && (a.y-wall.y1)*(b.y-wall.y1)<=0 && Math.abs(a.y-b.y)>.01){
      crosses=mx>=Math.min(wall.x1,wall.x2)-.02 && mx<=Math.max(wall.x1,wall.x2)+.02;
    }
    if(!crosses) continue;
    if(doorsOpen){
      const gap=doorGapOnWall(wall,doors).some(d=>{
        const half=(Number(d.width)||.9)/2;
        return vertical ? Math.abs(my-Number(d.y))<=half : Math.abs(mx-Number(d.x))<=half;
      });
      if(gap) continue;
    }
    return true;
  }
  return false;
}

function buildGrid(geometry,floorGeometrySystem,res=ROOM_GRID_M){
  const cols=Math.max(1,Math.ceil(Number(geometry.widthM)/res));
  const rows=Math.max(1,Math.ceil(Number(geometry.depthM)/res));
  const valid=new Set();
  for(let r=0;r<rows;r++){
    for(let c=0;c<cols;c++){
      const p={x:(c+.5)*res,y:(r+.5)*res};
      if(pointInside(p,geometry,floorGeometrySystem)) valid.add(c+','+r);
    }
  }
  return {cols,rows,res,valid};
}

function components(options){
  const o=options||{},geometry=o.geometry||{},floor=o.floor||{},fgs=o.floorGeometrySystem;
  const grid=buildGrid(geometry,fgs,o.res||ROOM_GRID_M);
  const seen=new Set(),groups=[];
  const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
  for(const key of grid.valid){
    if(seen.has(key)) continue;
    const [sc,sr]=key.split(',').map(Number);
    const group=[];const q=[[sc,sr]];seen.add(key);
    while(q.length){
      const [c,r]=q.shift();group.push([c,r]);
      const a={x:(c+.5)*grid.res,y:(r+.5)*grid.res};
      for(const [dc,dr] of dirs){
        const nc=c+dc,nr=r+dr,nk=nc+','+nr;
        if(!grid.valid.has(nk)||seen.has(nk)) continue;
        const b={x:(nc+.5)*grid.res,y:(nr+.5)*grid.res};
        if(edgeBlocked(a,b,floor.editorWalls||[],floor.editorDoors||[],!!o.doorsOpen)) continue;
        seen.add(nk);q.push([nc,nr]);
      }
    }
    groups.push(group);
  }
  return {grid,groups};
}

function roomType(items){
  let kitchen=0,storage=0,dining=0,reception=0;
  for(const item of items){
    const s=specFor(item.kind)||{};
    kitchen+=Number(s.kitchen)||0;
    storage+=Number(s.storage)||0;
    reception+=Number(s.reception)||0;
    if(s.type==='table') dining+=3;
  }
  const scores=[['厨房工作区',kitchen],['储物空间',storage],['就餐空间',dining],['接待/等候空间',reception]]
    .filter(x=>x[1]>0).sort((a,b)=>b[1]-a[1]);
  if(!scores.length) return '未利用空间';
  if(scores.length>1 && scores[0][1]-scores[1][1]<=1) return '混合功能空间';
  return scores[0][0];
}

function detectRooms(options){
  const o=options||{};
  const result=components({...o,doorsOpen:false});
  const placements=o.floor.editorPlacements||[];
  return result.groups.map((group,index)=>{
    const keys=new Set(group.map(([c,r])=>c+','+r));
    const items=placements.filter(item=>{
      const c=Math.floor((Number(item.mx)||0)/result.grid.res);
      const r=Math.floor((Number(item.my)||0)/result.grid.res);
      return keys.has(c+','+r);
    });
    const area=round2(group.length*result.grid.res*result.grid.res);
    return {
      id:'room_'+index,
      area,
      type:roomType(items),
      itemCount:items.length,
      seats:items.reduce((sum,item)=>sum+((specFor(item.kind)||{}).seats||0),0)
    };
  }).filter(room=>room.area>=1);
}

function walkConnectivity(options){
  const result=components({...options,doorsOpen:true,res:.45});
  return {
    components:result.groups.length,
    connected:result.groups.length<=1
  };
}

function analyzeFloor(options){
  const o=options||{},floor=o.floor||{},geometry=o.geometry||{};
  const issues=[];let status='green';
  let furnitureUseArea=0;

  for(const item of floor.editorPlacements||[]){
    const v=validateCandidate({
      ...o,
      item,
      placements:floor.editorPlacements||[],
      ignoreId:item.id
    });
    const s=specFor(item.kind);
    furnitureUseArea += Number(s&&s.floorArea)||0;
    if(!v.valid){
      status='red';
      issues.push(...v.issues.map(issue=>({...issue,itemId:item.id})));
    }else if(v.status==='yellow'&&status!=='red'){
      status='yellow';
      issues.push(...v.issues.map(issue=>({...issue,itemId:item.id})));
    }
  }

  for(const wall of floor.editorWalls||[]){
    const v=validateWall({...o,wall});
    if(!v.valid){
      status='red';
      issues.push(...v.issues.map(issue=>({...issue,wallId:wall.id})));
    }
  }

  const walk=walkConnectivity(o);
  if(!walk.connected){
    status='red';
    issues.push({code:'blocked_route',message:'内墙切断主要通行，请增加门或调整墙体'});
  }

  const rooms=detectRooms(o);
  const structureArea=Math.max(0,Number(o.areaMetrics&&o.areaMetrics.structuralReservedArea)||0);
  const remaining=Math.max(0,(Number(floor.area)||0)-structureArea-furnitureUseArea);

  const unique=[];
  const seen=new Set();
  for(const issue of issues){
    const key=issue.code+':'+issue.message;
    if(seen.has(key)) continue;
    seen.add(key);unique.push(issue);
  }

  return {
    version:VERSION,
    valid:status!=='red',
    status,
    issues:unique,
    primaryIssue:unique[0]||null,
    rooms,
    roomCount:rooms.length,
    furnitureUseArea:round2(furnitureUseArea),
    remainingFrontArea:round2(remaining),
    frontArea:round2(Math.max(0,(Number(floor.area)||0)-structureArea)),
    mainAisleWidthM:walk.connected?0.90:0,
    serviceFactor:status==='red'?0.62:status==='yellow'?0.88:1
  };
}

module.exports={
  VERSION,GRID_M,VISIBLE_GRID_M,ROOM_GRID_M,SPECS,
  clamp,snap,specFor,isTable,isEquipment,dimensionsFor,rectFor,rectsOverlap,
  entranceRect,validateCandidate,findFirstValidPosition,
  normalizeWall,wallLength,validateWall,nearestWall,createDoorOnWall,
  detectRooms,analyzeFloor
};
