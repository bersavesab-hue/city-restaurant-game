'use strict';

// V0866_FREE_BUILD_SPATIAL
// Free-form restaurant renovation: the property shell is fixed, while the
// player draws internal walls, places doors and positions furniture/equipment.
// Legacy kitchen/storage/service ratios remain save-compatible only; they are
// not used as placement boundaries in this model.

const VERSION = 'V0866_FREE_BUILD_SPATIAL';
const GRID_M = 0.25;
const VISIBLE_GRID_M = 0.5;
const WALL_THICKNESS_M = 0.12;
const DEFAULT_DOOR_WIDTH_M = 0.90;

const FURNITURE_SPECS = Object.freeze({
  table2: { label:'2人桌', bodyW:0.75, bodyD:0.75, useW:1.50, useD:1.60, seats:2, floorArea:2.4, group:'dining' },
  table4: { label:'4人桌', bodyW:1.20, bodyD:0.75, useW:2.00, useD:1.80, seats:4, floorArea:3.6, group:'dining' },
  table6: { label:'6人桌', bodyW:1.60, bodyD:0.82, useW:2.40, useD:2.00, seats:6, floorArea:4.8, group:'dining' },
  table8: { label:'8人桌', bodyW:2.10, bodyD:0.88, useW:3.00, useD:2.00, seats:8, floorArea:6.0, group:'dining' },
  plant: { label:'绿植', bodyW:0.45, bodyD:0.45, useW:0.55, useD:0.55, floorArea:0.3, group:'decor' },
  sofa: { label:'等候沙发', bodyW:1.80, bodyD:0.72, useW:2.00, useD:1.15, floorArea:2.3, group:'decor' },
  screen: { label:'屏风', bodyW:1.50, bodyD:0.18, useW:1.65, useD:0.50, floorArea:0.8, group:'decor' },
  pendant: { label:'吊灯', bodyW:0.35, bodyD:0.35, useW:0.35, useD:0.35, floorArea:0.1, group:'decor', overhead:true },

  stove: { label:'灶台', bodyW:1.20, bodyD:0.75, useW:1.45, useD:1.35, floorArea:2.0, group:'kitchen' },
  prep: { label:'操作台', bodyW:1.40, bodyD:0.70, useW:1.65, useD:1.20, floorArea:2.0, group:'kitchen' },
  sink: { label:'水池', bodyW:1.20, bodyD:0.65, useW:1.45, useD:1.10, floorArea:1.6, group:'kitchen' },
  fridge: { label:'冷柜', bodyW:0.80, bodyD:0.75, useW:1.00, useD:1.00, floorArea:1.0, group:'storage' },
  storage_shelf: { label:'货架', bodyW:1.20, bodyD:0.45, useW:1.40, useD:0.80, floorArea:1.1, group:'storage' },
  cashier: { label:'收银台', bodyW:1.20, bodyD:0.65, useW:1.55, useD:1.10, floorArea:1.7, group:'service' }
});

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function round2(value) {
  return Number((Number(value) || 0).toFixed(2));
}

function snap(value, step) {
  const size = Math.max(0.01, Number(step) || GRID_M);
  return round2(Math.round((Number(value) || 0) / size) * size);
}

function isTable(kind) {
  return /^table(?:2|4|6|8)$/.test(String(kind || ''));
}

function specFor(kind) {
  return FURNITURE_SPECS[kind] || null;
}

function dimensionsFor(item, useEnvelope) {
  const spec = specFor(item && item.kind);
  if (!spec) return { w:0.5, d:0.5 };

  let w = useEnvelope ? spec.useW : spec.bodyW;
  let d = useEnvelope ? spec.useD : spec.bodyD;
  const rotation = ((Number(item && item.rotation) || 0) % 180 + 180) % 180;

  if (rotation === 90) {
    const t = w;
    w = d;
    d = t;
  }

  return { w, d };
}

function rectFor(item, useEnvelope) {
  const size = dimensionsFor(item, useEnvelope);
  const cx = Number(item && (item.mx ?? item.x)) || 0;
  const cy = Number(item && (item.my ?? item.y)) || 0;

  return {
    x:cx - size.w / 2,
    y:cy - size.d / 2,
    w:size.w,
    h:size.d,
    cx,
    cy
  };
}

function rectsOverlap(a, b, epsilon) {
  const e = Number.isFinite(Number(epsilon)) ? Number(epsilon) : 0.001;
  return (
    a.x < b.x + b.w - e &&
    a.x + a.w > b.x + e &&
    a.y < b.y + b.h - e &&
    a.y + a.h > b.y + e
  );
}

function inflateRect(rect, amount) {
  const n = Math.max(0, Number(amount) || 0);
  return {
    x:rect.x - n,
    y:rect.y - n,
    w:rect.w + n * 2,
    h:rect.h + n * 2
  };
}

function rectPoints(rect) {
  return [
    {x:rect.x,y:rect.y},
    {x:rect.x+rect.w,y:rect.y},
    {x:rect.x+rect.w,y:rect.y+rect.h},
    {x:rect.x,y:rect.y+rect.h},
    {x:rect.x+rect.w/2,y:rect.y},
    {x:rect.x+rect.w/2,y:rect.y+rect.h},
    {x:rect.x,y:rect.y+rect.h/2},
    {x:rect.x+rect.w,y:rect.y+rect.h/2},
    {x:rect.x+rect.w/2,y:rect.y+rect.h/2}
  ];
}

function rectInsidePolygon(rect, polygon, pointInPolygon) {
  return Array.isArray(polygon) &&
    polygon.length >= 3 &&
    rectPoints(rect).every(point => pointInPolygon(point, polygon));
}

function obstacleRect(obstacle) {
  return {
    x:Number(obstacle.x) || 0,
    y:Number(obstacle.y) || 0,
    w:Math.max(0, Number(obstacle.w) || 0),
    h:Math.max(0, Number(obstacle.h) || 0)
  };
}

function circleIntersectsRect(circle, rect, padding) {
  const r = Math.max(0, Number(circle.radius) || 0) + (Number(padding) || 0);
  const cx = Number(circle.x) || 0;
  const cy = Number(circle.y) || 0;
  const nx = clamp(cx, rect.x, rect.x + rect.w);
  const ny = clamp(cy, rect.y, rect.y + rect.h);
  const dx = cx - nx;
  const dy = cy - ny;
  return dx * dx + dy * dy < r * r;
}

function entranceRect(entrance, geometry, clearDepthM) {
  const width = Math.max(0.9, Number(entrance && entrance.width) || 1.2) + 0.5;
  const half = width / 2;
  const depth = Math.max(1.0, Number(clearDepthM) || 1.2);
  const ex = Number(entrance && entrance.x) || 0;
  const ey = Number(entrance && entrance.y) || 0;

  if (entrance && entrance.side === 'north') {
    return { x:ex-half, y:Math.max(0,ey), w:width, h:depth };
  }

  if (entrance && entrance.side === 'east') {
    return { x:Math.max(0,ex-depth), y:ey-half, w:depth, h:width };
  }

  if (entrance && entrance.side === 'west') {
    return { x:ex, y:ey-half, w:depth, h:width };
  }

  return {
    x:ex-half,
    y:Math.max(0, Number(geometry && geometry.depthM) - depth),
    w:width,
    h:depth
  };
}

function zoneGeometry(floor, geometry) {
  // Compatibility API. In free-build mode, the whole property shell is the
  // editable area; there is no hard-coded dining/kitchen rectangle.
  return {
    backRatio:0,
    serviceWidthRatio:0,
    dining:{
      x:0,
      y:0,
      w:Number(geometry && geometry.widthM) || 0,
      h:Number(geometry && geometry.depthM) || 0
    }
  };
}

function normalizeWall(wall) {
  if (!wall) return null;

  let x1 = snap(wall.x1);
  let y1 = snap(wall.y1);
  let x2 = snap(wall.x2);
  let y2 = snap(wall.y2);

  if (Math.abs(x2 - x1) >= Math.abs(y2 - y1)) {
    y2 = y1;
  } else {
    x2 = x1;
  }

  if (x1 > x2 || y1 > y2) {
    const tx = x1, ty = y1;
    x1 = x2; y1 = y2;
    x2 = tx; y2 = ty;
  }

  return {
    ...wall,
    x1:round2(x1),
    y1:round2(y1),
    x2:round2(x2),
    y2:round2(y2),
    thickness:Math.max(0.08, Number(wall.thickness) || WALL_THICKNESS_M)
  };
}

function wallLength(wall) {
  const w = normalizeWall(wall);
  if (!w) return 0;
  return round2(Math.abs(w.x2 - w.x1) + Math.abs(w.y2 - w.y1));
}

function wallOrientation(wall) {
  const w = normalizeWall(wall);
  return w && Math.abs(w.x2 - w.x1) >= Math.abs(w.y2 - w.y1)
    ? 'horizontal'
    : 'vertical';
}

function doorForWall(door, wall) {
  if (!door || !wall || door.wallId !== wall.id) return null;
  const w = normalizeWall(wall);
  const width = clamp(Number(door.width) || DEFAULT_DOOR_WIDTH_M, 0.70, 1.60);

  if (wallOrientation(w) === 'horizontal') {
    const c = clamp(Number(door.cx) || w.x1, w.x1 + width / 2, w.x2 - width / 2);
    return { ...door, cx:c, cy:w.y1, width };
  }

  const c = clamp(Number(door.cy) || w.y1, w.y1 + width / 2, w.y2 - width / 2);
  return { ...door, cx:w.x1, cy:c, width };
}

function wallRects(floor, includeDoorGaps) {
  const walls = Array.isArray(floor && floor.editorWalls) ? floor.editorWalls : [];
  const doors = Array.isArray(floor && floor.editorDoors) ? floor.editorDoors : [];
  const result = [];

  for (const raw of walls) {
    const wall = normalizeWall(raw);
    if (!wall || wallLength(wall) < 0.25) continue;

    const horizontal = wallOrientation(wall) === 'horizontal';
    const thickness = wall.thickness || WALL_THICKNESS_M;
    const cuts = [];

    if (includeDoorGaps !== false) {
      for (const rawDoor of doors) {
        const door = doorForWall(rawDoor, wall);
        if (!door) continue;

        if (horizontal) {
          cuts.push([
            clamp(door.cx - door.width / 2, wall.x1, wall.x2),
            clamp(door.cx + door.width / 2, wall.x1, wall.x2)
          ]);
        } else {
          cuts.push([
            clamp(door.cy - door.width / 2, wall.y1, wall.y2),
            clamp(door.cy + door.width / 2, wall.y1, wall.y2)
          ]);
        }
      }
    }

    cuts.sort((a,b) => a[0] - b[0]);

    const start = horizontal ? wall.x1 : wall.y1;
    const end = horizontal ? wall.x2 : wall.y2;
    let cursor = start;

    for (const cut of cuts) {
      if (cut[0] > cursor + 0.01) {
        if (horizontal) {
          result.push({
            wallId:wall.id,
            x:cursor,
            y:wall.y1 - thickness / 2,
            w:cut[0] - cursor,
            h:thickness
          });
        } else {
          result.push({
            wallId:wall.id,
            x:wall.x1 - thickness / 2,
            y:cursor,
            w:thickness,
            h:cut[0] - cursor
          });
        }
      }
      cursor = Math.max(cursor, cut[1]);
    }

    if (cursor < end - 0.01) {
      if (horizontal) {
        result.push({
          wallId:wall.id,
          x:cursor,
          y:wall.y1 - thickness / 2,
          w:end - cursor,
          h:thickness
        });
      } else {
        result.push({
          wallId:wall.id,
          x:wall.x1 - thickness / 2,
          y:cursor,
          w:thickness,
          h:end - cursor
        });
      }
    }
  }

  return result;
}

function internalDoorClearRects(floor) {
  const walls = Array.isArray(floor && floor.editorWalls) ? floor.editorWalls : [];
  const doors = Array.isArray(floor && floor.editorDoors) ? floor.editorDoors : [];
  const result = [];

  for (const rawDoor of doors) {
    const wall = walls.find(item => item.id === rawDoor.wallId);
    const door = doorForWall(rawDoor, wall);
    if (!door || !wall) continue;

    if (wallOrientation(wall) === 'horizontal') {
      result.push({
        doorId:door.id,
        x:door.cx - door.width / 2,
        y:door.cy - 0.45,
        w:door.width,
        h:0.90
      });
    } else {
      result.push({
        doorId:door.id,
        x:door.cx - 0.45,
        y:door.cy - door.width / 2,
        w:0.90,
        h:door.width
      });
    }
  }

  return result;
}

function pushIssue(list, level, code, message, detail) {
  list.push({ level, code, message, detail:detail || null });
}

function validateCandidate(args) {
  const {
    item,
    floor,
    geometry,
    placements = [],
    floorGeometrySystem,
    clearDepthM = 1.2,
    ignoreId = null
  } = args || {};

  const spec = specFor(item && item.kind);
  const issues = [];

  if (!item || !spec || !floor || !geometry || !floorGeometrySystem) {
    return {
      status:'red',
      valid:false,
      issues:[{level:'red',code:'INVALID_DATA',message:'装修物体数据不完整'}]
    };
  }

  const snapped = {
    ...item,
    mx:snap(item.mx),
    my:snap(item.my),
    rotation:((Number(item.rotation) || 0) % 180 + 180) % 180
  };

  const body = rectFor(snapped, false);
  const use = rectFor(snapped, true);

  if (!rectInsidePolygon(body, geometry.polygon, floorGeometrySystem.pointInPolygon)) {
    pushIssue(issues, 'red', 'OUTSIDE_PROPERTY', spec.label + '超出门店外墙');
  }

  if (!spec.overhead && !rectInsidePolygon(use, geometry.polygon, floorGeometrySystem.pointInPolygon)) {
    pushIssue(issues, 'red', 'USE_SPACE_OUTSIDE', spec.label + '的使用空间超出门店外墙');
  }

  for (const obstacle of geometry.obstacles || []) {
    if (obstacle.type === 'column') {
      if (circleIntersectsRect(obstacle, body, 0.04)) {
        pushIssue(issues, 'red', 'COLUMN_BODY_COLLISION', '与柱体发生碰撞');
      } else if (!spec.overhead && circleIntersectsRect(obstacle, use, 0.10)) {
        pushIssue(issues, 'yellow', 'COLUMN_CLEARANCE_TIGHT', '使用空间贴近柱体');
      }
    } else {
      const box = obstacleRect(obstacle);
      if (rectsOverlap(body, box)) {
        pushIssue(
          issues,
          'red',
          'FIXED_STRUCTURE_COLLISION',
          '与' + (obstacle.type === 'toilet' ? '卫生间' : obstacle.type === 'stair' ? '楼梯' : '固定结构') + '发生碰撞'
        );
      } else if (!spec.overhead && rectsOverlap(use, inflateRect(box, 0.12))) {
        pushIssue(issues, 'yellow', 'FIXED_CLEARANCE_TIGHT', '使用空间贴近固定结构');
      }
    }
  }

  if (!spec.overhead) {
    for (const entrance of geometry.entrances || []) {
      if (rectsOverlap(use, entranceRect(entrance, geometry, clearDepthM))) {
        pushIssue(issues, 'red', 'ENTRANCE_CLEARANCE', '占用门店入口/消防疏散净空');
      }
    }

    for (const box of wallRects(floor, true)) {
      if (rectsOverlap(body, box)) {
        pushIssue(issues, 'red', 'WALL_BODY_COLLISION', '与内墙发生碰撞');
      } else if (rectsOverlap(use, inflateRect(box, 0.06))) {
        pushIssue(issues, 'yellow', 'WALL_CLEARANCE_TIGHT', '使用空间贴近内墙');
      }
    }

    for (const box of internalDoorClearRects(floor)) {
      if (rectsOverlap(use, box)) {
        pushIssue(issues, 'red', 'DOOR_CLEARANCE', '占用室内门通行空间');
      }
    }
  }

  for (const other of placements || []) {
    if (!other || other.id === ignoreId || other.id === item.id) continue;
    const otherSpec = specFor(other.kind);
    if (!otherSpec) continue;

    const otherBody = rectFor(other, false);
    if (rectsOverlap(body, otherBody)) {
      pushIssue(issues, 'red', 'FURNITURE_BODY_COLLISION', '与' + otherSpec.label + '发生碰撞');
      continue;
    }

    if (!spec.overhead && !otherSpec.overhead) {
      const otherUse = rectFor(other, true);
      if (rectsOverlap(use, otherUse)) {
        pushIssue(issues, 'yellow', 'USE_SPACE_OVERLAP', '与' + otherSpec.label + '的使用空间重叠');
      }
    }
  }

  const redCount = issues.filter(issue => issue.level === 'red').length;
  const yellowCount = issues.filter(issue => issue.level === 'yellow').length;

  return {
    item:snapped,
    body,
    use,
    issues,
    redCount,
    yellowCount,
    status:redCount ? 'red' : yellowCount ? 'yellow' : 'green',
    valid:redCount === 0
  };
}

function validateWallCandidate(args) {
  const {
    wall,
    floor,
    geometry,
    placements = [],
    floorGeometrySystem
  } = args || {};

  const normalized = normalizeWall(wall);
  const issues = [];

  if (!normalized || !floor || !geometry || !floorGeometrySystem) {
    return { valid:false, issues:[{level:'red',code:'INVALID_WALL',message:'墙体数据不完整'}] };
  }

  const length = wallLength(normalized);

  if (length < 0.50) {
    pushIssue(issues, 'red', 'WALL_TOO_SHORT', '墙体至少需要0.50m');
  }

  const mx = (normalized.x1 + normalized.x2) / 2;
  const my = (normalized.y1 + normalized.y2) / 2;

  // Endpoints are allowed to touch the fixed outer shell. Test a point a few
  // centimeters inward so an internal wall can properly close a room.
  const points = [
    {
      x:normalized.x1 + (mx-normalized.x1)*0.02,
      y:normalized.y1 + (my-normalized.y1)*0.02
    },
    {
      x:normalized.x2 + (mx-normalized.x2)*0.02,
      y:normalized.y2 + (my-normalized.y2)*0.02
    },
    {x:mx,y:my}
  ];

  if (!points.every(point => floorGeometrySystem.pointInPolygon(point, geometry.polygon || []))) {
    pushIssue(issues, 'red', 'WALL_OUTSIDE_PROPERTY', '内墙不能超出房源外墙');
  }

  const candidateRects = wallRects(
    { editorWalls:[normalized], editorDoors:[] },
    true
  );

  for (const item of placements || []) {
    const spec = specFor(item && item.kind);
    if (!spec || spec.overhead) continue;

    const body = rectFor(item, false);
    if (candidateRects.some(rect => rectsOverlap(rect, body))) {
      pushIssue(issues, 'red', 'WALL_THROUGH_FURNITURE', '墙体穿过了' + spec.label);
      break;
    }
  }

  for (const entrance of geometry.entrances || []) {
    const clear = entranceRect(entrance, geometry, 1.0);
    if (candidateRects.some(rect => rectsOverlap(rect, clear))) {
      pushIssue(issues, 'red', 'WALL_BLOCKS_ENTRANCE', '墙体挡住门店入口');
    }
  }

  const duplicate = (floor.editorWalls || []).some(existing => {
    const e = normalizeWall(existing);
    return e &&
      e.x1 === normalized.x1 &&
      e.y1 === normalized.y1 &&
      e.x2 === normalized.x2 &&
      e.y2 === normalized.y2;
  });

  if (duplicate) {
    pushIssue(issues, 'red', 'WALL_DUPLICATE', '这里已经有一面墙');
  }

  return {
    valid:!issues.some(issue => issue.level === 'red'),
    wall:normalized,
    length,
    issues
  };
}

function nearestWall(floor, point, maxDistance) {
  const px = Number(point && point.x) || 0;
  const py = Number(point && point.y) || 0;
  const limit = Math.max(0.15, Number(maxDistance) || 0.45);
  let best = null;

  for (const raw of floor && floor.editorWalls || []) {
    const wall = normalizeWall(raw);
    if (!wall) continue;

    let nx, ny;
    if (wallOrientation(wall) === 'horizontal') {
      nx = clamp(px, wall.x1, wall.x2);
      ny = wall.y1;
    } else {
      nx = wall.x1;
      ny = clamp(py, wall.y1, wall.y2);
    }

    const dx = px - nx;
    const dy = py - ny;
    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance <= limit && (!best || distance < best.distance)) {
      best = { wall, x:nx, y:ny, distance };
    }
  }

  return best;
}

function makeDoorAt(floor, point, width) {
  const near = nearestWall(floor, point, 0.55);
  if (!near) {
    return { ok:false, message:'请点在已有内墙上开门' };
  }

  const wall = near.wall;
  const length = wallLength(wall);
  const doorWidth = clamp(Number(width) || DEFAULT_DOOR_WIDTH_M, 0.70, 1.20);

  if (length < doorWidth + 0.35) {
    return { ok:false, message:'这面墙太短，无法开门' };
  }

  const horizontal = wallOrientation(wall) === 'horizontal';
  const door = {
    id:'',
    wallId:wall.id,
    cx:horizontal
      ? snap(clamp(near.x, wall.x1 + doorWidth/2 + 0.10, wall.x2 - doorWidth/2 - 0.10))
      : wall.x1,
    cy:horizontal
      ? wall.y1
      : snap(clamp(near.y, wall.y1 + doorWidth/2 + 0.10, wall.y2 - doorWidth/2 - 0.10)),
    width:doorWidth
  };

  return { ok:true, door };
}

function pointBlockedByObstacle(point, geometry, padding) {
  const p = Math.max(0, Number(padding) || 0);

  for (const obstacle of geometry.obstacles || []) {
    if (obstacle.type === 'column') {
      const dx = Number(point.x) - Number(obstacle.x);
      const dy = Number(point.y) - Number(obstacle.y);
      if (Math.sqrt(dx*dx+dy*dy) <= (Number(obstacle.radius)||0.22)+p) return true;
    } else {
      const box = inflateRect(obstacleRect(obstacle), p);
      if (
        point.x >= box.x &&
        point.x <= box.x + box.w &&
        point.y >= box.y &&
        point.y <= box.y + box.h
      ) return true;
    }
  }

  return false;
}

function pointBlockedByRects(point, rects) {
  return (rects || []).some(rect => (
    point.x >= rect.x &&
    point.x <= rect.x + rect.w &&
    point.y >= rect.y &&
    point.y <= rect.y + rect.h
  ));
}

function gridKey(ix, iy) {
  return ix + ':' + iy;
}

function buildReachability(args) {
  const {
    floor,
    geometry,
    placements = [],
    floorGeometrySystem,
    clearanceM = 0.90,
    closeDoors = false,
    blockFurniture = true
  } = args || {};

  const step = GRID_M;
  const width = Number(geometry.widthM) || 0;
  const depth = Number(geometry.depthM) || 0;
  const nx = Math.max(1, Math.ceil(width / step));
  const ny = Math.max(1, Math.ceil(depth / step));
  const pad = Math.max(0, (Number(clearanceM) || 0) / 2 - 0.18);
  const wallInflate = closeDoors
    ? GRID_M * 0.55
    : 0.03;

  const wallBoxes = wallRects(floor, !closeDoors)
    .map(rect => inflateRect(rect, wallInflate));
  const furnitureBoxes = blockFurniture
    ? (placements || [])
        .filter(item => {
          const spec = specFor(item && item.kind);
          return spec && !spec.overhead;
        })
        .map(item => inflateRect(rectFor(item, false), Math.max(0.08, pad * 0.55)))
    : [];

  function cellPoint(ix, iy) {
    return {
      x:Math.min(width, (ix + 0.5) * step),
      y:Math.min(depth, (iy + 0.5) * step)
    };
  }

  function open(ix, iy) {
    if (ix < 0 || iy < 0 || ix >= nx || iy >= ny) return false;
    const point = cellPoint(ix, iy);
    if (!floorGeometrySystem.pointInPolygon(point, geometry.polygon || [])) return false;
    if (pointBlockedByObstacle(point, geometry, Math.max(0.03, pad * 0.3))) return false;
    if (pointBlockedByRects(point, wallBoxes)) return false;
    if (pointBlockedByRects(point, furnitureBoxes)) return false;
    return true;
  }

  return { step, width, depth, nx, ny, cellPoint, open };
}

function entranceStartCells(grid, geometry) {
  const cells = [];
  const entrances = geometry.entrances || [];

  for (const entrance of entrances) {
    let x = Number(entrance.x) || 0;
    let y = Number(entrance.y) || 0;
    const inset = 0.45;

    if (entrance.side === 'north') y += inset;
    else if (entrance.side === 'east') x -= inset;
    else if (entrance.side === 'west') x += inset;
    else y -= inset;

    const ix = clamp(Math.floor(x / grid.step), 0, grid.nx - 1);
    const iy = clamp(Math.floor(y / grid.step), 0, grid.ny - 1);

    if (grid.open(ix, iy)) cells.push([ix, iy]);
  }

  if (!cells.length) {
    for (let iy = grid.ny - 1; iy >= 0 && !cells.length; iy--) {
      for (let ix = 0; ix < grid.nx; ix++) {
        if (grid.open(ix, iy)) {
          cells.push([ix, iy]);
          break;
        }
      }
    }
  }

  return cells;
}

function flood(grid, starts) {
  const queue = (starts || []).slice();
  const visited = new Set();

  for (const [ix,iy] of queue) visited.add(gridKey(ix,iy));

  for (let q = 0; q < queue.length; q++) {
    const [ix,iy] = queue[q];
    const neighbors = [[ix+1,iy],[ix-1,iy],[ix,iy+1],[ix,iy-1]];

    for (const [nx,ny] of neighbors) {
      const key = gridKey(nx,ny);
      if (visited.has(key) || !grid.open(nx,ny)) continue;
      visited.add(key);
      queue.push([nx,ny]);
    }
  }

  return visited;
}

function reachableNearItem(visited, grid, item) {
  const spec = specFor(item && item.kind);
  if (!spec || spec.overhead) return true;

  const body = rectFor(item, false);
  const margin = 0.85;
  const x0 = Math.max(0, Math.floor((body.x - margin) / grid.step));
  const y0 = Math.max(0, Math.floor((body.y - margin) / grid.step));
  const x1 = Math.min(grid.nx - 1, Math.ceil((body.x + body.w + margin) / grid.step));
  const y1 = Math.min(grid.ny - 1, Math.ceil((body.y + body.h + margin) / grid.step));

  for (let iy = y0; iy <= y1; iy++) {
    for (let ix = x0; ix <= x1; ix++) {
      if (!visited.has(gridKey(ix,iy))) continue;
      const p = grid.cellPoint(ix,iy);
      const dx = Math.max(body.x - p.x, 0, p.x - (body.x + body.w));
      const dy = Math.max(body.y - p.y, 0, p.y - (body.y + body.h));
      if (Math.sqrt(dx*dx + dy*dy) <= margin) return true;
    }
  }

  return false;
}

function pathExists(args, clearanceM) {
  const grid = buildReachability({
    ...(args || {}),
    clearanceM:Number(clearanceM) || 0.90,
    closeDoors:false,
    blockFurniture:true
  });

  const starts = entranceStartCells(grid, args.geometry);
  if (!starts.length) return false;

  const visited = flood(grid, starts);

  return (args.placements || []).every(item => reachableNearItem(visited, grid, item));
}

function detectRooms(args) {
  const {
    floor,
    geometry,
    placements = [],
    floorGeometrySystem
  } = args || {};

  if (!floor || !geometry || !floorGeometrySystem) return [];

  const grid = buildReachability({
    floor,
    geometry,
    placements:[],
    floorGeometrySystem,
    clearanceM:0,
    closeDoors:true,
    blockFurniture:false
  });

  const seen = new Set();
  const rooms = [];

  for (let iy = 0; iy < grid.ny; iy++) {
    for (let ix = 0; ix < grid.nx; ix++) {
      const key = gridKey(ix,iy);
      if (seen.has(key) || !grid.open(ix,iy)) continue;

      const cells = [];
      const queue = [[ix,iy]];
      seen.add(key);

      for (let q = 0; q < queue.length; q++) {
        const [cx,cy] = queue[q];
        cells.push([cx,cy]);

        for (const [nx,ny] of [[cx+1,cy],[cx-1,cy],[cx,cy+1],[cx,cy-1]]) {
          const nk = gridKey(nx,ny);
          if (seen.has(nk) || !grid.open(nx,ny)) continue;
          seen.add(nk);
          queue.push([nx,ny]);
        }
      }

      const area = round2(cells.length * GRID_M * GRID_M);
      if (area < 0.75) continue;

      const cellSet = new Set(cells.map(([a,b]) => gridKey(a,b)));
      const items = (placements || []).filter(item => {
        const px = Number(item.mx) || 0;
        const py = Number(item.my) || 0;
        const gx = clamp(Math.floor(px / GRID_M), 0, grid.nx - 1);
        const gy = clamp(Math.floor(py / GRID_M), 0, grid.ny - 1);
        return cellSet.has(gridKey(gx,gy));
      });

      const groups = new Set(items.map(item => {
        const spec = specFor(item.kind);
        return spec && spec.group;
      }).filter(Boolean));

      let label = '空房间';
      if (groups.has('kitchen') && groups.has('dining')) label = '混合功能空间';
      else if (groups.has('kitchen')) label = '厨房工作间';
      else if (groups.has('storage')) label = '储物间';
      else if (groups.has('dining')) label = '就餐空间';
      else if (groups.has('service') || groups.has('decor')) label = '接待/等候空间';

      const xs = cells.map(([a]) => grid.cellPoint(a,0).x);
      const ys = cells.map(([,b]) => grid.cellPoint(0,b).y);

      rooms.push({
        id:'room_' + rooms.length,
        area,
        label,
        itemCount:items.length,
        groups:Array.from(groups),
        center:{
          x:round2(xs.reduce((s,v)=>s+v,0) / Math.max(1,xs.length)),
          y:round2(ys.reduce((s,v)=>s+v,0) / Math.max(1,ys.length))
        }
      });
    }
  }

  return rooms.sort((a,b) => b.area - a.area);
}

function legacyPlacements(floor, geometry, slots, floorGeometrySystem, clearDepthM) {
  const actual = Array.isArray(floor && floor.editorPlacements)
    ? floor.editorPlacements.map(item => ({...item}))
    : [];

  const counts = floor && floor.tables || {};

  for (const key of ['2','4','6','8']) {
    const kind = 'table' + key;
    const desired = Math.max(0, Number(counts[key]) || 0);
    let existing = actual.filter(item => item.kind === kind).length;

    while (existing < desired) {
      const found = findFirstValidPosition({
        kind,
        floor,
        geometry,
        placements:actual,
        floorGeometrySystem,
        clearDepthM,
        rotation:Number(key) >= 6 ? 90 : 0
      });

      if (!found) break;

      actual.push({
        id:'__legacy_' + key + '_' + existing,
        kind,
        mx:found.x,
        my:found.y,
        rotation:found.rotation || 0,
        synthetic:true
      });

      existing++;
    }
  }

  return actual;
}

function analyzeFloor(args) {
  const {
    floor,
    geometry,
    areaMetrics,
    floorGeometrySystem,
    clearDepthM = 1.2
  } = args || {};

  if (!floor || !geometry || !floorGeometrySystem) {
    return {
      valid:false,
      status:'red',
      issues:[{level:'red',code:'NO_GEOMETRY',message:'空间数据不可用'}],
      itemStates:{},
      serviceFactor:0.75,
      mainAisleWidthM:0,
      furnitureUseArea:0,
      remainingFrontArea:0,
      rooms:[]
    };
  }

  const placements = legacyPlacements(
    floor,
    geometry,
    areaMetrics && areaMetrics.usableDiningSlots || geometry.diningSlots || [],
    floorGeometrySystem,
    clearDepthM
  );

  const issues = [];
  const itemStates = {};
  let furnitureUseArea = 0;

  const expectedTables = ['2','4','6','8']
    .reduce((sum,key)=>sum+Math.max(0,Number(floor.tables && floor.tables[key])||0),0);
  const materializedTables = placements.filter(item=>isTable(item.kind)).length;

  if (materializedTables < expectedTables) {
    pushIssue(
      issues,
      'red',
      'UNPLACEABLE_TABLE_COUNT',
      '有' + (expectedTables-materializedTables) + '张餐桌无法找到合法位置'
    );
  }

  for (const item of placements) {
    const state = validateCandidate({
      item,
      floor,
      geometry,
      placements,
      floorGeometrySystem,
      clearDepthM,
      ignoreId:item.id
    });

    itemStates[item.id] = state;

    const spec = specFor(item.kind);
    if (spec && !spec.overhead) {
      furnitureUseArea += Number(spec.floorArea) || (spec.useW * spec.useD);
    }

    for (const issue of state.issues) {
      issues.push({
        ...issue,
        itemId:item.id,
        itemKind:item.kind,
        itemLabel:spec && spec.label || item.kind
      });
    }
  }

  const requiredPath = pathExists(
    { floor, geometry, placements, floorGeometrySystem },
    0.90
  );

  const comfortPath = requiredPath && pathExists(
    { floor, geometry, placements, floorGeometrySystem },
    1.10
  );

  if (!requiredPath && placements.some(item => {
    const spec = specFor(item.kind);
    return spec && !spec.overhead;
  })) {
    pushIssue(issues, 'red', 'MAIN_AISLE_BLOCKED', '入口到家具/设备的主通道不足0.90m或被阻断');
  } else if (requiredPath && !comfortPath) {
    pushIssue(issues, 'yellow', 'MAIN_AISLE_TIGHT', '主通道可通行，但不足1.10m');
  }

  const unique = [];
  const seen = new Set();

  for (const issue of issues) {
    const token = issue.code + ':' + (issue.itemId || '') + ':' + issue.message;
    if (seen.has(token)) continue;
    seen.add(token);
    unique.push(issue);
  }

  const redCount = unique.filter(issue => issue.level === 'red').length;
  const yellowCount = unique.filter(issue => issue.level === 'yellow').length;
  const frontArea = Math.max(
    0,
    Number(areaMetrics && areaMetrics.effectiveDiningArea) ||
    Number(geometry.areaM2) ||
    Number(floor.area) ||
    0
  );
  const rooms = detectRooms({ floor, geometry, placements, floorGeometrySystem });

  return {
    version:VERSION,
    gridM:GRID_M,
    visibleGridM:VISIBLE_GRID_M,
    placements,
    itemStates,
    issues:unique,
    primaryIssue:unique.find(issue=>issue.level==='red') || unique[0] || null,
    redCount,
    yellowCount,
    status:redCount ? 'red' : yellowCount ? 'yellow' : 'green',
    valid:redCount === 0,
    mainAisleWidthM:comfortPath ? 1.10 : requiredPath ? 0.90 : 0,
    serviceFactor:redCount ? 0.75 : yellowCount ? Math.max(0.88,0.97-yellowCount*0.015) : 1,
    furnitureUseArea:round2(furnitureUseArea),
    frontArea:round2(frontArea),
    remainingFrontArea:round2(frontArea-furnitureUseArea),
    roomCount:rooms.length,
    rooms,
    wallLengthM:round2((floor.editorWalls || []).reduce((sum,wall)=>sum+wallLength(wall),0)),
    doorCount:(floor.editorDoors || []).length
  };
}

function candidateGrid(floor, geometry) {
  const points = [];
  const step = VISIBLE_GRID_M;
  const width = Number(geometry.widthM) || 0;
  const depth = Number(geometry.depthM) || 0;

  for (let y = step/2; y <= depth-step/2; y += step) {
    for (let x = step/2; x <= width-step/2; x += step) {
      points.push({x:snap(x),y:snap(y)});
    }
  }

  const cx = width / 2;
  const cy = depth / 2;

  return points.sort((a,b) => {
    const da=(a.x-cx)*(a.x-cx)+(a.y-cy)*(a.y-cy);
    const db=(b.x-cx)*(b.x-cx)+(b.y-cy)*(b.y-cy);
    return da-db;
  });
}

function findFirstValidPosition(args) {
  const {
    kind,
    floor,
    geometry,
    placements = [],
    floorGeometrySystem,
    clearDepthM = 1.2,
    rotation = 0
  } = args || {};

  if (!specFor(kind)) return null;

  let yellow = null;

  for (const point of candidateGrid(floor, geometry)) {
    const item = {
      id:'__candidate__',
      kind,
      mx:point.x,
      my:point.y,
      rotation
    };

    const state = validateCandidate({
      item,
      floor,
      geometry,
      placements,
      floorGeometrySystem,
      clearDepthM,
      ignoreId:'__candidate__'
    });

    if (state.status === 'green') {
      return { ...point, rotation, state };
    }

    if (!yellow && state.valid) {
      yellow = { ...point, rotation, state };
    }
  }

  return yellow;
}

module.exports = {
  VERSION,
  GRID_M,
  VISIBLE_GRID_M,
  WALL_THICKNESS_M,
  DEFAULT_DOOR_WIDTH_M,
  FURNITURE_SPECS,
  snap,
  isTable,
  specFor,
  dimensionsFor,
  rectFor,
  rectsOverlap,
  zoneGeometry,
  entranceRect,
  normalizeWall,
  wallLength,
  wallOrientation,
  wallRects,
  internalDoorClearRects,
  validateCandidate,
  validateWallCandidate,
  nearestWall,
  makeDoorAt,
  detectRooms,
  analyzeFloor,
  findFirstValidPosition,
  materializeLegacyPlacements:legacyPlacements,
  pathExists
};
