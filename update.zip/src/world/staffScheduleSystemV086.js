'use strict';

const gameState =
  require('../core/gameState.js');

const openingConfig =
  require('../opening/openingConfig.js');

const SHIFT_DEFS = [
  { id:'opening', name:'开门班', startHour:6, endHour:14 },
  { id:'day', name:'日班', startHour:10, endHour:18 },
  { id:'evening', name:'晚班', startHour:15, endHour:23 },
  { id:'night', name:'夜班', startHour:20, endHour:4 }
];

const HOUR_PRESETS = [
  { id:'full', name:'全天', openHour:6, closeHour:23 },
  { id:'standard', name:'常规', openHour:10, closeHour:22 },
  { id:'breakfast', name:'早餐型', openHour:6, closeHour:18 },
  { id:'night', name:'夜宵型', openHour:11, closeHour:2 }
];

const ROLE_WEIGHTS = {
  manager:0.10,
  chef:0.38,
  server:0.37,
  cashier:0.15
};

function clamp(value,min=0,max=1) {
  return Math.max(
    min,
    Math.min(
      max,
      Number(value) || 0
    )
  );
}

function formatHour(hour) {
  const h =
    (
      Math.round(Number(hour) || 0) %
      24 +
      24
    ) %
    24;

  return String(h).padStart(2,'0') + ':00';
}

function getShop(shopId) {
  return (
    gameState.getBusiness().shops ||
    []
  ).find(
    row => row.id === shopId
  ) || null;
}

function getStaffState(shopId) {
  const prep =
    gameState.getOpeningPrep();

  prep.staffing =
    prep.staffing ||
    {};

  prep.staffing[shopId] =
    prep.staffing[shopId] ||
    {
      hired:[],
      candidateDay:null,
      candidates:[]
    };

  prep.staffing[shopId].hired =
    Array.isArray(
      prep.staffing[shopId].hired
    )
      ? prep.staffing[shopId].hired
      : [];

  return prep.staffing[shopId];
}

function businessHours(shop) {
  const raw =
    shop &&
    shop.businessHours &&
    typeof shop.businessHours === 'object'
      ? shop.businessHours
      : {};

  const openHour =
    Number.isFinite(Number(raw.openHour))
      ? Number(raw.openHour)
      : Number.isFinite(Number(shop && shop.openHour))
        ? Number(shop.openHour)
        : 6;

  const closeHour =
    Number.isFinite(Number(raw.closeHour))
      ? Number(raw.closeHour)
      : Number.isFinite(Number(shop && shop.closeHour))
        ? Number(shop.closeHour)
        : 23;

  return {
    openHour:clamp(openHour,0,24),
    closeHour:clamp(closeHour,0,24),
    presetId:raw.presetId || null
  };
}

function hourValue(time) {
  const source =
    time ||
    gameState.getTime();

  return (
    Number(source.hour) ||
    0
  ) +
  (
    Number(source.minute) ||
    0
  ) / 60;
}

function within(value,start,end) {
  if (start === end) {
    return true;
  }

  if (end > start) {
    return (
      value >= start &&
      value < end
    );
  }

  return (
    value >= start ||
    value < end
  );
}

function isOpen(shop,time) {
  const hours =
    businessHours(shop);

  return within(
    hourValue(time),
    hours.openHour,
    hours.closeHour
  );
}

function getShift(shiftId) {
  return (
    SHIFT_DEFS.find(
      row => row.id === shiftId
    ) ||
    SHIFT_DEFS[0]
  );
}

function isShiftActive(shiftId,time) {
  const shift =
    getShift(shiftId);

  return within(
    hourValue(time),
    shift.startHour,
    shift.endHour
  );
}

function defaultPattern(roleId) {
  if (roleId === 'server') {
    return [
      'day',
      'evening',
      'opening',
      'night'
    ];
  }

  return [
    'opening',
    'evening',
    'day',
    'night'
  ];
}

function ensureAssignments(shopId) {
  const state =
    getStaffState(shopId);

  const counters = {};

  for (const staff of state.hired) {
    const roleId =
      staff.roleId ||
      'server';

    counters[roleId] =
      Number(counters[roleId]) ||
      0;

    if (
      !SHIFT_DEFS.some(
        row => row.id === staff.shiftId
      )
    ) {
      const pattern =
        defaultPattern(roleId);

      staff.shiftId =
        pattern[
          counters[roleId] %
          pattern.length
        ];
    }

    counters[roleId] += 1;
  }

  return state;
}

function requiredByRole(shop) {
  const seats =
    Math.max(
      1,
      Number(
        shop &&
        (
          shop.seatEstimate ||
          shop.seats
        )
      ) ||
      30
    );

  const result = {};

  for (const role of openingConfig.roles) {
    result[role.id] =
      role.id === 'manager'
        ? 1
        : Math.max(
            1,
            Math.ceil(
              seats /
              Math.max(
                1,
                Number(role.seatsPerWorker) ||
                1
              )
            )
          );
  }

  return result;
}

function setBusinessHoursPreset(shopId,presetId) {
  const shop =
    getShop(shopId);

  const preset =
    HOUR_PRESETS.find(
      row => row.id === presetId
    );

  if (!shop || !preset) {
    return {
      ok:false,
      message:'营业时间方案不存在'
    };
  }

  shop.businessHours = {
    openHour:preset.openHour,
    closeHour:preset.closeHour,
    presetId:preset.id
  };

  return {
    ok:true,
    message:
      '营业时间已调整为 ' +
      formatHour(preset.openHour) +
      '–' +
      formatHour(preset.closeHour)
  };
}

function setStaffShift(shopId,staffId,shiftId) {
  const state =
    ensureAssignments(shopId);

  const staff =
    state.hired.find(
      row => row.id === staffId
    );

  const shift =
    SHIFT_DEFS.find(
      row => row.id === shiftId
    );

  if (!staff || !shift) {
    return {
      ok:false,
      message:'员工或班次不存在'
    };
  }

  staff.shiftId =
    shift.id;

  return {
    ok:true,
    message:
      (staff.name || '员工') +
      ' 已调整为' +
      shift.name,
    shiftId:shift.id
  };
}

function cycleStaffShift(shopId,staffId) {
  const state =
    ensureAssignments(shopId);

  const staff =
    state.hired.find(
      row => row.id === staffId
    );

  if (!staff) {
    return {
      ok:false,
      message:'员工不存在'
    };
  }

  const index =
    Math.max(
      0,
      SHIFT_DEFS.findIndex(
        row => row.id === staff.shiftId
      )
    );

  const next =
    SHIFT_DEFS[
      (
        index +
        1
      ) %
      SHIFT_DEFS.length
    ];

  return setStaffShift(
    shopId,
    staffId,
    next.id
  );
}

function getCoverage(shopId,time) {
  const shop =
    getShop(shopId);

  if (!shop) {
    return {
      isOpen:false,
      coverageMultiplier:1,
      coveragePercent:100,
      activeStaff:0,
      totalStaff:0,
      underStaffed:false,
      roleCoverage:{},
      activeStaffIds:[]
    };
  }

  const state =
    ensureAssignments(shopId);

  const open =
    isOpen(shop,time);

  const required =
    requiredByRole(shop);

  const activeByRole = {};
  const activeStaff = [];

  for (const role of openingConfig.roles) {
    activeByRole[role.id] = 0;
  }

  for (const staff of state.hired) {
    if (
      isShiftActive(
        staff.shiftId,
        time
      )
    ) {
      activeStaff.push(staff);

      const roleId =
        staff.roleId ||
        'server';

      activeByRole[roleId] =
        (
          Number(activeByRole[roleId]) ||
          0
        ) + 1;
    }
  }

  const roleCoverage = {};
  let weighted = 0;

  for (const role of openingConfig.roles) {
    const need =
      Math.max(
        1,
        Number(required[role.id]) ||
        1
      );

    const ratio =
      clamp(
        (
          Number(activeByRole[role.id]) ||
          0
        ) /
        need,
        0,
        1.15
      );

    roleCoverage[role.id] = {
      active:
        Number(activeByRole[role.id]) ||
        0,
      required:need,
      ratio:Math.round(ratio * 100)
    };

    weighted +=
      ratio *
      (
        ROLE_WEIGHTS[role.id] ||
        0
      );
  }

  const coverageMultiplier =
    !open
      ? 0
      : clamp(
          0.35 +
          weighted *
          0.70,
          0.35,
          1.08
        );

  return {
    isOpen:open,
    coverageMultiplier,
    coveragePercent:
      Math.round(
        coverageMultiplier *
        100
      ),
    activeStaff:activeStaff.length,
    totalStaff:state.hired.length,
    underStaffed:
      open &&
      coverageMultiplier < 0.82,
    activeByRole,
    roleCoverage,
    required,
    activeStaffIds:
      activeStaff.map(
        row => row.id
      )
  };
}

function getDashboard(shopId,time) {
  const shop =
    getShop(shopId);

  if (!shop) {
    return null;
  }

  const state =
    ensureAssignments(shopId);

  const hours =
    businessHours(shop);

  const coverage =
    getCoverage(shopId,time);

  return {
    shopId,
    hours:{
      ...hours,
      label:
        formatHour(hours.openHour) +
        '–' +
        formatHour(hours.closeHour)
    },
    isOpen:coverage.isOpen,
    coverage,
    shifts:
      SHIFT_DEFS.map(
        shift => ({
          ...shift,
          label:
            formatHour(shift.startHour) +
            '–' +
            formatHour(shift.endHour),
          staffCount:
            state.hired.filter(
              staff =>
                staff.shiftId === shift.id
            ).length
        })
      ),
    staff:
      state.hired.map(
        row => {
          const shift =
            getShift(row.shiftId);

          return {
            id:row.id,
            name:row.name || '员工',
            roleId:row.roleId,
            shiftId:shift.id,
            shiftName:shift.name,
            shiftLabel:
              formatHour(shift.startHour) +
              '–' +
              formatHour(shift.endHour),
            active:
              coverage
                .activeStaffIds
                .includes(row.id)
          };
        }
      ),
    presets:
      HOUR_PRESETS.map(
        row => ({
          ...row,
          label:
            formatHour(row.openHour) +
            '–' +
            formatHour(row.closeHour)
        })
      )
  };
}

module.exports = {
  SHIFT_DEFS,
  HOUR_PRESETS,
  formatHour,
  businessHours,
  isOpen,
  isShiftActive,
  ensureAssignments,
  requiredByRole,
  setBusinessHoursPreset,
  setStaffShift,
  cycleStaffShift,
  getCoverage,
  getDashboard
};
