from pathlib import Path
p=Path('/mnt/data/home_v2_v055/src/main.js')
s=p.read_text()
def one(old,new,name):
    global s
    if old not in s:
        raise SystemExit('missing '+name)
    s=s.replace(old,new,1)

needle="const resourceManager =\n  require('./core/resourceManager.js');\n"
one(needle,needle+"\nconst homeAssetLoader =\n  require('./assets/assetLoaderV2.js');\n",'require')

needle="const RIGHT_TOOLS = [\n  {\n    id: 'land',\n    label: '地块',\n    icon: '地'\n  },\n\n  {\n    id: 'population',\n    label: '人口',\n    icon: '人'\n  },\n\n  {\n    id: 'rank',\n    label: '排行',\n    icon: '榜'\n  }\n];\n"
one(needle,needle+"\n/* HOME_V2_ASSET_MAPS_V055 */\nconst HOME_NAV_SPRITES = { city: 'nav_city', shop: 'nav_store', research: 'nav_menu', supply: 'nav_supply', business: 'nav_data', system: 'nav_system' };\nconst HOME_TOOL_SPRITES = { overview: 'func_analytics', dynamic: 'func_growth', event: 'func_marketing', land: 'func_site_select', population: 'func_customers', rank: 'func_rating' };\nconst HOME_DISTRICT_ASSETS = { university: 'district_university', hightech: 'district_hightech', cbd: 'district_business_center', oldtown: 'district_oldtown', village: 'district_urban_village', market: 'district_market', industry: 'district_industrial' };\n",'maps')

marker="/* =========================\n   地图裁切\n========================= */"
helpers='''/* HOME_V2_DRAW_HELPERS_V055 */\nfunction drawHomeSprite(spriteId, dx, dy, dw, dh, alpha) {\n  const sprite = homeAssetLoader.getSprite(spriteId);\n  if (!sprite) return false;\n  const image = resourceManager.getImage(sprite.atlasId);\n  if (!image) return false;\n  const region = sprite.region;\n  ctx.save();\n  if (alpha != null) ctx.globalAlpha = alpha;\n  ctx.drawImage(image, region.x, region.y, region.w, region.h, dx, dy, dw, dh);\n  ctx.restore();\n  return true;\n}\n\nfunction drawHomeImageCover(resourceId, dx, dy, dw, dh, radius, focusX, focusY) {\n  if (!homeAssetLoader.getAsset(resourceId)) return false;\n  const image = resourceManager.getImage(resourceId);\n  if (!image) return false;\n  ctx.save();\n  roundedPath(ctx, dx, dy, dw, dh, radius || 0);\n  ctx.clip();\n  drawImageFocus(ctx, image, dx, dy, dw, dh, 1, focusX == null ? 0.5 : focusX, focusY == null ? 0.5 : focusY);\n  ctx.restore();\n  return true;\n}\n\nfunction getHomeHudBackgroundId() {\n  const world = gameState.getWorld();\n  const display = timeSystem.getDisplayState();\n  const hour = Number(String(display.time || '12:00').split(':')[0]);\n  if (hour >= 19 || hour < 6) return 'home_bg_night';\n  if (world.weather === 'rain' || world.weather === 'heavyRain') return 'home_bg_rain_day';\n  if (world.weather === 'cloudy') return 'home_bg_cloudy_day';\n  if (world.weather === 'cold') return 'home_bg_winter';\n  if (world.weather === 'hot') return 'home_bg_summer';\n  return 'home_bg_sunny_day';\n}\n\n'''
one(marker,helpers+marker,'helpers')

old="""function drawTopHud() {\n  if (\n    !drawAtlas(\n      'hud',\n      0,\n      0,\n      VIEW_W,\n      TOP_H\n    )\n  ) {\n    const gradient =\n      ctx.createLinearGradient(\n        0,\n        0,\n        0,\n        TOP_H\n      );\n\n    gradient.addColorStop(\n      0,\n      '#163F59'\n    );\n\n    gradient.addColorStop(\n      1,\n      '#09293D'\n    );\n\n    ctx.fillStyle =\n      gradient;\n\n    ctx.fillRect(\n      0,\n      0,\n      VIEW_W,\n      TOP_H\n    );\n  }\n"""
new="""function drawTopHud() {\n  const homeHudBackgroundId = getHomeHudBackgroundId();\n  const homeHudBackground = resourceManager.getImage(homeHudBackgroundId);\n  if (homeHudBackground) {\n    drawImageFocus(ctx, homeHudBackground, 0, 0, VIEW_W, TOP_H, 1.16, 0.5, 0.34);\n    const homeHudShade = ctx.createLinearGradient(0, 0, VIEW_W, 0);\n    homeHudShade.addColorStop(0, 'rgba(5,38,59,0.90)');\n    homeHudShade.addColorStop(0.56, 'rgba(5,38,59,0.70)');\n    homeHudShade.addColorStop(1, 'rgba(5,38,59,0.88)');\n    ctx.fillStyle = homeHudShade;\n    ctx.fillRect(0, 0, VIEW_W, TOP_H);\n  } else if (!drawAtlas('hud', 0, 0, VIEW_W, TOP_H)) {\n    const gradient = ctx.createLinearGradient(0, 0, 0, TOP_H);\n    gradient.addColorStop(0, '#163F59');\n    gradient.addColorStop(1, '#09293D');\n    ctx.fillStyle = gradient;\n    ctx.fillRect(0, 0, VIEW_W, TOP_H);\n  }\n  /* HOME_V2_HUD_CARDS_V055 */\n  roundedRect(278, 6, 104, 28, 9, 'rgba(5,34,53,0.74)', 'rgba(100,195,236,0.42)');\n  roundedRect(278, 38, 104, 25, 9, 'rgba(5,34,53,0.72)', 'rgba(255,211,87,0.28)');\n"""
one(old,new,'top')

old="""  drawText(\n    cityName,\n    14,\n    18,\n    16,\n    COLORS.white,\n    '700'\n  );\n\n  drawText(\n    '一座有味道的城市',\n    14,\n    39,\n    8,\n    'rgba(255,255,255,0.70)',\n    '500'\n  );\n"""
new="""  drawHomeSprite('nav_city', 8, 8, 27, 27, 0.98);\n\n  drawText(\n    cityName,\n    41,\n    18,\n    16,\n    COLORS.white,\n    '700'\n  );\n\n  drawText(\n    '一座有味道的城市',\n    41,\n    39,\n    8,\n    'rgba(255,255,255,0.76)',\n    '500'\n  );\n"""
one(old,new,'city title')

needle="""  drawText(\n    weather +\n      ' ' +\n      world.temperature +\n      '℃',\n    164,\n    53,\n"""
rep="""  drawHomeSprite('hud_weather', 142, 43, 18, 18, 0.98);\n  drawHomeSprite('hud_cash', 284, 9, 19, 19, 0.98);\n  drawHomeSprite('hud_level', 284, 40, 18, 18, 0.98);\n\n  drawText(\n    weather +\n      ' ' +\n      world.temperature +\n      '℃',\n    164,\n    53,\n"""
one(needle,rep,'hud icons')

old="""  drawText(\n    '✓',\n    x + 20.5,\n    y + h / 2,\n    14,\n    '#D67E2B',\n    '700',\n    'center'\n  );\n"""
new="""  if (!drawHomeSprite('hud_target', x + 10, y + 10, h - 20, h - 20)) {\n    drawText('✓', x + 20.5, y + h / 2, 14, '#D67E2B', '700', 'center');\n  }\n"""
one(old,new,'goal')

old="""  drawText(\n    item.icon,\n    x + size / 2,\n    y + 13,\n    11,\n    '#F7EACD',\n    '700',\n    'center'\n  );\n\n  drawText(\n    item.label,\n    x + size / 2,\n    y + 29,\n"""
new="""  const homeToolSprite = HOME_TOOL_SPRITES[item.id];\n  if (!homeToolSprite || !drawHomeSprite(homeToolSprite, x + size / 2 - 9, y + 4, 18, 18)) {\n    drawText(item.icon, x + size / 2, y + 13, 11, '#F7EACD', '700', 'center');\n  }\n\n  drawText(\n    item.label,\n    x + size / 2,\n    y + 29,\n"""
one(old,new,'side tools')

old="""  const currentDemand =\n    demandSystem\n      .getTotalDemand(\n        district.id\n      );\n\n  drawText(\n    district.name,\n    17,\n    y + 21,\n    15,\n    COLORS.text,\n    '700'\n  );\n\n  drawText(\n    '市场饱和 ' +\n      district.saturation +\n      '%',\n    17,\n    y + 41,\n"""
new="""  const currentDemand =\n    demandSystem\n      .getTotalDemand(\n        district.id\n      );\n\n  const homeDistrictAssetId = HOME_DISTRICT_ASSETS[district.id];\n  const homeDistrictHasImage = homeDistrictAssetId &&\n    drawHomeImageCover(homeDistrictAssetId, 16, y + 9, 72, 42, 9, 0.5, 0.52);\n\n  drawText(\n    district.name,\n    homeDistrictHasImage ? 98 : 17,\n    y + 20,\n    14,\n    COLORS.text,\n    '700'\n  );\n\n  drawText(\n    '市场饱和 ' +\n      district.saturation +\n      '%',\n    homeDistrictHasImage ? 98 : 17,\n    y + 40,\n"""
one(old,new,'district image')
one("  const chipY =\n    y +\n    53;\n\n  drawMetricChip(\n    16,\n    chipY,\n","  const chipY =\n    y +\n    57;\n\n  drawMetricChip(\n    16,\n    chipY,\n",'chip')

old="""    drawText(\n      item.icon,\n      cx,\n      NAV_Y +\n        NAV_H *\n        0.35,\n      14,\n\n      active\n        ? '#23323A'\n        : COLORS.white,\n\n      '700',\n      'center'\n    );\n\n    drawText(\n      item.name,\n"""
new="""    const homeNavSprite = HOME_NAV_SPRITES[item.id];\n    const homeNavDrawn = homeNavSprite &&\n      drawHomeSprite(homeNavSprite, cx - 13, NAV_Y + 5, 26, 26, active ? 1 : 0.88);\n\n    if (!homeNavDrawn) {\n      drawText(\n        item.icon,\n        cx,\n        NAV_Y +\n          NAV_H *\n          0.35,\n        14,\n\n        active\n          ? '#23323A'\n          : COLORS.white,\n\n        '700',\n        'center'\n      );\n    }\n\n    drawText(\n      item.name,\n"""
one(old,new,'bottom nav')

old="""    resourceManager\n      .loadImage(\n        'property_icons_01',\n        'assets/images/ui/property_icons_01.png',\n        'property'\n      )\n  ])\n"""
new="""    resourceManager\n      .loadImage(\n        'property_icons_01',\n        'assets/images/ui/property_icons_01.png',\n        'property'\n      ),\n\n    homeAssetLoader\n      .preloadHomeEssential(\n        resourceManager\n      ),\n\n    homeAssetLoader\n      .loadHomeScene(\n        resourceManager,\n        'city'\n      ),\n\n    homeAssetLoader\n      .loadAtlas(\n        resourceManager,\n        'functions_atlas'\n      )\n  ])\n"""
one(old,new,'load resources')

s=s.replace('城市餐饮经营小游戏 UI V3 自适应版启动成功','城市餐饮经营小游戏 HOME V2.0 资源实装版启动成功')
s=s.replace('城市餐饮经营小游戏 V4 动态商圈找铺版启动成功','城市餐饮经营小游戏 HOME V2.0 资源实装版启动成功')
p.write_text(s)
print('patched',len(s))
