'use strict';

const assert = require('assert');
const spatial = require('../src/renovation/renovationFreeBuildV0866.js');

function pointInPolygon(point) {
  return (
    point.x >= -0.001 &&
    point.x <= 10.001 &&
    point.y >= -0.001 &&
    point.y <= 8.001
  );
}

const floorGeometrySystem = { pointInPolygon };

const geometry = {
  widthM:10,
  depthM:8,
  areaM2:80,
  polygon:[
    {x:0,y:0},
    {x:10,y:0},
    {x:10,y:8},
    {x:0,y:8}
  ],
  obstacles:[],
  entrances:[
    {side:'south',x:5,y:8,width:1.2}
  ]
};

const floor = {
  index:0,
  area:80,
  freeBuildVersion:1,
  kitchenRatio:0.27,
  storageRatio:0.08,
  serviceRatio:0.11,
  tables:{2:0,4:0,6:0,8:0},
  editorPlacements:[],
  editorWalls:[],
  editorDoors:[],
  privateRooms:[]
};

const wallState = spatial.validateWallCandidate({
  wall:{id:'w1',x1:4,y1:0,x2:4,y2:8},
  floor,
  geometry,
  placements:[],
  floorGeometrySystem
});

assert.ok(wallState.valid,'贯穿铺面的内墙必须可创建');
floor.editorWalls.push({...wallState.wall,id:'w1'});

let rooms = spatial.detectRooms({
  floor,
  geometry,
  placements:[],
  floorGeometrySystem
});

assert.ok(
  rooms.length >= 2,
  '建墙后必须由墙体而不是面积比例自动形成多个空间'
);

const doorResult = spatial.makeDoorAt(
  floor,
  {x:4,y:4},
  0.90
);

assert.ok(doorResult.ok,'已有墙体上必须可以开门');
floor.editorDoors.push({...doorResult.door,id:'d1'});

const table = {
  id:'t1',
  kind:'table4',
  mx:2,
  my:4,
  rotation:0
};

const tableState = spatial.validateCandidate({
  item:table,
  floor,
  geometry,
  placements:[table],
  floorGeometrySystem,
  clearDepthM:1.2,
  ignoreId:'t1'
});

assert.ok(
  tableState.valid,
  '自由建造模式下餐桌不应再被旧堂食区比例禁止'
);

floor.editorPlacements.push(table);
floor.tables['4'] = 1;

const analysis = spatial.analyzeFloor({
  floor,
  geometry,
  areaMetrics:{
    effectiveDiningArea:80,
    usableDiningSlots:[]
  },
  floorGeometrySystem,
  clearDepthM:1.2
});

assert.ok(
  analysis.rooms.some(room => room.label === '就餐空间'),
  '系统必须根据房间中的家具自动识别就餐空间'
);

assert.ok(
  analysis.mainAisleWidthM >= 0.9,
  '开门后入口必须能够连接到有家具的空间'
);

const throughFurniture = spatial.validateWallCandidate({
  wall:{id:'w2',x1:0,y1:4,x2:4,y2:4},
  floor,
  geometry,
  placements:[table],
  floorGeometrySystem
});

assert.strictEqual(
  throughFurniture.valid,
  false,
  '墙体不得直接穿过已摆放家具'
);

for (const kind of [
  'stove',
  'prep',
  'sink',
  'fridge',
  'storage_shelf',
  'cashier'
]) {
  assert.ok(
    spatial.specFor(kind),
    '自由装修必须支持真实设备：' + kind
  );
}

console.log('V0.8.66 free-build spatial tests passed');
