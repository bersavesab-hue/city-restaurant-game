'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const spatial = require('../src/renovation/renovationFreeBuildV0866.js');

const geometry = {
  widthM: 5,
  depthM: 8,
  polygon: [
    {x:0,y:0},{x:5,y:0},{x:5,y:8},{x:0,y:8}
  ],
  obstacles: [],
  entrances: [
    {side:'south',x:2.5,y:8,width:1.2}
  ]
};

const floorGeometrySystem = {
  pointInPolygon(point) {
    return point.x >= -0.001 &&
      point.x <= 5.001 &&
      point.y >= -0.001 &&
      point.y <= 8.001;
  }
};

const floor = {
  area:40,
  freeBuildVersion:1,
  editorWalls:[],
  editorDoors:[],
  editorPlacements:[],
  tables:{2:0,4:0,6:0,8:0}
};

const table = {
  id:'table_1',
  kind:'table4',
  mx:1.25,
  my:6.0,
  rotation:0
};

let validation = spatial.validateCandidate({
  item:table,
  floor,
  geometry,
  placements:[],
  floorGeometrySystem,
  clearDepthM:1.35
});

assert.equal(validation.valid,true,'合法餐桌应能摆放');
assert.equal(spatial.specFor('table4').floorArea,3.6,'4人桌使用空间必须为3.6㎡');

floor.editorPlacements.push(table);
floor.tables[4]=1;

const wall = spatial.normalizeWall(
  {x:0,y:4},
  {x:5,y:4},
  'wall_1'
);

const wallCheck = spatial.validateWall({
  wall,
  floor,
  geometry,
  floorGeometrySystem,
  clearDepthM:1.35
});

assert.equal(wallCheck.valid,true,'不穿家具、不堵入口的内墙必须允许');
floor.editorWalls.push(wall);

let analysis = spatial.analyzeFloor({
  floor,
  geometry,
  areaMetrics:{structuralReservedArea:0},
  floorGeometrySystem,
  clearDepthM:1.35
});

assert.equal(analysis.valid,false,'整面无门隔墙切断通行时必须判无效');
assert.ok(
  analysis.issues.some(x=>x.code==='blocked_route'),
  '必须明确指出墙体切断通行'
);

const door = spatial.createDoorOnWall(
  wall,
  {x:2.5,y:4},
  0.9,
  'door_1'
);

assert.ok(door,'墙体中部必须能开0.90m门');
floor.editorDoors.push(door);

analysis = spatial.analyzeFloor({
  floor,
  geometry,
  areaMetrics:{structuralReservedArea:0},
  floorGeometrySystem,
  clearDepthM:1.35
});

assert.equal(analysis.valid,true,'增加门后主要通行必须恢复');
assert.ok(analysis.rooms.length>=2,'墙体必须真实形成多个空间');
assert.ok(
  analysis.rooms.some(x=>x.type==='就餐空间'),
  '含餐桌空间必须能自动识别为就餐空间'
);

const throughWall = {
  id:'table_bad',
  kind:'table4',
  mx:2.5,
  my:4,
  rotation:0
};

validation = spatial.validateCandidate({
  item:throughWall,
  floor,
  geometry,
  placements:floor.editorPlacements,
  floorGeometrySystem,
  clearDepthM:1.35
});

assert.equal(validation.valid,false,'家具不能穿墙');

const root = path.resolve(__dirname,'..');
const editor = fs.readFileSync(
  path.join(root,'src/renovation/renovationEditorV0866.js'),
  'utf8'
);

assert.ok(editor.includes("'select','选择'"),'新版装修必须有选择模式');
assert.ok(editor.includes("'wall','建墙'"),'新版装修必须有建墙模式');
assert.ok(editor.includes("'door','开门'"),'新版装修必须有开门模式');
assert.ok(editor.includes("'equipment','设备'"),'新版装修必须有设备模式');
assert.ok(editor.includes('this.navH=0'),'装修必须使用沉浸式全屏');
assert.ok(!editor.includes("page:zones"),'新版玩家界面不能再暴露旧比例分区入口');
assert.ok(!editor.includes('空间分区'),'新版装修不能再显示旧空间分区文案');

console.log('V0.8.66 free-build renovation tests passed');
