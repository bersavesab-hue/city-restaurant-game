'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname,'..');
const editorSource = fs.readFileSync(
  path.join(ROOT,'src/renovation/renovationEditorV0866.js'),
  'utf8'
);
const mainSource = fs.readFileSync(
  path.join(ROOT,'src/main.js'),
  'utf8'
);

for (const token of [
  'V0866_IMMERSIVE_FREE_BUILD_EDITOR',
  "'editor:mode:wall'",
  "'editor:mode:door'",
  "'editor:mode:equipment'",
  "'editor:wall:delete'",
  'editorWalls',
  'editorDoors',
  'drawRoomLabels',
  '自由'
]) {
  assert.ok(
    editorSource.includes(token),
    '自由装修编辑器缺失：' + token
  );
}

assert.ok(
  mainSource.includes("sceneManager.getCurrentId() !==\n    'renovation'"),
  '装修页必须隐藏全局底部导航'
);

let height = 780;

globalThis.GameRuntime = {
  api:{
    getSystemInfoSync(){
      return {windowWidth:390,windowHeight:height};
    },
    showToast(){},
    setStorageSync(){},
    getStorageSync(){return null;}
  },
  requestRender(){}
};

const gameState = require('../src/core/gameState.js');
const renovationSystem = require('../src/renovation/renovationSystem.js');
const scene = require('../src/scenes/renovationScene.js');

gameState.reset();
gameState.setCash(1000000);
gameState.addShop({
  id:'v0866_free_build_shop',
  name:'自由装修测试店',
  status:'leased_pending_renovation',
  grossArea:120,
  usableArea:96,
  floor:'1层',
  frontage:8
});

const gradient = { addColorStop(){} };
const ctx = new Proxy({},{
  get(target,key){
    if(key==='createLinearGradient'||key==='createRadialGradient'){
      return ()=>gradient;
    }
    if(key==='measureText'){
      return value=>({width:String(value).length*5});
    }
    if(!target[key]) target[key]=()=>{};
    return target[key];
  },
  set(target,key,value){
    target[key]=value;
    return true;
  }
});

scene.enter({
  shopId:'v0866_free_build_shop',
  page:'layout'
});

for(const viewportHeight of [780,667,600]){
  height=viewportHeight;
  scene.page='layout';
  scene._editorMode='select';
  scene.render(ctx);

  const geometry = scene.getMainGeometry();

  assert.ok(
    geometry.planH >= 450,
    viewportHeight + 'px 下装修主画布必须保持沉浸式高度'
  );

  assert.ok(
    scene.floorCanvasInteraction &&
    scene.floorCanvasInteraction.frame &&
    scene.floorCanvasInteraction.frame.h >= 400,
    viewportHeight + 'px 下真实平面图不能再缩成小窗口'
  );

  for(const id of [
    'editor:mode:wall',
    'editor:mode:door',
    'page:furniture',
    'editor:mode:equipment'
  ]){
    assert.ok(
      scene.buttons.some(button=>button.id===id),
      '必须显示自由装修工具：' + id
    );
  }

  assert.ok(
    !scene.buttons.some(button=>button.id==='page:zones'),
    '玩家界面不得继续出现旧面积分区按钮'
  );
}

height=780;
scene.page='layout';
scene._editorMode='select';
scene.render(ctx);

const wallButton=scene.buttons.find(button=>button.id==='editor:mode:wall');
assert.ok(wallButton,'必须可以进入建墙模式');

scene.handleTap(
  wallButton.x+wallButton.w/2,
  wallButton.y+wallButton.h/2
);

scene.render(ctx);

const frame=scene.floorCanvasInteraction.frame;
const p1={x:frame.x+frame.w*0.35,y:frame.y+frame.h*0.25};
const p2={x:p1.x,y:frame.y+frame.h*0.72};

assert.ok(scene.handleTap(p1.x,p1.y),'第一次点击必须记录墙体起点');
assert.ok(scene.handleTap(p2.x,p2.y),'第二次点击必须真正创建墙体');

const planAfterWall=scene.getPlan();
assert.ok(
  Array.isArray(planAfterWall.floors[0].editorWalls) &&
  planAfterWall.floors[0].editorWalls.length >= 1,
  '建墙操作必须持久化到装修方案'
);

scene.render(ctx);
const doorButton=scene.buttons.find(button=>button.id==='editor:mode:door');
scene.handleTap(doorButton.x+doorButton.w/2,doorButton.y+doorButton.h/2);
scene.render(ctx);

const wall=scene.getPlan().floors[0].editorWalls[0];
const mx=(Number(wall.x1)+Number(wall.x2))/2;
const my=(Number(wall.y1)+Number(wall.y2))/2;
const doorX=frame.x+mx*frame.scale;
const doorY=frame.y+my*frame.scale;

scene.handleTap(doorX,doorY);

assert.ok(
  scene.getPlan().floors[0].editorDoors.length >= 1,
  '点墙开门必须写入真实门对象'
);

console.log('V0.8.66 immersive free-build editor tests passed');
