'use strict';

const assert = require('assert');
const core = require('../src/simulation/v090/restaurantCore.js');
const space = require('../src/simulation/v090/spaceModel.js');
const tables = require('../src/simulation/v090/tableModel.js');
const inventory = require('../src/simulation/v090/inventoryModel.js');
const supply = require('../src/simulation/v090/supplyModel.js');
const competitor = require('../src/simulation/v090/competitorModel.js');
const finance = require('../src/simulation/v090/financeModel.js');
const migration = require('../src/simulation/v090/saveMigration.js');

function fixture() {
  return {
    seed: 'core-test',
    day: { day: 12, weekday: 3 },
    context: { weather: 'sunny', eventMultiplier: 1, openMinutes: 660, averageDwellMinutes: 55 },
    district: {
      id: 'test', name: '测试商圈', baseDemand: 620, avgSpend: 32, saturation: 72, restaurantCount: 36, rentIndex: 0.72,
      segmentMix: { office: 0.42, resident: 0.28, family: 0.2, student: 0.1 }
    },
    store: {
      id: 'player', name: '玩家餐厅', cash: 100000, rating: 4.1, reputation: 58, brandHeat: 42, visibility: 74,
      rentMonthly: 12000, propertyFeeMonthly: 1200, utilitiesBaseDaily: 45, utilitiesPerCover: 0.8, maintenanceDaily: 24,
      property: { grossArea: 118, frontage: 8.5, visibility: 74 },
      layout: { tables: { 2: 5, 4: 9, 6: 2 } },
      stoves: 4, prepReadiness: 0.92,
      staff: [
        { id: 'c1', role: 'chef', skill: 1.05, dailyWage: 300, fatigue: 18, morale: 78 },
        { id: 'c2', role: 'cook', skill: 0.96, dailyWage: 230, fatigue: 22, morale: 75 },
        { id: 'c3', role: 'prep', skill: 0.9, dailyWage: 165, fatigue: 17, morale: 76 },
        { id: 'w1', role: 'waiter', skill: 1.0, dailyWage: 175, fatigue: 20, morale: 77 },
        { id: 'w2', role: 'waiter', skill: 0.95, dailyWage: 170, fatigue: 24, morale: 72 },
        { id: 'w3', role: 'waiter', skill: 0.92, dailyWage: 165, fatigue: 15, morale: 76 },
        { id: 'w4', role: 'waiter', skill: 0.9, dailyWage: 160, fatigue: 19, morale: 73 },
        { id: 'm1', role: 'manager', skill: 0.95, dailyWage: 260, fatigue: 16, morale: 80 }
      ],
      menu: [
        { id: 'noodle', name: '招牌牛肉面', price: 29, cookMinutes: 8, quality: 82, popularity: 76, segmentFit: { office: 0.9, resident: 0.8, student: 0.86, family: 0.65 }, ingredients: [{ id: 'flour', qty: 0.16 }, { id: 'beef', qty: 0.09 }, { id: 'veg', qty: 0.05 }] },
        { id: 'rice', name: '小炒肉盖饭', price: 32, cookMinutes: 10, quality: 80, popularity: 72, segmentFit: { office: 0.88, resident: 0.82, student: 0.76, family: 0.72 }, ingredients: [{ id: 'rice', qty: 0.18 }, { id: 'pork', qty: 0.11 }, { id: 'veg', qty: 0.07 }] },
        { id: 'family', name: '家常三菜套餐', price: 46, cookMinutes: 15, quality: 84, popularity: 61, segmentFit: { office: 0.55, resident: 0.82, family: 1, student: 0.42 }, ingredients: [{ id: 'pork', qty: 0.14 }, { id: 'chicken', qty: 0.12 }, { id: 'veg', qty: 0.12 }] }
      ],
      inventory: {
        flour: { qty: 60, unitCost: 3.6, freshness: 0.92, shelfLifeDays: 10 },
        beef: { qty: 32, unitCost: 38, freshness: 0.9, shelfLifeDays: 5 },
        veg: { qty: 65, unitCost: 5.2, freshness: 0.92, shelfLifeDays: 3 },
        rice: { qty: 80, unitCost: 4.5, freshness: 0.98, shelfLifeDays: 45 },
        pork: { qty: 46, unitCost: 19, freshness: 0.9, shelfLifeDays: 4 },
        chicken: { qty: 32, unitCost: 16, freshness: 0.9, shelfLifeDays: 4 }
      },
      suppliers: [
        { id: 's1', name: '综合供应商', reliability: 0.94, quality: 0.86, leadTimeDays: 1, minOrder: 5, catalog: {
          flour: { unitCost: 3.7, packSize: 5 }, beef: { unitCost: 37, packSize: 2 }, veg: { unitCost: 5, packSize: 3 },
          rice: { unitCost: 4.4, packSize: 10 }, pork: { unitCost: 18.5, packSize: 3 }, chicken: { unitCost: 15.5, packSize: 3 }
        } }
      ]
    },
    competitors: [
      { id: 'n1', name: '老街饭馆', rating: 3.9, reputation: 55, quality: 68, priceFit: 0.9, visibility: 68, brandHeat: 44 },
      { id: 'n2', name: '快捷厨房', rating: 3.7, reputation: 48, quality: 62, priceFit: 0.95, visibility: 72, brandHeat: 38 },
      { id: 'n3', name: '家味餐厅', rating: 4.0, reputation: 57, quality: 72, priceFit: 0.82, visibility: 60, brandHeat: 45 },
      { id: 'n4', name: '青年食堂', rating: 3.8, reputation: 49, quality: 65, priceFit: 1.02, visibility: 70, brandHeat: 40 }
    ]
  };
}

(function testPropertyBreakdown() {
  const p = space.normalizeProperty({ grossArea: 60 });
  assert.strictEqual(p.grossArea, 60);
  assert(p.usableDiningArea > 0 && p.usableDiningArea < 60);
  assert(p.zones.kitchen > 0);
})();

(function testAreaOverflow() {
  const r = space.evaluateAreaPlan({ grossArea: 25 }, { tables: { 4: 8 } });
  assert.strictEqual(r.valid, false);
  assert(r.warnings.some(x => x.code === 'AREA_OVERFLOW'));
})();

(function testCollision() {
  const r = space.validateCoordinateLayout({ width: 5, depth: 5 }, [
    { id: 'a', x: 1, y: 1, width: 2, depth: 2 },
    { id: 'b', x: 2, y: 2, width: 2, depth: 2 }
  ]);
  assert.strictEqual(r.valid, false);
  assert(r.errors.some(x => x.code === 'COLLISION'));
})();

(function testDoorBlock() {
  const r = space.validateCoordinateLayout({ width: 5, depth: 5, doors: [{ id: 'door', x: 0, y: 2, width: 0.9 }] }, [
    { id: 'cabinet', x: 0, y: 1.8, width: 1, depth: 1 }
  ]);
  assert(r.errors.some(x => x.code === 'BLOCKED_DOOR'));
})();

(function testTableMismatch() {
  const result = tables.seatParties({ 8: 8 }, { 1: 30, 2: 20 }, { openMinutes: 300, averageDwellMinutes: 60, peakConcurrencyFactor: 0.5 });
  assert(result.wasteRatio > 0.5);
})();

(function testFiniteDemandConserved() {
  const f = fixture();
  const allocation = competitor.allocateFiniteDemand(500, f.store, { averageQuality: 80, priceFit: 0.9 }, f.competitors, { playerMarketCapacity: 2000 });
  const total = allocation.participants.reduce((a, b) => a + b.allocatedCovers, 0) + allocation.unmetMarketDemand;
  assert(total <= 500);
  assert.strictEqual(allocation.conserved, true);
})();

(function testZeroOrdersStillCostsMoney() {
  const f = fixture();
  f.store.open = false;
  const result = core.simulateDay(f);
  assert.strictEqual(result.report.funnel.paidCovers, 0);
  assert(result.report.finance.netProfit < -500, `expected meaningful fixed-cost loss, got ${result.report.finance.netProfit}`);
})();

(function testNormalDayProducesRevenue() {
  const result = core.simulateDay(fixture());
  assert(result.report.finance.revenue > 0);
  assert(result.report.funnel.paidCovers > 0);
  assert(result.report.finance.fixedCosts > 0);
})();

(function testCashReconciles() {
  const f = fixture();
  const result = core.simulateDay(f);
  const delta = result.nextStore.cash - f.store.cash;
  assert(Math.abs(delta - result.report.finance.netCashFlow) < 0.01);
})();

(function testStockoutCreatesLoss() {
  const f = fixture();
  for (const item of Object.values(f.store.inventory)) item.qty = 0.2;
  const result = core.simulateDay(f);
  assert(result.report.losses.stockout > 0 || result.report.inventory.shortages.length > 0);
})();

(function testKitchenBottleneck() {
  const f = fixture();
  f.district.baseDemand = 1800;
  f.store.property.grossArea = 220;
  f.store.layout.tables = { 2: 10, 4: 16, 6: 4 };
  f.store.staff = [{ role: 'cook', skill: 0.6, dailyWage: 180 }, { role: 'waiter', skill: 1, dailyWage: 170 }, { role: 'waiter', skill: 1, dailyWage: 170 }, { role: 'waiter', skill: 1, dailyWage: 170 }];
  f.store.stoves = 1;
  const result = core.simulateDay(f);
  assert(result.diagnostics.kitchen.bottleneck || result.report.losses.kitchen > 0);
})();

(function testServiceBottleneck() {
  const f = fixture();
  f.district.baseDemand = 1800;
  f.store.property.grossArea = 220;
  f.store.layout.tables = { 2: 10, 4: 16, 6: 4 };
  f.store.staff = [...f.store.staff.filter(x => ['chef','cook','prep'].includes(x.role)), { role: 'waiter', skill: 0.55, dailyWage: 140 }];
  const result = core.simulateDay(f);
  assert(result.diagnostics.service.bottleneck || result.report.losses.service > 0);
})();

(function testHighRentHurtsProfit() {
  const normal = core.simulateDay(fixture());
  const expensive = fixture();
  expensive.store.rentMonthly = 120000;
  const high = core.simulateDay(expensive);
  assert(high.report.finance.netProfit < normal.report.finance.netProfit);
})();

(function testInventoryAgingSpoils() {
  const aged = inventory.ageInventory({ fish: { qty: 10, unitCost: 20, freshness: 0.2, shelfLifeDays: 1, ageDays: 2 } }, 1);
  assert(aged.spoilageCost > 0);
  assert(aged.inventory.fish.qty < 10);
})();

(function testSupplierReorder() {
  const orders = supply.buildReorderPlan(
    { pork: { qty: 1, unitCost: 18 } },
    { pork: 4 },
    [{ id: 's', reliability: 1, leadTimeDays: 1, minOrder: 5, catalog: { pork: { unitCost: 18, packSize: 2 } } }],
    { targetDaysCover: 4 }
  );
  assert.strictEqual(orders.length, 1);
  assert(orders[0].qty >= 5);
})();

(function testSupplierDeliveryDeterministic() {
  const order = [{ ingredientId: 'pork', qty: 6, unitCost: 18, expectedLeadTimeDays: 0, reliability: 1, quality: 0.9 }];
  const a = supply.progressPurchaseOrders(order, {}, 5);
  assert.strictEqual(a.delivered.length, 1);
  assert(a.inventory.pork.qty >= 6);
})();

(function testMigrationIdempotent() {
  const a = migration.migrateState({ day: 3 });
  const b = migration.migrateState(a);
  assert.deepStrictEqual(a, b);
  assert.strictEqual(b.simulationCoreV090.version, '0.9.0');
})();

(function testDeterminism() {
  const a = core.simulateDay(fixture());
  const b = core.simulateDay(fixture());
  assert.deepStrictEqual(a.report, b.report);
})();

(function testNoNonFiniteNumbers() {
  const result = core.simulateDay(fixture());
  assert(Number.isFinite(result.report.finance.netProfit));
  assert(Number.isFinite(result.report.metrics.kitchenUtilization));
})();

(function testMultiDay() {
  const result = core.simulateDays(fixture(), 5);
  assert.strictEqual(result.reports.length, 5);
  assert(result.store.cash !== fixture().store.cash);
})();

(function testAreaInvalidReducesEffectiveCapacity() {
  const f = fixture();
  f.store.property.grossArea = 25;
  f.store.layout.tables = { 4: 12 };
  const result = core.simulateDay(f);
  assert.strictEqual(result.report.space.valid, false);
  assert(result.diagnostics.areaPlan.warnings.some(x => x.code === 'AREA_OVERFLOW'));
})();

(function testBreakEvenRevenuePositive() {
  const f = fixture();
  const value = finance.breakEvenRevenue(f.store, { laborCost: 1500, foodCostRate: 0.35 });
  assert(value > 0);
})();

(function testReportHasCausalAdvice() {
  const result = core.simulateDay(fixture());
  assert(Array.isArray(result.report.drivers) && result.report.drivers.length > 0);
  assert(result.report.primaryDriver && result.report.primaryDriver.action);
})();

(function testNoMagicMinusOne() {
  const f = fixture();
  f.store.open = false;
  const result = core.simulateDay(f);
  assert.notStrictEqual(result.report.finance.netProfit, -1);
  assert(result.report.finance.rentAccrual > 0);
  assert(result.report.finance.labor > 0);
})();

console.log('V0.9.0 core rework tests PASS');
