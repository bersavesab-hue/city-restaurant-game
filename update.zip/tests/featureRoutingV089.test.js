'use strict';

const assert =
  require('assert');

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const pkg =
  JSON.parse(
    fs.readFileSync(
      path.join(
        ROOT,
        'package.json'
      ),
      'utf8'
    )
  );

assert.equal(
  pkg.version,
  '0.8.9',
  '第一分类完成后版本必须为0.8.9'
);

const mainSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/main.js'
    ),
    'utf8'
  );

assert.ok(
  mainSource.includes(
    "require('./core/entryRouterV089.js')"
  ) &&
  mainSource.includes(
    "require('./scenes/featureHubSceneV089.js')"
  ) &&
  mainSource.includes(
    "'featureHub',\n  featureHubScene"
  ),
  '主程序必须注册统一路由和功能中心'
);

assert.ok(
  /entryRouter\s*\.open\(\s*sceneId/.test(
    mainSource
  ),
  '底部通用导航必须经过统一路由'
);

assert.ok(
  /entryRouter\s*\.open\(\s*'shop'/.test(
    mainSource
  ),
  '城市进入门店必须经过统一路由'
);

const systemSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/scenes/systemSceneV086.js'
    ),
    'utf8'
  );

assert.ok(
  systemSource.includes(
    "'feature:hub'"
  ) &&
  /entryRouter\s*\.open\(\s*'featureHub'/.test(
    systemSource
  ),
  '系统页必须提供真实可执行的功能中心入口'
);

assert.ok(
  /entryRouter\s*\.clearHistory\(\)/.test(
    systemSource
  ),
  '重新开局必须清理旧路由历史'
);

const routerSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/core/entryRouterV089.js'
    ),
    'utf8'
  );

for (
  const routeId
  of [
    'city',
    'shop',
    'store',
    'research',
    'supply',
    'staff',
    'schedule',
    'staffCareer',
    'business',
    'dynamicWorld',
    'system',
    'featureHub'
  ]
) {
  assert.ok(
    routerSource.includes(
      routeId + ':{'
    ),
    '统一路由缺少入口：' +
      routeId
  );
}

const sceneManagerPath =
  require.resolve(
    '../src/core/sceneManager.js'
  );

const routerPath =
  require.resolve(
    '../src/core/entryRouterV089.js'
  );

const savedSceneManager =
  require.cache[
    sceneManagerPath
  ];

const savedRouter =
  require.cache[
    routerPath
  ];

let current =
  'city';

const calls =
  [];

const available =
  new Set([
    'city',
    'shop',
    'research',
    'supply',
    'staff',
    'schedule',
    'staffCareer',
    'business',
    'dynamicWorld',
    'system',
    'featureHub'
  ]);

const fakeSceneManager = {
  getCurrentId() {
    return current;
  },
  switchTo(
    scene,
    payload
  ) {
    calls.push({
      scene,
      payload
    });

    if (
      !available.has(
        scene
      )
    ) {
      return false;
    }

    current =
      scene;

    return true;
  }
};

require.cache[
  sceneManagerPath
] = {
  id:sceneManagerPath,
  filename:sceneManagerPath,
  loaded:true,
  exports:fakeSceneManager
};

delete require.cache[
  routerPath
];

const router =
  require(
    routerPath
  );

assert.equal(
  router.resolve(
    'finance'
  ).scene,
  'business',
  '财务别名必须映射到当前经营数据中心'
);

assert.equal(
  router.resolve(
    'purchase'
  ).scene,
  'supply',
  '采购别名必须映射到供应链页面'
);

assert.equal(
  router.open(
    'schedule',
    {
      shopId:'shop_route_test'
    }
  ),
  true,
  '有效路由必须能够打开'
);

assert.equal(
  current,
  'schedule',
  '有效路由必须切换到目标页面'
);

assert.equal(
  router.open(
    'city'
  ),
  true,
  '必须能够从功能页返回一级页面'
);

assert.equal(
  router.open(
    'schedule'
  ),
  true,
  '再次打开页面必须成功'
);

assert.equal(
  calls[
    calls.length - 1
  ].payload.shopId,
  'shop_route_test',
  '统一路由必须记住上次页面入口参数'
);

assert.equal(
  router.back(
    'city'
  ),
  true,
  '路由历史返回必须成功'
);

assert.equal(
  current,
  'city',
  '返回必须恢复上一有效页面'
);

const historyBeforeFailure =
  router.getHistory().length;

assert.equal(
  router.open(
    'store'
  ),
  false,
  '目标页面未注册时必须安全失败'
);

assert.equal(
  router.getHistory().length,
  historyBeforeFailure,
  '失败跳转不能污染路由历史'
);

assert.ok(
  /页面尚未注册/.test(
    router.getLastError() ||
      ''
  ),
  '失败跳转必须返回可诊断原因'
);

assert.equal(
  router.open(
    'route-does-not-exist'
  ),
  false,
  '未知入口必须安全失败'
);

const runnerSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'scripts/run-ci-tests-v060.js'
    ),
    'utf8'
  );

assert.ok(
  runnerSource.includes(
    'tests/featureRoutingV089.test.js'
  ),
  '永久CI必须包含功能路由测试'
);

assert.ok(
  !fs.existsSync(
    path.join(
      ROOT,
      'scripts/apply-v089-feature-routing.js'
    )
  ),
  '正式树必须删除V0.8.9一次性安装脚本'
);

if (savedSceneManager) {
  require.cache[
    sceneManagerPath
  ] =
    savedSceneManager;
} else {
  delete require.cache[
    sceneManagerPath
  ];
}

if (savedRouter) {
  require.cache[
    routerPath
  ] =
    savedRouter;
} else {
  delete require.cache[
    routerPath
  ];
}

console.log(
  'V0.8.9 feature routing tests passed'
);
