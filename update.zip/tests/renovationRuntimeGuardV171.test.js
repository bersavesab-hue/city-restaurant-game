'use strict';
const assert=require('assert');
const fs=require('fs');
const path=require('path');
const cp=require('child_process');
const os=require('os');

const root=path.resolve(__dirname,'..');
const real=path.join(root,'src/scenes/renovationScene.js');
if(fs.existsSync(real)){
  const src=fs.readFileSync(real,'utf8');
  assert.ok(src.includes('V17_RENOVATION_UI_REWRITE'),'V17装修页标记必须保留');
  assert.ok(src.includes('template:save'),'模板保存接口必须保留');
  assert.ok(src.includes('V17_1_RENOVATION_RUNTIME_GUARD'),'V17.1运行时保护必须已注入');
  assert.ok(src.includes('兼容渲染已接管'),'兼容平面图渲染必须存在');
  const check=cp.spawnSync(process.execPath,['--check',real],{cwd:root,encoding:'utf8'});
  assert.strictEqual(check.status,0,check.stderr||'renovationScene.js syntax error');
}

// 独立验证 patcher 对已知 V17 导出结构可重复执行且不破坏原接口。
const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'renovation-v171-'));
fs.mkdirSync(path.join(tmp,'src/scenes'),{recursive:true});
fs.mkdirSync(path.join(tmp,'scripts'),{recursive:true});
const sample=`'use strict';\n// V17_RENOVATION_UI_REWRITE\nclass RenovationScene {\n render(ctx){ throw new Error('synthetic floor plan crash'); }\n handleTap(){ return false; }\n}\n// template:save\nmodule.exports = new RenovationScene();\n`;
fs.writeFileSync(path.join(tmp,'src/scenes/renovationScene.js'),sample);
const patchSource=fs.readFileSync(path.join(root,'scripts/apply-v17-1-renovation-runtime-guard.js'),'utf8');
fs.writeFileSync(path.join(tmp,'scripts/apply-v17-1-renovation-runtime-guard.js'),patchSource);
let r=cp.spawnSync(process.execPath,['scripts/apply-v17-1-renovation-runtime-guard.js'],{cwd:tmp,encoding:'utf8'});
assert.strictEqual(r.status,0,r.stderr);
r=cp.spawnSync(process.execPath,['scripts/apply-v17-1-renovation-runtime-guard.js'],{cwd:tmp,encoding:'utf8'});
assert.strictEqual(r.status,0,r.stderr);
const patched=fs.readFileSync(path.join(tmp,'src/scenes/renovationScene.js'),'utf8');
assert.strictEqual((patched.match(/V17_1_RENOVATION_RUNTIME_GUARD/g)||[]).length,1,'runtime guard must be injected only once');
const syntax=cp.spawnSync(process.execPath,['--check',path.join(tmp,'src/scenes/renovationScene.js')],{encoding:'utf8'});
assert.strictEqual(syntax.status,0,syntax.stderr);
console.log('renovationRuntimeGuardV171.test.js PASS');
