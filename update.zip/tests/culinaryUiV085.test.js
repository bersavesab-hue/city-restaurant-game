'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const research = fs.readFileSync(path.join(ROOT, 'src/scenes/researchScene.js'), 'utf8');
const ops = fs.readFileSync(path.join(ROOT, 'src/operations/operationsStoreV080.js'), 'utf8');
const business = fs.readFileSync(path.join(ROOT, 'src/scenes/businessScene.js'), 'utf8');

for (const token of [
  "{id:'menu',name:'菜单'}",
  "{id:'research',name:'研发'}",
  "{id:'improve',name:'改良'}",
  "{id:'rating',name:'评分'}",
  "{id:'awards',name:'奖项'}",
  'operations.startRecipeResearch',
  'operations.addMenuRecipe',
  'operations.improveCulinaryDish',
  'operations.evaluateCulinaryAwards',
  'operations.holdCulinaryAwardCeremony',
  '参加颁奖礼',
  '菜品七维评分',
  '八维评分'
]) {
  assert.ok(research.includes(token), '菜单研发页缺少关键接线：' + token);
}

for (const token of [
  'V085_CULINARY_PRESTIGE_BRIDGE',
  'module.exports.culinaryPrestigeSnapshot',
  'module.exports.improveCulinaryDish',
  'module.exports.evaluateCulinaryAwards',
  'module.exports.holdCulinaryAwardCeremony',
  'module.exports.culinaryRanking'
]) {
  assert.ok(ops.includes(token), '经营存储缺少V0.8.50桥接：' + token);
}

for (const token of [
  'V085_RANKING_BRIDGE',
  "rankCategory = __v085BusinessScene.rankCategory || 'overall'",
  "rankScope = __v085BusinessScene.rankScope || 'district'",
  "'rankcat:'",
  "'rankscope:'",
  '动态排行榜 · 多维竞争',
  'gapToPrev',
  'thresholdTop3'
]) {
  assert.ok(business.includes(token), '排行榜页面缺少关键能力：' + token);
}

console.log('V0.8.50 culinary UI and ranking wiring tests passed');
