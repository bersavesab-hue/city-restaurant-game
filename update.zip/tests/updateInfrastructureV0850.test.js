'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const runner = fs.readFileSync(path.join(ROOT, 'scripts/run-ci-tests-v060.js'), 'utf8');
const gradle = fs.readFileSync(path.join(ROOT, 'android/app/build.gradle'), 'utf8');

assert.strictEqual(pkg.version, '0.8.50');
if (fs.existsSync(path.join(ROOT, 'package-lock.json'))) {
  const lock = JSON.parse(fs.readFileSync(path.join(ROOT, 'package-lock.json'), 'utf8'));
  assert.strictEqual(lock.version, '0.8.50');
  if (lock.packages && lock.packages['']) assert.strictEqual(lock.packages[''].version, '0.8.50');
}

for (const name of [
  'tests/culinaryPrestigeV085.test.js',
  'tests/culinaryUiV085.test.js',
  'tests/updateInfrastructureV0850.test.js'
]) {
  assert.ok(runner.includes(name), '主测试入口缺少：' + name);
}

assert.ok(/versionCode\s+850/.test(gradle));
assert.ok(/versionName\s+['"]0\.8\.50['"]/.test(gradle));
assert.ok(fs.existsSync(path.join(ROOT, 'PATCH_MANIFEST_V0850.json')));
assert.ok(fs.existsSync(path.join(ROOT, 'src/reputation/culinaryPrestigeSystemV085.js')));

const discoveryPath = path.join(ROOT, 'tools/devkit/test-discovery.js');
if (fs.existsSync(discoveryPath)) {
  const discovery = require(discoveryPath).audit(ROOT);
  assert.strictEqual(
    discovery.metrics.uncovered,
    0,
    '全部测试必须纳入主入口：' + discovery.uncovered.join(', ')
  );
}

console.log('V0.8.50 update infrastructure tests passed');
