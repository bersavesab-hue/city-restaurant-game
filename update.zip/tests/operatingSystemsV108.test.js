'use strict';

const assert = require('assert');
const { BusinessOperatingSystemV108, SCHEMA_VERSION } = require('../src/operating/businessOperatingSystemV108.js');

const memory = {};
const player = { cash: 24000, reputation: 55 };
const storage = {
  get(key) { return memory[key] ? JSON.parse(JSON.stringify(memory[key])) : null; },
  set(key, value) { memory[key] = JSON.parse(JSON.stringify(value)); }
};
const adapter = {
  mutateCash(delta) { player.cash += delta; return true; },
  mutateReputation(delta) { player.reputation += delta; return true; }
};

function snap(day, extra) {
  return Object.assign({
    time: { year: 1, month: 4, day },
    dayKey: `1-4-${day}`,
    monthKey: '1-4',
    dayOrdinal: day,
    districtId: 'university',
    cash: player.cash,
    reputation: player.reputation,
    hasStore: true,
    storeOpen: true,
    operatingDays: day,
    safeCashLine: 10000,
    daily: { revenue: 5200, orders: 180, foodCost: 1500, laborCost: 900, operatingProfit: 1450, sourceCompleteness: 'test' }
  }, extra || {});
}

const system = new BusinessOperatingSystemV108({ storage, adapter, seed: 12345 });
assert.strictEqual(system.getState().schemaVersion, SCHEMA_VERSION);

// 强制事件：必须进入 active，选择后进入历史并释放。
const beforeCash = player.cash;
const forced = system.triggerEvent('food_safety_inspection', snap(1), 'test');
assert(forced && system.getState().events.active, 'forced event should become active');
const resolved = system.resolveForcedEvent('cooperate', snap(1));
assert.strictEqual(resolved.ok, true);
assert.strictEqual(system.getState().events.active, null);
assert(player.cash < beforeCash, 'event effect should mutate cash');
assert(system.getState().events.history.some(x => x.eventId === 'food_safety_inspection'));

// 事件效果应真正改变需求倍率，并在到期后恢复。
system.triggerEvent('university_opening_week', snap(2), 'test');
assert(system.getDemandMultiplier('university') > 1.1);
system.getState().simMinutes += 5 * 1440;
assert.strictEqual(system.getDemandMultiplier('university'), 1);

// 事件链：选择高风险方案会排入后续事件。
system.triggerEvent('freezer_failure', snap(3), 'test');
assert(system.getState().events.active);
system.resolveForcedEvent('keep', snap(3));
assert(system.getState().events.chainQueue.some(x => x.eventId === 'customer_complaint_safety'));
// 清掉可能残余 active，推进到链事件到期。
system.getState().simMinutes += 1300;
system.onTimeAdvanced(1, snap(4));
assert(system.getState().events.active && system.getState().events.active.eventId === 'customer_complaint_safety');
system.resolveForcedEvent('support_check', snap(4));

// 金融：授信、放款、计息、还款闭环。
const credit = system.getAvailableCredit(snap(5));
assert(credit >= 10000);
const loanResult = system.requestLoan(10000, 90, 0.12, snap(5), '测试经营贷');
assert.strictEqual(loanResult.ok, true);
assert(system.getState().finance.loans.some(x => x.status === 'active'));
const cashAfterLoan = player.cash;
system.onTimeAdvanced(1440, snap(6, { cash: player.cash }));
const loan = system.getState().finance.loans.find(x => x.id === loanResult.loan.id);
assert(loan.accruedInterest >= 0);
const repay = system.repayLoan(loan.id, 1000, snap(6, { cash: player.cash }));
assert.strictEqual(repay.ok, true);
assert(player.cash < cashAfterLoan);

// 漏斗、评分、菜品、排行接口。
const funnel = system.recordFunnel({ demand: 300, potential: 220, actualOrders: 170, loss: { kitchen: 20, seats: 15, wait: 15 } }, snap(6));
assert.strictEqual(funnel.lostOrders, 50);
const rating = system.recordRating({ taste: 96, service: 92, environment: 90, value: 90, speed: 92, safety: 98 }, snap(6));
assert(rating.overall > 4);
system.recordDish({ id: 'dish_1', name: '测试菜', price: 28, cost: 9, quality: 82, sales: 120 }, snap(6));
const improved = system.improveDish('dish_1', 'quality', 700, snap(6));
assert.strictEqual(improved.ok, true);
system.recordRanking({ districtRank: 3, score: 84.2 }, snap(6));
assert.strictEqual(system.getState().rankings.current.districtRank, 3);

// 日/周结算：跨日时结算前一日，不重复写同一天。
for (let day = 7; day <= 15; day++) {
  system.onTimeAdvanced(1440, snap(day, { cash: player.cash }));
}
assert(system.getState().settlements.daily.length >= 7, 'daily settlements should accumulate');
assert(system.getState().settlements.weekly.length >= 1, 'weekly settlement should be created');

// 存档恢复：active/queue/history/loans 都必须保留。
system.persist();
const restored = new BusinessOperatingSystemV108({ storage, adapter, seed: 1 });
assert.strictEqual(restored.getState().schemaVersion, SCHEMA_VERSION);
assert(restored.getState().finance.loans.length >= 1);
assert(restored.getState().events.history.length >= 3);

console.log('[V1.0.8] operatingSystemsV108.test PASS');
