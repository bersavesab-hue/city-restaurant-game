'use strict';

const assert = require('assert');
const path = require('path');
const fs = require('fs');
const childProcess = require('child_process');
const os = require('os');

const root = path.resolve(__dirname, '..');

const esbuild = path.join(
  root,
  'node_modules',
  '.bin',
  process.platform === 'win32'
    ? 'esbuild.cmd'
    : 'esbuild'
);

const outfile = path.join(
  os.tmpdir(),
  'city-restaurant-v21-test-bundle.js'
);

/*
 * 独立“游戏底层自动测试”工作流目前不会先 npm install。
 * V35清理 node_modules 后，这个旧测试不能再把“依赖未安装”
 * 误判成“Android代码损坏”。
 *
 * 有 esbuild 时继续做真正bundle回归；
 * 没有 esbuild 时做源码语法兜底，并确认项目仍声明esbuild依赖。
 */
if (!fs.existsSync(esbuild)) {
  const pkg = JSON.parse(
    fs.readFileSync(
      path.join(root, 'package.json'),
      'utf8'
    )
  );

  assert.ok(
    pkg.devDependencies &&
    pkg.devDependencies.esbuild,
    '项目必须声明esbuild开发依赖'
  );

  for (const file of [
    path.join(root, 'android/entry.js'),
    path.join(root, 'src/main.js')
  ]) {
    const checked = childProcess.spawnSync(
      process.execPath,
      ['--check', file],
      {
        cwd: root,
        encoding: 'utf8',
        timeout: 45000
      }
    );

    assert.strictEqual(
      checked.status,
      0,
      '无node_modules环境下源码语法检查必须通过：\n' +
        (checked.stderr || checked.stdout || '')
    );
  }

  console.log(
    'V21 Android bundle regression test: esbuild未安装，已完成声明检查与源码语法兜底'
  );

  process.exit(0);
}

function runBundle() {
  try {
    if (fs.existsSync(outfile)) {
      fs.unlinkSync(outfile);
    }
  } catch (error) {
  }

  return childProcess.spawnSync(
    esbuild,
    [
      path.join(root, 'android/entry.js'),
      '--bundle',
      '--platform=browser',
      '--format=iife',
      '--target=chrome100',
      '--outfile=' + outfile
    ],
    {
      cwd: root,
      encoding: 'utf8',
      maxBuffer: 16 * 1024 * 1024,
      timeout: 45000
    }
  );
}

let result = null;

for (let attempt = 1; attempt <= 3; attempt++) {
  result = runBundle();

  if (
    result &&
    typeof result.status === 'number'
  ) {
    break;
  }

  if (attempt < 3) {
    console.warn(
      'V21 Android bundle test spawn status=null，重试 ' +
      (attempt + 1) +
      '/3'
    );
  }
}

const detail =
  result
    ? (
      result.stderr ||
      result.stdout ||
      (
        result.error
          ? String(result.error)
          : ''
      ) ||
      (
        result.signal
          ? 'signal=' + result.signal
          : ''
      )
    )
    : 'spawnSync未返回结果';

assert.strictEqual(
  result && result.status,
  0,
  'V21 Android JS bundle必须成功:\n' +
    detail
);

assert.ok(
  fs.existsSync(outfile) &&
  fs.statSync(outfile).size > 1000,
  'V21 Android测试bundle未生成'
);

try {
  fs.unlinkSync(outfile);
} catch (error) {
}

console.log(
  'V21 Android esbuild regression test passed'
);
