'use strict';

const assert = require('assert');
const Module = require('module');

const business = {};
const player = { reputation: 20 };
const time = { year: 1, month: 1, day: 8 };
const mockGameState = {
  getBusiness(){ return business; },
  getPlayer(){ return player; },
  getTime(){ return time; }
};

const oldLoad = Module._load;
Module._load = function(request, parent, isMain) {
  if (
    request === '../core/gameState.js' &&
    parent &&
    /culinaryPrestigeSystemV085\.js$/.test(parent.filename)
  ) {
    return mockGameState;
  }
  return oldLoad.apply(this, arguments);
};

const prestige = require('../src/reputation/culinaryPrestigeSystemV085.js');

assert.strictEqual(prestige.VERSION, '0.8.5');
assert.strictEqual(prestige.IMPROVEMENTS.length, 7);
assert.strictEqual(prestige.RANK_CATEGORIES.length, 7);
assert.ok(prestige.AWARDS.length >= 8);

const dishScore = prestige.computeDishScore({
  taste: 90,
  consistency: 80,
  value: 75,
  speed: 70,
  innovation: 85,
  presentation: 78,
  health: 72
});
assert.ok(dishScore > 75 && dishScore < 90, '菜品评分应为七维加权结果');

const lowSample = prestige.computeStoreScore({
  taste:95, service:95, speed:95, value:95,
  hygiene:95, atmosphere:95, consistency:95, innovation:95
}, 1);
const highSample = prestige.computeStoreScore({
  taste:95, service:95, speed:95, value:95,
  hygiene:95, atmosphere:95, consistency:95, innovation:95
}, 300);
assert.ok(lowSample.score < highSample.score, '小样本高分必须被可信度校正');
assert.ok(lowSample.confidence < highSample.confidence, '样本越多可信度应越高');

const item = { id:'dish_1', recipeId:'recipe_1', name:'黑椒牛肉', listPrice:28 };
const firstPlan = prestige.improvementPlan('shop_a', item, 'taste', 11.6);
assert.ok(firstPlan.ok && firstPlan.cost >= 420);
const first = prestige.applyImprovement('shop_a', item, 'taste', { paidCost:firstPlan.cost, costEstimate:11.6 });
assert.ok(first.ok);
assert.ok(first.after > first.before, '第一次改良应提升菜品分');
const secondPlan = prestige.improvementPlan('shop_a', item, 'taste', 11.6);
assert.ok(secondPlan.cost > firstPlan.cost, '连续改良成本应上升');
assert.ok(secondPlan.effects.taste < firstPlan.effects.taste, '连续同向改良收益应递减');

const runtime = {
  shop:{ id:'shop_a', name:'怀仁食堂', rating:4.7, reviewCount:160 },
  menu:[
    item,
    { id:'dish_2', recipeId:'recipe_2', name:'番茄鸡蛋面', listPrice:18, active:true },
    { id:'dish_3', recipeId:'recipe_3', name:'脆皮鸡排饭', listPrice:22, active:true }
  ],
  dailySnapshots:[{ financial:{ orders:180, customers:185, profitRate:24 } }]
};
const context = { costByItem:{ dish_1:11.6, dish_2:6.2, dish_3:8.4 }, profitRate:24 };
const snap = prestige.overview('shop_a', runtime, context);
assert.ok(snap.rating.score > 0);
assert.strictEqual(Object.keys(snap.rating.metrics).length, 8, '门店评分应有八个维度');
assert.strictEqual(snap.dishes.length, 3);

const rank1 = prestige.buildRanking('shop_a', runtime, { scope:'district', category:'innovation', context, baseRows:[] });
const rank2 = prestige.buildRanking('shop_a', runtime, { scope:'district', category:'innovation', context, baseRows:[] });
assert.strictEqual(rank1.rows.length, 12);
assert.ok(rank1.player.rank >= 1 && rank1.player.rank <= 12);
assert.deepStrictEqual(
  rank1.rows.map(x => [x.name,x.score,x.rank]),
  rank2.rows.map(x => [x.name,x.score,x.rank]),
  '同一周期同一榜单应稳定，不能每次打开随机跳名次'
);
assert.ok(Number.isFinite(rank1.player.gapToPrev));

const lowRuntime = {
  shop:{ id:'shop_low', name:'样本不足店', rating:5, reviewCount:2 },
  menu:[{ id:'d', name:'测试菜', listPrice:20 }],
  dailySnapshots:[]
};
const lowAwards = prestige.evaluateAwards('shop_low', lowRuntime, { context:{costByItem:{d:6}} });
assert.ok(lowAwards.awards.some(x => x.eligible === false), '样本不足不能直接拿奖');

const awards = prestige.evaluateAwards('shop_a', runtime, { context });
assert.strictEqual(awards.awards.length, prestige.AWARDS.length);
for (const row of awards.awards) {
  assert.ok(Array.isArray(row.nominees) && row.nominees.length <= 3);
  assert.ok(typeof row.reason === 'string' && row.reason.length > 0);
}
const cached = prestige.evaluateAwards('shop_a', runtime, { context });
assert.deepStrictEqual(
  cached.awards.map(x => [x.awardId,x.periodKey,x.selectedWinner,x.won]),
  awards.awards.map(x => [x.awardId,x.periodKey,x.selectedWinner,x.won]),
  '同一评奖周期不得重复抽奖改变结果'
);
const ceremonyBefore = prestige.getShopState('shop_a').awards.won.length;
const ceremony = prestige.holdAwardCeremony('shop_a', runtime);
assert.ok(ceremony.ok);
assert.ok(prestige.getShopState('shop_a').awards.won.length >= ceremonyBefore);
for (const granted of ceremony.granted) {
  assert.strictEqual(granted.ceremonyHeld, true);
  assert.strictEqual(granted.won, true);
}
const secondCeremony = prestige.holdAwardCeremony('shop_a', runtime);
assert.strictEqual(secondCeremony.granted.length, 0, '同一期奖项不能重复颁奖');

Module._load = oldLoad;
console.log('V0.8.50 culinary prestige system tests passed');
