'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const root = path.resolve(__dirname, '..');
const catalog = require('../src/assets/assetCatalogV2.js');
const loader = require('../src/assets/assetLoaderV2.js');

assert.strictEqual(catalog.manifest.schema, 2);
assert.strictEqual(catalog.manifest.version, '2.0.0');
assert.strictEqual(catalog.getGroup('backgrounds').length, 8);
assert.strictEqual(catalog.getGroup('districts').length, 12);
assert.strictEqual(catalog.getGroup('storefronts').length, 8);
assert.strictEqual(catalog.getGroup('store_states').length, 8);
assert.strictEqual(catalog.getGroup('empty_states').length, 6);

const atlasNames = ['nav_atlas','hud_atlas','functions_atlas','facilities_atlas','status_atlas','decorative_atlas'];
for (const id of atlasNames) {
  const atlas = catalog.getAtlas(id);
  assert(atlas, 'missing atlas ' + id);
  assert(fs.existsSync(path.join(root, atlas.path)), 'missing file ' + atlas.path);
  for (const region of Object.values(atlas.sprites || {})) {
    assert(region.x >= 0 && region.y >= 0);
    assert(region.x + region.w <= atlas.width);
    assert(region.y + region.h <= atlas.height);
  }
}

const deleteList = require('../assets/ui/home/delete-list-v2.json');
assert(deleteList.delete.length >= 120);
for (const rel of deleteList.delete) {
  assert(rel.startsWith('assets/ui/home/'));
  assert(!rel.includes('..'));
  assert(rel.endsWith('.png'));
}

let bytes = 0;
for (const item of catalog.manifest.entries) bytes += fs.statSync(path.join(root, item.path)).size;
for (const atlas of Object.values(catalog.manifest.atlases)) bytes += fs.statSync(path.join(root, atlas.path)).size;
assert(bytes < 8 * 1024 * 1024, 'optimized home asset pack should stay below 8 MB');

(async () => {
  const calls = [];
  const mock = {loadImage(id, p, g){calls.push([id,p,g]); return Promise.resolve(id);}};
  loader.resetTracking();
  await loader.preloadHomeEssential(mock);
  assert.strictEqual(calls.length, 2);
  await loader.loadHomeScene(mock, 'city');
  assert.strictEqual(calls.length, 22);
  const s = loader.getSprite('nav_city');
  assert(s && s.atlasId === 'nav_atlas');
  console.log('assetPipelineV054.test.js PASS');
})().catch((e) => { console.error(e); process.exit(1); });
