'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const main = fs.readFileSync(path.join(ROOT, 'src/main.js'), 'utf8');
const store = fs.readFileSync(path.join(ROOT, 'src/scenes/storeScene.js'), 'utf8');

assert.ok(main.includes('V36_HEADER_MONEY_WEATHER_FINAL'), 'V36主页资金天气改版必须存在');
assert.ok(main.includes('function v36CompactHeaderMoney'), '主页必须使用短金额格式');
assert.ok(main.includes('const weatherW = 62;'), '天气必须使用独立紧凑胶囊');
assert.ok(main.includes('const moneyW = 82;'), '首页资金卡必须缩窄，避免遮挡天气');
assert.ok(main.includes("'资金'"), '首页资金标签必须简化为“资金”');

const hudStart = main.indexOf('drawTopHud = function () {');
const hudEnd = main.indexOf('drawNewsTicker = function () {', hudStart);
assert.ok(hudStart >= 0 && hudEnd > hudStart, '必须能定位最终主页顶部HUD');
const hud = main.slice(hudStart, hudEnd);
assert.ok(!hud.includes("drawText('+',"), '最终主页资金卡不得再显示“+”按钮');
assert.ok(hud.includes('v36CompactHeaderMoney(player.cash)'), '首页必须使用V36短金额');

assert.ok(store.includes('V36_HEADER_MONEY_WEATHER_FINAL'), '门店页V36改版必须存在');
assert.ok(store.includes('function compactHeaderMoney'), '门店页必须使用短金额格式');
assert.ok(store.includes("cityName ===\n        '未命名城市'"), '门店页未命名城市必须兜底为美食市');

const headerStart = store.indexOf('  drawHeader(');
const headerEnd = store.indexOf('  drawStoreHero(', headerStart);
assert.ok(headerStart >= 0 && headerEnd > headerStart, '必须能定位门店页顶部');
const header = store.slice(headerStart, headerEnd);
assert.ok(header.includes('compactHeaderMoney('), '门店顶部必须使用短金额');
assert.ok(!header.includes("'可用资金'"), '门店顶部不再使用冗长“可用资金”');
assert.ok(header.includes("'资金'"), '门店顶部资金标签应统一为“资金”');

console.log('V36 header money/weather regression tests passed');
