'use strict';

const assert = require('assert');
const traffic = require('../src/city/customerTrafficSystem.js');

function baseFacilities(area) {
  return {
    usableArea: area,
    exhaust: true,
    gas: false,
    threePhase: true,
    drainage: true,
    greaseTrap: true,
    fireSprinkler: true
  };
}

assert.strictEqual(
  traffic.classifyStore(baseFacilities(8)).id,
  'stall'
);
assert.strictEqual(
  traffic.classifyStore(baseFacilities(20)).id,
  'takeaway_shop'
);
assert.strictEqual(
  traffic.classifyStore(baseFacilities(35)).id,
  'micro_restaurant'
);
assert.strictEqual(
  traffic.classifyStore(baseFacilities(55)).id,
  'small_restaurant'
);
assert.strictEqual(
  traffic.classifyStore(baseFacilities(100)).id,
  'restaurant'
);
assert.strictEqual(
  traffic.classifyStore(baseFacilities(180)).id,
  'large_restaurant'
);

const noDrain = traffic.classifyStore({
  ...baseFacilities(55),
  drainage: false
});
assert.strictEqual(noDrain.dineInAllowed, false);

const pool = {
  mealPeriod: 'lunch',
  totalDemand: 500,
  remainingDemand: 500,
  customerGroups: {
    student: { demand: 350 },
    resident: { demand: 150 }
  }
};

const customerTypes = {
  student: { speedSensitivity: 0.72 },
  resident: { speedSensitivity: 0.48 }
};

const smallResult = traffic.simulate({
  mealPeriod: 'lunch',
  district: { saturation: 70, baseDemand: 1800 },
  demandPool: pool,
  customerTypes,
  store: {
    ...baseFacilities(30),
    footfall: 9000,
    visibility: 85,
    frontage: 4.5,
    rating: 4.0,
    reputation: 55,
    priceFit: 70,
    menuAppeal: 70,
    staffCount: 2
  }
});

const biggerResult = traffic.simulate({
  mealPeriod: 'lunch',
  district: { saturation: 70, baseDemand: 1800 },
  demandPool: pool,
  customerTypes,
  store: {
    ...baseFacilities(70),
    footfall: 9000,
    visibility: 85,
    frontage: 4.5,
    rating: 4.0,
    reputation: 55,
    priceFit: 70,
    menuAppeal: 70,
    staffCount: 5
  }
});

assert.ok(smallResult.funnel.periodPassers > 0);
assert.ok(smallResult.funnel.attempted >= smallResult.funnel.actualCustomers);
assert.strictEqual(
  smallResult.funnel.lostCustomers,
  smallResult.funnel.attempted - smallResult.funnel.actualCustomers
);
assert.ok(
  biggerResult.funnel.actualCustomers >= smallResult.funnel.actualCustomers,
  'larger properly staffed shop should not serve fewer customers with same demand'
);

console.log('customerTrafficSystemV103 tests PASS');
