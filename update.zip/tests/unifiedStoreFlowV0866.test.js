'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const gameState = require('../src/core/gameState.js');
const simulationSystem = require('../src/core/simulationSystem.js');
const starter = require('../src/core/starterShopV0866.js');
const storeModel = require('../src/operations/storeOperatingModelV0866.js');
const operations = require('../src/operations/operationsStoreV080.js');
const restaurantSimulation = require('../src/operations/restaurantSimulationV081.js');
const floorSimulation = require('../src/operations/floorSimulationV082.js');
const runtimeEngine = require('../src/operations/restaurantRuntimeV10.js');

gameState.reset();
gameState.setCityName('云州市');
simulationSystem.initialize();

const created = starter.ensureStarterShop({gameState});
assert.equal(created.created,true,'新玩家必须自动接手成熟小店');

const business = gameState.getBusiness();
assert.equal(business.hasShop,true);
assert.equal(business.currentShopId,starter.STARTER_ID);

const shop = business.shops.find(x=>x.id===starter.STARTER_ID);
assert.ok(shop);
assert.equal(shop.usableArea,42,'成熟首店应约42㎡');
assert.equal(shop.status,'open','成熟首店必须直接营业');
assert.equal(shop.ownerOperatedRoles.includes('manager'),true,'老板应兼任店长');
assert.equal(shop.ownerOperatedRoles.includes('cashier'),true,'老板应兼任收银');

const capacity = storeModel.actualSeatCapacity(shop);
assert.equal(capacity.seats,16,'营业座位必须来自装修真实餐桌');
assert.deepEqual(capacity.counts,{two:4,four:2,six:0,eight:0});

const format = storeModel.format(shop);
assert.equal(format.id,'small_restaurant');
assert.equal(format.dineInAllowed,true);
assert.ok(storeModel.serviceChannels(shop).includes('dine_in'));

const runtime = operations.getRuntime(shop.id);
assert.ok(runtime);
assert.equal(runtime.menu.length,6,'成熟首店开局菜单应控制在6道');
assert.equal(
  runtime.diningRoom.tables.reduce((sum,t)=>sum+Number(t.seats||0),0),
  16,
  '楼面餐桌必须与装修座位一致'
);
assert.ok(
  runtime.inventory.lots.some(lot=>Number(lot.grams)>0),
  '成熟首店必须带基础库存'
);

const staff = gameState.getOpeningPrep().staffing[shop.id];
assert.equal(staff.hired.length,2,'首店应有1名厨师+1名前厅员工');
assert.deepEqual(
  storeModel.requiredStaff(shop),
  {manager:0,chef:1,server:1,cashier:0},
  '老板兼岗后不应强塞四名NPC'
);

const time = gameState.getTime();
time.hour=12;
time.minute=0;

const rate = restaurantSimulation.expectedArrivalsPerMinute(shop,runtime);
assert.ok(rate>0,'正式营业顾客必须来自真实客流漏斗');
assert.ok(runtime.simulation.trafficFunnel,'营业Runtime必须保存当前客流漏斗');
assert.ok(runtime.simulation.trafficFunnel.funnel.periodPassers>0,'必须存在门前经过人数');
assert.ok(runtime.simulation.trafficFunnel.funnel.attempted>=0,'必须存在尝试进店人数');

const stall = {
  id:'stall_test',
  status:'open',
  districtId:'university',
  usableArea:10,
  grossArea:10,
  seatEstimate:8,
  footfall:9000,
  exhaust:false,
  drainage:true,
  fireSafety:true
};

const stallFormat = storeModel.format(stall);
assert.equal(stallFormat.id,'stall');
assert.equal(stallFormat.seatCapacity,0,'10㎡档口不能因旧seatEstimate获得堂食座位');
assert.equal(stallFormat.dineInAllowed,false);
assert.ok(!storeModel.serviceChannels(stall).includes('dine_in'),'0座档口不能生成堂食渠道');

const isolated = runtimeEngine.createRuntime({
  seed:'zero-seat-test',
  shopId:'stall_test',
  recipeIds:runtime.menu.map(x=>x.recipeId).slice(0,2)
});

floorSimulation.syncTables(
  isolated,
  0,
  {two:0,four:0,six:0,eight:0}
);

assert.equal(isolated.diningRoom.tables.length,0,'楼面系统不得再强制制造最低8座');


const simulationSource = fs.readFileSync(
  path.join(__dirname,'../src/operations/restaurantSimulationV081.js'),
  'utf8'
);
assert.ok(
  simulationSource.includes('peakDemandFactor') &&
  simulationSource.includes('workloadTick.overtimeCost'),
  '真实客流接入后仍必须保留高峰负荷与加班成本'
);

const planningShop = {
  id:'planning_capacity_test',
  status:'leased_pending_renovation',
  usableArea:80,
  seatEstimate:28,
  exhaust:true,
  drainage:true,
  fireSafety:true
};
assert.equal(
  storeModel.planningSeatCapacity(planningShop),
  28,
  '筹备报价允许使用房源预计席位，正式营业不得使用该值兜底'
);

console.log('V0.8.66 unified starter/traffic/capacity tests passed');
