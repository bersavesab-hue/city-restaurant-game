'use strict';

const assert =
  require('assert');

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const source =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/scenes/renovationScene.js'
    ),
    'utf8'
  );

assert.ok(
  source.includes(
    'V47_RENOVATION_REFERENCE_REBUILD'
  ),
  'V47重构标记不存在'
);

for (
  const token
  of [
    'drawFloorCanvas(',
    'drawPlanBase(',
    'drawTemplateStrip(',
    'drawTablePicker(',
    'drawMetrics(',
    'drawFooter(',
    'renderZones(',
    'renderFurniture(',
    'renderStyle(',
    'renderRooms(',
    'renderContractors('
  ]
) {
  assert.ok(
    source.includes(token),
    'V47核心模块缺失：' +
      token
  );
}

for (
  const asset
  of [
    'reno_stove',
    'reno_prep',
    'reno_sink',
    'reno_fridge',
    'reno_storage_shelf',
    'reno_cashier',
    'reno_table_2',
    'reno_table_4',
    'reno_table_6',
    'reno_table_8',
    'reno_plant_1'
  ]
) {
  assert.ok(
    source.includes(asset),
    '完整平面图缺少家具资源：' +
      asset
  );
}

assert.ok(
  !source.includes(
    "'v45_layout_dining'"
  ) &&
  !source.includes(
    "'v45_layout_kitchen'"
  ),
  'V47主平面图禁止再放大小型layout缩略图'
);

assert.ok(
  source.includes(
    'drawImageContain('
  ),
  '家具必须使用contain模式避免裁半截'
);

assert.ok(
  source.includes(
    "'装修模板'"
  ) &&
  source.includes(
    "'餐厅平面图'"
  ) &&
  source.includes(
    "'餐桌类型'"
  ) &&
  source.includes(
    "'装修数据预览'"
  ) &&
  source.includes(
    "'选择施工队并开始施工  ›'"
  ),
  '主页面必须保留参考图五大层级'
);

assert.ok(
  source.includes(
    "'座位数'"
  ) &&
  source.includes(
    "'预算'"
  ) &&
  source.includes(
    "'工期'"
  ) &&
  source.includes(
    "'舒适度'"
  ) &&
  source.includes(
    "'吸引力'"
  ) &&
  source.includes(
    "'运营效率'"
  ),
  '数据预览六指标不完整'
);

assert.ok(
  source.includes(
    'V45_HALL_STYLE_VISUAL'
  ),
  'V45风格资源兼容必须保留'
);

for (
  const action
  of [
    "'template:save'",
    "'template:save-as'",
    "'shop:rename'",
    "'history:undo'",
    "'history:redo'",
    "'room:add'",
    "'construction:start'",
    "'construction:confirm'"
  ]
) {
  assert.ok(
    source.includes(action),
    '真实交互缺失：' +
      action
  );
}

for (
  const bad
  of [
    '🛋',
    '💡',
    '🚪',
    '🪑',
    '🔨',
    '💾',
    '👨‍🍳',
    '🍴'
  ]
) {
  assert.ok(
    !source.includes(bad),
    'V47不应再使用Emoji拼装修UI：' +
      bad
  );
}

console.log(
  'V47 renovation reference rebuild tests passed'
);
