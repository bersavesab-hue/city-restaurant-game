'use strict';
const assert=require('assert');
const reno=require('../src/renovation/index.js');
const Engine=reno.LayoutEngine;
const rules=reno.rules;

(function areaAndRoomShape(){
  const small=rules.createFloorPlan({usableArea:18,frontage:3.6,depth:5,exhaust:true,threePhase:true,drainage:true});
  const large=rules.createFloorPlan({usableArea:96,frontage:8,depth:12,exhaust:true,gas:true,threePhase:true,drainage:true,electricCapacityKw:50});
  assert.ok(large.widthCells*large.depthCells>small.widthCells*small.depthCells,'大房源必须拥有更多可用网格');
  assert.ok(Math.abs(small.usableAreaFromGrid-18)<=1,'18㎡网格面积必须接近真实可用面积');
  assert.ok(Math.abs(large.usableAreaFromGrid-96)<=2,'96㎡网格面积必须接近真实可用面积');
})();

(function collisionBoundaryAndDoor(){
  const e=new Engine({usableArea:42,frontage:5.6,depth:7.5,exhaust:true,gas:true,threePhase:true,drainage:true,electricCapacityKw:36});
  assert.ok(e.place('dining_table_2',0,4,0).ok);
  assert.strictEqual(e.place('dining_table_2',0,4,0).ok,false,'家具图片重叠对应的逻辑占地必须被拒绝');
  assert.strictEqual(e.place('dining_table_4',99,99,0).ok,false,'超出租赁面积必须被拒绝');
  const door=e.getPlan().doors[0];
  assert.strictEqual(e.place('service_cashier',door.x,0,0).ok,false,'入口/消防疏散区必须保持空闲');
})();

(function utilityConstraints(){
  const e=new Engine({usableArea:42,frontage:5.6,depth:7.5,exhaust:false,gas:true,threePhase:true,drainage:true});
  const r=e.place('kitchen_wok_2',0,e.getPlan().depthCells-4,0);
  assert.strictEqual(r.ok,false);
  assert.ok(r.errors.some((x)=>/排烟/.test(x)),'无排烟不能摆炒灶');
})();

(function autoLayoutsAcrossSizes(){
  const rows=[
    [{usableArea:22,frontage:4,depth:5.5,exhaust:true,threePhase:true,drainage:true,electricCapacityKw:28},'economy'],
    [{usableArea:48,frontage:6,depth:8,exhaust:true,gas:true,threePhase:true,drainage:true,electricCapacityKw:40},'balanced'],
    [{usableArea:96,frontage:8,depth:12,exhaust:true,gas:true,threePhase:true,drainage:true,electricCapacityKw:55},'balanced']
  ];
  for(const [property,mode] of rows){
    const e=new Engine(property);const r=e.autoLayout(mode);assert.ok(r.ok,'自动布局应适配 '+property.usableArea+'㎡');
    const m=e.getMetrics();assert.ok(m.pathOk,'自动布局必须保留可通行主通道');
    assert.ok(m.occupancyRate<0.80,'自动布局不能把房间塞满');
  }
})();

(function zOrderSaveRestore(){
  const e=new Engine({usableArea:60,frontage:6,depth:10,exhaust:true,gas:true,threePhase:true,drainage:true,electricCapacityKw:45});
  assert.ok(e.autoLayout('balanced').ok);
  const ordered=e.getDrawOrder();assert.strictEqual(ordered.length,e.getPlacements().length);
  for(let i=1;i<ordered.length;i++){
    const a=reno.pack.ASSET_BY_ID[ordered[i-1].assetId],b=reno.pack.ASSET_BY_ID[ordered[i].assetId];
    const la=reno.pack.LAYER_ORDER[a.layer]||0,lb=reno.pack.LAYER_ORDER[b.layer]||0;
    assert.ok(la<=lb,'不同图层必须按固定层级绘制，避免遮挡错乱');
  }
  const saved=e.exportPlan();const e2=new Engine(saved.property,saved);assert.deepStrictEqual(e2.getPlacements(),saved.placements,'装修存档必须可恢复');
})();

console.log('renovationLayoutV180.test.js PASS');
