'use strict';

const assert = require('assert');
const moduleUnderTest = require('../src/core/newGameFlowV0814.js');

function makeState() {
  let data;

  function reset() {
    data = {
      version:1,
      player:{
        cash:50000,
        brandName:'未命名品牌',
        reputation:0
      },
      world:{
        cityName:'',
        currentCityId:'yunzhou',
        currentDistrictId:'university',
        simulation:{ seed:null }
      },
      business:{
        hasShop:false,
        currentShopId:null,
        shops:[],
        renovations:{},
        openingPrep:{
          equipment:{},
          permits:{},
          staffing:{}
        },
        restaurantOperations:{
          version:'0.8.3',
          sharedSupplierNetwork:null,
          shops:{}
        }
      },
      progress:{
        firstLaunch:true,
        tutorialStep:0
      }
    };
  }

  reset();

  return {
    getData:() => data,
    getPlayer:() => data.player,
    getWorld:() => data.world,
    getBusiness:() => data.business,
    getRenovations:() => data.business.renovations,
    getOpeningPrep:() => data.business.openingPrep,
    getRestaurantOperations:() => data.business.restaurantOperations,
    getSimulation:() => data.world.simulation,
    setCityName(name) {
      const clean = String(name || '').trim();
      if (!clean) return false;
      data.world.cityName = clean.slice(0, 12);
      return true;
    },
    getCityName() {
      return data.world.cityName || '未命名城市';
    },
    reset
  };
}

const state = makeState();

let saveCalls = 0;
let autoSaveCalls = 0;
let simulationInitCalls = 0;
let busEvents = [];

const fakeSave = {
  newGame() {
    state.reset();
    saveCalls++;
    return true;
  },
  save() {
    saveCalls++;
    return true;
  },
  autoSave() {
    autoSaveCalls++;
    return true;
  }
};

const flow = moduleUnderTest.createFlow({
  gameState:state,
  saveSystem:fakeSave,
  simulationSystem:{
    initialize() {
      simulationInitCalls++;
      return true;
    }
  },
  openingPrepSystem:{
    getStaffOverview() {
      return { coverage:1 };
    }
  },
  bus:{
    emit(type,payload) {
      busEvents.push({type,payload});
    }
  },
  now:() => 123456789
});

let progress = flow.initialize({
  fresh:true,
  restoredFromSave:false
});

assert.equal(progress.stage,'city_setup');
assert.equal(flow.getStartupRoute().routeId,'newGame');

const confirmed = flow.confirmCityName('星河市');

assert.ok(confirmed.ok);
assert.equal(state.getWorld().cityName,'星河市');
assert.equal(state.getBusiness().hasShop,true,'确认城市后应直接接手成熟首店');
assert.equal(state.getBusiness().shops.length,1);
assert.equal(state.getBusiness().shops[0].usableArea,42);
assert.equal(state.getBusiness().shops[0].status,'open');
assert.equal(confirmed.stage,'complete','成熟首店应直接进入正式经营');
assert.equal(confirmed.next.routeId,'shop');
assert.equal(confirmed.next.params.shopId,'starter_shop_1');
assert.ok(autoSaveCalls>0);

const plan = state.getRenovations().starter_shop_1;
assert.ok(plan);
assert.equal(plan.status,'completed');
assert.equal(plan.floors[0].tables[2],4);
assert.equal(plan.floors[0].tables[4],2);

const prep = state.getOpeningPrep();
assert.equal(prep.staffing.starter_shop_1.hired.length,2);
assert.equal(
  Object.values(prep.permits.starter_shop_1.items)
    .every(x=>x.status==='approved'),
  true
);

progress = flow.getProgress();
assert.ok(progress.completed);

const restarted = flow.restart();
assert.equal(restarted.stage,'city_setup');
assert.equal(state.getBusiness().shops.length,0);
assert.equal(simulationInitCalls,1);
assert.ok(saveCalls>=2);
assert.ok(busEvents.some(item=>item.type==='openingFlow.restarted'));

console.log('V0.8.66 mature starter new game flow tests passed');
