'use strict';

const assert =
  require('assert');

const fs =
  require('fs');

const path =
  require('path');

const source =
  fs.readFileSync(
    path.resolve(
      __dirname,
      '../src/main.js'
    ),
    'utf8'
  );

assert.ok(
  source.includes(
    'V20_HOME_REFERENCE_1TO1'
  ),
  '主页必须升级到V20目标图版'
);

for (
  const token of [
    'function drawGoalBar(',
    'function drawTrafficOverlay(',
    'function getHomeGoalState(',
    'function getDistrictVisualMeta(',
    'function drawDistrictPictogram(',
    'function drawMetricSymbol(',
    "id: 'traffic'",
    "name: '客流'",
    "'city:rename'",
    "'brand:status'",
    "'goal:current'"
  ]
) {
  assert.ok(
    source.includes(
      token
    ),
    'V20主页缺少：' +
      token
  );
}

assert.ok(
  source.includes(
    'meta.myShopCount'
  ),
  '地图必须显示真实我的门店标识'
);

assert.ok(
  source.includes(
    'district.demandDeltaRatio'
  ) &&
  source.includes(
    'district.saturation'
  ) &&
  source.includes(
    'district.rentIndex'
  ),
  '商圈标签必须由真实动态数据决定'
);

assert.ok(
  source.includes(
    "current ===\n            'renovation'"
  ) ||
  source.includes(
    "current ===\n          'renovation'"
  ),
  '装修页必须归入门店底栏高亮体系'
);

console.log(
  'V20 homepage reference-layout tests passed'
);
