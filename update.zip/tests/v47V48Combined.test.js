'use strict';

// v47V48Combined.test.js is retained as a historical CI path after the V0.8.66 renovation
// architecture replacement. It now checks compatibility with the free-build
// model instead of requiring deleted percentage-zone behavior.

const assert = require('assert');
const spatial = require('../src/renovation/renovationFreeBuildV0866.js');

assert.equal(spatial.VERSION,'0.8.66');
assert.equal(spatial.GRID_M,0.25);
assert.equal(spatial.VISIBLE_GRID_M,0.5);
assert.ok(spatial.specFor('table4'));
assert.ok(spatial.specFor('stove'));
assert.equal(typeof spatial.normalizeWall,'function');
assert.equal(typeof spatial.createDoorOnWall,'function');
assert.equal(typeof spatial.detectRooms,'function');

console.log('v47V48Combined.test.js migrated to V0.8.66 free-build compatibility');
