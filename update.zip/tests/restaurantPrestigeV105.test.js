'use strict';

const assert = require('assert');
const system = require('../src/reputation/restaurantPrestigeSystemV105.js');

const dims = system.computeDimensionsFromDashboard({
  store:{ id:'test_shop', rating:4.7, reviewCount:300, environmentScore:84, hygieneScore:90 },
  today:{ rating:4.7, grossMargin:0.62, profitMargin:0.18, turnoverRate:2.1, orders:120, repeatRate:0.72, queueMinutes:6 },
  yesterday:{ rating:4.6, grossMargin:0.60, repeatRate:0.68, queueMinutes:8 },
  funnel:{ potential:135, conversionRate:0.89, reasons:{ quality:2 } },
  capacity:{ queueMinutes:6, turnoverRate:2.1 },
  dishes:[],
  staff:{ averageSkill:82, averageMorale:86, staff:[] },
  supply:{ items:[{freshness:92},{freshness:88}] }
}, {
  reputation:{ averageStars:4.7, reviewCount:300, earnedReach:18000 },
  regulatory:{ complianceScore:92 },
  player:{ reputation:76 }
});

assert.equal(system.VERSION, '1.0.5');
assert.equal(system.CATEGORY_DEFS.length, 5);
assert.ok(system.AWARD_DEFS.length >= 10);
assert.ok(dims.operating > 70 && dims.operating <= 100);
assert.ok(dims.dishQuality > 80);
assert.ok(dims.safety === 92);
assert.ok(['D','C','B','A','S'].includes(dims.grade));
assert.ok(dims.overall > 70 && dims.overall <= 100);

console.log('V1.0.5 prestige consumes V104 rating data successfully');
