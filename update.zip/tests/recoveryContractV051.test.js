'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

for (const name of ['test', 'health', 'repo:cleanup', 'repo:cleanup:dry', 'build:android-js']) {
  assert(pkg.scripts && pkg.scripts[name], `package.json 缺少 scripts.${name}`);
}

for (const rel of [
  'src/foundation/createFoundation.js',
  'src/entities/entityFactory.js',
  'src/property/propertyPackV02.js',
  'src/person/personPackV10.js',
  'src/competitor/competitorPackV10.js',
  'src/customer/customerPackV10.js',
  'src/easteregg/easterEggPackV10.js',
  'scripts/project-health-check.js',
  'scripts/repo-cleanup.js',
  'scripts/run-ci-tests.js',
  '.github/workflows/apply-update-final.yml',
  'package-lock.json'
]) {
  assert(fs.existsSync(path.join(root, rel)), `恢复包缺少 ${rel}`);
}

console.log('recoveryContractV051.test.js PASS');
