'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const main = fs.readFileSync(path.join(ROOT, 'src/main.js'), 'utf8');
const store = fs.readFileSync(path.join(ROOT, 'src/scenes/storeScene.js'), 'utf8');

assert.ok(
  main.includes('/* V37_MONEY_WEATHER_FINAL */'),
  'V37资金天气最终方案必须存在'
);

assert.ok(
  main.includes('const weatherX = 164') &&
  main.includes('const weatherW = 56'),
  '天气必须拥有独立区域，不能再与资金卡重叠'
);

assert.ok(
  main.includes('const moneyW = 80') &&
  main.includes("drawText(\n    '资金'"),
  '首页资金卡必须缩短并使用“资金”标签'
);

const v37Start = main.indexOf('/* V37_MONEY_WEATHER_FINAL */');
const v35Start = main.indexOf('/* V35_TOP_HUD_POLISH */');
const relevant = main.slice(
  Math.max(0, main.lastIndexOf('drawTopHud = function ()', v37Start)),
  v35Start > v37Start ? v35Start : main.length
);

assert.ok(
  !relevant.includes("drawText('+',"),
  '最终首页资金区域禁止再出现+按钮'
);

assert.ok(
  store.includes('/* V37_STORE_HEADER_MONEY_FINAL */'),
  '门店页必须使用最终资金卡'
);

assert.ok(
  store.includes(".replace(/^¥/, '')"),
  '门店页顶部资金必须使用无¥的短金额，避免重复货币表达'
);

assert.ok(
  !store.includes("'可用资金'"),
  '门店顶部不再使用过长的“可用资金”标签'
);

console.log('V37 money/weather final regression tests passed');
