'use strict';
const assert = require('assert');
const { createOperatingRuntimeV108 } = require('../src/operating/operatingRuntimeCoreV108.js');
let paused = false;
let speed = 2;
const gameState = {
  player: { cash: 30000, reputation: 60 },
  world: { currentDistrictId: 'university' },
  time: { year: 1, month: 4, day: 1 },
  getPlayer(){ return this.player; },
  getWorld(){ return this.world; },
  getTime(){ return this.time; }
};
const timeSystem = {
  update(ms){ return Math.max(0, Math.floor(ms / 1000)); },
  getSpeed(){ return speed; }, setSpeed(v){ speed=v; return true; },
  isPaused(){ return paused; }, pause(){ paused=true; }, resume(){ paused=false; }, togglePause(){ paused=!paused; }, resetAccumulator(){}
};
const demandSystem = { getTotalDemand(){ return 1000; } };
const mem = {};
const runtime = { api: { getStorageSync(k){ return mem[k] || null; }, setStorageSync(k,v){ mem[k]=v; } } };
const api = createOperatingRuntimeV108({ gameState, timeSystem, demandSystem, runtime });
assert(api && api.system, 'runtime api missing');
api.system.triggerEvent('university_opening_week', api.buildSnapshot(), 'smoke');
assert(demandSystem.getTotalDemand('university') > 1000, 'demand hook not active');
api.system.triggerEvent('food_safety_inspection', api.buildSnapshot(), 'smoke');
timeSystem.update(1000);
assert.strictEqual(paused, true, 'forced event should pause time');
console.log('[V1.0.8] runtimeCoreV108.smoke PASS');
