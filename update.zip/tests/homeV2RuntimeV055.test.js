'use strict';
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const root = path.resolve(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'src/main.js'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'assets/ui/home/manifest.json'), 'utf8'));
assert(main.includes("require('./assets/assetLoaderV2.js')"));
assert(main.includes('HOME_V2_ASSET_MAPS_V055'));
assert(main.includes('HOME_V2_DRAW_HELPERS_V055'));
for (const id of ['nav_city','nav_store','nav_menu','nav_supply','nav_data','nav_system','hud_weather','hud_cash','hud_level','hud_target','func_analytics','func_growth','func_marketing','func_site_select','func_customers','func_rating']) {
  let found = false;
  for (const atlas of Object.values(manifest.atlases || {})) if (atlas.sprites && atlas.sprites[id]) found = true;
  assert(found, 'missing sprite '+id);
}
for (const id of ['home_bg_sunny_day','home_bg_cloudy_day','home_bg_rain_day','home_bg_night','home_bg_summer','home_bg_winter','district_university','district_hightech','district_business_center','district_oldtown','district_urban_village','district_market','district_industrial']) {
  assert(manifest.index && manifest.index[id], 'missing asset '+id);
}
console.log('homeV2RuntimeV055.test.js PASS');
