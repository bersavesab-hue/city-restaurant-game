'use strict';
const assert=require('assert');
const reno=require('../src/renovation/index.js');
const rules=reno.rules;
for(const row of [
  {usableArea:18,frontage:3.6,depth:5},
  {usableArea:42,frontage:5.6,depth:7.5},
  {usableArea:96,frontage:8,depth:12},
  {usableArea:350,frontage:10,depth:35},
  {usableArea:1000,frontage:12,depth:30},
  {usableArea:20000,frontage:40,depth:80}
]){
  const plan=rules.createFloorPlan(Object.assign({exhaust:true,gas:true,threePhase:true,drainage:true,electricCapacityKw:80},row));
  const diff=Math.abs(plan.usableAreaFromGrid-row.usableArea)/row.usableArea;
  assert.ok(diff<0.08,'网格面积必须跟随真实可用面积: '+row.usableArea+'㎡ => '+plan.usableAreaFromGrid+'㎡');
  assert.ok(plan.widthCells>=6&&plan.depthCells>=6);
}
const e=new reno.LayoutEngine({usableArea:350,frontage:10,depth:35,exhaust:true,gas:true,threePhase:true,drainage:true,electricCapacityKw:90});
assert.ok(e.autoLayout('balanced').ok,'350㎡房源自动布局应可生成');
assert.ok(e.getMetrics().pathOk,'大房源也必须保留约1米主通道');
console.log('renovationLargePropertyV181.test.js PASS');
