'use strict';

const assert = require('assert');
const reno = require('../src/renovation/index.js');
const Engine = reno.LayoutEngine;
const rules = reno.rules;

for (const row of [
  { usableArea:18, frontage:3.6, depth:5 },
  { usableArea:42, frontage:5.6, depth:7.5 },
  { usableArea:96, frontage:8, depth:12 },
  { usableArea:350, frontage:10, depth:35 },
  { usableArea:1000, frontage:12, depth:30 }
]) {
  const plan = rules.createFloorPlan(Object.assign({
    exhaust:true, gas:true, threePhase:true, drainage:true, electricCapacityKw:90
  }, row));
  const diff = Math.abs(plan.usableAreaFromGrid - row.usableArea) / row.usableArea;
  assert.ok(diff < 0.08, '网格面积必须跟随真实可用面积：' + row.usableArea + '㎡');
}

const e = new Engine({
  id:'p42', usableArea:42, frontage:5.6, depth:7.5,
  exhaust:true, gas:true, threePhase:true, drainage:true, electricCapacityKw:36
});
assert.ok(e.place('dining_table_2',0,4,0).ok);
assert.strictEqual(e.place('dining_table_2',0,4,0).ok,false,'重叠必须被拒绝');
assert.strictEqual(e.place('dining_table_4',99,99,0).ok,false,'越界必须被拒绝');
const door=e.getPlan().doors[0];
assert.strictEqual(e.place('service_cashier',door.x,0,0).ok,false,'入口/消防区域不能被占用');

const noSmoke = new Engine({usableArea:42,frontage:5.6,depth:7.5,exhaust:false,gas:true,threePhase:true,drainage:true});
const bad = noSmoke.place('kitchen_wok_2',0,noSmoke.getPlan().depthCells-4,0);
assert.strictEqual(bad.ok,false);
assert.ok(bad.errors.some(x=>/排烟/.test(x)),'无排烟不能摆炒灶');

const big = new Engine({usableArea:350,frontage:10,depth:35,exhaust:true,gas:true,threePhase:true,drainage:true,electricCapacityKw:90});
assert.ok(big.autoLayout('balanced').ok,'大面积房源应能自动布局');
assert.ok(big.getMetrics().pathOk,'自动布局必须保留主通道');

console.log('renovationLayoutV182.test.js PASS');
