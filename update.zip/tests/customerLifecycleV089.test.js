'use strict';

const assert =
  require('assert');

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const gameState =
  require('../src/core/gameState.js');

const customerLifecycle =
  require('../src/operations/customerLifecycleV089.js');

gameState.reset();

gameState
  .addShop({
    id:'shop_customer_v089',
    name:'顾客生命周期测试店',
    status:'open',
    districtId:'university',
    usableArea:90,
    grossArea:100,
    seatEstimate:32,
    monthlyRent:3600
  });

const shop =
  gameState
    .getBusiness()
    .shops[0];

const runtime = {
  customers:{}
};

function closed(
  day,
  rating=4.45,
  customers=126,
  revenue=5670
) {
  return {
    day,
    financial:{
      customers,
      orders:
        Math.max(
          1,
          Math.round(
            customers /
            1.8
          )
        ),
      revenue
    },
    shopRating:
      rating
  };
}

for (
  let day = 1;
  day <= 8;
  day++
) {
  customerLifecycle
    .onDayClosed(
      shop,
      runtime,
      closed(
        day
      )
    );
}

let dashboard =
  customerLifecycle
    .getDashboard(
      shop.id
    );

assert.ok(
  dashboard.stats
    .knownCustomers >
    0,
  '连续营业后必须沉淀长期顾客'
);

assert.ok(
  dashboard.stats
    .repeatRate >
    0,
  '长期顾客必须产生真实复购'
);

assert.ok(
  Object.keys(
    runtime.customers
  ).length >
    0,
  '长期顾客必须回写到餐厅顾客池'
);

const multiplier =
  customerLifecycle
    .getDemandMultiplier(
      shop.id
    );

assert.ok(
  multiplier >=
    0.78 &&
  multiplier <=
    1.20,
  '顾客关系需求系数必须处于安全范围'
);

const membership =
  customerLifecycle
    .setMembershipEnabled(
      shop.id,
      true
    );

assert.ok(
  membership.ok &&
  membership.enabled,
  '玩家必须可以开启会员计划'
);

for (
  let day = 9;
  day <= 18;
  day++
) {
  customerLifecycle
    .onDayClosed(
      shop,
      runtime,
      closed(
        day,
        4.65,
        144,
        6912
      )
    );
}

dashboard =
  customerLifecycle
    .getDashboard(
      shop.id
    );

assert.ok(
  dashboard.membershipEnabled,
  '会员计划状态必须持久化'
);

assert.ok(
  dashboard.stats
    .members >
    0,
  '高满意熟客必须能够沉淀为会员'
);

assert.ok(
  dashboard.dailyHistory
    .length >
    0,
  '必须保留近期顾客经营历史'
);

const state =
  customerLifecycle
    .ensureShop(
      shop.id
    );

const rows =
  Object.values(
    state.profiles
  );

assert.ok(
  rows.length >
    0,
  '顾客档案必须持久存在'
);

rows[0].lastVisitDay =
  1;

rows[0].repeatProbability =
  0.2;

rows[0].churned =
  false;

customerLifecycle
  .ageProfiles(
    state,
    80
  );

assert.equal(
  rows[0].churned,
  true,
  '长期不回店且低复购概率的顾客必须流失'
);

const restaurantSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/operations/restaurantSimulationV081.js'
    ),
    'utf8'
  );

assert.ok(
  restaurantSource.includes(
    "require('./customerLifecycleV089.js')"
  ) &&
  restaurantSource.includes(
    'customerFactor'
  ) &&
  restaurantSource.includes(
    '.onDayClosed('
  ),
  '顾客长期系统必须接入真实客流和每日结算'
);

const businessSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/scenes/businessScene.js'
    ),
    'utf8'
  );

assert.ok(
  businessSource.includes(
    "id:'customer'"
  ) &&
  businessSource.includes(
    'renderCustomers'
  ) &&
  businessSource.includes(
    'customer:membership'
  ),
  '经营管理必须提供真实顾客管理页'
);

const pkg =
  JSON.parse(
    fs.readFileSync(
      path.join(
        ROOT,
        'package.json'
      ),
      'utf8'
    )
  );

assert.ok(
  !/scripts\/apply-v\d+/i.test(
    pkg.scripts.pretest ||
    ''
  ),
  '正式pretest不能保留一次性安装脚本'
);

assert.ok(
  !fs.existsSync(
    path.join(
      ROOT,
      'scripts/apply-v089-customer-lifecycle.js'
    )
  ),
  '正式树不能保留V0.8.9安装脚本'
);

console.log(
  'V0.8.9 customer lifecycle tests passed'
);
