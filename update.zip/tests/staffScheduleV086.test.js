'use strict';

const assert =
  require('assert');

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const gameState =
  require('../src/core/gameState.js');

const scheduleSystem =
  require('../src/world/staffScheduleSystemV086.js');

gameState.reset();

gameState
  .getBusiness()
  .shops = [
    {
      id:'shop_v086_schedule',
      name:'排班测试店',
      status:'trial_opening',
      districtId:'university',
      seatEstimate:44
    }
  ];

gameState
  .getBusiness()
  .hasShop =
  true;

gameState
  .getBusiness()
  .currentShopId =
  'shop_v086_schedule';

gameState
  .getOpeningPrep()
  .staffing
  .shop_v086_schedule = {
    candidateDay:null,
    candidates:[],
    hired:[
      {
        id:'manager_1',
        name:'周安',
        roleId:'manager',
        wage:7200
      },
      {
        id:'chef_1',
        name:'李文',
        roleId:'chef',
        wage:6800
      },
      {
        id:'server_1',
        name:'陈宁',
        roleId:'server',
        wage:4200
      },
      {
        id:'server_2',
        name:'林佳',
        roleId:'server',
        wage:4200
      },
      {
        id:'cashier_1',
        name:'王晓',
        roleId:'cashier',
        wage:4300
      }
    ]
  };

const initial =
  scheduleSystem
    .getDashboard(
      'shop_v086_schedule',
      {
        hour:11,
        minute:30
      }
    );

assert.ok(
  initial,
  '必须生成排班面板'
);

assert.strictEqual(
  initial.hours.label,
  '06:00–23:00',
  '老存档必须保持默认营业时间'
);

assert.strictEqual(
  initial.staff.length,
  5,
  '必须接管已有员工'
);

assert.ok(
  initial.staff.every(
    row =>
      scheduleSystem
        .SHIFT_DEFS
        .some(
          shift =>
            shift.id ===
            row.shiftId
        )
  ),
  '老员工必须自动获得有效班次'
);

const night =
  scheduleSystem
    .setBusinessHoursPreset(
      'shop_v086_schedule',
      'night'
    );

assert.ok(
  night.ok,
  '必须能切换夜宵营业时间'
);

assert.ok(
  scheduleSystem
    .isOpen(
      gameState
        .getBusiness()
        .shops[0],
      {
        hour:1,
        minute:0
      }
    ),
  '跨午夜营业凌晨1点必须营业'
);

assert.ok(
  !scheduleSystem
    .isOpen(
      gameState
        .getBusiness()
        .shops[0],
      {
        hour:5,
        minute:0
      }
    ),
  '凌晨5点必须已打烊'
);

assert.ok(
  scheduleSystem
    .setStaffShift(
      'shop_v086_schedule',
      'chef_1',
      'night'
    ).ok,
  '必须支持员工换班'
);

const oneAM =
  scheduleSystem
    .getCoverage(
      'shop_v086_schedule',
      {
        hour:1,
        minute:0
      }
    );

assert.ok(
  oneAM.activeStaff >=
  1,
  '夜班员工凌晨必须真实在岗'
);

assert.ok(
  oneAM.coverageMultiplier >=
    0.35 &&
  oneAM.coverageMultiplier <=
    1.08,
  '排班产能必须保持安全边界'
);

const businessSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/scenes/businessScene.js'
    ),
    'utf8'
  );

assert.ok(
  businessSource.includes(
    'V086_BUSINESS_SCHEDULE'
  ) &&
  businessSource.includes(
    "id:'schedule'"
  ) &&
  businessSource.includes(
    'renderSchedule'
  ) &&
  businessSource.includes(
    'shiftstaff:'
  ),
  '经营管理中心必须接入可操作排班页'
);

const simulationSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/operations/restaurantSimulationV081.js'
    ),
    'utf8'
  );

assert.ok(
  simulationSource.includes(
    'V086_STAFF_SCHEDULE'
  ) &&
  simulationSource.includes(
    'staffScheduleSystem'
  ) &&
  simulationSource.includes(
    'coverageMultiplier'
  ),
  '真实经营模拟必须接入当前班次产能'
);

assert.ok(
  fs.existsSync(
    path.join(
      ROOT,
      'tests/businessLifecycleV086.test.js'
    )
  ),
  '必须保留已落库的完整经营闭环系统'
);

console.log(
  'V0.8.6 schedule compatibility tests passed'
);
