'use strict';

const assert = require('assert');
const pacing = require('../src/core/framePacing.js');

(function testDeltaClamp() {
  assert.strictEqual(pacing.clampFrameDelta(16), 16);
  assert.strictEqual(pacing.clampFrameDelta(5000), 100);
  assert.strictEqual(pacing.clampFrameDelta(-1), 0);
})();

(function testHighSpeedUsesLowerUiRate() {
  const one = pacing.getRenderIntervalMs(1, false, false);
  const two = pacing.getRenderIntervalMs(2, false, false);
  const five = pacing.getRenderIntervalMs(5, false, false);
  const ten = pacing.getRenderIntervalMs(10, false, false);
  assert(one < two);
  assert(two <= five);
  assert(five <= ten);
  assert(ten >= 50);
})();

(function testAnimationStaysSmooth() {
  const normal = pacing.getRenderIntervalMs(10, false, false);
  const animated = pacing.getRenderIntervalMs(10, false, true);
  assert(animated < normal);
})();

(function testForceRender() {
  assert.strictEqual(pacing.shouldRender(0, 10, false, false, true), true);
})();

console.log('V0.9.2 render pacing self-test PASS');
