'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

const store = fs.readFileSync(
  path.join(ROOT, 'src/scenes/storeScene.js'),
  'utf8'
);

const androidTest = fs.readFileSync(
  path.join(ROOT, 'tests/v21AndroidBundle.test.js'),
  'utf8'
);

assert.ok(
  store.includes(
    ".loadGroup(\n        'store'"
  ) ||
  store.includes(
    ".loadGroup(\n          'store'"
  ),
  'V36.1必须兼容旧visualAssets门店资源加载检查'
);

assert.ok(
  store.includes('V36_STORE_THREE_STATE_PHASE1'),
  'V36三状态门店页不能丢'
);

assert.ok(
  androidTest.includes('attempt <= 3') &&
  androidTest.includes("typeof result.status === 'number'"),
  'V21 Android bundle测试必须只对status=null做有限重试'
);

console.log(
  'V36.1 legacy compatibility tests passed'
);
