餐饮项目代码清理机器人（旧版本一起清理）

用途：
1. 将 fooV081.js / foo-v0.8.1.js / foo-final.js 这类版本化源码归并成 foo.js。
2. 自动改写项目内对旧文件名的引用。
3. 删除已被新版本替代的旧源码、旧修复脚本、迁移脚本、备份、临时文件、update.zip 等残留。
4. 不删除 package.json、android/entry.js、主更新工作流、主 APK 工作流。
5. 清理后自动执行 JavaScript 语法检查、npm test、npm run build:android-js。
6. 任一验证失败，会恢复本轮隔离的文件并退出失败，避免把清坏的代码提交进 main。
7. 生成 cleanup-report.json，记录本次归并、删除、保留和验证结果。

推荐用法（适配你现有 Apply Update ZIP 工作流）：
- 将本压缩包中的 scripts/ 目录内容作为 update.zip 上传到仓库根目录。
- 现有工作流会执行 scripts/apply-update-patch.js。
- 安装脚本会自动把 cleanup:scan / cleanup:apply 写入 package.json，并立即执行一次清理。
- 随后的 npm test、Android JS 构建、APK 构建继续作为最终验收。

之后手动扫描： npm run cleanup:scan
之后正式清理： npm run cleanup:apply

注意：
- Git 提交历史仍保留旧版本，主工程目录不再保留旧版本文件。
- .github/workflows 下的历史工作流如果当前 Apply Update 工作流设置了保护恢复，将不会由 update.zip 修改；这部分应在 GitHub 仓库中单独删除。
