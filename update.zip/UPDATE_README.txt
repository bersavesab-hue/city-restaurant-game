餐饮经营中枢一次性整合包 V1.0.5

使用方式：
1. 将本压缩包重命名为 update.zip（已另提供同名版本时无需重命名）。
2. 上传到当前餐饮项目 GitHub 仓库根目录。
3. 现有 Apply Update ZIP 工作流会自动解包、执行 scripts/apply-update-patch.js、自检、npm test、打包 Android JS、构建 APK。
4. 不要手工拆包覆盖 package.json，也不要修改 workflow。

本包包含：事件/强制弹窗/事件队列/冷却/事件链/历史/存档、消息中心、金融、日周月结算、客流漏斗、员工健康、菜品改良接口、评分、排行、奖项、经营引导、需求联动、自检与幂等安装。
