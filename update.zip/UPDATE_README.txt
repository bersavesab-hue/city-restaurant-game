城市餐饮经营系统 V1.0.8 自适应修正版

本版针对 V1.0.5 / V1.0.6 连续失败重做安装方式：
1. 不再写死 android/entry.js、src/core、src/city 路径。
2. 读取仓库 package.json 的真实 build:android-js 命令自动发现入口。
3. 自动发现 gameState / timeSystem / demandSystem，并生成 bootstrap 接线。
4. 清理仅属于本经营补丁 V1.0.5~V1.0.7 的旧接线/旧文件。
5. 自动把功能测试+运行时冒烟+接线审计接入 npm test。
6. Android build 前再次运行接线审计。
7. 安装后生成 scripts/operating-v108-paths.json，记录真实发现路径。
8. 已测试连续安装两次后仓库文件哈希完全一致。

更新包本身不包含 package.json，也不包含 .github/workflows。
package.json 只由 scripts/apply-update-patch.js 在工作流内增量修改。
