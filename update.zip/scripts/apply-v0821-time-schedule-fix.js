'use strict';

const fs =
  require('fs');

const path =
  require('path');

const childProcess =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const CONFIG =
  path.join(
    ROOT,
    'src/core/simulationConfig.js'
  );

const TIME =
  path.join(
    ROOT,
    'src/core/timeSystem.js'
  );

const STATE =
  path.join(
    ROOT,
    'src/core/gameState.js'
  );

const MAIN =
  path.join(
    ROOT,
    'src/main.js'
  );

const RENOVATION =
  path.join(
    ROOT,
    'src/renovation/renovationSystem.js'
  );

const RENOVATION_SCENE =
  path.join(
    ROOT,
    'src/scenes/renovationScene.js'
  );

const STORE_SCENE =
  path.join(
    ROOT,
    'src/scenes/storeScene.js'
  );

const RESTAURANT =
  path.join(
    ROOT,
    'src/operations/restaurantSimulationV081.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.21] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function replaceRequired(
  source,
  before,
  after,
  expected,
  label
) {
  let count =
    0;

  let cursor =
    0;

  while (
    true
  ) {
    const index =
      source.indexOf(
        before,
        cursor
      );

    if (
      index <
      0
    ) {
      break;
    }

    source =
      source.slice(
        0,
        index
      ) +
      after +
      source.slice(
        index +
        before.length
      );

    cursor =
      index +
      after.length;

    count +=
      1;
  }

  if (
    count !==
    expected
  ) {
    throw new Error(
      '[V0.8.21] ' +
      label +
      ' 替换数量异常：' +
      count +
      '，预期 ' +
      expected
    );
  }

  return source;
}

function syntaxCheck(
  file
) {
  childProcess
    .execFileSync(
      process.execPath,
      [
        '--check',
        file
      ],
      {
        cwd:ROOT,
        stdio:'inherit'
      }
    );
}

function patchConfig() {
  let source =
    fs.readFileSync(
      CONFIG,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`    allowedSpeeds: [
      1,
      2,
      5,
      10
    ]`,
`    allowedSpeeds: [
      1,
      5,
      20,
      100
    ],

    // 避免应用恢复或掉帧时一次吞掉过长真实时间。
    maxRealDeltaMs: 250,

    // 高倍速按最多30游戏分钟一段推进，
    // 让客流、餐期、日结和长期日程看到正确的中间时间。
    maxSimulationChunkMinutes: 30`,
      '时间倍率配置'
    );

  fs.writeFileSync(
    CONFIG,
    source,
    'utf8'
  );
}

function patchState() {
  let source =
    fs.readFileSync(
      STATE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`  getTimeSpeed() {
    const speed =
      Number(
        this.data.time.speed
      );

    return speed || 1;
  }`,
`  getTimeSpeed() {
    const config =
      require('./simulationConfig.js');

    const allowed =
      config.time
        .allowedSpeeds;

    const raw =
      Number(
        this.data.time.speed
      ) ||
      1;

    if (
      allowed.indexOf(
        raw
      ) >= 0
    ) {
      return raw;
    }

    let migrated =
      allowed[0];

    for (
      const value
      of allowed
    ) {
      if (
        Math.abs(
          value -
          raw
        ) <
        Math.abs(
          migrated -
          raw
        )
      ) {
        migrated =
          value;
      }
    }

    this.data.time.speed =
      migrated;

    return migrated;
  }`,
      '旧存档倍率迁移'
    );

  fs.writeFileSync(
    STATE,
    source,
    'utf8'
  );
}

function patchTime() {
  let source =
    fs.readFileSync(
      TIME,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`  update(deltaMs) {`,
`  update(
    deltaMs,
    onStep
  ) {`,
      '时间更新回调签名'
    );

  source =
    replaceOnce(
      source,
`    delta =
      Math.min(
        delta,
        1000
      );`,
`    delta =
      Math.min(
        delta,
        Number(
          simulationConfig
            .time
            .maxRealDeltaMs
        ) ||
        250
      );`,
      '单帧时间上限'
    );

  source =
    replaceOnce(
      source,
`    this.addMinutes(
      wholeMinutes
    );

    return wholeMinutes;`,
`    const callback =
      typeof onStep ===
        'function'
        ? onStep
        : null;

    if (!callback) {
      this.addMinutes(
        wholeMinutes
      );

      return wholeMinutes;
    }

    const maxChunk =
      Math.max(
        1,
        Math.floor(
          Number(
            simulationConfig
              .time
              .maxSimulationChunkMinutes
          ) ||
          30
        )
      );

    let remaining =
      wholeMinutes;

    while (
      remaining >
      0
    ) {
      const step =
        Math.min(
          maxChunk,
          remaining
        );

      this.addMinutes(
        step
      );

      callback(
        step
      );

      remaining -=
        step;
    }

    return wholeMinutes;`,
      '高倍速分段推进'
    );

  fs.writeFileSync(
    TIME,
    source,
    'utf8'
  );
}

function patchRenovation() {
  let source =
    fs.readFileSync(
      RENOVATION,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`    const currentDay =
      simulationSystem
        .getDayOrdinal(
          gameState
            .getTime()
        );

    plan.status =
      'constructing';

    plan.construction = {
      contractor:
        clone(quote),
      startDay:
        currentDay,
      finishDay:
        currentDay +
        quote.days,
      paid:
        quote.price,
      snapshot:
        clone(metrics)
    };`,
`    const currentTime =
      gameState
        .getTime();

    const currentDay =
      simulationSystem
        .getDayOrdinal(
          currentTime
        );

    const startMinute =
      currentDay *
        1440 +
      Number(
        currentTime.hour ||
        0
      ) *
        60 +
      Number(
        currentTime.minute ||
        0
      );

    plan.status =
      'constructing';

    plan.construction = {
      contractor:
        clone(quote),
      startDay:
        currentDay,
      finishDay:
        currentDay +
        quote.days,
      startMinute,
      finishMinute:
        startMinute +
        quote.days *
          1440,
      paid:
        quote.price,
      snapshot:
        clone(metrics)
    };`,
      '装修分钟级开始结束时间'
    );

  source =
    replaceOnce(
      source,
`  updateShop(
    shopId
  ) {
    const shop =`,
`  getConstructionProgress(
    shopId
  ) {
    const plan =
      this.ensurePlan(
        shopId
      );

    if (
      !plan ||
      !plan.construction
    ) {
      return {
        status:
          plan
            ? plan.status
            : 'draft',
        progress:
          plan &&
          plan.status ===
            'completed'
            ? 1
            : 0,
        elapsedMinutes:0,
        totalMinutes:0,
        remainingMinutes:0,
        startMinute:null,
        finishMinute:null
      };
    }

    const time =
      gameState
        .getTime();

    const currentMinute =
      simulationSystem
        .getDayOrdinal(
          time
        ) *
        1440 +
      Number(
        time.hour ||
        0
      ) *
        60 +
      Number(
        time.minute ||
        0
      );

    const legacyStart =
      Number(
        plan
          .construction
          .startDay
      ) *
      1440;

    const legacyFinish =
      Number(
        plan
          .construction
          .finishDay
      ) *
      1440;

    const startMinute =
      Number.isFinite(
        Number(
          plan
            .construction
            .startMinute
        )
      )
        ? Number(
            plan
              .construction
              .startMinute
          )
        : legacyStart;

    const finishMinute =
      Number.isFinite(
        Number(
          plan
            .construction
            .finishMinute
        )
      )
        ? Number(
            plan
              .construction
              .finishMinute
          )
        : legacyFinish;

    const totalMinutes =
      Math.max(
        1,
        finishMinute -
        startMinute
      );

    const elapsedMinutes =
      Math.max(
        0,
        Math.min(
          totalMinutes,
          currentMinute -
          startMinute
        )
      );

    const progress =
      plan.status ===
        'completed'
        ? 1
        : Math.max(
            0,
            Math.min(
              1,
              elapsedMinutes /
              totalMinutes
            )
          );

    return {
      status:
        plan.status,
      progress,
      elapsedMinutes,
      totalMinutes,
      remainingMinutes:
        Math.max(
          0,
          finishMinute -
          currentMinute
        ),
      startMinute,
      finishMinute,
      startDay:
        plan
          .construction
          .startDay,
      finishDay:
        plan
          .construction
          .finishDay
    };
  }

  updateShop(
    shopId
  ) {
    const shop =`,
      '装修真实进度接口'
    );

  const oldCheck =
`    const currentDay =
      simulationSystem
        .getDayOrdinal(
          gameState
            .getTime()
        );

    if (
      currentDay <
      plan
        .construction
        .finishDay
    ) {
      return false;
    }`;

  const newCheck =
`    const progress =
      this.getConstructionProgress(
        shopId
      );

    if (
      progress.progress <
      1
    ) {
      return false;
    }`;

  source =
    replaceOnce(
      source,
      oldCheck,
      newCheck,
      '装修完工分钟级判断'
    );

  fs.writeFileSync(
    RENOVATION,
    source,
    'utf8'
  );
}

function patchRenovationScene() {
  let source =
    fs.readFileSync(
      RENOVATION_SCENE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`    const construction =
      plan.construction;

    ui.card(`,
`    const construction =
      plan.construction;

    const progressInfo =
      renovationSystem
        .getConstructionProgress(
          shop.id
        );

    const progress =
      plan.status ===
        'completed'
        ? 1
        : progressInfo
            .progress;

    ui.card(`,
      '装修页读取真实进度'
    );

  source =
    replaceOnce(
      source,
`      plan.status ===
        'completed'
        ? 308
        : 174,`,
`      Math.max(
        8,
        308 *
        progress
      ),`,
      '装修页真实进度条'
    );

  source =
    replaceOnce(
      source,
`      plan.status ===
        'completed'
        ? '可以返回门店继续筹备开业'
        : '施工期间仍可查看进度，完工后自动进入下一阶段',`,
`      plan.status ===
        'completed'
        ? '可以返回门店继续筹备开业'
        : (
            '实际进度 ' +
            Math.round(
              progress *
              100
            ) +
            '% · 剩余约' +
            Math.ceil(
              progressInfo
                .remainingMinutes /
              60
            ) +
            '小时'
          ),`,
      '装修页真实剩余时间'
    );

  fs.writeFileSync(
    RENOVATION_SCENE,
    source,
    'utf8'
  );
}

function patchStoreScene() {
  let source =
    fs.readFileSync(
      STORE_SCENE,
      'utf8'
    );

  const start =
    source.indexOf(
`  getRenovationProgress(shopId) {`
    );

  const end =
    source.indexOf(
`  getPreparationState(shop) {`,
      start
    );

  if (
    start <
      0 ||
    end <
      0
  ) {
    throw new Error(
      '[V0.8.21] 找不到门店装修进度方法'
    );
  }

  source =
    source.slice(
      0,
      start
    ) +
`  getRenovationProgress(shopId) {
    const progress =
      renovationSystem
        .getConstructionProgress(
          shopId
        );

    return clamp(
      Number(
        progress.progress
      ) ||
      0,
      0,
      1
    );
  }

` +
    source.slice(
      end
    );

  fs.writeFileSync(
    STORE_SCENE,
    source,
    'utf8'
  );
}

function patchRestaurant() {
  let source =
    fs.readFileSync(
      RESTAURANT,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`  arrivals =
    Math.min(
      arrivals,
      18
    );`,
`  const arrivalBatchLimit =
    Math.max(
      18,
      Math.min(
        120,
        Math.ceil(
          Math.max(
            1,
            advancedMinutes
          ) *
          3
        )
      )
    );

  arrivals =
    Math.min(
      arrivals,
      arrivalBatchLimit
    );`,
      '高倍速客流批量上限'
    );

  fs.writeFileSync(
    RESTAURANT,
    source,
    'utf8'
  );
}

function patchMain() {
  let source =
    fs.readFileSync(
      MAIN,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const openingPrepSystem =
  require('./opening/openingPrepSystem.js');`,
`const openingPrepSystem =
  require('./opening/openingPrepSystem.js');

const globalTimeline =
  require('./core/globalTimelineV0821.js');`,
      '全局日程系统require'
    );

  const multilineOld =
`  const speedItems = [
    [
      'time:pause',
      timeSystem
        .isPaused()
        ? '▶'
        : 'Ⅱ'
    ],
    [
      'time:speed:1',
      '1×'
    ],
    [
      'time:speed:2',
      '2×'
    ],
    [
      'time:speed:5',
      '5×'
    ],
    [
      'time:speed:10',
      '10×'
    ]
  ];`;

  const multilineNew =
`  const speedItems = [
    [
      'time:pause',
      timeSystem
        .isPaused()
        ? '▶'
        : 'Ⅱ'
    ],
    [
      'time:speed:1',
      '1×'
    ],
    [
      'time:speed:5',
      '5×'
    ],
    [
      'time:speed:20',
      '20×'
    ],
    [
      'time:speed:100',
      '100×'
    ]
  ];`;

  source =
    replaceRequired(
      source,
      multilineOld,
      multilineNew,
      1,
      '主时间倍率按钮'
    );

  const compactOld =
`  const speedItems = [
    ['time:pause', 'Ⅱ'],
    ['time:speed:1', '1x'],
    ['time:speed:2', '2x'],
    ['time:speed:5', '5x'],
    ['time:speed:10', '10x']
  ];`;

  const compactNew =
`  const speedItems = [
    ['time:pause', 'Ⅱ'],
    ['time:speed:1', '1x'],
    ['time:speed:5', '5x'],
    ['time:speed:20', '20x'],
    ['time:speed:100', '100x']
  ];`;

  source =
    replaceRequired(
      source,
      compactOld,
      compactNew,
      1,
      '备用时间倍率按钮'
    );

  const loopOld =
`  const advancedMinutes =
    timeSystem
      .update(
        deltaMs
      );

  const simulationChanged =
    advancedMinutes >
      0
      ? simulationSystem
          .update(
            advancedMinutes
          )
      : false;

  const restaurantChanged =
    advancedMinutes >
      0
      ? restaurantSimulation
          .update(
            advancedMinutes
          )
      : false;

  if (
    simulationChanged ||
    restaurantChanged
  ) {
    saveSystem
      .autoSave();
  }

  if (
    advancedMinutes >
      0 ||
    simulationChanged ||
    restaurantChanged ||
    animationChanged ||
    needsResize
  ) {
    render();
  }`;

  const loopNew =
`  let simulationChanged =
    false;

  let timelineChanged =
    false;

  let restaurantChanged =
    false;

  const advancedMinutes =
    timeSystem
      .update(
        deltaMs,
        function (
          stepMinutes
        ) {
          if (
            simulationSystem
              .update(
                stepMinutes
              )
          ) {
            simulationChanged =
              true;
          }

          if (
            globalTimeline
              .update(
                stepMinutes
              )
          ) {
            timelineChanged =
              true;
          }

          if (
            restaurantSimulation
              .update(
                stepMinutes
              )
          ) {
            restaurantChanged =
              true;
          }
        }
      );

  if (
    simulationChanged ||
    timelineChanged ||
    restaurantChanged
  ) {
    saveSystem
      .autoSave();
  }

  if (
    advancedMinutes >
      0 ||
    simulationChanged ||
    timelineChanged ||
    restaurantChanged ||
    animationChanged ||
    needsResize
  ) {
    render();
  }`;

  source =
    replaceOnce(
      source,
      loopOld,
      loopNew,
      '高倍速分段主循环'
    );

  fs.writeFileSync(
    MAIN,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/timeScheduleV0821.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/liveRestaurantV082.test.js',
    'tests/v60CleanBase.test.js'`,
`    'tests/liveRestaurantV082.test.js',
    'tests/timeScheduleV0821.test.js',
    'tests/v60CleanBase.test.js'`,
        '时间日程测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function cleanupStrayWorkflow() {
  const stray =
    path.join(
      ROOT,
      'apply-update.yml'
    );

  if (
    fs.existsSync(
      stray
    )
  ) {
    fs.unlinkSync(
      stray
    );

    console.log(
      '[V0.8.21] 已清理根目录误上传 apply-update.yml'
    );
  }
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.21';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchConfig();
  patchState();
  patchTime();
  patchRenovation();
  patchRenovationScene();
  patchStoreScene();
  patchRestaurant();
  patchMain();
  patchRunner();
  cleanupStrayWorkflow();
  finalizePackage();

  for (
    const file
    of [
      CONFIG,
      TIME,
      STATE,
      MAIN,
      RENOVATION,
      RENOVATION_SCENE,
      STORE_SCENE,
      RESTAURANT,
      path.join(
        ROOT,
        'src/core/globalTimelineV0821.js'
      )
    ]
  ) {
    syntaxCheck(
      file
    );
  }

  console.log(
    '[V0.8.21] 时间倍率与全局装修日程修复完成'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
