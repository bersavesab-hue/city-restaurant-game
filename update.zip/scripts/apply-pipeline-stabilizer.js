'use strict';

const fs = require('fs');
const path = require('path');

const pkgPath = path.resolve('package.json');
const workflowPath = path.resolve('.github/workflows/apply-update.yml');

const originalPretest = "node tests/updateInfrastructureV089.test.js && node tests/staffWorkloadV089.test.js && node tests/updateInfrastructureV088.test.js && node tests/staffCareerV088.test.js && node tests/operationsScheduleV087.test.js && node tests/businessLifecycleV086.test.js && node tests/managementCenterV085.test.js && node tests/liveWorldV084.test.js && node tests/foundationFixesV083.test.js && node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js";
const workflow = "name: Apply Update ZIP\n\non:\n  push:\n    branches:\n      - main\n    paths:\n      - update.zip\n  workflow_dispatch:\n\npermissions:\n  contents: write\n\nconcurrency:\n  group: city-restaurant-one-click-update\n  cancel-in-progress: false\n\njobs:\n  apply-test-build:\n    runs-on: ubuntu-latest\n\n    steps:\n      - name: Checkout repository\n        uses: actions/checkout@v4\n        with:\n          ref: main\n          fetch-depth: 0\n\n      - name: Check update package\n        id: pkg\n        shell: bash\n        run: |\n          set -euo pipefail\n\n          if [ ! -f update.zip ]; then\n            echo \"has_update=false\" >> \"$GITHUB_OUTPUT\"\n            echo \"update.zip is absent; nothing to apply.\"\n            exit 0\n          fi\n\n          echo \"has_update=true\" >> \"$GITHUB_OUTPUT\"\n          entries=\"$(unzip -Z1 update.zip)\"\n\n          if grep -Eq '(^/|(^|/)\\.\\.(/|$)|^\\.git/)' <<< \"$entries\"; then\n            echo \"Unsafe path found in update.zip\"\n            exit 1\n          fi\n\n          if grep -Eq '^(\\.github/|package\\.json$|package-lock\\.json$|scripts/run-ci-tests-v060\\.js$|scripts/v60-audit\\.js$)' <<< \"$entries\"; then\n            echo \"Protected control file found in update.zip.\"\n            echo \"Use scripts/apply-update-patch.js for version/test-runner changes.\"\n            exit 1\n          fi\n\n      - name: Apply update to workspace\n        if: steps.pkg.outputs.has_update == 'true'\n        shell: bash\n        run: |\n          set -euo pipefail\n          unzip -o update.zip -x '.git/*'\n\n      - name: Setup Node.js\n        if: steps.pkg.outputs.has_update == 'true'\n        uses: actions/setup-node@v4\n        with:\n          node-version: 20\n\n      - name: Apply incremental patch script\n        if: steps.pkg.outputs.has_update == 'true'\n        shell: bash\n        run: |\n          set -euo pipefail\n\n          if [ -f scripts/apply-update-patch.js ]; then\n            node scripts/apply-update-patch.js\n            rm -f scripts/apply-update-patch.js\n          else\n            echo \"No incremental patch script supplied; continuing with file-only update.\"\n          fi\n\n          node -e \"JSON.parse(require('fs').readFileSync('package.json','utf8')); console.log('package.json JSON PASS')\"\n\n      - name: Install JavaScript dependencies\n        if: steps.pkg.outputs.has_update == 'true'\n        run: npm install\n\n      - name: Run all game tests\n        if: steps.pkg.outputs.has_update == 'true'\n        run: npm test\n\n      - name: Build Android game JavaScript\n        if: steps.pkg.outputs.has_update == 'true'\n        run: npm run build:android-js\n\n      - name: Copy game image assets\n        if: steps.pkg.outputs.has_update == 'true'\n        shell: bash\n        run: |\n          set -euo pipefail\n          mkdir -p android/app/src/main/assets/assets\n\n          if [ -d \"assets\" ]; then\n            rm -rf android/app/src/main/assets/assets/*\n            cp -R assets/. android/app/src/main/assets/assets/\n          fi\n\n      - name: Setup Java 17\n        if: steps.pkg.outputs.has_update == 'true'\n        uses: actions/setup-java@v4\n        with:\n          distribution: temurin\n          java-version: 17\n\n      - name: Setup Android SDK\n        if: steps.pkg.outputs.has_update == 'true'\n        uses: android-actions/setup-android@v3\n\n      - name: Install Android 34\n        if: steps.pkg.outputs.has_update == 'true'\n        shell: bash\n        run: |\n          set -euo pipefail\n          sdkmanager \"platforms;android-34\"\n          sdkmanager \"build-tools;34.0.0\"\n\n      - name: Setup Gradle\n        if: steps.pkg.outputs.has_update == 'true'\n        uses: gradle/actions/setup-gradle@v4\n        with:\n          gradle-version: \"8.7\"\n\n      - name: Build debug APK\n        if: steps.pkg.outputs.has_update == 'true'\n        run: gradle -p android assembleDebug --no-daemon\n\n      - name: Remove update package before commit\n        if: steps.pkg.outputs.has_update == 'true'\n        shell: bash\n        run: |\n          set -euo pipefail\n          rm -f update.zip\n\n      - name: Commit validated update\n        if: steps.pkg.outputs.has_update == 'true'\n        shell: bash\n        run: |\n          set -euo pipefail\n\n          git config user.name \"github-actions[bot]\"\n          git config user.email \"41898282+github-actions[bot]@users.noreply.github.com\"\n\n          git add -A\n\n          if git diff --cached --quiet; then\n            echo \"No file changes to commit.\"\n            exit 0\n          fi\n\n          git commit -m \"Apply validated one-click update\"\n          git push origin main\n\n      - name: Upload APK artifact\n        if: steps.pkg.outputs.has_update == 'true'\n        uses: actions/upload-artifact@v4\n        with:\n          name: city-restaurant-debug-apk\n          path: android/app/build/outputs/apk/debug/app-debug.apk\n          retention-days: 30\n";

const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

if (String(pkg.version) !== '0.8.9') {
  throw new Error(
    'Pipeline stabilizer refused: expected repository version 0.8.9, got ' +
    String(pkg.version)
  );
}

if (!pkg.scripts || typeof pkg.scripts !== 'object') {
  throw new Error('Pipeline stabilizer refused: package scripts missing.');
}

pkg.scripts.pretest = originalPretest;
fs.writeFileSync(
  pkgPath,
  JSON.stringify(pkg, null, 2) + '\n',
  'utf8'
);

fs.mkdirSync(path.dirname(workflowPath), { recursive: true });
fs.writeFileSync(workflowPath, workflow, 'utf8');

try {
  fs.unlinkSync(__filename);
} catch (error) {
  // GitHub Actions can still remove it later; do not fail the patch for cleanup.
}

console.log(
  '[pipeline-stabilizer] PASS: package restored to 0.8.9 and update workflow hardened'
);
