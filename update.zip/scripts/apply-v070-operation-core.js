'use strict';

const fs=require('fs');
const path=require('path');
const ROOT=path.resolve(__dirname,'..');
const PACKAGE=path.join(ROOT,'package.json');
const RUNNER=path.join(ROOT,'scripts/run-ci-tests-v060.js');

function patchRunner(){
  let source=fs.readFileSync(RUNNER,'utf8');
  if(source.includes('tests/operationCoreV070.test.js'))return;
  const anchor="'tests/v60CleanBase.test.js'";
  if(!source.includes(anchor))throw new Error('[V0.7.0] 找不到CI测试锚点');
  source=source.replace(anchor,"'tests/operationCoreV070.test.js',\n    "+anchor);
  fs.writeFileSync(RUNNER,source,'utf8');
}
function finalizePackage(){
  const pkg=JSON.parse(fs.readFileSync(PACKAGE,'utf8'));
  pkg.version='0.7.0';
  pkg.scripts=pkg.scripts||{};
  pkg.scripts.pretest='node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';
  fs.writeFileSync(PACKAGE,JSON.stringify(pkg,null,2)+'\n','utf8');
}
try{
  patchRunner();finalizePackage();
  console.log('[V0.7.0] 餐饮经营核心包已接入CI');
  try{fs.unlinkSync(__filename);}catch(e){}
}catch(e){console.error(e.stack||e);process.exit(1);}
