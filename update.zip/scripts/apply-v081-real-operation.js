'use strict';

const fs=require('fs');
const path=require('path');
const ROOT=path.resolve(__dirname,'..');

const MAIN=path.join(ROOT,'src/main.js');
const GAME_STATE=path.join(ROOT,'src/core/gameState.js');
const STORE=path.join(ROOT,'src/scenes/storeScene.js');
const ANDROID=path.join(ROOT,'android/entry.js');
const RUNNER=path.join(ROOT,'scripts/run-ci-tests-v060.js');
const PACKAGE=path.join(ROOT,'package.json');

function replaceOnce(source,before,after,label){
  if(source.includes(after)) return source;
  const index=source.indexOf(before);
  if(index<0) throw new Error('[V0.8.1] 找不到锚点：'+label);
  return source.slice(0,index)+after+source.slice(index+before.length);
}

function patchGameState(){
  let source=fs.readFileSync(GAME_STATE,'utf8');
  source=replaceOnce(source,
`    finance: {
      openingLoans: {}
    }
  },`,
`    finance: {
      openingLoans: {}
    },

    restaurantOperations: {
      version: '0.8.1',
      sharedSupplierNetwork: null,
      shops: {}
    }
  },`,
  'restaurantOperations默认状态');

  source=replaceOnce(source,
`  getSimulation() {`,
`  getRestaurantOperations() {
    const business =
      this.data.business;

    if (
      !business.restaurantOperations
    ) {
      business.restaurantOperations = {
        version: '0.8.1',
        sharedSupplierNetwork: null,
        shops: {}
      };
    }

    return business.restaurantOperations;
  }

  getSimulation() {`,
  'restaurantOperations getter');

  fs.writeFileSync(GAME_STATE,source,'utf8');
}

function patchMain(){
  let source=fs.readFileSync(MAIN,'utf8');

  source=replaceOnce(source,
`const timeSystem =
  require('./core/timeSystem.js');`,
`const timeSystem =
  require('./core/timeSystem.js');

const saveSystem =
  require('./core/saveSystem.js');

const restaurantSimulation =
  require('./operations/restaurantSimulationV081.js');`,
  '运行系统require');

  source=replaceOnce(source,
`  const simulationChanged =
    advancedMinutes >
      0
      ? simulationSystem
          .update(
            advancedMinutes
          )
      : false;`,
`  const simulationChanged =
    advancedMinutes >
      0
      ? simulationSystem
          .update(
            advancedMinutes
          )
      : false;

  const restaurantChanged =
    advancedMinutes >
      0
      ? restaurantSimulation
          .update(
            advancedMinutes
          )
      : false;

  if (
    simulationChanged ||
    restaurantChanged
  ) {
    saveSystem
      .autoSave();
  }`,
  '经营模拟接入主循环');

  source=source.replace(
`    simulationChanged ||
    animationChanged ||`,
`    simulationChanged ||
    restaurantChanged ||
    animationChanged ||`
  );

  source=replaceOnce(source,
`simulationSystem
  .initialize();

sceneManager
  .switchTo(
    'city'
  );`,
`const restoredFromSave =
  saveSystem.load();

simulationSystem
  .initialize();

if (
  !restoredFromSave
) {
  saveSystem.save();
}

if (
  api &&
  typeof api.onHide ===
    'function'
) {
  api.onHide(
    function () {
      saveSystem.save();
    }
  );
}

sceneManager
  .switchTo(
    'city'
  );`,
  '启动读档');

  source=source.replace(
    '城市餐饮经营小游戏 V35 顶部HUD精修版启动成功',
    '城市餐饮经营小游戏 V0.8.1 真实营业循环启动成功'
  );

  fs.writeFileSync(MAIN,source,'utf8');
}

function patchStore(){
  let source=fs.readFileSync(STORE,'utf8');

  source=replaceOnce(source,
`const openingFinanceSystem =
  require('../finance/openingFinanceSystem.js');`,
`const openingFinanceSystem =
  require('../finance/openingFinanceSystem.js');

const operationsStore =
  require('../operations/operationsStoreV080.js');`,
  'StoreScene经营状态require');

  const start=source.indexOf('  getOperatingSnapshot(shop) {');
  const end=source.indexOf('\n  getStoreImageKey(index) {',start);

  if(start<0||end<0){
    throw new Error('[V0.8.1] 找不到 getOperatingSnapshot 函数');
  }

  const replacement=`  getOperatingSnapshot(shop) {
    const state =
      this.getPreparationState(
        shop
      );

    const district =
      citySystem.getDistrict(
        shop.districtId
      );

    const seats =
      Math.max(
        6,
        Number(
          state.metrics
            ? state.metrics.totalSeats
            : shop.seatEstimate
        ) || 30
      );

    const dashboard =
      operationsStore
        .dashboard(
          shop.id
        );

    const finance =
      dashboard &&
      dashboard.finance
        ? dashboard.finance
        : {
            revenue: 0,
            profit: 0,
            orders: 0,
            customers: 0,
            avgTicket: 0
          };

    const runtime =
      operationsStore
        .getRuntime(
          shop.id
        );

    const customers =
      Number(
        finance.customers
      ) ||
      Number(
        runtime &&
        runtime.simulation &&
        runtime.simulation.todayCustomers
      ) ||
      0;

    const revenue =
      Number(
        finance.revenue
      ) ||
      0;

    const profit =
      Number(
        finance.profit
      ) ||
      0;

    const rating =
      clamp(
        Number(
          dashboard &&
          dashboard.shopRating
        ) || 4,
        1,
        5
      );

    const turnover =
      customers /
      Math.max(
        1,
        seats
      );

    const staffCoverage =
      state.readiness &&
      state.readiness.staffing
        ? clamp(
            Number(
              state.readiness.staffing.coverage
            ) || 0,
            0,
            1.15
          )
        : 0.8;

    const avgSpend =
      Number(
        finance.avgTicket
      ) ||
      Math.max(
        0,
        customers > 0
          ? revenue / customers
          : 0
      );

    const openDay =
      Math.max(
        1,
        dayOrdinal() -
        (
          Number(
            shop.trialOpenedDay
          ) ||
          dayOrdinal()
        ) +
        1
      );

    return {
      state,
      district,
      seats,
      customers,
      revenue,
      profit,
      rating,
      turnover,
      openDay,
      staffCoverage,
      avgSpend,
      orders:
        Number(
          finance.orders
        ) || 0,
      foodCostRate:
        Number(
          finance.foodCostRate
        ) || 0,
      profitRate:
        Number(
          finance.profitRate
        ) || 0,
      realOperation:
        true
    };
  }
`;

  source=source.slice(0,start)+replacement+source.slice(end);

  fs.writeFileSync(STORE,source,'utf8');
}

function patchAndroid(){
  let source=fs.readFileSync(ANDROID,'utf8');
  if(!source.includes('onHide(callback)')){
    source=replaceOnce(source,
`  onTouchEnd(callback) {`,
`  onHide(callback) {
    if (
      typeof callback !==
      'function'
    ) {
      return;
    }

    window.addEventListener(
      'pagehide',
      callback
    );

    document.addEventListener(
      'visibilitychange',
      function () {
        if (
          document.hidden
        ) {
          callback();
        }
      }
    );
  },

  onTouchEnd(callback) {`,
    'Android onHide');
  }
  fs.writeFileSync(ANDROID,source,'utf8');
}

function patchRunner(){
  let source=fs.readFileSync(RUNNER,'utf8');
  if(!source.includes('tests/wiringStageV080.test.js')){
    source=replaceOnce(source,
`    'tests/operationCoreV070.test.js',`,
`    'tests/operationCoreV070.test.js',
    'tests/wiringStageV080.test.js',
    'tests/realOperationLoopV081.test.js',`,
    'V080/V081测试接入');
  }else if(!source.includes('tests/realOperationLoopV081.test.js')){
    source=source.replace(
      `'tests/wiringStageV080.test.js',`,
      `'tests/wiringStageV080.test.js',
    'tests/realOperationLoopV081.test.js',`
    );
  }
  fs.writeFileSync(RUNNER,source,'utf8');
}

function finalizePackage(){
  const pkg=JSON.parse(fs.readFileSync(PACKAGE,'utf8'));
  pkg.version='0.8.1';
  pkg.scripts=pkg.scripts||{};
  pkg.scripts.pretest='node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';
  fs.writeFileSync(PACKAGE,JSON.stringify(pkg,null,2)+'\n','utf8');
}

try{
  patchGameState();
  patchMain();
  patchStore();
  patchAndroid();
  patchRunner();
  finalizePackage();
  console.log('[V0.8.1] 真实营业循环已接入');
  try{fs.unlinkSync(__filename);}catch(e){}
}catch(e){
  console.error(e&&e.stack?e.stack:e);
  process.exit(1);
}
