'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const MAIN =
  path.join(
    ROOT,
    'src/main.js'
  );

const STORE =
  path.join(
    ROOT,
    'src/scenes/storeScene.js'
  );

const OPERATIONS =
  path.join(
    ROOT,
    'src/operations/operationsStoreV080.js'
  );

const SETTLEMENT =
  path.join(
    ROOT,
    'src/operations/settlementEngineV10.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.1] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function patchOperations() {
  let source =
    fs.readFileSync(
      OPERATIONS,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const gameState =
  require('../core/gameState.js');

const runtimeEngine =`,
`const gameState =
  require('../core/gameState.js');

const simulationSystem =
  require('../core/simulationSystem.js');

const runtimeEngine =`,
      'simulationSystem require'
    );

  const dayStart =
    source.indexOf(
      'function currentDay() {'
    );

  const dayEnd =
    source.indexOf(
      '\nfunction getRoot() {',
      dayStart
    );

  if (
    dayStart <
      0 ||
    dayEnd <
      0
  ) {
    throw new Error(
      '[V0.8.1] 找不到 currentDay'
    );
  }

  source =
    source.slice(
      0,
      dayStart
    ) +
`function currentDay() {
  return simulationSystem
    .getDayOrdinal(
      gameState.getTime()
    );
}

function normalizeLegacyCalendar(
  runtime
) {
  const expected =
    currentDay();

  const oldDay =
    Number(
      runtime.day
    ) ||
    expected;

  if (
    Math.abs(
      oldDay -
      expected
    ) <=
    90
  ) {
    return;
  }

  const delta =
    expected -
    oldDay;

  runtime.day =
    expected;

  if (
    runtime.inventory
  ) {
    runtime
      .inventory
      .day =
      (
        Number(
          runtime
            .inventory
            .day
        ) ||
        oldDay
      ) +
      delta;

    for (
      const lot
      of runtime
          .inventory
          .lots ||
        []
    ) {
      lot.receivedDay =
        (
          Number(
            lot.receivedDay
          ) ||
          oldDay
        ) +
        delta;

      lot.expiryDay =
        (
          Number(
            lot.expiryDay
          ) ||
          oldDay
        ) +
        delta;
    }
  }

  if (
    runtime.procurement &&
    Array.isArray(
      runtime
        .procurement
        .purchaseOrders
    )
  ) {
    for (
      const po
      of runtime
          .procurement
          .purchaseOrders
    ) {
      for (
        const key
        of [
          'orderedDay',
          'expectedDay',
          'receivedDay'
        ]
      ) {
        if (
          po[key] !=
          null
        ) {
          po[key] =
            Number(
              po[key]
            ) +
            delta;
        }
      }
    }
  }
}
` +
    source.slice(
      dayEnd + 1
    );

  source =
    source.replace(
      "version: '0.8.0',",
      "version: '0.8.1',"
    );

  source =
    source.replace(
`  root.version =
    '0.8.0';`,
`  root.version =
    '0.8.1';`
    );

  source =
    replaceOnce(
      source,
`    history:
      clone(
        runtime.history
      )
  };`,
`    history:
      clone(
        runtime.history
      ),

    simulation:
      clone(
        runtime.simulation ||
        {
          arrivalCarry: 0,
          lastRestockMinute: null,
          unpaidOperatingPayables: 0,
          todayOrders: 0,
          todayCustomers: 0
        }
      ),

    dailySnapshots:
      clone(
        runtime.dailySnapshots ||
        []
      )
  };`,
      'runtime snapshot扩展'
    );

  source =
    replaceOnce(
      source,
`        'campaigns',
        'customers',
        'history'
      ]`,
`        'campaigns',
        'customers',
        'history',
        'simulation',
        'dailySnapshots'
      ]`,
      'runtime恢复字段'
    );

  source =
    replaceOnce(
      source,
`  runtime.shop.id =
    shopId;`,
`  normalizeLegacyCalendar(
    runtime
  );

  if (
    !runtime.simulation
  ) {
    runtime.simulation = {
      arrivalCarry: 0,
      lastRestockMinute: null,
      unpaidOperatingPayables: 0,
      todayOrders: 0,
      todayCustomers: 0
    };
  }

  if (
    !Array.isArray(
      runtime.dailySnapshots
    )
  ) {
    runtime.dailySnapshots = [];
  }

  runtime.shop.id =
    shopId;`,
      'runtime 0.8.1初始化'
    );

  source =
    replaceOnce(
      source,
`    history:
      (
        runtime.history ||
        []
      ).slice(
        -8
      )
  };`,
`    history:
      (
        runtime.history ||
        []
      ).slice(
        -8
      ),

    simulation:
      clone(
        runtime.simulation ||
        {}
      ),

    lastDailySnapshot:
      runtime.dailySnapshots &&
      runtime.dailySnapshots.length
        ? clone(
            runtime.dailySnapshots[
              runtime.dailySnapshots.length - 1
            ]
          )
        : null
  };`,
      'dashboard经营游标'
    );

  fs.writeFileSync(
    OPERATIONS,
    source,
    'utf8'
  );
}

function patchSettlement() {
  let source =
    fs.readFileSync(
      SETTLEMENT,
      'utf8'
    );

  source =
    source.replace(
`function createLedger(){return {revenue:0,foodCost:0,labor:0,rent:0,utilities:0,platformFees:0,marketing:0,waste:0,refunds:0,orders:0,customers:0,entries:[]};}`,
`function createLedger(){return {revenue:0,foodCost:0,labor:0,rent:0,utilities:0,platformFees:0,packaging:0,marketing:0,waste:0,refunds:0,orders:0,customers:0,entries:[]};}`
  );

  source =
    source.replace(
`  ledger.revenue+=revenue;ledger.foodCost+=foodCost;ledger.platformFees+=platformFee;ledger.refunds+=refund;ledger.orders++;`,
`  ledger.revenue+=revenue;ledger.foodCost+=foodCost;ledger.platformFees+=platformFee;ledger.packaging=(Number(ledger.packaging)||0)+packaging;ledger.refunds+=refund;ledger.orders++;`
    );

  source =
    source.replace(
`  const cost=ledger.foodCost+ledger.labor+ledger.rent+ledger.utilities+ledger.platformFees+ledger.marketing+ledger.waste+ledger.refunds;`,
`  const cost=(Number(ledger.foodCost)||0)+(Number(ledger.labor)||0)+(Number(ledger.rent)||0)+(Number(ledger.utilities)||0)+(Number(ledger.platformFees)||0)+(Number(ledger.packaging)||0)+(Number(ledger.marketing)||0)+(Number(ledger.waste)||0)+(Number(ledger.refunds)||0);`
    );

  fs.writeFileSync(
    SETTLEMENT,
    source,
    'utf8'
  );
}

function patchMain() {
  let source =
    fs.readFileSync(
      MAIN,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const saveSystem =
  require('./core/saveSystem.js');

const sceneManager =`,
`const saveSystem =
  require('./core/saveSystem.js');

const restaurantSimulation =
  require('./operations/restaurantSimulationV081.js');

const sceneManager =`,
      'restaurantSimulation require'
    );

  source =
    replaceOnce(
      source,
`  const simulationChanged =
    advancedMinutes >
      0
      ? simulationSystem
          .update(
            advancedMinutes
          )
      : false;

  if (
    simulationChanged
  ) {
    saveSystem
      .autoSave();
  }

  if (
    advancedMinutes >
      0 ||
    simulationChanged ||
    animationChanged ||
    needsResize
  ) {`,
`  const simulationChanged =
    advancedMinutes >
      0
      ? simulationSystem
          .update(
            advancedMinutes
          )
      : false;

  const restaurantChanged =
    advancedMinutes >
      0
      ? restaurantSimulation
          .update(
            advancedMinutes
          )
      : false;

  if (
    simulationChanged ||
    restaurantChanged
  ) {
    saveSystem
      .autoSave();
  }

  if (
    advancedMinutes >
      0 ||
    simulationChanged ||
    restaurantChanged ||
    animationChanged ||
    needsResize
  ) {`,
      '主循环真实营业'
    );

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.0 经营接线第一阶段启动成功',
      '城市餐饮经营小游戏 V0.8.1 真实营业循环启动成功'
    );

  fs.writeFileSync(
    MAIN,
    source,
    'utf8'
  );
}

function patchStore() {
  let source =
    fs.readFileSync(
      STORE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const openingFinanceSystem =
  require('../finance/openingFinanceSystem.js');`,
`const openingFinanceSystem =
  require('../finance/openingFinanceSystem.js');

const operationsStore =
  require('../operations/operationsStoreV080.js');`,
      'StoreScene经营状态'
    );

  const start =
    source.indexOf(
      '  getOperatingSnapshot(shop) {'
    );

  const end =
    source.indexOf(
      '\n  getStoreImageKey(index) {',
      start
    );

  if (
    start <
      0 ||
    end <
      0
  ) {
    throw new Error(
      '[V0.8.1] 找不到 getOperatingSnapshot'
    );
  }

  const replacement =
`  getOperatingSnapshot(shop) {
    const state =
      this.getPreparationState(
        shop
      );

    const district =
      citySystem.getDistrict(
        shop.districtId
      );

    const seats =
      Math.max(
        6,
        Number(
          state.metrics
            ? state.metrics.totalSeats
            : shop.seatEstimate
        ) || 30
      );

    const dashboard =
      operationsStore
        .dashboard(
          shop.id
        );

    const finance =
      dashboard &&
      dashboard.finance
        ? dashboard.finance
        : {
            revenue: 0,
            profit: 0,
            orders: 0,
            customers: 0,
            avgTicket: 0
          };

    const customers =
      Number(
        finance.customers
      ) ||
      0;

    const revenue =
      Number(
        finance.revenue
      ) ||
      0;

    const profit =
      Number(
        finance.profit
      ) ||
      0;

    const rating =
      clamp(
        Number(
          dashboard &&
          dashboard.shopRating
        ) || 4,
        1,
        5
      );

    const turnover =
      customers /
      Math.max(
        1,
        seats
      );

    const staffCoverage =
      state.readiness &&
      state.readiness.staffing
        ? clamp(
            Number(
              state.readiness.staffing.coverage
            ) || 0,
            0,
            1.15
          )
        : 0.8;

    const avgSpend =
      Number(
        finance.avgTicket
      ) ||
      (
        customers >
          0
          ? revenue /
            customers
          : 0
      );

    const openDay =
      Math.max(
        1,
        dayOrdinal() -
        (
          Number(
            shop.trialOpenedDay
          ) ||
          dayOrdinal()
        ) +
        1
      );

    return {
      state,
      district,
      seats,
      customers,
      revenue,
      profit,
      rating,
      turnover,
      openDay,
      staffCoverage,
      avgSpend,
      orders:
        Number(
          finance.orders
        ) || 0,
      foodCostRate:
        Number(
          finance.foodCostRate
        ) || 0,
      profitRate:
        Number(
          finance.profitRate
        ) || 0,
      realOperation:
        true
    };
  }
`;

  source =
    source.slice(
      0,
      start
    ) +
    replacement +
    source.slice(
      end
    );

  fs.writeFileSync(
    STORE,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/realOperationLoopV081.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/wiringStageV080.test.js',`,
`    'tests/wiringStageV080.test.js',
    'tests/realOperationLoopV081.test.js',`,
        'V0.8.1测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.1';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchOperations();
  patchSettlement();
  patchMain();
  patchStore();
  patchRunner();
  finalizePackage();

  console.log(
    '[V0.8.1] 真实营业循环已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
