'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

function replaceOnce(
  source,
  needle,
  replacement,
  label
) {
  if (
    !source.includes(
      needle
    )
  ) {
    throw new Error(
      'V46：找不到替换位置：' +
      label
    );
  }

  return source.replace(
    needle,
    replacement
  );
}

function patchConfig() {
  const file =
    path.join(
      ROOT,
      'src/renovation/renovationConfig.js'
    );

  let source =
    fs.readFileSync(
      file,
      'utf8'
    );

  if (
    source.includes(
      'V46_RENOVATION_DECOR_CONFIG'
    )
  ) {
    return;
  }

  source =
    source.replace(
      "'use strict';",
      "'use strict';\n\n// V46_RENOVATION_DECOR_CONFIG"
    );

  const needle =
`  privateRoomSeatOptions: [4, 6, 8, 10, 12],`;

  const replacement =
`  decorItems: [
    {
      id: 'plant',
      name: '绿植',
      imageKey: 'v45_plant',
      cost: 680,
      comfort: 0.018,
      appeal: 0.014,
      max: 8
    },
    {
      id: 'pendant',
      name: '吊灯',
      imageKey: 'v45_pendant',
      cost: 980,
      comfort: 0.008,
      appeal: 0.022,
      max: 8
    },
    {
      id: 'screen',
      name: '屏风',
      imageKey: 'v45_screen',
      cost: 1680,
      comfort: 0.014,
      appeal: 0.028,
      max: 5
    },
    {
      id: 'sofa',
      name: '等候沙发',
      imageKey: 'v45_waiting_sofa',
      cost: 2280,
      comfort: 0.030,
      appeal: 0.020,
      max: 4
    }
  ],

  privateRoomSeatOptions: [4, 6, 8, 10, 12],`;

  source =
    replaceOnce(
      source,
      needle,
      replacement,
      'decorItems'
    );

  fs.writeFileSync(
    file,
    source,
    'utf8'
  );
}

function patchSystem() {
  const file =
    path.join(
      ROOT,
      'src/renovation/renovationSystem.js'
    );

  let source =
    fs.readFileSync(
      file,
      'utf8'
    );

  if (
    source.includes(
      'V46_RENOVATION_PLAYABILITY_SYSTEM'
    )
  ) {
    return;
  }

  source =
    source.replace(
      "'use strict';",
      "'use strict';\n\n// V46_RENOVATION_PLAYABILITY_SYSTEM"
    );

  // New plans start with soft-decoration counts.
  const planNeedle =
`        lightingLevel:
          'basic',

        floors,`;

  const planReplacement =
`        lightingLevel:
          'basic',

        decorCounts: {
          plant: 0,
          pendant: 0,
          screen: 0,
          sofa: 0
        },

        floors,`;

  source =
    replaceOnce(
      source,
      planNeedle,
      planReplacement,
      '新方案 decorCounts'
    );

  // Old saves gain decorCounts lazily.
  const returnNeedle =
`    return clone(
      store[shopId]
    );
  }

  mutatePlan(`;

  const returnReplacement =
`    if (
      !store[shopId]
        .decorCounts
    ) {
      store[shopId]
        .decorCounts = {
          plant: 0,
          pendant: 0,
          screen: 0,
          sofa: 0
        };
    }

    return clone(
      store[shopId]
    );
  }

  mutatePlan(`;

  source =
    replaceOnce(
      source,
      returnNeedle,
      returnReplacement,
      '旧存档 decorCounts'
    );

  // New soft-decoration controller.
  const addRoomNeedle =
`  addPrivateRoom(
    shopId,
    floorIndex
  ) {`;

  const decorMethod =
`  adjustDecor(
    shopId,
    decorId,
    delta
  ) {
    const item =
      config.decorItems
        .find(
          value =>
            value.id ===
            decorId
        );

    if (!item) {
      return null;
    }

    return this.mutatePlan(
      shopId,
      plan => {
        if (!plan.decorCounts) {
          plan.decorCounts = {};
        }

        const current =
          Number(
            plan.decorCounts[
              decorId
            ]
          ) || 0;

        plan.decorCounts[
          decorId
        ] =
          clamp(
            current +
              Number(delta || 0),
            0,
            item.max
          );
      }
    );
  }

`;

  if (
    !source.includes(
      addRoomNeedle
    )
  ) {
    throw new Error(
      'V46：找不到 addPrivateRoom'
    );
  }

  source =
    source.replace(
      addRoomNeedle,
      decorMethod +
      addRoomNeedle
    );

  // Add decor economics before total cost.
  const costNeedle =
`    const totalCost =
      Math.round(
        constructionBase +
        lightingCost +
        furnitureCost +
        roomCost +
        kitchenComplexity
      );`;

  const costReplacement =
`    const decorCounts =
      plan.decorCounts ||
      {};

    let decorCost =
      0;

    let decorComfortBonus =
      0;

    let decorAppealBonus =
      0;

    for (
      let i = 0;
      i <
      config.decorItems.length;
      i++
    ) {
      const item =
        config.decorItems[i];

      const count =
        clamp(
          Number(
            decorCounts[
              item.id
            ]
          ) || 0,
          0,
          item.max
        );

      decorCost +=
        count *
        item.cost;

      decorComfortBonus +=
        count *
        item.comfort;

      decorAppealBonus +=
        count *
        item.appeal;
    }

    const totalCost =
      Math.round(
        constructionBase +
        lightingCost +
        furnitureCost +
        roomCost +
        kitchenComplexity +
        decorCost
      );`;

  source =
    replaceOnce(
      source,
      costNeedle,
      costReplacement,
      '软装成本'
    );

  const comfortNeedle =
`        lighting.appeal *
        (
          1 -
          Math.max(`;

  const comfortReplacement =
`        lighting.appeal *
        (
          1 +
          decorComfortBonus
        ) *
        (
          1 -
          Math.max(`;

  source =
    replaceOnce(
      source,
      comfortNeedle,
      comfortReplacement,
      '舒适度软装加成'
    );

  const appealNeedle =
`        hallStyle.appeal *
        lighting.appeal *
        material.quality *
        (
          roomCount`;

  const appealReplacement =
`        hallStyle.appeal *
        lighting.appeal *
        material.quality *
        (
          1 +
          decorAppealBonus
        ) *
        (
          roomCount`;

  source =
    replaceOnce(
      source,
      appealNeedle,
      appealReplacement,
      '吸引力软装加成'
    );

  // Grade and operating-impact preview.
  const buildDaysNeedle =
`    const buildDays =
      Math.max(`;

  const scoreBlock =
`    const renovationScore =
      Math.round(
        clamp(
          (
            comfort /
            1.35
          ) *
            32 +
          (
            appeal /
            1.55
          ) *
            32 +
          (
            operationalEfficiency /
            1.35
          ) *
            26 +
          (
            invalidFloorCount === 0
              ? 10
              : 0
          ),
          0,
          100
        )
      );

    const operatingImpact = {
      trafficFactor:
        Number(
          clamp(
            0.86 +
              appeal *
                0.14,
            0.90,
            1.18
          ).toFixed(3)
        ),

      spendFactor:
        Number(
          clamp(
            0.92 +
              comfort *
                0.08,
            0.95,
            1.12
          ).toFixed(3)
        ),

      serviceFactor:
        Number(
          clamp(
            0.88 +
              operationalEfficiency *
                0.12,
            0.92,
            1.10
          ).toFixed(3)
        )
    };

`;

  if (
    !source.includes(
      buildDaysNeedle
    )
  ) {
    throw new Error(
      'V46：找不到 buildDays'
    );
  }

  source =
    source.replace(
      buildDaysNeedle,
      scoreBlock +
      buildDaysNeedle
    );

  const returnNeedle2 =
`      totalDiningArea:
        Number(
          totalDiningArea.toFixed(1)
        ),
      invalidFloorCount,`;

  const returnReplacement2 =
`      totalDiningArea:
        Number(
          totalDiningArea.toFixed(1)
        ),

      decorCost:
        Math.round(
          decorCost
        ),

      decorCounts:
        clone(
          decorCounts
        ),

      renovationScore,

      operatingImpact,

      invalidFloorCount,`;

  source =
    replaceOnce(
      source,
      returnNeedle2,
      returnReplacement2,
      '返回装修评分'
    );

  fs.writeFileSync(
    file,
    source,
    'utf8'
  );
}

function patchScene() {
  const file =
    path.join(
      ROOT,
      'src/scenes/renovationScene.js'
    );

  let source =
    fs.readFileSync(
      file,
      'utf8'
    );

  if (
    source.includes(
      'V46_RENOVATION_PLAYABILITY_UI'
    )
  ) {
    return;
  }

  source =
    source.replace(
      '// V45_LIBRARY_RENOVATION_PHASE1',
      '// V45_LIBRARY_RENOVATION_PHASE1\n// V46_RENOVATION_PLAYABILITY_UI'
    );

  // Accept the new pages.
  const pagesNeedle =
`      [
        'layout',
        'rooms',
        'style',
        'templates'
      ].includes(`;

  const pagesReplacement =
`      [
        'layout',
        'zones',
        'furniture',
        'rooms',
        'style',
        'templates',
        'contractors'
      ].includes(`;

  source =
    replaceOnce(
      source,
      pagesNeedle,
      pagesReplacement,
      '页面白名单'
    );

  // Right-side toolbox becomes actual playability navigation.
  const toolboxNeedle =
`    const toolbox = [
      [
        'style:hall',
        'v45_waiting_sofa',
        '大厅风格'
      ],
      [
        'style:lighting',
        'v45_pendant',
        '灯光'
      ],
      [
        'style:material',
        'v45_screen',
        '材料'
      ],
      [
        'page:rooms',
        'v45_layout_private_medium',
        '包厢'
      ],
      [
        'page:layout',
        'v45_table_4',
        '桌椅'
      ],
      [
        'floor:next',
        'v45_layout_corridor',
        (
          '楼层 ' +
          (
            metrics.plan
              .activeFloor +
            1
          ) +
          'F'
        )
      ]
    ];`;

  const toolboxReplacement =
`    const toolbox = [
      [
        'page:zones',
        'v45_layout_kitchen',
        '区域'
      ],
      [
        'page:furniture',
        'v45_table_4',
        '家具'
      ],
      [
        'page:style',
        'v45_style_chinese',
        '风格'
      ],
      [
        'page:rooms',
        'v45_layout_private_medium',
        '包厢'
      ],
      [
        'aisle:cycle',
        'v45_layout_corridor',
        '动线'
      ],
      [
        'floor:next',
        'v45_layout_corridor',
        (
          '楼层 ' +
          (
            metrics.plan
              .activeFloor +
            1
          ) +
          'F'
        )
      ]
    ];`;

  source =
    replaceOnce(
      source,
      toolboxNeedle,
      toolboxReplacement,
      '右侧装修工具栏'
    );

  // Add zone/furniture/contractor pages before renderRooms.
  const roomsNeedle =
`  renderRooms(
    ctx,
    metrics,
    floor
  ) {`;

  const extraPages =
`  renderZones(
    ctx,
    metrics,
    floor
  ) {
    const y =
      this.drawSecondaryHeader(
        ctx,
        '区域面积',
        '调整后厨、仓储、服务区比例，堂食面积自动联动'
      );

    const rows = [
      {
        key:
          'kitchenRatio',
        label:
          '后厨',
        image:
          'v45_layout_kitchen',
        min:
          renovationConfig
            .zoneRules
            .minKitchenRatio,
        max:
          renovationConfig
            .zoneRules
            .maxKitchenRatio
      },
      {
        key:
          'storageRatio',
        label:
          '仓储',
        image:
          'v45_layout_storage',
        min:
          renovationConfig
            .zoneRules
            .minStorageRatio,
        max:
          renovationConfig
            .zoneRules
            .maxStorageRatio
      },
      {
        key:
          'serviceRatio',
        label:
          '服务区',
        image:
          'v45_layout_service',
        min:
          renovationConfig
            .zoneRules
            .minServiceRatio,
        max:
          renovationConfig
            .zoneRules
            .maxServiceRatio
      }
    ];

    let drawY =
      y;

    for (
      let i = 0;
      i <
      rows.length;
      i++
    ) {
      const item =
        rows[i];

      const ratio =
        Number(
          floor[
            item.key
          ]
        ) || 0;

      const area =
        floor.area *
        ratio;

      ui.card(
        ctx,
        10,
        drawY,
        370,
        74,
        {
          radius: 13,
          fill:
            COLORS.panel,
          stroke:
            '#DDD2C3',
          shadow: false
        }
      );

      this.drawVisual(
        ctx,
        item.image,
        18,
        drawY + 8,
        74,
        58,
        1
      );

      ui.text(
        ctx,
        item.label,
        105,
        drawY + 17,
        8.5,
        COLORS.text,
        '800'
      );

      ui.text(
        ctx,
        Math.round(
          ratio *
          100
        ) +
        '% · ' +
        area.toFixed(1) +
        '㎡',
        105,
        drawY + 38,
        7.1,
        COLORS.orange,
        '800'
      );

      ui.text(
        ctx,
        '范围 ' +
        Math.round(
          item.min *
          100
        ) +
        '%–' +
        Math.round(
          item.max *
          100
        ) +
        '%',
        105,
        drawY + 57,
        5.5,
        COLORS.muted,
        '600'
      );

      ui.card(
        ctx,
        283,
        drawY + 17,
        32,
        32,
        {
          radius: 15,
          fill:
            '#F3EFE7',
          stroke:
            '#D3C8B9',
          shadow: false
        }
      );

      ui.text(
        ctx,
        '−',
        299,
        drawY + 33,
        11,
        COLORS.navy,
        '800',
        'center'
      );

      this.addButton(
        'zone:' +
          item.key +
          ':minus',
        278,
        drawY + 12,
        42,
        42
      );

      ui.card(
        ctx,
        329,
        drawY + 17,
        32,
        32,
        {
          radius: 15,
          fill:
            COLORS.gold,
          stroke:
            '#DDA11F',
          shadow: false
        }
      );

      ui.text(
        ctx,
        '+',
        345,
        drawY + 33,
        10,
        COLORS.text,
        '800',
        'center'
      );

      this.addButton(
        'zone:' +
          item.key +
          ':plus',
        324,
        drawY + 12,
        42,
        42
      );

      drawY +=
        81;
    }

    const diningRatio =
      Math.max(
        0,
        1 -
        floor.kitchenRatio -
        floor.storageRatio -
        floor.serviceRatio
      );

    ui.card(
      ctx,
      10,
      drawY,
      370,
      72,
      {
        radius: 13,
        fill:
          '#F5FAF7',
        stroke:
          '#C9DFD2',
        shadow: false
      }
    );

    this.drawVisual(
      ctx,
      'v45_layout_dining',
      18,
      drawY + 8,
      84,
      56,
      1
    );

    ui.text(
      ctx,
      '堂食区',
      114,
      drawY + 19,
      8.5,
      COLORS.text,
      '800'
    );

    ui.text(
      ctx,
      Math.round(
        diningRatio *
        100
      ) +
      '% · ' +
      (
        floor.area *
        diningRatio
      ).toFixed(1) +
      '㎡',
      114,
      drawY + 43,
      7.2,
      COLORS.green,
      '800'
    );

    ui.text(
      ctx,
      '餐位与包厢共用堂食面积',
      250,
      drawY + 43,
      5.3,
      COLORS.muted,
      '600'
    );

    drawY +=
      80;

    const aisle =
      renovationConfig
        .aisleModes[
          floor.aisleMode
        ];

    ui.card(
      ctx,
      10,
      drawY,
      370,
      62,
      {
        radius: 13,
        fill:
          '#FFF8E8',
        stroke:
          '#E5C975',
        shadow: false
      }
    );

    this.drawVisual(
      ctx,
      'v45_layout_corridor',
      18,
      drawY + 8,
      70,
      46,
      1
    );

    ui.text(
      ctx,
      '动线模式',
      101,
      drawY + 18,
      7.6,
      COLORS.text,
      '800'
    );

    ui.text(
      ctx,
      aisle.name +
        ' · 舒适 ' +
        Math.round(
          aisle.comfort *
          100
        ) +
        ' · 效率 ' +
        Math.round(
          aisle
            .serviceEfficiency *
          100
        ),
      101,
      drawY + 41,
      5.6,
      COLORS.muted,
      '600'
    );

    ui.card(
      ctx,
      300,
      drawY + 14,
      62,
      31,
      {
        radius: 15,
        fill:
          COLORS.gold,
        stroke:
          '#DDA11F',
        shadow: false
      }
    );

    ui.text(
      ctx,
      '切换',
      331,
      drawY + 29.5,
      6.2,
      COLORS.text,
      '800',
      'center'
    );

    this.addButton(
      'aisle:cycle',
      294,
      drawY + 9,
      74,
      41
    );
  }

  renderFurniture(
    ctx,
    metrics,
    floor
  ) {
    const y =
      this.drawSecondaryHeader(
        ctx,
        '家具配置',
        '餐桌决定餐位，软装影响舒适度、吸引力和预算'
      );

    ui.text(
      ctx,
      '餐桌组合',
      18,
      y + 13,
      8.3,
      COLORS.text,
      '800'
    );

    const tableKeys = [
      '2',
      '4',
      '6',
      '8'
    ];

    for (
      let i = 0;
      i < 4;
      i++
    ) {
      const key =
        tableKeys[i];

      const x =
        10 +
        i * 93;

      ui.card(
        ctx,
        x,
        y + 27,
        86,
        126,
        {
          radius: 12,
          fill:
            '#FFF9EF',
          stroke:
            '#DDD2C3',
          shadow: false
        }
      );

      this.drawVisual(
        ctx,
        'visual_table_' +
          key,
        x + 8,
        y + 34,
        70,
        63,
        1
      );

      ui.text(
        ctx,
        key +
          '人桌',
        x + 43,
        y + 103,
        6.2,
        COLORS.text,
        '800',
        'center'
      );

      ui.text(
        ctx,
        '数量 ' +
        (
          floor.tables[
            key
          ] || 0
        ),
        x + 43,
        y + 121,
        5.5,
        COLORS.muted,
        '600',
        'center'
      );

      ui.card(
        ctx,
        x + 7,
        y + 130,
        30,
        18,
        {
          radius: 8,
          fill:
            '#F2EEE7',
          stroke:
            '#D4C9BB',
          shadow: false
        }
      );

      ui.text(
        ctx,
        '−',
        x + 22,
        y + 139,
        8,
        COLORS.navy,
        '800',
        'center'
      );

      this.addButton(
        'table:' +
          key +
          ':minus',
        x + 4,
        y + 126,
        36,
        26
      );

      ui.card(
        ctx,
        x + 49,
        y + 130,
        30,
        18,
        {
          radius: 8,
          fill:
            COLORS.gold,
          stroke:
            '#DDA11F',
          shadow: false
        }
      );

      ui.text(
        ctx,
        '+',
        x + 64,
        y + 139,
        7,
        COLORS.text,
        '800',
        'center'
      );

      this.addButton(
        'table:' +
          key +
          ':plus',
        x + 46,
        y + 126,
        36,
        26
      );
    }

    const decorY =
      y + 169;

    ui.text(
      ctx,
      '软装配置',
      18,
      decorY,
      8.3,
      COLORS.text,
      '800'
    );

    const decorItems =
      renovationConfig
        .decorItems;

    for (
      let i = 0;
      i <
      decorItems.length;
      i++
    ) {
      const item =
        decorItems[i];

      const x =
        10 +
        i * 93;

      const count =
        Number(
          metrics
            .decorCounts[
              item.id
            ]
        ) || 0;

      ui.card(
        ctx,
        x,
        decorY + 14,
        86,
        128,
        {
          radius: 12,
          fill:
            '#FFF9EF',
          stroke:
            '#DDD2C3',
          shadow: false
        }
      );

      this.drawVisual(
        ctx,
        item.imageKey,
        x + 8,
        decorY + 21,
        70,
        63,
        1
      );

      ui.text(
        ctx,
        item.name,
        x + 43,
        decorY + 91,
        6.1,
        COLORS.text,
        '800',
        'center'
      );

      ui.text(
        ctx,
        money(
          item.cost
        ) +
          ' · ' +
          count +
          '/' +
          item.max,
        x + 43,
        decorY + 108,
        4.8,
        COLORS.muted,
        '600',
        'center'
      );

      ui.card(
        ctx,
        x + 7,
        decorY + 116,
        30,
        18,
        {
          radius: 8,
          fill:
            '#F2EEE7',
          stroke:
            '#D4C9BB',
          shadow: false
        }
      );

      ui.text(
        ctx,
        '−',
        x + 22,
        decorY + 125,
        8,
        COLORS.navy,
        '800',
        'center'
      );

      this.addButton(
        'decor:' +
          item.id +
          ':minus',
        x + 4,
        decorY + 112,
        36,
        26
      );

      ui.card(
        ctx,
        x + 49,
        decorY + 116,
        30,
        18,
        {
          radius: 8,
          fill:
            COLORS.gold,
          stroke:
            '#DDA11F',
          shadow: false
        }
      );

      ui.text(
        ctx,
        '+',
        x + 64,
        decorY + 125,
        7,
        COLORS.text,
        '800',
        'center'
      );

      this.addButton(
        'decor:' +
          item.id +
          ':plus',
        x + 46,
        decorY + 112,
        36,
        26
      );
    }

    const impactY =
      decorY + 151;

    ui.card(
      ctx,
      10,
      impactY,
      370,
      63,
      {
        radius: 13,
        fill:
          '#F3F8FA',
        stroke:
          '#C7DCE6',
        shadow: false
      }
    );

    ui.text(
      ctx,
      '当前软装 ' +
        money(
          metrics.decorCost
        ),
      22,
      impactY + 19,
      7.1,
      COLORS.text,
      '800'
    );

    ui.text(
      ctx,
      '装修评分 ' +
        metrics
          .renovationScore,
      151,
      impactY + 19,
      7.1,
      COLORS.orange,
      '800'
    );

    ui.text(
      ctx,
      '客流 ×' +
        metrics
          .operatingImpact
          .trafficFactor
          .toFixed(2) +
        ' · 客单 ×' +
        metrics
          .operatingImpact
          .spendFactor
          .toFixed(2) +
        ' · 服务 ×' +
        metrics
          .operatingImpact
          .serviceFactor
          .toFixed(2),
      22,
      impactY + 44,
      5.4,
      COLORS.muted,
      '600'
    );
  }

  renderContractors(
    ctx,
    metrics
  ) {
    const y =
      this.drawSecondaryHeader(
        ctx,
        '选择施工队',
        '报价、工期、可靠度和质量均来自当前装修方案'
      );

    const plan =
      metrics.plan;

    const quotes =
      renovationSystem
        .getContractorQuotes(
          this.shopId
        );

    let drawY =
      y;

    for (
      let i = 0;
      i <
      quotes.length;
      i++
    ) {
      const quote =
        quotes[i];

      const selected =
        plan
          .selectedContractorId ===
        quote.id ||
        (
          !plan
            .selectedContractorId &&
          i === 0
        );

      ui.card(
        ctx,
        10,
        drawY,
        370,
        88,
        {
          radius: 13,
          fill:
            selected
              ? '#FFF8DE'
              : COLORS.panel,
          stroke:
            selected
              ? '#E2B52B'
              : '#DDD2C3',
          shadow: false
        }
      );

      this.drawVisual(
        ctx,
        'v45_advice_renovation',
        18,
        drawY + 9,
        64,
        70,
        1
      );

      ui.text(
        ctx,
        quote.name,
        95,
        drawY + 19,
        8.1,
        COLORS.text,
        '800'
      );

      ui.text(
        ctx,
        '报价 ' +
          money(
            quote.price
          ) +
          ' · 工期 ' +
          quote.days +
          '天',
        95,
        drawY + 41,
        6.1,
        COLORS.orange,
        '800'
      );

      ui.text(
        ctx,
        '可靠度 ' +
          quote
            .reliability +
          ' · 质量 ' +
          quote
            .quality,
        95,
        drawY + 62,
        5.5,
        COLORS.muted,
        '600'
      );

      ui.card(
        ctx,
        303,
        drawY + 24,
        57,
        32,
        {
          radius: 15,
          fill:
            selected
              ? COLORS.gold
              : '#E7F2F7',
          stroke:
            selected
              ? '#DDA11F'
              : '#AFCFDD',
          shadow: false
        }
      );

      ui.text(
        ctx,
        selected
          ? '已选'
          : '选择',
        331.5,
        drawY + 40,
        6.2,
        COLORS.text,
        '800',
        'center'
      );

      this.addButton(
        'contractor:select:' +
          quote.id,
        296,
        drawY + 18,
        71,
        44
      );

      drawY +=
        96;
    }

    ui.card(
      ctx,
      10,
      drawY,
      370,
      73,
      {
        radius: 13,
        fill:
          metrics.valid
            ? '#F2F9F4'
            : '#FFF1EC',
        stroke:
          metrics.valid
            ? '#BDDCC7'
            : '#E4B6A9',
        shadow: false
      }
    );

    ui.text(
      ctx,
      '装修评分 ' +
        metrics
          .renovationScore +
        ' · 预算 ' +
        money(
          metrics.totalCost
        ),
      22,
      drawY + 20,
      7.2,
      metrics.valid
        ? COLORS.green
        : COLORS.red,
      '800'
    );

    ui.text(
      ctx,
      '预计经营影响：客流 ×' +
        metrics
          .operatingImpact
          .trafficFactor
          .toFixed(2) +
        ' · 客单 ×' +
        metrics
          .operatingImpact
          .spendFactor
          .toFixed(2),
      22,
      drawY + 43,
      5.3,
      COLORS.muted,
      '600'
    );

    ui.card(
      ctx,
      252,
      drawY + 17,
      108,
      38,
      {
        radius: 18,
        fill:
          metrics.valid
            ? COLORS.gold
            : '#D9D4CB',
        stroke:
          metrics.valid
            ? '#DDA11F'
            : '#C4BCAF',
        shadow: false
      }
    );

    ui.text(
      ctx,
      metrics.valid
        ? '确认施工'
        : '方案无效',
      306,
      drawY + 36,
      7,
      metrics.valid
        ? COLORS.text
        : COLORS.muted,
      '800',
      'center'
    );

    if (
      metrics.valid
    ) {
      this.addButton(
        'construction:confirm',
        245,
        drawY + 11,
        122,
        50
      );
    }
  }

`;

  if (
    !source.includes(
      roomsNeedle
    )
  ) {
    throw new Error(
      'V46：找不到 renderRooms'
    );
  }

  source =
    source.replace(
      roomsNeedle,
      extraPages +
      roomsNeedle
    );

  // New page dispatch.
  const dispatchNeedle =
`    if (
      this.page ===
        'rooms'
    ) {
      this.renderRooms(
        ctx,
        metrics,
        floor
      );
    } else if (
      this.page ===
        'style'
    ) {`;

  const dispatchReplacement =
`    if (
      this.page ===
        'zones'
    ) {
      this.renderZones(
        ctx,
        metrics,
        floor
      );
    } else if (
      this.page ===
        'furniture'
    ) {
      this.renderFurniture(
        ctx,
        metrics,
        floor
      );
    } else if (
      this.page ===
        'contractors'
    ) {
      this.renderContractors(
        ctx,
        metrics
      );
    } else if (
      this.page ===
        'rooms'
    ) {
      this.renderRooms(
        ctx,
        metrics,
        floor
      );
    } else if (
      this.page ===
        'style'
    ) {`;

  source =
    replaceOnce(
      source,
      dispatchNeedle,
      dispatchReplacement,
      '页面渲染分发'
    );

  // Footer now opens contractor selection instead of immediately picking cheapest.
  source =
    source.replace(
      "'确认方案并开始施工  ›'",
      "'选择施工队并开始施工  ›'"
    );

  // Preview includes the new score.
  const previewNeedle =
`          '座位 ' +
            metrics.totalSeats +
            ' · 舒适度 ' +
            Math.round(
              metrics.comfort *
              100
            ) +
            ' · 吸引力 ' +
            Math.round(
              metrics.appeal *
              100
            )`;

  const previewReplacement =
`          '装修评分 ' +
            metrics.renovationScore +
            ' · 座位 ' +
            metrics.totalSeats +
            ' · 舒适度 ' +
            Math.round(
              metrics.comfort *
              100
            ) +
            ' · 吸引力 ' +
            Math.round(
              metrics.appeal *
              100
            )`;

  source =
    replaceOnce(
      source,
      previewNeedle,
      previewReplacement,
      '预览评分'
    );

  // Add interactive handlers before page routing.
  const pageHandlerNeedle =
`    if (
      id.indexOf(
        'page:'
      ) ===
      0
    ) {`;

  const actionHandlers =
`    if (
      id ===
      'aisle:cycle'
    ) {
      const plan =
        this.getPlan();

      renovationSystem
        .cycleAisle(
          this.shopId,
          plan.activeFloor
        );

      return true;
    }

    if (
      id.indexOf(
        'zone:'
      ) ===
      0
    ) {
      const parts =
        id.split(':');

      const key =
        parts[1];

      const delta =
        parts[2] ===
          'plus'
          ? 0.02
          : -0.02;

      const plan =
        this.getPlan();

      renovationSystem
        .adjustZone(
          this.shopId,
          plan.activeFloor,
          key,
          delta
        );

      return true;
    }

    if (
      id.indexOf(
        'decor:'
      ) ===
      0
    ) {
      const parts =
        id.split(':');

      renovationSystem
        .adjustDecor(
          this.shopId,
          parts[1],
          parts[2] ===
            'plus'
            ? 1
            : -1
        );

      return true;
    }

    if (
      id.indexOf(
        'contractor:select:'
      ) ===
      0
    ) {
      renovationSystem
        .selectContractor(
          this.shopId,
          id.slice(
            'contractor:select:'
              .length
          )
        );

      return true;
    }

`;

  if (
    !source.includes(
      pageHandlerNeedle
    )
  ) {
    throw new Error(
      'V46：找不到 page handler'
    );
  }

  source =
    source.replace(
      pageHandlerNeedle,
      actionHandlers +
      pageHandlerNeedle
    );

  // Replace old immediate construction action.
  const constructionStart =
    source.indexOf(
      "    if (\n      id ===\n      'construction:start'\n    ) {"
    );

  const returnFalse =
    source.indexOf(
      '\n    return false;',
      constructionStart
    );

  if (
    constructionStart < 0 ||
    returnFalse < 0
  ) {
    throw new Error(
      'V46：找不到 construction:start'
    );
  }

  const newConstructionHandler =
`    if (
      id ===
      'construction:start'
    ) {
      this.page =
        'contractors';

      return true;
    }

    if (
      id ===
      'construction:confirm'
    ) {
      const quotes =
        renovationSystem
          .getContractorQuotes(
            this.shopId
          );

      const plan =
        this.getPlan();

      if (
        !plan
          .selectedContractorId &&
        quotes[0]
      ) {
        renovationSystem
          .selectContractor(
            this.shopId,
            quotes[0].id
          );
      }

      const result =
        renovationSystem
          .startConstruction(
            this.shopId
          );

      this.showToast(
        result.ok
          ? '施工已经开始'
          : result.message
      );

      textInput
        .requestRender();

      return true;
    }
`;

  source =
    source.slice(
      0,
      constructionStart
    ) +
    newConstructionHandler +
    source.slice(
      returnFalse
    );

  fs.writeFileSync(
    file,
    source,
    'utf8'
  );
}

patchConfig();
patchSystem();
patchScene();

console.log(
  'V46 装修可玩性阶段已应用'
);
