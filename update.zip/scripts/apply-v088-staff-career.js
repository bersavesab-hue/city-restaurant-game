'use strict';

const fs =
  require('fs');

const path =
  require('path');

const childProcess =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const MAIN =
  path.join(
    ROOT,
    'src/main.js'
  );

const STAFF_SCENE =
  path.join(
    ROOT,
    'src/scenes/staffScene.js'
  );

const SCHEDULE =
  path.join(
    ROOT,
    'src/operations/operationsScheduleV087.js'
  );

const LIVE_WORLD =
  path.join(
    ROOT,
    'src/world/liveWorldSystemV084.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.8] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function syntaxCheck(
  file
) {
  childProcess
    .execFileSync(
      process.execPath,
      [
        '--check',
        file
      ],
      {
        cwd:ROOT,
        stdio:'inherit'
      }
    );
}

function patchSchedule() {
  let source =
    fs.readFileSync(
      SCHEDULE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`  const t =
    time ||
    gameState.getTime();

  if (
    employee.offDay ===
    weekDay(
      t
    )
  ) {
    return false;
  }`,
`  const t =
    time ||
    gameState.getTime();

  const staffState =
    openingPrepSystem
      .getStaffState(
        shopId
      );

  const hiredStaff =
    (
      staffState.hired ||
      []
    ).find(
      row =>
        String(
          row.id
        ) ===
        String(
          employee.personId
        )
    );

  const career =
    hiredStaff &&
    hiredStaff.career ||
    {};

  const currentDay =
    dayOrdinal(
      t
    );

  if (
    career.training &&
    Number(
      career.training
        .finishDay
    ) >
      currentDay
  ) {
    return false;
  }

  if (
    career.leave &&
    Number(
      career.leave
        .untilDay
    ) >
      currentDay
  ) {
    return false;
  }

  if (
    employee.offDay ===
    weekDay(
      t
    )
  ) {
    return false;
  }`,
      '培训请假影响真实排班'
    );

  fs.writeFileSync(
    SCHEDULE,
    source,
    'utf8'
  );
}

function patchLiveWorld() {
  let source =
    fs.readFileSync(
      LIVE_WORLD,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`      personEngine
        .dailyTick(
          profile,
          {
            workload,
            overtime:
              workload >
                78
                ? 22
                : workload >
                    65
                  ? 10
                  : 0,
            managerQuality,
            payFairness,`,
`      const career =
        staff.career ||
        {};

      const careerUnavailable =
        (
          career.training &&
          Number(
            career.training
              .finishDay
          ) >
            day
        ) ||
        (
          career.leave &&
          Number(
            career.leave
              .untilDay
          ) >
            day
        );

      personEngine
        .dailyTick(
          profile,
          {
            workload:
              careerUnavailable
                ? 15
                : workload,
            overtime:
              careerUnavailable
                ? 0
                : workload >
                    78
                  ? 22
                  : workload >
                      65
                    ? 10
                    : 0,
            dayOff:
              careerUnavailable,
            managerQuality,
            payFairness,`,
      '请假培训进入NPC每日状态'
    );

  fs.writeFileSync(
    LIVE_WORLD,
    source,
    'utf8'
  );
}

function patchStaffScene() {
  let source =
    fs.readFileSync(
      STAFF_SCENE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`    this.rounded(
      ctx,
      10,
      actionY,
      177,
      40,
      11,
      COLORS.navy
    );

    this.text(
      ctx,
      '返回门店',
      98,
      actionY + 20,
      8.5,
      COLORS.white,
      '700',
      'center'
    );

    this.addButton(
      'back',
      10,
      actionY,
      177,
      40
    );

    this.rounded(
      ctx,
      193,
      actionY,
      187,
      40,
      11,
      overview.coverage >=
        0.9
        ? COLORS.green
        : COLORS.gold
    );

    this.text(
      ctx,
      '营业时间 / 员工排班',
      286,
      actionY + 20,
      8.1,
      overview.coverage >=
        0.9
        ? COLORS.white
        : COLORS.text,
      '700',
      'center'
    );

    this.addButton(
      'schedule',
      193,
      actionY,
      187,
      40
    );`,
`    this.rounded(
      ctx,
      10,
      actionY,
      112,
      40,
      11,
      COLORS.navy
    );

    this.text(
      ctx,
      '返回门店',
      66,
      actionY + 20,
      7.8,
      COLORS.white,
      '700',
      'center'
    );

    this.addButton(
      'back',
      10,
      actionY,
      112,
      40
    );

    this.rounded(
      ctx,
      128,
      actionY,
      118,
      40,
      11,
      COLORS.gold
    );

    this.text(
      ctx,
      '团队管理',
      187,
      actionY + 20,
      7.8,
      COLORS.text,
      '700',
      'center'
    );

    this.addButton(
      'career',
      128,
      actionY,
      118,
      40
    );

    this.rounded(
      ctx,
      252,
      actionY,
      128,
      40,
      11,
      overview.coverage >=
        0.9
        ? COLORS.green
        : COLORS.gold
    );

    this.text(
      ctx,
      '营业 / 排班',
      316,
      actionY + 20,
      7.7,
      overview.coverage >=
        0.9
        ? COLORS.white
        : COLORS.text,
      '700',
      'center'
    );

    this.addButton(
      'schedule',
      252,
      actionY,
      128,
      40
    );`,
      '招聘页增加团队管理入口'
    );

  source =
    replaceOnce(
      source,
`    if (
      item.id ===
      'schedule'
    ) {
      sceneManager
        .switchTo(
          'schedule',
          {
            shopId:
              this.shopId
          }
        );

      return true;
    }`,
`    if (
      item.id ===
      'career'
    ) {
      sceneManager
        .switchTo(
          'staffCareer',
          {
            shopId:
              this.shopId
          }
        );

      return true;
    }

    if (
      item.id ===
      'schedule'
    ) {
      sceneManager
        .switchTo(
          'schedule',
          {
            shopId:
              this.shopId
          }
        );

      return true;
    }`,
      '团队管理按钮点击'
    );

  fs.writeFileSync(
    STAFF_SCENE,
    source,
    'utf8'
  );
}

function patchMain() {
  let source =
    fs.readFileSync(
      MAIN,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const businessLifecycle =
  require('./core/businessLifecycleV086.js');`,
`const businessLifecycle =
  require('./core/businessLifecycleV086.js');

const staffCareer =
  require('./operations/staffCareerV088.js');`,
      '主循环接入员工职业系统'
    );

  source =
    replaceOnce(
      source,
`const scheduleScene =
  require('./scenes/scheduleSceneV087.js');`,
`const scheduleScene =
  require('./scenes/scheduleSceneV087.js');

const staffCareerScene =
  require('./scenes/staffCareerSceneV088.js');`,
      '团队管理页面require'
    );

  source =
    replaceOnce(
      source,
`sceneManager.register(
  'schedule',
  scheduleScene
);`,
`sceneManager.register(
  'schedule',
  scheduleScene
);

sceneManager.register(
  'staffCareer',
  staffCareerScene
);`,
      '团队管理页面注册'
    );

  source =
    replaceOnce(
      source,
`  let lifecycleChanged =
    false;

  const advancedMinutes =`,
`  let lifecycleChanged =
    false;

  let staffCareerChanged =
    false;

  const advancedMinutes =`,
      '员工职业变化标记'
    );

  source =
    replaceOnce(
      source,
`          if (
            businessLifecycle
              .update()
          ) {
            lifecycleChanged =
              true;
          }`,
`          if (
            businessLifecycle
              .update()
          ) {
            lifecycleChanged =
              true;
          }

          if (
            staffCareer
              .update()
          ) {
            staffCareerChanged =
              true;
          }`,
      '员工职业每日推进'
    );

  source =
    replaceOnce(
      source,
`    restaurantChanged ||
    lifecycleChanged
  ) {`,
`    restaurantChanged ||
    lifecycleChanged ||
    staffCareerChanged
  ) {`,
      '员工职业变化自动保存'
    );

  source =
    replaceOnce(
      source,
`    restaurantChanged ||
    lifecycleChanged ||
    animationChanged ||`,
`    restaurantChanged ||
    lifecycleChanged ||
    staffCareerChanged ||
    animationChanged ||`,
      '员工职业变化触发重绘'
    );

  fs.writeFileSync(
    MAIN,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/staffCareerV088.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/operationsScheduleV087.test.js',
    'tests/v60CleanBase.test.js'`,
`    'tests/operationsScheduleV087.test.js',
    'tests/staffCareerV088.test.js',
    'tests/v60CleanBase.test.js'`,
        'V0.8.8测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.8';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node scripts/apply-v088-staff-career.js && node tests/staffCareerV088.test.js && node tests/operationsScheduleV087.test.js && node tests/businessLifecycleV086.test.js && node tests/managementCenterV085.test.js && node tests/liveWorldV084.test.js && node tests/foundationFixesV083.test.js && node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchSchedule();
  patchLiveWorld();
  patchStaffScene();
  patchMain();
  patchRunner();
  finalizePackage();

  for (
    const file
    of [
      MAIN,
      STAFF_SCENE,
      SCHEDULE,
      LIVE_WORLD,
      path.join(
        ROOT,
        'src/operations/staffCareerV088.js'
      ),
      path.join(
        ROOT,
        'src/scenes/staffCareerSceneV088.js'
      )
    ]
  ) {
    syntaxCheck(
      file
    );
  }

  console.log(
    '[V0.8.8] 员工长期经营系统已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
