'use strict';

const fs = require('fs');
const path = require('path');
const ROOT = path.resolve(__dirname, '..');

function patchStoreScene() {
  const file = path.join(ROOT, 'src/scenes/storeScene.js');
  let s = fs.readFileSync(file, 'utf8');

  if (s.includes('V43_REFERENCE_IMAGE_UI')) {
    return;
  }

  s = s.replace(
    '// V42_STORE_MASTER_REFERENCE_REBUILD\n',
    '// V42_STORE_MASTER_REFERENCE_REBUILD\n// V43_REFERENCE_IMAGE_UI\n'
  );

  const constantNeedle = 'const COLORS = {';
  const iconConst = `
const V43_REFERENCE_ICONS = {
  rent: 'money',
  visibility: 'view',
  hot: 'target',
  layout: 'renovation',
  broker: 'people',
  new: 'restaurant',
  rider: 'delivery',
  event: 'bulletin',
  route: 'route',
  store: 'shop',
  warning: 'warning',
  lease: 'location',
  contract: 'complete'
};

`;
  if (!s.includes('V43_REFERENCE_ICONS')) {
    s = s.replace(constantNeedle, iconConst + constantNeedle);
  }

  const enterNeedle = `  enter(params) {
    visualAssetSystem`;
  const enterReplace = `  enter(params) {
    Object.values(V43_REFERENCE_ICONS)
      .filter((value, index, list) => list.indexOf(value) === index)
      .forEach(name => {
        resourceManager
          .loadImage(
            'v43_icon_' + name,
            'assets/images/v43_reference_icons/' + name + '.png',
            'v43-reference-icons'
          )
          .catch(() => {});
      });

    visualAssetSystem`;
  if (s.includes(enterNeedle)) {
    s = s.replace(enterNeedle, enterReplace);
  }

  const drawStart = s.indexOf('  drawPropertyIcon(');
  const drawEnd = s.indexOf('\n  getListingScore(', drawStart);
  if (drawStart >= 0 && drawEnd > drawStart) {
    const method = `  drawPropertyIcon(
    ctx,
    name,
    x,
    y,
    size,
    fallback,
    tint
  ) {
    const mapped =
      V43_REFERENCE_ICONS[name];

    const libImage =
      mapped
        ? resourceManager.getImage(
            'v43_icon_' + mapped
          )
        : null;

    if (libImage) {
      ctx.drawImage(
        libImage,
        x,
        y,
        size,
        size
      );
      return;
    }

    const image =
      resourceManager.getImage(
        'property_icons_01'
      );

    const region =
      propertyIconAtlas.icons[name];

    if (image && region) {
      ctx.drawImage(
        image,
        region.x,
        region.y,
        region.w,
        region.h,
        x,
        y,
        size,
        size
      );
      return;
    }

    ctx.beginPath();
    ctx.arc(
      x + size / 2,
      y + size / 2,
      size / 2,
      0,
      Math.PI * 2
    );
    ctx.fillStyle = tint || '#E8F4F9';
    ctx.fill();

    storeText(
      ctx,
      fallback || '·',
      x + size / 2,
      y + size / 2,
      Math.max(5, size * 0.32),
      COLORS.navy,
      '800',
      'center'
    );
  }
`;
    s = s.slice(0, drawStart) + method + s.slice(drawEnd);
  }

  fs.writeFileSync(file, s, 'utf8');
}

function patchPropertyScene() {
  const file = path.join(ROOT, 'src/scenes/shopScene.js');
  let s = fs.readFileSync(file, 'utf8');

  if (s.includes('V43_PROPERTY_IMAGE_REBUILD')) {
    return;
  }

  s = s.replace(
    "'use strict';",
    "'use strict';\n\n// V43_PROPERTY_IMAGE_REBUILD"
  );

  const requireNeedle = `const resourceManager =
  require('../core/resourceManager.js');`;
  if (!s.includes(requireNeedle)) {
    throw new Error('V43: shopScene resourceManager require not found');
  }

  const iconConstNeedle = 'const DESIGN_W = 390;';
  if (s.includes(iconConstNeedle) && !s.includes('V43_PROPERTY_ICONS')) {
    s = s.replace(iconConstNeedle, `${iconConstNeedle}

const V43_PROPERTY_ICONS = {
  area: 'restaurant',
  frontage: 'view',
  exhaust: 'renovation',
  gas: 'warning',
  power: 'upgrade',
  competitor: 'people',
  event: 'bulletin',
  filter: 'search',
  sort: 'route',
  lease: 'location',
  floor: 'shop',
  layout: 'restaurant',
  warning: 'warning',
  broker: 'people',
  landlord: 'people'
};

const V43_STOREFRONTS = [
  'assets/images/library_store/listings/storefront_1.png',
  'assets/images/library_store/listings/storefront_2.png',
  'assets/images/library_store/listings/storefront_3.png',
  'assets/images/library_store/listings/storefront_4.png',
  'assets/images/library_store/listings/storefront_5.png'
];
`);
  }

  const enterNeedle = `  enter(
    payload
  ) {
    const data =`;
  const enterReplace = `  enter(
    payload
  ) {
    Object.values(V43_PROPERTY_ICONS)
      .filter((value, index, list) => list.indexOf(value) === index)
      .forEach(name => {
        resourceManager
          .loadImage(
            'v43_icon_' + name,
            'assets/images/v43_reference_icons/' + name + '.png',
            'v43-reference-icons'
          )
          .catch(() => {});
      });

    V43_STOREFRONTS.forEach((asset, index) => {
      resourceManager
        .loadImage(
          'v43_storefront_' + index,
          asset,
          'v43-property-storefronts'
        )
        .catch(() => {});
    });

    resourceManager
      .loadImage(
        'v43_property_header',
        'assets/images/premium/store/explore_banner.jpg',
        'v43-property-storefronts'
      )
      .catch(() => {});

    const data =`;
  if (s.includes(enterNeedle)) {
    s = s.replace(enterNeedle, enterReplace);
  }

  // Precise small text for the property pages.
  const textStart = s.indexOf('  text(\n');
  const iconStart = s.indexOf('\n  drawIcon(', textStart);
  if (textStart >= 0 && iconStart > textStart) {
    const textMethod = `  text(
    ctx,
    text,
    x,
    y,
    size,
    color,
    weight,
    align
  ) {
    ctx.save();
    ctx.fillStyle = color || COLORS.text;
    const readableSize =
      Math.max(
        4.8,
        Number(size) || 5.5
      );
    ctx.font =
      (weight || '500') +
      ' ' +
      readableSize +
      'px "Noto Sans SC","Microsoft YaHei",sans-serif';
    ctx.textAlign = align || 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(text), x, y);
    ctx.restore();
  }
`;
    s = s.slice(0, textStart) + textMethod + s.slice(iconStart);
  }

  // Image-first icon rendering.
  const drawStart = s.indexOf('  drawIcon(');
  const drawHeaderStart = s.indexOf('\n  drawHeader(', drawStart);
  if (drawStart >= 0 && drawHeaderStart > drawStart) {
    const drawMethod = `  drawIcon(
    ctx,
    name,
    x,
    y,
    size,
    fallback
  ) {
    const mapped =
      V43_PROPERTY_ICONS[name];

    const libImage =
      mapped
        ? resourceManager.getImage(
            'v43_icon_' + mapped
          )
        : null;

    if (libImage) {
      ctx.drawImage(
        libImage,
        x,
        y,
        size,
        size
      );
      return;
    }

    const image =
      resourceManager.getImage(
        'property_icons_01'
      );
    const region =
      propertyIconAtlas.icons[name];

    if (image && region) {
      ctx.drawImage(
        image,
        region.x,
        region.y,
        region.w,
        region.h,
        x,
        y,
        size,
        size
      );
      return;
    }

    this.roundedRect(
      ctx,
      x,
      y,
      size,
      size,
      Math.max(4, size * 0.23),
      '#EEE2D3'
    );
    this.text(
      ctx,
      fallback || '·',
      x + size / 2,
      y + size / 2,
      Math.max(5, size * 0.32),
      COLORS.navy,
      '700',
      'center'
    );
  }
`;
    s = s.slice(0, drawStart) + drawMethod + s.slice(drawHeaderStart);
  }

  // Header now uses an actual Library/premium city image like the reference.
  const headerStart = s.indexOf('  drawHeader(');
  const districtTabsStart = s.indexOf('\n  drawDistrictTabs(', headerStart);
  if (headerStart >= 0 && districtTabsStart > headerStart) {
    const headerMethod = `  drawHeader(
    ctx,
    title,
    subtitle,
    backId
  ) {
    const h = 66;
    const headerImage =
      resourceManager.getImage(
        'v43_property_header'
      );

    if (headerImage) {
      ctx.save();
      ctx.drawImage(
        headerImage,
        0,
        0,
        DESIGN_W,
        h
      );
      ctx.fillStyle =
        'rgba(2,42,64,0.64)';
      ctx.fillRect(
        0,
        0,
        DESIGN_W,
        h
      );
      ctx.restore();
    } else {
      ctx.fillStyle = COLORS.navy2;
      ctx.fillRect(0, 0, DESIGN_W, h);
    }

    if (backId) {
      this.roundedRect(
        ctx,
        10,
        13,
        46,
        34,
        10,
        'rgba(3,55,80,0.88)',
        'rgba(255,255,255,0.25)'
      );
      this.text(
        ctx,
        '‹',
        33,
        30,
        20,
        '#FFE070',
        '800',
        'center'
      );
      this.addButton(
        backId,
        6,
        8,
        54,
        44
      );
    }

    const textX = backId ? 69 : 15;
    this.text(
      ctx,
      title,
      textX,
      21,
      15,
      COLORS.white,
      '800'
    );
    this.text(
      ctx,
      subtitle || '',
      textX,
      44,
      5.6,
      'rgba(255,255,255,0.82)',
      '600'
    );
    this.text(
      ctx,
      money(
        gameState.getPlayer().cash
      ),
      377,
      20,
      10,
      '#FFE37A',
      '800',
      'right'
    );

    const time =
      gameState.getTime();
    this.text(
      ctx,
      '第' +
        time.year +
        '年 ' +
        time.month +
        '月' +
        time.day +
        '日',
      377,
      43,
      5.4,
      '#E1ECF0',
      '600',
      'right'
    );
  }
`;
    s = s.slice(0, headerStart) + headerMethod + s.slice(districtTabsStart);
  }

  // Listing cards: actual storefront photos on the left.
  const cardStart = s.indexOf('  drawListingCard(');
  const pagerStart = s.indexOf('\n  drawPager(', cardStart);
  if (cardStart >= 0 && pagerStart > cardStart) {
    const cardMethod = `  drawListingCard(
    ctx,
    item,
    x,
    y,
    w,
    h
  ) {
    const hot =
      item.watchers >= 4 ||
      item.competitorCount >= 2;

    const isNew =
      item.daysOnMarket <= 3;

    const isCut =
      item.priceChangeRate < -0.01;

    this.roundedRect(
      ctx,
      x,
      y,
      w,
      h,
      13,
      COLORS.panel,
      '#D7CABC'
    );

    const imageIndex =
      Math.abs(
        String(item.marketKey || item.address)
          .split('')
          .reduce(
            (sum, ch) =>
              sum + ch.charCodeAt(0),
            0
          )
      ) %
      5;

    const photo =
      resourceManager.getImage(
        'v43_storefront_' +
        imageIndex
      );

    if (photo) {
      ctx.save();
      this.roundedPath(
        ctx,
        x + 8,
        y + 8,
        105,
        h - 16,
        9
      );
      ctx.clip();
      ctx.drawImage(
        photo,
        x + 8,
        y + 8,
        105,
        h - 16
      );
      ctx.restore();
    }

    let badgeX =
      x + 14;

    if (isNew) {
      badgeX +=
        this.drawBadge(
          ctx,
          '新上架',
          badgeX,
          y + 10,
          '#E4F0E8',
          COLORS.green
        ) + 4;
    }

    if (isCut) {
      badgeX +=
        this.drawBadge(
          ctx,
          '租金低',
          badgeX,
          y + 10,
          '#E7F2EA',
          COLORS.green
        ) + 4;
    }

    if (hot) {
      this.drawBadge(
        ctx,
        '多人关注',
        badgeX,
        y + 10,
        '#FFF0DD',
        COLORS.orange
      );
    }

    const tx =
      x + 123;

    this.text(
      ctx,
      item.address,
      tx,
      y + 22,
      9.2,
      COLORS.text,
      '800'
    );

    this.text(
      ctx,
      item.propertyTypeName +
        ' · ' +
        item.layoutTypeName +
        ' · ' +
        item.floor,
      tx,
      y + 39,
      5.2,
      COLORS.muted,
      '600'
    );

    this.text(
      ctx,
      money(
        item.askingMonthlyRent
      ),
      x + w - 12,
      y + 21,
      11.5,
      COLORS.red,
      '800',
      'right'
    );

    this.text(
      ctx,
      '/月',
      x + w - 12,
      y + 39,
      5.2,
      COLORS.muted,
      '600',
      'right'
    );

    const metricY =
      y + 50;

    const metrics = [
      ['area', item.grossArea + '㎡'],
      ['frontage', item.frontage + 'm'],
      ['competitor', item.competitorCount + '人']
    ];

    for (
      let i = 0;
      i < metrics.length;
      i++
    ) {
      const mx =
        tx + i * 62;
      this.drawIcon(
        ctx,
        metrics[i][0],
        mx,
        metricY,
        17,
        ''
      );
      this.text(
        ctx,
        metrics[i][1],
        mx + 21,
        metricY + 8.5,
        5.7,
        COLORS.text,
        '700'
      );
    }

    this.drawHardwareMini(
      ctx,
      item,
      tx,
      y + 74
    );

    this.text(
      ctx,
      '入场约 ' +
        money(
          item.liveUpfrontCash
        ),
      tx,
      y + h - 15,
      5.1,
      COLORS.red,
      '700'
    );

    this.text(
      ctx,
      '详情 ›',
      x + w - 12,
      y + h - 15,
      6.4,
      COLORS.navy,
      '800',
      'right'
    );

    this.addButton(
      'listing:' +
        item.marketKey,
      x,
      y,
      w,
      h
    );
  }
`;
    s = s.slice(0, cardStart) + cardMethod + s.slice(pagerStart);
  }

  // Detail page one: image-led first card instead of a text-only card.
  const detailStart = s.indexOf('  renderDetailPageOne(');
  const detail2Start = s.indexOf('\n  renderDetailPageTwo(', detailStart);
  if (detailStart >= 0 && detail2Start > detailStart) {
    const detailMethod = `  renderDetailPageOne(
    ctx,
    item
  ) {
    const y0 = 76;

    this.roundedRect(
      ctx,
      10,
      y0,
      370,
      128,
      14,
      COLORS.panel,
      COLORS.line
    );

    const imageIndex =
      Math.abs(
        String(item.marketKey || item.address)
          .split('')
          .reduce(
            (sum, ch) =>
              sum + ch.charCodeAt(0),
            0
          )
      ) %
      5;

    const photo =
      resourceManager.getImage(
        'v43_storefront_' +
        imageIndex
      );

    if (photo) {
      ctx.save();
      this.roundedPath(
        ctx,
        18,
        y0 + 8,
        136,
        112,
        10
      );
      ctx.clip();
      ctx.drawImage(
        photo,
        18,
        y0 + 8,
        136,
        112
      );
      ctx.restore();
    }

    this.text(
      ctx,
      item.address,
      166,
      y0 + 21,
      12.5,
      COLORS.text,
      '800'
    );

    this.text(
      ctx,
      item.propertyTypeName +
        ' · ' +
        item.layoutTypeName +
        ' · ' +
        item.floor,
      166,
      y0 + 42,
      5.5,
      COLORS.muted,
      '600'
    );

    this.text(
      ctx,
      money(
        item.askingMonthlyRent
      ) +
        '/月',
      366,
      y0 + 22,
      14,
      COLORS.red,
      '800',
      'right'
    );

    this.text(
      ctx,
      '签约前约 ' +
        money(
          item.liveUpfrontCash
        ),
      366,
      y0 + 45,
      5.5,
      COLORS.orange,
      '700',
      'right'
    );

    this.text(
      ctx,
      '挂牌 ' +
        item.daysOnMarket +
        '天 · 关注 ' +
        item.watchers +
        ' · ' +
        item.competitorCount +
        '个竞争者',
      166,
      y0 + 66,
      5.4,
      COLORS.muted,
      '600'
    );

    const fastMetrics = [
      ['预算友好', item.liveUpfrontCash <= 80000 ? '高' : '中'],
      ['堂食能力', item.seatEstimate + '席'],
      ['外卖潜力', item.riderAccess >= 60 ? '高' : '中'],
      ['改造难度', item.riskLevel <= 1 ? '低' : '中']
    ];

    for (
      let i = 0;
      i < 4;
      i++
    ) {
      const mx =
        166 + (i % 2) * 100;
      const my =
        y0 + 83 + Math.floor(i / 2) * 20;

      this.text(
        ctx,
        fastMetrics[i][0],
        mx,
        my,
        4.6,
        COLORS.muted,
        '600'
      );

      this.text(
        ctx,
        fastMetrics[i][1],
        mx + 61,
        my,
        5.4,
        i === 3
          ? COLORS.orange
          : COLORS.green,
        '800'
      );
    }

    const gridY = 214;
    const metricW = 116;

    this.drawDetailMetric(ctx, 'area', '建筑面积', item.grossArea + '㎡', 10, gridY, metricW);
    this.drawDetailMetric(ctx, 'layout', '可用面积', item.usableArea + '㎡', 137, gridY, metricW);
    this.drawDetailMetric(ctx, 'floor', '估算座位', item.seatEstimate + '席', 264, gridY, metricW);
    this.drawDetailMetric(ctx, 'frontage', '门面宽', item.frontage + 'm', 10, gridY + 57, metricW);
    this.drawDetailMetric(ctx, 'depth', '进深', item.depth + 'm', 137, gridY + 57, metricW);
    this.drawDetailMetric(ctx, 'layout', '层高', item.ceilingHeight + 'm', 264, gridY + 57, metricW);

    this.roundedRect(
      ctx,
      10,
      gridY + 119,
      370,
      77,
      13,
      COLORS.panel,
      COLORS.line
    );

    this.text(
      ctx,
      '餐饮硬件条件',
      22,
      gridY + 136,
      7.5,
      COLORS.text,
      '800'
    );

    const boolY =
      gridY + 145;

    const bools = [
      ['exhaust', '排烟', item.exhaust],
      ['gas', '燃气', item.gas],
      ['power', '三相电', item.threePhase],
      ['drainage', '排水', item.drainage],
      ['grease', '隔油', item.greaseTrap],
      ['fire', '消防', item.fireSprinkler]
    ];

    for (
      let i = 0;
      i < bools.length;
      i++
    ) {
      this.drawBoolCell(
        ctx,
        bools[i][0],
        bools[i][1],
        bools[i][2],
        16 + i * 61,
        boolY
      );
    }

    const utilityY =
      gridY + 207;

    this.roundedRect(
      ctx,
      10,
      utilityY,
      370,
      90,
      13,
      COLORS.panel,
      COLORS.line
    );

    this.text(
      ctx,
      '经营能力评估',
      22,
      utilityY + 17,
      7.5,
      COLORS.text,
      '800'
    );

    this.text(
      ctx,
      '建议厨房 ' +
        item.kitchenSuggestedArea +
        '㎡ · 堂食 ' +
        item.diningSuggestedArea +
        '㎡ · 电容量 ' +
        item.electricCapacityKw +
        'kW',
      22,
      utilityY + 39,
      5.2,
      COLORS.text,
      '600'
    );

    this.text(
      ctx,
      '可见度 ' +
        item.visibility +
        ' · 停车 ' +
        item.parkingScore +
        ' · 骑手便利 ' +
        item.riderAccess +
        ' · 卸货 ' +
        item.loadingAccess,
      22,
      utilityY + 60,
      5.2,
      COLORS.text,
      '600'
    );

    this.text(
      ctx,
      '水压 ' +
        item.waterPressure +
        ' · 夜间容忍 ' +
        item.noiseTolerance +
        ' · 独立卫生间 ' +
        (
          item.independentToilet
            ? '有'
            : '无'
        ),
      22,
      utilityY + 78,
      5.2,
      COLORS.text,
      '600'
    );
  }
`;
    s = s.slice(0, detailStart) + detailMethod + s.slice(detail2Start);
  }

  fs.writeFileSync(file, s, 'utf8');
}

patchStoreScene();
patchPropertyScene();

try {
  fs.unlinkSync(__filename);
} catch (error) {}

console.log('V43 reference image UI applied');
