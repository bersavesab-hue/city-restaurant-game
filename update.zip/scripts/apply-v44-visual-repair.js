'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function replaceBlock(source, startToken, endToken, replacement, label) {
  const start = source.indexOf(startToken);
  const end = source.indexOf(endToken, start + startToken.length);

  if (start < 0 || end < 0 || end <= start) {
    throw new Error(
      'V44：无法定位 ' + label +
      ' [' + startToken + ' -> ' + endToken + ']'
    );
  }

  return (
    source.slice(0, start) +
    replacement +
    '\n\n' +
    source.slice(end)
  );
}

function patchShopScene() {
  const file = path.join(
    ROOT,
    'src/scenes/shopScene.js'
  );

  let source = fs.readFileSync(
    file,
    'utf8'
  );

  if (source.includes('V44_PROPERTY_VISUAL_REPAIR')) {
    return;
  }

  source = source.replace(
    '// V43_PROPERTY_IMAGE_REBUILD',
    '// V43_PROPERTY_IMAGE_REBUILD\n// V44_PROPERTY_VISUAL_REPAIR'
  );

  // V44.1: clean the legacy V43 semantic table too.
  // Historical tests still require this constant to exist, but the meanings
  // must no longer point exhaust/gas/power at unrelated glossy assets.
  source = source.replace(
    /const V43_PROPERTY_ICONS = \{[\s\S]*?\};/,
`const V43_PROPERTY_ICONS = {
  area: 'area',
  frontage: 'frontage',
  exhaust: 'exhaust',
  gas: 'gas',
  power: 'power',
  competitor: 'competitor',
  event: 'event',
  filter: 'filter',
  sort: 'sort',
  lease: 'lease',
  floor: 'floor',
  layout: 'layout',
  warning: 'warning',
  broker: 'broker',
  landlord: 'landlord'
};`
  );

  // Unified compact currency: ¥5万 / ¥12.6亿, while small rents remain ¥3,900.
  source = replaceBlock(
    source,
    'function money(',
    'function percent(',
`function money(
  value
) {
  const n =
    Number(value) || 0;

  const sign =
    n < 0
      ? '-'
      : '';

  const abs =
    Math.abs(n);

  function trim(v, decimals) {
    return Number(v)
      .toFixed(decimals)
      .replace(/\\.0+$/, '')
      .replace(/(\\.\\d*?[1-9])0+$/, '$1');
  }

  if (abs >= 1000000000000) {
    const v = abs / 1000000000000;
    return sign + '¥' +
      trim(v, v >= 100 ? 0 : v >= 10 ? 1 : 2) +
      '万亿';
  }

  if (abs >= 100000000) {
    const v = abs / 100000000;
    return sign + '¥' +
      trim(v, v >= 100 ? 0 : v >= 10 ? 1 : 2) +
      '亿';
  }

  if (abs >= 10000) {
    const v = abs / 10000;
    return sign + '¥' +
      trim(v, v >= 100 ? 0 : v >= 10 ? 1 : 2) +
      '万';
  }

  return sign + '¥' +
    Math.round(abs).toLocaleString();
}`,
    'money'
  );

  // Load clean V44 standalone icons; V43 resources are retained for historical
  // regression compatibility but no longer drive small property hardware icons.
  const enterToken =
`  enter(
    payload
  ) {`;

  const enterPos = source.indexOf(enterToken);
  if (enterPos < 0) {
    throw new Error('V44：找不到 shopScene.enter');
  }

  const enterInsertPos =
    enterPos + enterToken.length;

  source =
    source.slice(0, enterInsertPos) +
`
    ['money', 'target', 'bulletin', 'star', 'gift']
      .forEach(name => {
        resourceManager
          .loadImage(
            'v44_glossy_' + name,
            'assets/images/v44_glossy/' + name + '.png',
            'v44-glossy'
          )
          .catch(() => {});
      });
` +
    source.slice(enterInsertPos);

  // Critical fix: never use the old explore_banner with embedded text as a
  // property header background.
  source = source.replace(
    "'assets/images/premium/store/explore_banner.jpg'",
    "'assets/images/v32_home/home_background.jpg'"
  );

  // Stronger but still compact text. Headings are deliberately heavier so the
  // page feels closer to the saturated reference design.
  source = replaceBlock(
    source,
    '  text(\n',
    '  drawIcon(',
`  text(
    ctx,
    text,
    x,
    y,
    size,
    color,
    weight,
    align
  ) {
    ctx.save();

    ctx.fillStyle =
      color ||
      COLORS.text;

    const readableSize =
      Math.max(
        4.8,
        Number(size) || 5.5
      );

    const rawWeight =
      String(
        weight || '500'
      );

    const finalWeight =
      rawWeight === '800'
        ? '900'
        : rawWeight === '700'
          ? '800'
          : rawWeight;

    ctx.font =
      finalWeight +
      ' ' +
      readableSize +
      'px "Noto Sans SC","Microsoft YaHei",sans-serif';

    ctx.textAlign =
      align || 'left';

    ctx.textBaseline =
      'middle';

    if (
      readableSize >= 10 &&
      finalWeight === '900'
    ) {
      ctx.shadowColor =
        'rgba(0,0,0,0.12)';
      ctx.shadowBlur = 0.8;
    }

    ctx.fillText(
      String(text),
      x,
      y
    );

    ctx.restore();
  }`,
    'shopScene.text'
  );

  // Semantic property atlas FIRST. This removes the giant wrench, angry-face
  // and half-cut icons from hardware rows. Only three macro meanings use
  // carefully re-extracted glossy icons.
  source = replaceBlock(
    source,
    '  drawIcon(',
    '  drawHeader(',
`  drawIcon(
    ctx,
    name,
    x,
    y,
    size,
    fallback
  ) {
    const glossyMap = {
      rent: 'money',
      hot: 'target',
      event: 'bulletin'
    };

    const glossyName =
      glossyMap[name];

    const glossyImage =
      glossyName
        ? resourceManager.getImage(
            'v44_glossy_' +
            glossyName
          )
        : null;

    if (glossyImage) {
      ctx.drawImage(
        glossyImage,
        x,
        y,
        size,
        size
      );
      return;
    }

    const aliases = {
      area: 'area',
      frontage: 'frontage',
      exhaust: 'exhaust',
      gas: 'gas',
      power: 'power',
      competitor: 'competitor',
      filter: 'filter',
      sort: 'sort',
      lease: 'lease',
      floor: 'floor',
      layout: 'layout',
      warning: 'warning',
      broker: 'broker',
      landlord: 'landlord',
      drainage: 'drainage',
      grease: 'grease',
      fire: 'fire',
      depth: 'depth',
      new: 'new'
    };

    const key =
      aliases[name] ||
      name;

    const image =
      resourceManager.getImage(
        'property_icons_01'
      );

    const region =
      propertyIconAtlas.icons[
        key
      ];

    if (
      image &&
      region
    ) {
      ctx.drawImage(
        image,
        region.x,
        region.y,
        region.w,
        region.h,
        x,
        y,
        size,
        size
      );
      return;
    }

    this.roundedRect(
      ctx,
      x,
      y,
      size,
      size,
      Math.max(
        4,
        size * 0.23
      ),
      '#EEF3F5'
    );

    this.text(
      ctx,
      fallback || '·',
      x + size / 2,
      y + size / 2,
      Math.max(
        5,
        size * 0.32
      ),
      COLORS.navy,
      '700',
      'center'
    );
  }`,
    'shopScene.drawIcon'
  );

  // Clean city background + dark gradient + strong hierarchy.
  source = replaceBlock(
    source,
    '  drawHeader(',
    '  drawDistrictTabs(',
`  drawHeader(
    ctx,
    title,
    subtitle,
    backId
  ) {
    const h = 66;

    const headerImage =
      resourceManager.getImage(
        'v43_property_header'
      );

    if (headerImage) {
      ctx.save();
      ctx.drawImage(
        headerImage,
        0,
        0,
        DESIGN_W,
        h
      );

      const overlay =
        ctx.createLinearGradient(
          0,
          0,
          DESIGN_W,
          0
        );

      overlay.addColorStop(
        0,
        'rgba(2,38,59,0.82)'
      );

      overlay.addColorStop(
        0.60,
        'rgba(2,46,69,0.62)'
      );

      overlay.addColorStop(
        1,
        'rgba(2,38,59,0.78)'
      );

      ctx.fillStyle =
        overlay;

      ctx.fillRect(
        0,
        0,
        DESIGN_W,
        h
      );

      ctx.restore();
    } else {
      ctx.fillStyle =
        COLORS.navy2;

      ctx.fillRect(
        0,
        0,
        DESIGN_W,
        h
      );
    }

    ctx.fillStyle =
      '#E6B94B';

    ctx.fillRect(
      0,
      h - 1,
      DESIGN_W,
      1
    );

    if (backId) {
      this.roundedRect(
        ctx,
        10,
        13,
        46,
        34,
        10,
        'rgba(3,55,80,0.88)',
        'rgba(255,255,255,0.30)'
      );

      this.text(
        ctx,
        '‹',
        33,
        30,
        20,
        '#FFE070',
        '800',
        'center'
      );

      this.addButton(
        backId,
        6,
        8,
        54,
        44
      );
    }

    const textX =
      backId
        ? 69
        : 15;

    this.text(
      ctx,
      title,
      textX,
      20,
      14.2,
      COLORS.white,
      '800'
    );

    this.text(
      ctx,
      subtitle || '',
      textX,
      43,
      5.3,
      '#EAF3F6',
      '600'
    );

    const moneyIcon =
      resourceManager.getImage(
        'v44_glossy_money'
      );

    if (moneyIcon) {
      ctx.drawImage(
        moneyIcon,
        292,
        9,
        24,
        24
      );
    }

    this.text(
      ctx,
      money(
        gameState
          .getPlayer()
          .cash
      ),
      377,
      19,
      10,
      '#FFE37A',
      '800',
      'right'
    );

    const time =
      gameState.getTime();

    this.text(
      ctx,
      '第' +
        time.year +
        '年 ' +
        time.month +
        '月' +
        time.day +
        '日',
      377,
      43,
      5.1,
      '#E1ECF0',
      '600',
      'right'
    );
  }`,
    'shopScene.drawHeader'
  );

  // Summary card gets four semantic icons + stronger values.
  source = replaceBlock(
    source,
    '  drawSummary(',
    '  getDistrictEvents(',
`  drawSummary(
    ctx,
    y
  ) {
    const summary =
      this.cachedDistrictSummary;

    if (!summary) {
      return;
    }

    this.roundedRect(
      ctx,
      8,
      y,
      374,
      61,
      13,
      COLORS.panel,
      COLORS.line
    );

    const metrics = [
      [
        'new',
        '挂牌',
        summary.activeListingCount +
          '套',
        COLORS.navy
      ],
      [
        'rent',
        '均租',
        money(
          summary.averageAskingRent
        ),
        COLORS.red
      ],
      [
        'event',
        '均挂',
        summary.averageDaysOnMarket +
          '天',
        COLORS.blue
      ],
      [
        'hot',
        '最热',
        summary.hottestStreet
          ? summary.hottestStreet.name
          : '--',
        COLORS.orange
      ]
    ];

    for (
      let i = 0;
      i < metrics.length;
      i++
    ) {
      const x =
        16 +
        i * 92;

      if (i > 0) {
        ctx.fillStyle =
          '#E6DDD2';

        ctx.fillRect(
          x - 5,
          y + 12,
          1,
          37
        );
      }

      this.drawIcon(
        ctx,
        metrics[i][0],
        x,
        y + 14,
        19,
        ''
      );

      this.text(
        ctx,
        metrics[i][1],
        x + 25,
        y + 18,
        4.9,
        COLORS.muted,
        '700'
      );

      this.text(
        ctx,
        metrics[i][2],
        x + 25,
        y + 39,
        8.2,
        metrics[i][3],
        '800'
      );
    }
  }`,
    'shopScene.drawSummary'
  );

  // Hardware becomes three compact semantic chips instead of three oversized
  // unrelated glossy images.
  source = replaceBlock(
    source,
    '  drawHardwareMini(',
    '  drawListingCard(',
`  drawHardwareMini(
    ctx,
    item,
    x,
    y
  ) {
    const hardware = [
      [
        'exhaust',
        '排烟',
        item.exhaust
      ],
      [
        'gas',
        '燃气',
        item.gas
      ],
      [
        'power',
        '三相',
        item.threePhase
      ]
    ];

    for (
      let i = 0;
      i < hardware.length;
      i++
    ) {
      const cellX =
        x +
        i * 45;

      const ok =
        Boolean(
          hardware[i][2]
        );

      this.roundedRect(
        ctx,
        cellX,
        y,
        41,
        19,
        8,
        ok
          ? '#EAF7F1'
          : '#FFF0ED',
        ok
          ? '#B8DFCD'
          : '#E9C2BC'
      );

      this.drawIcon(
        ctx,
        hardware[i][0],
        cellX + 4,
        y + 4,
        11,
        ''
      );

      this.text(
        ctx,
        hardware[i][1],
        cellX + 18,
        y + 9.5,
        4.2,
        ok
          ? COLORS.green
          : COLORS.red,
        '800'
      );

      this.text(
        ctx,
        ok
          ? '✓'
          : '×',
        cellX + 36,
        y + 9.5,
        4.8,
        ok
          ? COLORS.green
          : COLORS.red,
        '800',
        'center'
      );
    }
  }`,
    'shopScene.drawHardwareMini'
  );

  fs.writeFileSync(
    file,
    source,
    'utf8'
  );
}

function patchStoreScene() {
  const file = path.join(
    ROOT,
    'src/scenes/storeScene.js'
  );

  let source =
    fs.readFileSync(
      file,
      'utf8'
    );

  if (source.includes('V44_STORE_VISUAL_REPAIR')) {
    return;
  }

  source = source.replace(
    '// V43_REFERENCE_IMAGE_UI',
    '// V43_REFERENCE_IMAGE_UI\n// V44_STORE_VISUAL_REPAIR'
  );

  if (!source.includes('const V44_GLOSSY_ICONS')) {
    source = source.replace(
      'const COLORS = {',
`const V44_GLOSSY_ICONS = {
  rent: 'money',
  hot: 'target',
  event: 'bulletin'
};

const V44_PROPERTY_ALIASES = {
  visibility: 'visibility',
  layout: 'layout',
  broker: 'broker',
  new: 'new',
  rider: 'rider',
  route: 'sort',
  store: 'new',
  warning: 'warning',
  lease: 'lease',
  contract: 'lease'
};

const COLORS = {`
    );
  }

  // New safe standalone icons + clean city header.
  const enterToken =
    '  enter(params) {';

  const enterPos =
    source.indexOf(
      enterToken
    );

  if (enterPos < 0) {
    throw new Error(
      'V44：找不到 storeScene.enter'
    );
  }

  const insertPos =
    enterPos +
    enterToken.length;

  source =
    source.slice(
      0,
      insertPos
    ) +
`
    ['money', 'target', 'bulletin', 'star', 'gift']
      .forEach(name => {
        resourceManager
          .loadImage(
            'v44_glossy_' + name,
            'assets/images/v44_glossy/' + name + '.png',
            'v44-glossy'
          )
          .catch(() => {});
      });

    resourceManager
      .loadImage(
        'v44_store_header',
        'assets/images/v32_home/home_background.jpg',
        'v44-store-header'
      )
      .catch(() => {});
` +
    source.slice(
      insertPos
    );

  source = replaceBlock(
    source,
    'function storeText(',
    'function storeDivider(',
`function storeText(
  ctx,
  value,
  x,
  y,
  size,
  color,
  weight,
  align
) {
  ctx.save();

  ctx.fillStyle =
    color ||
    '#123A55';

  const rawWeight =
    String(
      weight || '500'
    );

  const finalWeight =
    rawWeight === '800'
      ? '900'
      : rawWeight === '700'
        ? '800'
        : rawWeight;

  const finalSize =
    Math.max(
      4.6,
      Number(size) || 5.6
    );

  ctx.font =
    finalWeight +
    ' ' +
    finalSize +
    'px "Noto Sans SC","Microsoft YaHei",sans-serif';

  ctx.textAlign =
    align || 'left';

  ctx.textBaseline =
    'middle';

  if (
    finalSize >= 10 &&
    finalWeight === '900'
  ) {
    ctx.shadowColor =
      'rgba(0,0,0,0.14)';
    ctx.shadowBlur =
      0.8;
  }

  ctx.fillText(
    String(
      value == null
        ? ''
        : value
    ),
    x,
    y
  );

  ctx.restore();
}`,
    'storeText'
  );

  source = replaceBlock(
    source,
    '  drawPropertyIcon(',
    '  getListingScore(',
`  drawPropertyIcon(
    ctx,
    name,
    x,
    y,
    size,
    fallback,
    tint
  ) {
    const glossyName =
      V44_GLOSSY_ICONS[
        name
      ];

    const glossyImage =
      glossyName
        ? resourceManager.getImage(
            'v44_glossy_' +
            glossyName
          )
        : null;

    if (glossyImage) {
      ctx.drawImage(
        glossyImage,
        x,
        y,
        size,
        size
      );
      return;
    }

    const alias =
      V44_PROPERTY_ALIASES[
        name
      ] ||
      name;

    const image =
      resourceManager.getImage(
        'property_icons_01'
      );

    const region =
      propertyIconAtlas.icons[
        alias
      ];

    if (
      image &&
      region
    ) {
      ctx.drawImage(
        image,
        region.x,
        region.y,
        region.w,
        region.h,
        x,
        y,
        size,
        size
      );
      return;
    }

    ctx.beginPath();

    ctx.arc(
      x + size / 2,
      y + size / 2,
      size / 2,
      0,
      Math.PI * 2
    );

    ctx.fillStyle =
      tint ||
      '#E8F4F9';

    ctx.fill();

    storeText(
      ctx,
      fallback || '·',
      x + size / 2,
      y + size / 2,
      Math.max(
        5,
        size * 0.32
      ),
      COLORS.navy,
      '800',
      'center'
    );
  }`,
    'storeScene.drawPropertyIcon'
  );

  source = replaceBlock(
    source,
    '  drawScoreStars(',
    '  getShops()',
`  drawScoreStars(
    ctx,
    score,
    x,
    y
  ) {
    const rounded =
      Math.round(
        clamp(
          score,
          0,
          5
        )
      );

    const star =
      resourceManager.getImage(
        'v44_glossy_star'
      );

    for (
      let i = 0;
      i < 5;
      i++
    ) {
      if (star) {
        ctx.save();

        ctx.globalAlpha =
          i < rounded
            ? 1
            : 0.18;

        ctx.drawImage(
          star,
          x + i * 9,
          y - 5,
          8,
          8
        );

        ctx.restore();
      } else {
        storeText(
          ctx,
          '★',
          x + i * 9,
          y,
          5.4,
          i < rounded
            ? '#F7B916'
            : '#D7D9D9',
          '800'
        );
      }
    }
  }`,
    'storeScene.drawScoreStars'
  );

  source = replaceBlock(
    source,
    '  drawHeader(',
    '  drawActionButton(',
`  drawHeader(
    ctx,
    options
  ) {
    const opts =
      options || {};

    const headerImage =
      resourceManager.getImage(
        'v44_store_header'
      );

    if (headerImage) {
      ui.coverImage(
        ctx,
        headerImage,
        0,
        0,
        DESIGN_W,
        86,
        0,
        null
      );
    } else {
      ui.coverImage(
        ctx,
        visualAssetSystem.get(
          'premium_explore_banner'
        ),
        0,
        0,
        DESIGN_W,
        86,
        0,
        null
      );
    }

    const overlay =
      ctx.createLinearGradient(
        0,
        0,
        DESIGN_W,
        0
      );

    overlay.addColorStop(
      0,
      'rgba(2,37,59,0.84)'
    );

    overlay.addColorStop(
      0.62,
      'rgba(2,47,72,0.56)'
    );

    overlay.addColorStop(
      1,
      'rgba(2,37,59,0.80)'
    );

    ctx.fillStyle =
      overlay;

    ctx.fillRect(
      0,
      0,
      DESIGN_W,
      86
    );

    ui.card(
      ctx,
      10,
      12,
      38,
      38,
      {
        radius: 11,
        fill:
          'rgba(3,52,80,0.91)',
        stroke:
          'rgba(255,255,255,0.30)',
        shadow: false
      }
    );

    storeText(
      ctx,
      '‹',
      29,
      31,
      18,
      '#FFE070',
      '800',
      'center'
    );

    this.addButton(
      'header:back',
      7,
      9,
      44,
      44
    );

    const cityName =
      gameState.getCityName();

    storeText(
      ctx,
      cityName,
      58,
      20,
      15,
      COLORS.white,
      '800'
    );

    storeText(
      ctx,
      opts.subtitle ||
        '打造属于你的美食帝国',
      58,
      39,
      5.8,
      '#ECF5F8',
      '600'
    );

    const cash =
      compactMoney(
        gameState
          .getPlayer()
          .cash
      );

    ui.card(
      ctx,
      281,
      11,
      94,
      42,
      {
        radius: 12,
        fill:
          'rgba(2,53,83,0.94)',
        stroke:
          'rgba(107,208,247,0.40)',
        shadow: false
      }
    );

    const moneyIcon =
      resourceManager.getImage(
        'v44_glossy_money'
      );

    if (moneyIcon) {
      ctx.drawImage(
        moneyIcon,
        289,
        16,
        23,
        23
      );
    }

    storeText(
      ctx,
      cash,
      336,
      23,
      cash.length > 8
        ? 8.4
        : 9.8,
      '#FFE57A',
      '800',
      'center'
    );

    storeText(
      ctx,
      '可用资金',
      333,
      42,
      5.0,
      '#DCECF2',
      '600',
      'center'
    );

    const bulletin =
      simulationSystem
        .getBulletin();

    ui.card(
      ctx,
      8,
      59,
      374,
      23,
      {
        radius: 11,
        fill:
          'rgba(3,48,74,0.93)',
        stroke:
          'rgba(83,195,238,0.32)',
        shadow: false
      }
    );

    const speaker =
      resourceManager.getImage(
        'v44_glossy_bulletin'
      );

    if (speaker) {
      ctx.drawImage(
        speaker,
        15,
        62,
        17,
        17
      );
    }

    storeText(
      ctx,
      '城市动态',
      38,
      70.5,
      5.6,
      '#FFD35E',
      '800'
    );

    storeText(
      ctx,
      shortText(
        (
          bulletin.title ||
          ''
        ) +
        ' · ' +
        (
          bulletin.detail ||
          ''
        ),
        47
      ),
      87,
      70.5,
      5.0,
      COLORS.white,
      '600'
    );
  }`,
    'storeScene.drawHeader'
  );

  // Make the top three facts visually different and semantically clearer.
  const metricsStart =
    source.indexOf(
      '    const topMetrics = ['
    );

  if (metricsStart >= 0) {
    const metricsEnd =
      source.indexOf(
        '    ];',
        metricsStart
      );

    if (metricsEnd > metricsStart) {
      let part =
        source.slice(
          metricsStart,
          metricsEnd + 6
        );

      part =
        part.replace(
          "icon: 'visibility'",
          "icon: 'hot'"
        );

      const hotIndex =
        part.lastIndexOf(
          "icon: 'hot'"
        );

      if (hotIndex >= 0) {
        part =
          part.slice(
            0,
            hotIndex
          ) +
          "icon: 'lease'" +
          part.slice(
            hotIndex +
            "icon: 'hot'".length
          );
      }

      source =
        source.slice(
          0,
          metricsStart
        ) +
        part +
        source.slice(
          metricsEnd + 6
        );
    }
  }

  // Replace the sharp text stars inside the three recommendation cards.
  const oldStarBlock =
`      for (
        let s = 0;
        s < 5;
        s++
      ) {
        storeText(
          ctx,
          '★',
          x + 7 + s * 9,
          481,
          5.6,
          s <
          Math.round(score)
            ? '#F7B916'
            : '#D8D9D9',
          '800'
        );
      }`;

  if (
    source.includes(
      oldStarBlock
    )
  ) {
    source =
      source.replace(
        oldStarBlock,
`      this.drawScoreStars(
        ctx,
        score,
        x + 7,
        481
      );`
      );
  }

  // Add richer section-heading icons while keeping all data dynamic.
  source = source.replace(
`    storeText(
      ctx,
      '开店流程',
      22,
      296,
      7.5,
      COLORS.text,
      '800'
    );`,
`    this.drawPropertyIcon(
      ctx,
      'new',
      20,
      287,
      18,
      '',
      '#EEF4F6'
    );

    storeText(
      ctx,
      '开店流程',
      44,
      296,
      7.5,
      COLORS.text,
      '800'
    );`
  );

  source = source.replace(
`    storeText(
      ctx,
      '推荐房源',
      22,
      365,
      8.6,
      COLORS.text,
      '800'
    );`,
`    this.drawPropertyIcon(
      ctx,
      'hot',
      20,
      356,
      18,
      '',
      '#FFF3D8'
    );

    storeText(
      ctx,
      '推荐房源',
      44,
      365,
      8.6,
      COLORS.text,
      '800'
    );`
  );

  source = source.replace(
`    storeText(
      ctx,
      '今日机会',
      22,
      bottomY + 18,
      7.5,
      COLORS.text,
      '800'
    );`,
`    this.drawPropertyIcon(
      ctx,
      'event',
      20,
      bottomY + 9,
      18,
      '',
      '#FFF0E0'
    );

    storeText(
      ctx,
      '今日机会',
      44,
      bottomY + 18,
      7.5,
      COLORS.text,
      '800'
    );`
  );

  source = source.replace(
`    storeText(
      ctx,
      '市场动态',
      211,
      bottomY + 18,
      7.5,
      COLORS.text,
      '800'
    );`,
`    this.drawPropertyIcon(
      ctx,
      'rent',
      207,
      bottomY + 9,
      18,
      '',
      '#EFF7F0'
    );

    storeText(
      ctx,
      '市场动态',
      231,
      bottomY + 18,
      7.5,
      COLORS.text,
      '800'
    );`
  );

  fs.writeFileSync(
    file,
    source,
    'utf8'
  );
}

patchShopScene();
patchStoreScene();

try {
  fs.unlinkSync(__filename);
} catch (error) {}

console.log(
  'V44 visual repair applied'
);
