'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const root = path.resolve(__dirname, '..');
const marker = '.update-recovery-v051';
const workflow = String(process.env.GITHUB_WORKFLOW || '');
const inActions = process.env.GITHUB_ACTIONS === 'true';

function run(args, options = {}) {
  return cp.spawnSync('git', args, {
    cwd: root,
    encoding: 'utf8',
    stdio: options.inherit ? 'inherit' : 'pipe'
  });
}

function sleep(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function remoteHasMarker() {
  const r = run(['show', `origin/main:${marker}`]);
  return r.status === 0;
}

function deleteLegacyUpdater() {
  const legacy = path.join(root, '.github', 'workflows', 'apply-update.yml');
  if (fs.existsSync(legacy)) fs.rmSync(legacy, { force: true });
}

if (!(inActions && workflow === 'Apply Update ZIP')) {
  process.exit(0);
}

// During the one-time repair, an old fast updater may race the validated updater.
// If it has already committed this package, align to that commit, then keep only
// the intended deletion of the obsolete updater. This avoids a non-fast-forward push.
let found = false;
for (let i = 0; i < 20; i += 1) {
  run(['fetch', 'origin', 'main']);
  if (remoteHasMarker()) {
    found = true;
    break;
  }
  sleep(1500);
}

if (found) {
  const reset = run(['reset', '--hard', 'origin/main'], { inherit: true });
  if (reset.status !== 0) process.exit(reset.status || 1);
  deleteLegacyUpdater();
  console.log('[ci-reconcile] 已对齐旧 updater 的提交，并保留删除旧 updater 的变更。');
} else {
  deleteLegacyUpdater();
  console.log('[ci-reconcile] 未发现并行 updater 提交，继续由当前验证工作流完成更新。');
}
