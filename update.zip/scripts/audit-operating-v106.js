'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const root = process.cwd();
const required = [
  'android/entry.js',
  'src/operating/eventCatalogV106.js',
  'src/operating/businessOperatingSystemV106.js',
  'src/operating/operatingRuntimeBridgeV106.js',
  'tests/operatingSystemsV106.test.js',
  'src/core/gameState.js',
  'src/core/timeSystem.js',
  'src/city/demandSystem.js'
];
const problems = [];
for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) problems.push('缺少文件：' + rel);
}

if (!problems.length) {
  const entry = fs.readFileSync(path.join(root, 'android/entry.js'), 'utf8');
  const bridge = fs.readFileSync(path.join(root, 'src/operating/operatingRuntimeBridgeV106.js'), 'utf8');
  const needle = "require('../src/operating/operatingRuntimeBridgeV106.js')";
  const n = entry.split(needle).length - 1;
  if (n !== 1) problems.push('Android 入口经营中枢 require 数量异常：' + n);
  if (!bridge.includes("require('../city/demandSystem.js')")) problems.push('运行时需求系统未接入');
  if (!bridge.includes('installDemandHook')) problems.push('缺少运行时需求倍率挂接');
  if (!bridge.includes('installTimeHook')) problems.push('缺少时间推进挂接');
  if (!bridge.includes('installFloatingButton')) problems.push('缺少独立经营中枢入口');
  if (!bridge.includes('renderForcedOverlay')) problems.push('缺少强制事件弹窗');
}

for (const rel of required.filter(x => x.endsWith('.js'))) {
  const f = path.join(root, rel);
  if (!fs.existsSync(f)) continue;
  const result = cp.spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' });
  if (result.status !== 0) problems.push(rel + ' 语法检查失败：' + (result.stderr || result.stdout || '').trim());
}

if (problems.length) {
  console.error('[V1.0.6 AUDIT] FAIL');
  for (const p of problems) console.error(' - ' + p);
  process.exit(1);
}

console.log('[V1.0.6 AUDIT] PASS');
console.log(' - 只修改 android/entry.js 接入点');
console.log(' - 不修改 src/main.js');
console.log(' - 不修改 src/city/demandSystem.js');
console.log(' - 不修改 package.json');
console.log(' - 事件/强制弹窗/时间暂停/需求倍率/金融/结算/员工/菜品/评分/排行/奖项：运行时接入');
