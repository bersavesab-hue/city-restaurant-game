'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const perf = require('./v094-perf-lib.js');

const ROOT = process.cwd();
const STATE_PATH = path.join(ROOT, 'scripts', '.v094-test-state.json');

function say(msg) {
  process.stdout.write(`[V0.9.4 adaptive] ${msg}\n`);
}

function fail(msg) {
  process.stderr.write(`[V0.9.4 adaptive] ${msg}\n`);
}

function readState() {
  if (!fs.existsSync(STATE_PATH)) {
    throw new Error('V0.9.4 state file missing');
  }
  return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
}

function restoreExactPackage(state) {
  const pkgPath = path.join(ROOT, 'package.json');
  const backupPkgPath = path.join(ROOT, state.packageBackupPath);
  fs.copyFileSync(backupPkgPath, pkgPath);
}

function writeVariant(state, variant) {
  const mainPath = path.join(ROOT, state.mainPath);
  const backupPath = path.join(ROOT, state.mainBackupPath);
  const base = fs.readFileSync(backupPath, 'utf8');
  const next = perf.applyVariant(base, variant);
  fs.writeFileSync(mainPath, next, 'utf8');

  const syntax = cp.spawnSync(process.execPath, ['--check', state.mainPath], {
    cwd: ROOT,
    encoding: 'utf8'
  });
  if (syntax.status !== 0) {
    throw new Error(
      `variant ${variant} syntax check failed\n${syntax.stdout || ''}${syntax.stderr || ''}`
    );
  }
}

function runShell(command, label) {
  if (typeof command !== 'string' || !command.trim()) {
    return { status: 0, stdout: '', stderr: '' };
  }

  const result = cp.spawnSync(command, {
    cwd: ROOT,
    shell: true,
    encoding: 'utf8',
    env: process.env,
    maxBuffer: 64 * 1024 * 1024
  });

  return {
    label,
    status: Number.isInteger(result.status) ? result.status : 1,
    stdout: result.stdout || '',
    stderr: result.stderr || ''
  };
}

function runOriginalLifecycle(state, variant) {
  say(`用仓库原测试生命周期验证候选方案：${variant}`);

  // 让测试读取到补丁前的原始 package.json；但不再调用 npm test，
  // 从而避免 runner 递归，也避免父 npm 的 pretest 在 runner 之前先失败。
  restoreExactPackage(state);

  const steps = [
    ['pretest', state.originalPretest],
    ['test', state.originalTest],
    ['posttest', state.originalPosttest]
  ];

  let combinedOut = '';
  let combinedErr = '';

  for (const [label, command] of steps) {
    if (!command) continue;
    const result = runShell(command, label);
    combinedOut += result.stdout;
    combinedErr += result.stderr;
    if (result.status !== 0) {
      return {
        status: result.status,
        failedStage: label,
        stdout: combinedOut,
        stderr: combinedErr
      };
    }
  }

  return { status: 0, failedStage: null, stdout: combinedOut, stderr: combinedErr };
}

function printTestOutput(result) {
  if (result.stdout) process.stdout.write(result.stdout);
  if (result.stderr) process.stderr.write(result.stderr);
}

function writeSelectedMode(variant) {
  const out = path.join(ROOT, 'docs', 'V094_SELECTED_MODE.txt');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const description = {
    full: '整屏重绘节流 + Android 高分屏/地图缓存降载',
    throttle: '仅整屏重绘节流',
    resolution: '仅 Android 高分屏/地图缓存降载',
    baseline: '仓库原渲染代码（测试保护回退；本轮不应用倍速性能改动）'
  }[variant] || variant;
  fs.writeFileSync(
    out,
    `V0.9.4 adaptive selected mode: ${variant}\n${description}\n`,
    'utf8'
  );
}

function cleanup(state) {
  // 最终必须恢复 package.json 原始字节，避免临时 runner 进入仓库提交。
  try { restoreExactPackage(state); } catch (_) {}

  const targets = [
    path.join(ROOT, state.mainBackupPath),
    path.join(ROOT, state.packageBackupPath),
    STATE_PATH,
    path.join(ROOT, 'scripts', 'v094-perf-lib.js')
  ];
  for (const target of targets) {
    try { fs.rmSync(target, { force: true }); } catch (_) {}
  }

  try {
    const dir = path.join(ROOT, '.v094-backup');
    fs.rmdirSync(dir);
  } catch (_) {}

  try { fs.rmSync(__filename, { force: true }); } catch (_) {}
}

function main() {
  const state = readState();
  const variants = ['full', 'throttle', 'resolution', 'baseline'];
  let firstFailure = null;

  for (const variant of variants) {
    try {
      writeVariant(state, variant);
    } catch (error) {
      fail(`${variant} 无法应用：${error.message}`);
      if (firstFailure == null) firstFailure = 1;
      continue;
    }

    const result = runOriginalLifecycle(state, variant);
    if (result.status === 0) {
      printTestOutput(result);
      writeSelectedMode(variant);
      say(`仓库原测试通过，保留方案：${variant}`);
      cleanup(state);
      process.exit(0);
    }

    if (firstFailure == null) firstFailure = result.status;

    if (variant === 'baseline') {
      printTestOutput(result);
      fail(`完全恢复原 src/main.js 后，仓库原 ${result.failedStage || 'test'} 仍失败。`);
      fail('这说明失败来自仓库原测试/既有代码，而不是 V0.9.4 性能修改。');
    } else {
      say(`${variant} 在原 ${result.failedStage || 'test'} 阶段未通过，自动丢弃并尝试下一种。`);
    }
  }

  cleanup(state);
  process.exit(firstFailure || 1);
}

main();
