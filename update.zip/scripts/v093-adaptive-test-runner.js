'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const perf = require('./v093-perf-lib.js');

const ROOT = process.cwd();
const STATE_PATH = path.join(ROOT, 'scripts', '.v093-test-state.json');

function say(msg) {
  process.stdout.write(`[V0.9.3 adaptive] ${msg}\n`);
}

function fail(msg) {
  process.stderr.write(`[V0.9.3 adaptive] ${msg}\n`);
}

function readState() {
  if (!fs.existsSync(STATE_PATH)) {
    throw new Error('V0.9.3 state file missing');
  }
  return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
}

function restoreExactPackage(state) {
  const pkgPath = path.join(ROOT, 'package.json');
  const backupPkgPath = path.join(ROOT, state.packageBackupPath);
  fs.copyFileSync(backupPkgPath, pkgPath);
  say('已恢复 package.json 原始字节；仓库测试看到原配置。');
}

function writeVariant(state, variant) {
  const mainPath = path.join(ROOT, state.mainPath);
  const backupPath = path.join(ROOT, state.mainBackupPath);
  const base = fs.readFileSync(backupPath, 'utf8');
  const next = perf.applyVariant(base, variant);
  fs.writeFileSync(mainPath, next, 'utf8');

  const syntax = cp.spawnSync(process.execPath, ['--check', state.mainPath], {
    cwd: ROOT,
    encoding: 'utf8'
  });
  if (syntax.status !== 0) {
    throw new Error(
      `variant ${variant} syntax check failed\n${syntax.stdout || ''}${syntax.stderr || ''}`
    );
  }
}

function runOriginalTest(state, variant) {
  say(`用仓库原测试验证候选方案：${variant}`);
  const result = cp.spawnSync(state.originalTest, {
    cwd: ROOT,
    shell: true,
    encoding: 'utf8',
    env: process.env,
    maxBuffer: 64 * 1024 * 1024
  });

  return {
    status: Number.isInteger(result.status) ? result.status : 1,
    stdout: result.stdout || '',
    stderr: result.stderr || ''
  };
}

function printTestOutput(result) {
  if (result.stdout) process.stdout.write(result.stdout);
  if (result.stderr) process.stderr.write(result.stderr);
}

function writeSelectedMode(variant) {
  const out = path.join(ROOT, 'docs', 'V093_SELECTED_MODE.txt');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const description = {
    full: '整屏重绘节流 + Android 高分屏/地图缓存降载',
    throttle: '仅整屏重绘节流',
    resolution: '仅 Android 高分屏/地图缓存降载',
    baseline: '仓库原渲染代码（测试保护回退；本轮不应用倍速性能改动）'
  }[variant] || variant;
  fs.writeFileSync(
    out,
    `V0.9.3 adaptive selected mode: ${variant}\n${description}\n`,
    'utf8'
  );
}

function cleanup(state) {
  const targets = [
    path.join(ROOT, state.mainBackupPath),
    path.join(ROOT, state.packageBackupPath),
    STATE_PATH,
    path.join(ROOT, 'scripts', 'v093-perf-lib.js')
  ];
  for (const target of targets) {
    try { fs.rmSync(target, { force: true }); } catch (_) {}
  }

  for (const rel of [state.mainBackupPath, state.packageBackupPath]) {
    try {
      const dir = path.dirname(path.join(ROOT, rel));
      fs.rmdirSync(dir);
    } catch (_) {}
  }

  try { fs.rmSync(__filename, { force: true }); } catch (_) {}
}

function main() {
  const state = readState();

  // npm has already resolved the temporary runner command. From this point on,
  // restore the exact original package so existing tests cannot fail merely
  // because this patch temporarily redirected scripts.test.
  restoreExactPackage(state);

  const variants = ['full', 'throttle', 'resolution', 'baseline'];
  let firstFailure = null;

  for (const variant of variants) {
    try {
      writeVariant(state, variant);
    } catch (error) {
      fail(`${variant} 无法应用：${error.message}`);
      if (firstFailure == null) firstFailure = 1;
      continue;
    }

    const result = runOriginalTest(state, variant);
    if (result.status === 0) {
      printTestOutput(result);
      writeSelectedMode(variant);
      say(`仓库原测试通过，保留方案：${variant}`);
      cleanup(state);
      process.exit(0);
    }

    if (firstFailure == null) firstFailure = result.status;

    if (variant === 'baseline') {
      printTestOutput(result);
      fail('完全恢复原 src/main.js 后，仓库原测试仍失败。该失败不是本轮倍速优化造成。');
      fail('上方保留了仓库原测试的真实 AssertionError、文件和行号。');
    } else {
      say(`${variant} 未通过仓库原测试，已自动丢弃并尝试下一种。`);
    }
  }

  cleanup(state);
  process.exit(firstFailure || 1);
}

main();
