'use strict';

const fs =
  require('fs');

const path =
  require('path');

const cp =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

function file(
  rel
) {
  return path.join(
    ROOT,
    rel
  );
}

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  if (
    !source.includes(
      before
    )
  ) {
    throw new Error(
      '[V0.8.9] 找不到接线锚点：' +
      label
    );
  }

  return source.replace(
    before,
    after
  );
}

function patchSimulation() {
  const rel =
    'src/operations/restaurantSimulationV081.js';

  let source =
    fs.readFileSync(
      file(rel),
      'utf8'
    );

  if (
    !source.includes(
      'V089_STAFF_WORKLOAD'
    )
  ) {
    source =
      replaceOnce(
        source,
`const operationsSchedule =
  require('./operationsScheduleV087.js');
// V084_RESTAURANT_LIVE_WORLD`,
`const operationsSchedule =
  require('./operationsScheduleV087.js');

const staffWorkloadSystem =
  require('./staffWorkloadV089.js');
// V089_STAFF_WORKLOAD
// V084_RESTAURANT_LIVE_WORLD`,
        '经营模拟读取工作负荷系统'
      );

    source =
      replaceOnce(
        source,
`    const scheduled =
      operationsSchedule
        .getCoverage(
          shop.id,
          gameState
            .getTime()
        );

    return clamp(
      Math.min(
        base,
        Number(
          scheduled.factor
        ) ||
        1
      ) *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ),
      0.10,
      1.2
    );`,
`    const scheduled =
      operationsSchedule
        .getCoverage(
          shop.id,
          gameState
            .getTime()
        );

    const fatigue =
      staffWorkloadSystem
        .getCapacityModifier(
          shop.id,
          gameState
            .getTime()
        );

    return clamp(
      Math.min(
        base,
        Number(
          scheduled.factor
        ) ||
        1
      ) *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ) *
      fatigue,
      0.08,
      1.2
    );`,
        '疲劳进入真实门店承载'
      );

    source =
      replaceOnce(
        source,
`  const trialFactor =
    shop.status ===
      'trial_opening'
      ? 0.78
      : 1;

  return Math.max(`,
`  const trialFactor =
    shop.status ===
      'trial_opening'
      ? 0.78
      : 1;

  const peakDemandFactor =
    staffWorkloadSystem
      .getDemandMultiplier(
        time
      );

  return Math.max(`,
        '高峰期进入真实客流'
      );

    source =
      replaceOnce(
        source,
`      competitionFactor *
      nightFactor *
      trialFactor`,
`      competitionFactor *
      nightFactor *
      peakDemandFactor *
      trialFactor`,
        '高峰期需求倍率进入到店率'
      );

    source =
      replaceOnce(
        source,
`  maybeRestock(
    shop,
    runtime
  );

  const rate =`,
`  maybeRestock(
    shop,
    runtime
  );

  const workloadTick =
    staffWorkloadSystem
      .advance(
        shop.id,
        advancedMinutes,
        gameState
          .getTime()
      );

  if (
    workloadTick &&
    workloadTick.overtimeCost >
      0
  ) {
    settlementEngine
      .addFixedCosts(
        runtime.ledger,
        {
          labor:
            workloadTick
              .overtimeCost
        }
      );

    spendOperatingCash(
      workloadTick
        .overtimeCost,
      runtime,
      'labor'
    );

    changed =
      true;
  }

  const rate =`,
        '加班费进入真实成本'
      );

    fs.writeFileSync(
      file(rel),
      source
    );
  }
}

function patchScheduleScene() {
  const rel =
    'src/scenes/scheduleSceneV087.js';

  let source =
    fs.readFileSync(
      file(rel),
      'utf8'
    );

  if (
    !source.includes(
      'V089_SCHEDULE_WORKLOAD_UI'
    )
  ) {
    source =
      replaceOnce(
        source,
`const scheduleSystem =
  require('../operations/operationsScheduleV087.js');

const ui =`,
`const scheduleSystem =
  require('../operations/operationsScheduleV087.js');

const staffWorkloadSystem =
  require('../operations/staffWorkloadV089.js');
// V089_SCHEDULE_WORKLOAD_UI

const ui =`,
        '排班页面读取工作负荷'
      );

    source =
      replaceOnce(
        source,
`    if (!snapshot) {
      return;
    }

    const h =`,
`    if (!snapshot) {
      return;
    }

    const workload =
      staffWorkloadSystem
        .getSnapshot(
          this.shopId,
          gameState
            .getTime()
        );

    const h =`,
        '排班页面读取实时高峰与疲劳'
      );

    source =
      replaceOnce(
        source,
`      '真实影响客流与门店承载'`,
`      '高峰、疲劳、加班与班次缺口实时联动'`,
        '排班页面副标题'
      );

    source =
      replaceOnce(
        source,
`      14,
      274,
      362,
      72,`,
`      14,
      274,
      362,
      88,`,
        '扩展实时承载卡片'
      );

    source =
      replaceOnce(
        source,
`    ui.text(
      ctx,
      '实时排班承载 ' +
        Math.round(
          snapshot.coverage *
          100
        ) +
        '%',
      28,
      325,
      9,
      snapshot.coverage >=
        0.8
        ? '#40865A'
        : '#C37A35',
      '800'
    );

    ui.text(
      ctx,
      '员工排班',`,
`    ui.text(
      ctx,
      '实时排班承载 ' +
        Math.round(
          snapshot.coverage *
          100
        ) +
        '%',
      28,
      325,
      9,
      snapshot.coverage >=
        0.8
        ? '#40865A'
        : '#C37A35',
      '800'
    );

    ui.text(
      ctx,
      workload.peak.label +
        ' · ' +
        workload.pressure +
        ' · 疲劳' +
        workload.avgFatigue +
        ' · 冲突' +
        workload.conflictCount +
        ' · 加班¥' +
        Math.round(
          workload
            .todayOvertimePay
        ),
      28,
      347,
      6.6,
      workload.conflictCount >
        0 ||
      workload.avgFatigue >=
        65
        ? '#C85242'
        : '#617A86',
      '700'
    );

    ui.text(
      ctx,
      '员工排班',`,
        '排班页面展示高峰疲劳加班与冲突'
      );

    fs.writeFileSync(
      file(rel),
      source
    );
  }
}

patchSimulation();
patchScheduleScene();

const pkgPath =
  file(
    'package.json'
  );

const pkg =
  JSON.parse(
    fs.readFileSync(
      pkgPath,
      'utf8'
    )
  );

const installerPrefix =
  'node scripts/upgrade-workload-v089.js && ';

if (
  pkg.scripts &&
  typeof pkg.scripts.pretest ===
    'string'
) {
  pkg.scripts.pretest =
    pkg.scripts.pretest.replace(
      installerPrefix,
      ''
    );
}

pkg.version =
  '0.8.9';

fs.writeFileSync(
  pkgPath,
  JSON.stringify(
    pkg,
    null,
    2
  ) +
  '\n'
);

for (
  const target
  of [
    'src/operations/staffWorkloadV089.js',
    'src/operations/restaurantSimulationV081.js',
    'src/scenes/scheduleSceneV087.js',
    'tests/staffWorkloadV089.test.js',
    'tests/updateInfrastructureV089.test.js'
  ]
) {
  const result =
    cp.spawnSync(
      process.execPath,
      [
        '--check',
        file(target)
      ],
      {
        encoding:'utf8'
      }
    );

  if (
    result.status !==
    0
  ) {
    throw new Error(
      '[V0.8.9] 语法检查失败：' +
      target +
      '\n' +
      (
        result.stderr ||
        result.stdout ||
        ''
      )
    );
  }
}

try {
  fs.unlinkSync(
    __filename
  );
} catch (error) {
  console.warn(
    '[V0.8.9] 临时升级脚本自清理失败：' +
    error.message
  );
}

console.log(
  '[V0.8.9] 高峰/疲劳/加班/排班冲突接入完成'
);
