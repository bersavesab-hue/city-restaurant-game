"use strict";

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const mainPath = path.join(ROOT, "src/main.js");
const pkgPath = path.join(ROOT, "package.json");
const v27TestPath = path.join(ROOT, "tests/v27TargetSkin.test.js");

let source = fs.readFileSync(mainPath, "utf8");

const startMarker = "/* V27_TARGET_REFERENCE_SKIN */";
const startupMarker = "/* =========================\n   启动\n========================= */";

const start = source.indexOf(startMarker);
const startup = source.indexOf(startupMarker);

if (start >= 0) {
  if (startup < 0 || startup <= start) {
    throw new Error("V27回滚失败：找不到启动边界");
  }

  source =
    source.slice(0, start) +
    source.slice(startup);
}

source = source.replace(
  "城市餐饮经营小游戏 V27.1 目标图直接接入版启动成功",
  "城市餐饮经营小游戏 V26 主页硬重构版启动成功"
);

source = source.replace(
  "城市餐饮经营小游戏 V27 目标图原版皮肤启动成功",
  "城市餐饮经营小游戏 V26 主页硬重构版启动成功"
);

fs.writeFileSync(mainPath, source, "utf8");

// Remove the obsolete V27-only test file so it can never be picked up manually.
try {
  if (fs.existsSync(v27TestPath)) {
    fs.unlinkSync(v27TestPath);
  }
} catch (error) {
  console.warn("无法删除旧V27测试文件:", error.message);
}

// Remove one-shot pretest before commit. The current npm invocation has already
// captured the commands it needs to execute.
const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));

if (pkg.scripts) {
  delete pkg.scripts.pretest;

  if (typeof pkg.scripts.test === "string") {
    pkg.scripts.test = pkg.scripts.test
      .replace(/\s*&&\s*node tests\/v27TargetSkin\.test\.js/g, "")
      .trim();
  }
}

fs.writeFileSync(
  pkgPath,
  JSON.stringify(pkg, null, 2) + "\n",
  "utf8"
);

// This script is only needed for the update run.
try {
  fs.unlinkSync(__filename);
} catch (error) {
}

console.log("V27整页截图覆盖层已移除，主页恢复到V26动态实现");
