'use strict';
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const root = process.cwd();
const problems = [];
function full(rel){ return path.join(root, rel); }
function has(rel){ return fs.existsSync(full(rel)); }
function read(rel){ return fs.readFileSync(full(rel), 'utf8'); }
function problem(x){ problems.push(x); }

if (!has('scripts/operating-v108-paths.json')) problem('缺少路径报告 scripts/operating-v108-paths.json');
let report = null;
if (!problems.length) {
  try { report = JSON.parse(read('scripts/operating-v108-paths.json')); } catch (e) { problem('路径报告无法解析'); }
}
if (report) {
  for (const [key, rel] of Object.entries(report.discovered || {})) if (!has(rel)) problem(`${key} 路径不存在：${rel}`);
  if (report.discovered && report.discovered.entry && has(report.discovered.entry)) {
    const entry = read(report.discovered.entry);
    const n = (entry.match(/operatingBootstrapV108\.generated\.js/g) || []).length;
    if (n !== 1) problem('Android 入口 V1.0.8 接线数量异常：' + n);
  }
}
for (const rel of ['src/operating/eventCatalogV108.js','src/operating/businessOperatingSystemV108.js','src/operating/operatingRuntimeCoreV108.js','src/operating/operatingBootstrapV108.generated.js','tests/operatingSystemsV108.test.js','tests/runtimeCoreV108.smoke.js']) {
  if (!has(rel)) { problem('缺少文件：' + rel); continue; }
  const r = cp.spawnSync(process.execPath, ['--check', full(rel)], { encoding: 'utf8' });
  if (r.status !== 0) problem(rel + ' 语法失败：' + (r.stderr || r.stdout || '').trim());
}
if (has('package.json')) {
  try {
    const pkg = JSON.parse(read('package.json'));
    if (!String(pkg.scripts && pkg.scripts.test || '').includes('operatingSystemsV108.test.js')) problem('npm test 未挂接 V1.0.8 测试');
    if (!String(pkg.scripts && pkg.scripts['build:android-js'] || '').includes('audit-operating-v108.js')) problem('Android build 未挂接 V1.0.8 审计');
  } catch (e) { problem('package.json 无法解析'); }
}
if (problems.length) {
  console.error('[V1.0.8 AUDIT] FAIL');
  problems.forEach(x => console.error(' - ' + x));
  process.exit(1);
}
console.log('[V1.0.8 AUDIT] PASS');
if (report) console.log('[V1.0.8 DISCOVERED] ' + JSON.stringify(report.discovered));
