"use strict";

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const mainPath = path.join(ROOT, "src/main.js");
const pkgPath = path.join(ROOT, "package.json");
const startupMarker = "/* =========================\n   启动\n========================= */";

let source = fs.readFileSync(mainPath, "utf8");

// V32 is a new homepage baseline. Remove the V30/V31 tuning stack before inserting it.
const v30Start = source.indexOf("/* V30_LAYOUT_CALIBRATION */");
const startupIndexBefore = source.indexOf(startupMarker);

if (v30Start >= 0) {
  if (startupIndexBefore < 0 || startupIndexBefore <= v30Start) {
    throw new Error("V32无法清理旧主页覆盖层");
  }
  source = source.slice(0, v30Start) + source.slice(startupIndexBefore);
}

if (!source.includes("V32_REFERENCE_HOME_REBUILD")) {
  const insertAt = source.indexOf(startupMarker);
  if (insertAt < 0) throw new Error("V32无法找到启动标记");

  const block = String.raw`
/* V32_REFERENCE_HOME_REBUILD */

const V32_POINTS = {
  university: { x: 0.185, y: 0.105, side: 'right' },
  hightech:   { x: 0.790, y: 0.110, side: 'left'  },
  cbd:        { x: 0.465, y: 0.325, side: 'right' },
  oldtown:    { x: 0.070, y: 0.505, side: 'right' },
  village:    { x: 0.775, y: 0.500, side: 'left'  },
  industry:   { x: 0.180, y: 0.715, side: 'right' },
  market:     { x: 0.730, y: 0.695, side: 'left'  }
};

const V32_MARKER_KEYS = {
  university: 'v32_marker_university',
  hightech: 'v32_marker_hightech',
  cbd: 'v32_marker_cbd',
  oldtown: 'v32_marker_oldtown',
  village: 'v32_marker_village',
  industry: 'v32_marker_industry',
  market: 'v32_marker_market'
};

const V32_PREVIEW_KEYS = {
  university: 'v32_preview_university',
  hightech: 'v32_preview_hightech',
  cbd: 'v32_preview_cbd',
  oldtown: 'v32_preview_oldtown',
  village: 'v32_preview_village',
  industry: 'v32_preview_industry',
  market: 'v32_preview_market'
};

const v32PreviousLoadResources = loadResources;
const v32PreviousDrawBottomNav = drawBottomNav;

function v32FormatMoney(value) {
  const n = Number(value) || 0;
  const abs = Math.abs(n);

  if (abs < 1000000) {
    return '¥' + Math.round(n).toLocaleString();
  }

  if (abs < 100000000) {
    const v = n / 10000;
    return '¥' + (Math.abs(v) >= 100 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, '')) + '万';
  }

  if (abs < 1000000000000) {
    const v = n / 100000000;
    return '¥' + (Math.abs(v) >= 100 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, '')) + '亿';
  }

  const v = n / 1000000000000;
  return '¥' + (Math.abs(v) >= 100 ? v.toFixed(0) : v.toFixed(1).replace(/\.0$/, '')) + '万亿';
}

function v32DrawImage(key, x, y, w, h, alpha) {
  const img = resourceManager.getImage(key);
  if (!img) return false;

  ctx.save();
  ctx.globalAlpha = alpha == null ? 1 : alpha;
  ctx.drawImage(img, x, y, w, h);
  ctx.restore();
  return true;
}

function v32SelectedDistrict() {
  const districts = getDistricts() || [];
  let current = districts.find(function (item) {
    return item.id === selectedDistrictId;
  });

  if (!current) {
    current =
      districts.find(function (item) {
        return item.id === 'market';
      }) ||
      districts[0] ||
      null;

    if (current) {
      selectedDistrictId = current.id;
    }
  }

  return current;
}

function v32DistrictPoint(id) {
  const point = V32_POINTS[id];
  if (!point) return v26GetPoint(id);

  const top = MAP_Y + 65;
  const bottom = CARD_Y - 9;
  const usableH = Math.max(120, bottom - top);

  return {
    x: Math.round(MAP_X + MAP_W * point.x),
    y: Math.round(top + usableH * point.y)
  };
}

function v32DisplayBadge(meta) {
  if (meta.myShopCount > 0) return null;
  if (meta.badge === '需求↑') return { text: '人气高', fill: '#ED3347' };
  if (meta.badge === '竞争高') return { text: '竞争激烈', fill: '#ED3347' };
  if (meta.badge === '租金低') return { text: '租金低', fill: '#ED3347' };
  return null;
}

loadResources = function () {
  const tasks = [
    resourceManager.loadImage('v32_home_background', 'assets/images/v32_home/home_background.jpg', 'v32-home'),
    resourceManager.loadImage('v32_bottom_nav_reference', 'assets/images/v32_home/bottom_nav_reference.png', 'v32-home'),
    resourceManager.loadImage('v32_nav_renovation', 'assets/images/v32_home/nav_renovation.png', 'v32-home'),

    resourceManager.loadImage('v32_marker_university', 'assets/images/v32_home/marker_university.png', 'v32-home'),
    resourceManager.loadImage('v32_marker_hightech', 'assets/images/v32_home/marker_hightech.png', 'v32-home'),
    resourceManager.loadImage('v32_marker_cbd', 'assets/images/v32_home/marker_cbd.png', 'v32-home'),
    resourceManager.loadImage('v32_marker_oldtown', 'assets/images/v32_home/marker_oldtown.png', 'v32-home'),
    resourceManager.loadImage('v32_marker_village', 'assets/images/v32_home/marker_village.png', 'v32-home'),
    resourceManager.loadImage('v32_marker_industry', 'assets/images/v32_home/marker_industry.png', 'v32-home'),
    resourceManager.loadImage('v32_marker_market', 'assets/images/v32_home/marker_market.png', 'v32-home'),

    resourceManager.loadImage('v32_preview_university', 'assets/images/v32_home/preview_university.jpg', 'v32-home'),
    resourceManager.loadImage('v32_preview_hightech', 'assets/images/v32_home/preview_hightech.jpg', 'v32-home'),
    resourceManager.loadImage('v32_preview_cbd', 'assets/images/v32_home/preview_cbd.jpg', 'v32-home'),
    resourceManager.loadImage('v32_preview_oldtown', 'assets/images/v32_home/preview_oldtown.jpg', 'v32-home'),
    resourceManager.loadImage('v32_preview_village', 'assets/images/v32_home/preview_village.jpg', 'v32-home'),
    resourceManager.loadImage('v32_preview_industry', 'assets/images/v32_home/preview_industry.jpg', 'v32-home'),
    resourceManager.loadImage('v32_preview_market', 'assets/images/v32_home/preview_market.jpg', 'v32-home')
  ];

  return Promise.all(tasks).then(function () {
    return v32PreviousLoadResources();
  });
};

updateLayout = function () {
  TOP_H = (VIEW_H < 740 ? 94 : 98) + SAFE_TOP;
  NAV_H = (VIEW_H < 740 ? 62 : 65) + SAFE_BOTTOM;

  MAP_X = 0;
  MAP_Y = TOP_H;
  MAP_W = VIEW_W;

  NAV_Y = VIEW_H - NAV_H;
  MAP_H = NAV_Y - MAP_Y;

  CARD_H = VIEW_H < 740 ? 138 : 144;
  CARD_X = 6;
  CARD_W = VIEW_W - 12;
  CARD_Y = NAV_Y - CARD_H;
};

drawMapBase = function () {
  const image = resourceManager.getImage('v32_home_background');

  if (!image) {
    const fallback = resourceManager.getImage('city_base_01');
    if (fallback) {
      drawImageFocus(ctx, fallback, MAP_X, MAP_Y, MAP_W, MAP_H, 1.35, 0.50, 0.53);
      return;
    }

    ctx.fillStyle = '#0D5478';
    ctx.fillRect(MAP_X, MAP_Y, MAP_W, MAP_H);
    return;
  }

  drawImageFocus(
    ctx,
    image,
    MAP_X,
    MAP_Y,
    MAP_W,
    MAP_H,
    1.0,
    0.50,
    0.49
  );
};

drawTopHud = function () {
  const player = gameState.getPlayer();
  const world = gameState.getWorld();
  const display = timeSystem.getDisplayState();
  const brand = getBrandState(player);

  let cityName = gameState.getCityName();
  if (!cityName || cityName === '未命名城市') cityName = '美食市';

  const bg = resourceManager.getImage('v32_home_background');

  if (bg) {
    drawImageFocus(ctx, bg, 0, 0, VIEW_W, TOP_H, 1.30, 0.50, 0.10);
    ctx.fillStyle = 'rgba(4,43,70,0.56)';
    ctx.fillRect(0, 0, VIEW_W, TOP_H);
  } else {
    ctx.fillStyle = '#0B4A72';
    ctx.fillRect(0, 0, VIEW_W, TOP_H);
  }

  drawCityBadge(cityName, 10, 9 + SAFE_TOP, 44);

  drawText(
    fitText(cityName, 112, 18.8, '800'),
    66,
    20 + SAFE_TOP,
    18.8,
    '#FFFFFF',
    '800'
  );

  roundedRect(
    145,
    12 + SAFE_TOP,
    18,
    18,
    5,
    'rgba(4,49,72,0.78)',
    'rgba(255,255,255,0.24)'
  );
  drawText('✎', 154, 21 + SAFE_TOP, 7.2, '#FFE48A', '800', 'center');
  addButton('city:rename', 140, 7 + SAFE_TOP, 28, 28);

  drawText(
    '打造属于你的美食之都',
    66,
    42 + SAFE_TOP,
    7.4,
    '#F1F8FC',
    '600'
  );

  drawWeatherGlyph(world.weather, 180, 27 + SAFE_TOP);
  drawText(
    WEATHER_NAMES[world.weather] || '晴',
    200,
    18 + SAFE_TOP,
    7.6,
    '#FFFFFF',
    '800',
    'center'
  );
  drawText(
    (Number(world.temperature) || 22) + '℃',
    200,
    37 + SAFE_TOP,
    7.6,
    '#F4FAFD',
    '700',
    'center'
  );

  const levelW = 68;
  const moneyW = 106;
  const right = VIEW_W - 7;
  const levelX = right - levelW;
  const moneyX = levelX - 5 - moneyW;

  roundedRect(
    moneyX,
    9 + SAFE_TOP,
    moneyW,
    49,
    12,
    'rgba(3,57,91,0.94)',
    'rgba(72,183,236,0.55)'
  );

  drawCashGlyph(moneyX + 18, 26 + SAFE_TOP);

  const moneyText = v32FormatMoney(player.cash);
  const moneyFont = moneyText.length <= 7 ? 11.9 : moneyText.length <= 9 ? 10.9 : 9.9;

  drawText(
    fitText(moneyText, moneyW - 44, moneyFont, '800'),
    moneyX + 63,
    21 + SAFE_TOP,
    moneyFont,
    '#FFF5A9',
    '800',
    'center'
  );

  drawText(
    '可用资金',
    moneyX + 63,
    42 + SAFE_TOP,
    6.9,
    '#E5F2F7',
    '600',
    'center'
  );

  roundedRect(
    moneyX + moneyW - 18,
    16 + SAFE_TOP,
    13,
    13,
    4,
    '#FFB72B',
    '#FFE68D'
  );
  drawText('+', moneyX + moneyW - 11.5, 22.5 + SAFE_TOP, 8.6, '#FFFFFF', '800', 'center');

  roundedRect(
    levelX,
    9 + SAFE_TOP,
    levelW,
    49,
    12,
    'rgba(3,57,91,0.94)',
    'rgba(72,183,236,0.55)'
  );

  drawCrownGlyph(levelX + 15, 26 + SAFE_TOP);

  drawText(
    'Lv.' + brand.level,
    levelX + 45,
    19 + SAFE_TOP,
    8.6,
    '#FFE77E',
    '800',
    'center'
  );

  roundedRect(levelX + 20, 40 + SAFE_TOP, 40, 4, 2, 'rgba(255,255,255,0.22)');
  roundedRect(levelX + 20, 40 + SAFE_TOP, Math.max(4, 40 * brand.progress), 4, 2, '#FFD34B');

  drawText(
    brand.reputation + '/100',
    levelX + 40,
    51 + SAFE_TOP,
    5.5,
    '#F0F8FB',
    '600',
    'center'
  );

  addButton('brand:status', levelX - 3, 5 + SAFE_TOP, levelW + 6, 55);

  const speedItems = [
    ['time:pause', 'Ⅱ'],
    ['time:speed:1', '1x'],
    ['time:speed:2', '2x'],
    ['time:speed:5', '5x'],
    ['time:speed:10', '10x']
  ];

  const y = TOP_H - 30;

  for (let i = 0; i < speedItems.length; i++) {
    const id = speedItems[i][0];
    const speed = timeSystem.getSpeed();
    const paused = timeSystem.isPaused();

    const active =
      id === 'time:pause'
        ? paused
        : (!paused && Number(id.split(':')[2]) === speed);

    const x = 10 + i * 47;

    roundedRect(
      x,
      y,
      40,
      22,
      8,
      active ? '#FFC32E' : 'rgba(2,47,74,0.90)',
      active ? '#FFE58B' : 'rgba(255,255,255,0.18)'
    );

    drawText(
      speedItems[i][1],
      x + 20,
      y + 11,
      8,
      active ? '#14384D' : '#FFFFFF',
      '800',
      'center'
    );

    addButton(id, x - 3, y - 5, 46, 31);
  }

  drawText(
    fitText(
      display.date + ' · ' + display.time + ' · ' + (MEAL_NAMES[display.mealPeriod] || ''),
      170,
      6.6,
      '600'
    ),
    VIEW_W - 8,
    y + 11,
    6.6,
    '#F1F7FA',
    '600',
    'right'
  );
};

drawNewsTicker = function () {
  const feed = simulationSystem.getNewsFeed();
  const bulletin = simulationSystem.getBulletin();

  const x = 7;
  const y = MAP_Y + 4;
  const w = VIEW_W - 14;
  const h = 27;

  roundedRect(
    x,
    y,
    w,
    h,
    13.5,
    'rgba(2,54,86,0.96)',
    'rgba(87,194,241,0.66)'
  );

  drawText('🔊', x + 15, y + 13.8, 9.4, '#FFD85C', '800', 'center');
  drawText('城市播报', x + 30, y + 13.8, 7.4, '#FFD85C', '800');

  const items = ((feed && feed.length ? feed : [bulletin])).slice(0, 3);
  const startX = x + 87;
  const sectionW = (w - 111) / 3;

  for (let i = 0; i < 3; i++) {
    const item =
      items[i] ||
      {
        title:
          i === 0
            ? '美食节即将盛大开幕'
            : i === 1
              ? '新活动：舌尖上的城市'
              : '餐饮品牌纷纷入驻'
      };

    if (i > 0) {
      ctx.fillStyle = 'rgba(225,242,250,0.38)';
      ctx.fillRect(startX + i * sectionW - 6, y + 7, 1, 13);
    }

    drawText(
      fitText(item.title || '城市运行平稳', sectionW - 12, 6.2, '600'),
      startX + i * sectionW,
      y + 13.6,
      6.2,
      '#F8FCFE',
      '600'
    );
  }

  drawText('›', x + w - 12, y + 13.7, 13.5, '#FFE49A', '800', 'center');
  addButton('tool:news', x, y, w, h);
};

drawGoalBar = function () {
  const goal = getHomeGoalState();

  const x = 7;
  const y = MAP_Y + 35;
  const w = VIEW_W - 14;
  const h = 27;

  roundedRect(
    x,
    y,
    w,
    h,
    13.5,
    'rgba(2,54,86,0.96)',
    'rgba(87,194,241,0.58)'
  );

  drawText('◎', x + 15, y + 13.5, 12, '#FFD85C', '800', 'center');
  drawText('当前目标：', x + 28, y + 13.5, 7.1, '#FFD85C', '800');
  drawText('开设餐厅', x + 83, y + 13.5, 7.2, '#FFFFFF', '800');

  const labels = ['选址', '装修', '试营业', '经营', '签约'];
  const currentIndex = Math.max(0, Math.min(labels.length - 1, Number(goal.current) || 0));
  const startX = x + 168;
  const usable = w - 198;
  const gap = usable / (labels.length - 1);

  for (let i = 0; i < labels.length; i++) {
    const cx = startX + i * gap;
    const done = i < currentIndex;
    const active = i === currentIndex && !goal.completed;

    if (i < labels.length - 1) {
      ctx.strokeStyle = i < currentIndex ? '#FFD047' : 'rgba(221,237,245,0.42)';
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(cx + 8, y + 9.8);
      ctx.lineTo(cx + gap - 8, y + 9.8);
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.arc(cx, y + 9.8, 5, 0, Math.PI * 2);
    ctx.fillStyle = done ? '#F5C83A' : (active ? '#FFF8C8' : 'rgba(225,239,244,0.18)');
    ctx.fill();
    ctx.strokeStyle = done || active ? '#FFE58B' : '#9CB9C8';
    ctx.lineWidth = 1;
    ctx.stroke();

    drawText(
      labels[i],
      cx,
      y + 21.2,
      5.8,
      active ? '#FFE38A' : '#EEF7FA',
      active ? '800' : '600',
      'center'
    );
  }

  drawText('🎁', x + w - 13, y + 13.5, 9.7, '#FFD85C', '800', 'center');
};

drawDistrictMarker = function (district) {
  const point = v32DistrictPoint(district.id);
  if (!point) return;

  const x = point.x;
  const y = point.y;
  const selected = selectedDistrictId === district.id;
  const meta = getDistrictVisualMeta(district);
  const config = V32_POINTS[district.id] || { side: 'right' };
  const markerImage = resourceManager.getImage(V32_MARKER_KEYS[district.id]);

  if (selected) {
    ctx.beginPath();
    ctx.arc(x, y, 25 + districtFx.flash * 3, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,205,54,0.16)';
    ctx.fill();
  }

  const markerW = district.id === 'village' ? 50 : 48;
  const markerH = district.id === 'village' ? 50 : 48;

  if (markerImage) {
    ctx.save();
    const animated = districtFx.id === district.id;
    const markerScale = animated ? districtFx.scale : 1;
    ctx.translate(x, y);
    ctx.scale(markerScale, markerScale);
    ctx.drawImage(markerImage, -markerW / 2, -markerH / 2 - 2, markerW, markerH);
    ctx.restore();
  }

  const boxW = Math.max(83, Math.min(108, 44 + district.name.length * 9.5));
  const boxXBase = config.side === 'left' ? x - boxW - 14 : x + 14;
  const boxX = Math.max(6, Math.min(VIEW_W - boxW - 6, boxXBase));
  const boxY = Math.max(MAP_Y + 68, Math.min(CARD_Y - 46, y - 13));

  roundedRect(
    boxX,
    boxY,
    boxW,
    23,
    10,
    'rgba(3,61,91,0.97)',
    selected ? '#FFE16A' : 'rgba(255,224,105,0.86)',
    selected ? 1.35 : 1
  );

  drawText(district.name, boxX + 9, boxY + 11.5, 8.6, '#FFFFFF', '800');
  drawText('›', boxX + boxW - 8, boxY + 11.5, 9.5, '#FFE49C', '800', 'center');

  const subtitle = meta.subtitle || '';
  const subW = Math.max(boxW - 8, Math.min(150, 22 + subtitle.length * 6.0));
  let subX = boxX + boxW / 2 - subW / 2;
  subX = Math.max(5, Math.min(VIEW_W - subW - 5, subX));

  roundedRect(
    subX,
    boxY + 23,
    subW,
    16,
    7,
    'rgba(255,254,249,0.98)',
    'rgba(7,55,79,0.11)'
  );

  drawText(
    fitText(subtitle, subW - 14, 5.5, '700'),
    subX + subW / 2,
    boxY + 31.4,
    5.5,
    '#23485F',
    '700',
    'center'
  );

  const badge = v32DisplayBadge(meta);

  if (badge) {
    const badgeW = badge.text.length >= 4 ? 49 : 37;
    const badgeX = Math.max(
      5,
      Math.min(VIEW_W - badgeW - 5, boxX + boxW - badgeW + 7)
    );

    roundedRect(
      badgeX,
      boxY - 9,
      badgeW,
      17,
      8,
      badge.fill,
      '#FFD7D9',
      0.9
    );

    drawText(
      badge.text,
      badgeX + badgeW / 2,
      boxY - 0.4,
      5.5,
      '#FFFFFF',
      '800',
      'center'
    );
  }

  if (meta.myShopCount > 0) {
    const sw = meta.myShopCount > 1 ? 56 : 46;
    const sx = Math.max(
      5,
      Math.min(VIEW_W - sw - 5, boxX + boxW - sw + 6)
    );

    roundedRect(
      sx,
      boxY - 28,
      sw,
      17,
      8,
      '#1D9D5E',
      '#BCF0CB',
      0.9
    );

    drawText(
      meta.myShopCount > 1 ? '✓ 我的店×' + meta.myShopCount : '✓ 我的店',
      sx + sw / 2,
      boxY - 19.5,
      5,
      '#FFFFFF',
      '800',
      'center'
    );
  }

  const hitLeft = Math.min(x - 25, subX - 4);
  const hitRight = Math.max(x + 25, subX + subW + 4);
  const hitTop = Math.min(y - 28, boxY - 30);
  const hitBottom = Math.max(y + 28, boxY + 42);

  addButton(
    'district:' + district.id,
    hitLeft,
    hitTop,
    hitRight - hitLeft,
    hitBottom - hitTop
  );
};

drawDistrictCard = function () {
  const district = v32SelectedDistrict();
  if (!district) return;

  const meta = getDistrictVisualMeta(district);

  const x = CARD_X;
  const y = CARD_Y;
  const w = CARD_W;
  const h = CARD_H;

  roundedRect(
    x,
    y,
    w,
    h,
    17,
    'rgba(255,255,255,0.99)',
    'rgba(8,52,79,0.18)',
    1.15
  );

  const preview = resourceManager.getImage(V32_PREVIEW_KEYS[district.id]);
  const px = x + 9;
  const py = y + 8;
  const pw = 99;
  const ph = h - 16;

  if (preview) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(px + 13, py);
    ctx.arcTo(px + pw, py, px + pw, py + ph, 13);
    ctx.arcTo(px + pw, py + ph, px, py + ph, 13);
    ctx.arcTo(px, py + ph, px, py, 13);
    ctx.arcTo(px, py, px + pw, py, 13);
    ctx.closePath();
    ctx.clip();

    drawImageFocus(
      ctx,
      preview,
      px,
      py,
      pw,
      ph,
      1.0,
      0.50,
      0.47
    );

    ctx.restore();
  }

  const smallMarker = resourceManager.getImage(V32_MARKER_KEYS[district.id]);

  if (smallMarker) {
    ctx.drawImage(smallMarker, x + 112, y + 7, 24, 24);
  }

  drawText(
    district.name,
    x + 135,
    y + 18,
    14.6,
    '#0C3960',
    '800'
  );

  drawText(
    '›',
    x + 205,
    y + 18,
    13.0,
    '#2A5774',
    '800',
    'center'
  );

  drawText(
    fitText(meta.subtitle || '', w - 225, 6.3, '700'),
    x + 219,
    y + 18,
    6.3,
    '#547289',
    '700'
  );

  drawText(
    v26GetBadgeSummary(meta),
    x + 113,
    y + 36,
    6.8,
    '#1688C9',
    '800'
  );

  const metrics = [
    ['人口', district.population.toLocaleString(), '#176CB0'],
    ['需求', demandSystem.getTotalDemand(district.id).toLocaleString(), '#20A05B'],
    ['客单', '¥' + district.avgSpend, '#154A85'],
    ['餐饮店', district.restaurantCount + '家', '#154A85'],
    ['饱和度', district.saturation + '%', '#1788CE'],
    ['租金', district.rentIndex.toFixed(2), '#154A85']
  ];

  const metricX = x + 113;
  const metricY = y + 49;
  const gap = 4;
  const usableW = w - 123;
  const metricW = Math.floor((usableW - gap * 5) / 6);
  const metricH = 48;

  for (let i = 0; i < metrics.length; i++) {
    const mx = metricX + i * (metricW + gap);

    roundedRect(
      mx,
      metricY,
      metricW,
      metricH,
      8,
      '#FAF9F4',
      'rgba(19,65,92,0.10)'
    );

    drawMetricSymbol(
      metrics[i][0],
      mx + metricW / 2,
      metricY + 11,
      metrics[i][2]
    );

    drawText(
      metrics[i][0],
      mx + metricW / 2,
      metricY + 25,
      5.6,
      '#245477',
      '700',
      'center'
    );

    drawText(
      metrics[i][1],
      mx + metricW / 2,
      metricY + 40,
      7.2,
      metrics[i][2],
      '800',
      'center'
    );
  }

  const buttonW = 104;
  const buttonH = 35;
  const buttonX = x + w - buttonW - 9;
  const buttonY = y + h - buttonH - 8;

  drawText(
    fitText(
      '实时数据随人口、事件、竞争及租金动态变化',
      buttonX - (x + 113) - 8,
      5.7,
      '600'
    ),
    x + 113,
    y + h - 17,
    5.7,
    '#667F91',
    '600'
  );

  roundedRect(
    buttonX,
    buttonY,
    buttonW,
    buttonH,
    17,
    '#FFC62D',
    '#DBA11B',
    1.25
  );

  drawText(
    '进入商圈  ›',
    buttonX + buttonW / 2,
    buttonY + buttonH / 2,
    8.8,
    '#12394F',
    '800',
    'center'
  );

  addButton(
    'district:details',
    buttonX - 4,
    buttonY - 4,
    buttonW + 8,
    buttonH + 8
  );
};

drawBottomNav = function () {
  const current = sceneManager.getCurrentId();

  const items = [
    { id: 'city', label: '城市', mapTo: 'city' },
    { id: 'shop', label: '门店', mapTo: 'shop' },
    { id: 'renovation', label: '装修', mapTo: 'renovation' },
    { id: 'research', label: '菜单', mapTo: 'research' },
    { id: 'supply', label: '供应链', mapTo: 'supply' },
    { id: 'business', label: '数据', mapTo: 'business' },
    { id: 'system', label: '系统', mapTo: 'system' }
  ];

  if (current === 'city') {
    const navImage = resourceManager.getImage('v32_bottom_nav_reference');

    ctx.fillStyle = '#063C61';
    ctx.fillRect(0, NAV_Y, VIEW_W, NAV_H);

    if (navImage) {
      ctx.drawImage(
        navImage,
        0,
        NAV_Y,
        VIEW_W,
        NAV_H - SAFE_BOTTOM
      );
    }

    const cellW = VIEW_W / items.length;

    for (let i = 0; i < items.length; i++) {
      addButton(
        'nav:' + items[i].id,
        i * cellW,
        NAV_Y,
        cellW,
        NAV_H
      );
    }

    return;
  }

  roundedRect(0, NAV_Y, VIEW_W, NAV_H, 0, 'rgba(4,54,84,0.99)');
  const glow = ctx.createLinearGradient(0, NAV_Y, 0, NAV_Y + NAV_H);
  glow.addColorStop(0, 'rgba(28,134,207,0.24)');
  glow.addColorStop(1, 'rgba(28,134,207,0)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, NAV_Y, VIEW_W, NAV_H);

  const cellW = VIEW_W / items.length;

  for (let i = 0; i < items.length; i++) {
    const item = items[i];

    const active =
      (item.id === 'city' && current === 'city') ||
      (
        item.id === 'shop' &&
        (
          current === 'shop' ||
          current === 'propertyMarket' ||
          current === 'equipment' ||
          current === 'license' ||
          current === 'staff'
        )
      ) ||
      (item.id === 'renovation' && current === 'renovation') ||
      (item.id === 'research' && current === 'research') ||
      (item.id === 'supply' && current === 'supply') ||
      (item.id === 'business' && current === 'business');

    const cellX = i * cellW;

    if (active) {
      roundedRect(
        cellX + 4,
        NAV_Y + 4,
        cellW - 8,
        NAV_H - SAFE_BOTTOM - 8,
        13,
        '#F7CC2C',
        '#FFE99A',
        1.1
      );
    }

    if (item.id === 'renovation') {
      const img = resourceManager.getImage('v32_nav_renovation');

      if (img) {
        ctx.drawImage(
          img,
          cellX + cellW / 2 - 13,
          NAV_Y + 9,
          26,
          26
        );
      }
    } else {
      drawNavIcon(
        item.id,
        cellX + cellW / 2,
        NAV_Y + 22,
        active
      );
    }

    drawText(
      item.label,
      cellX + cellW / 2,
      NAV_Y + 48,
      8.0,
      active ? '#17384C' : '#FFFFFF',
      active ? '800' : '700',
      'center'
    );

    addButton(
      'nav:' + item.id,
      cellX,
      NAV_Y,
      cellW,
      NAV_H
    );
  }
};

if (cityScene && typeof cityScene.enter === 'function' && !cityScene.__v32Wrapped) {
  const originalEnter = cityScene.enter;

  cityScene.enter = function () {
    originalEnter.call(this);
    trafficMode = false;
    v32SelectedDistrict();
  };

  cityScene.__v32Wrapped = true;
}

console.log('V32_REFERENCE_HOME_REBUILD loaded');
`;

  source = source.slice(0, insertAt) + block + source.slice(insertAt);

  source = source.replace(
    '城市餐饮经营小游戏 V31 对齐与资金自适应版启动成功',
    '城市餐饮经营小游戏 V32 参考图主页重制版启动成功'
  );

  source = source.replace(
    '城市餐饮经营小游戏 V29 高清图标版启动成功',
    '城市餐饮经营小游戏 V32 参考图主页重制版启动成功'
  );

  fs.writeFileSync(mainPath, source, "utf8");
}

const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
if (pkg.scripts) delete pkg.scripts.pretest;
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n", "utf8");

try { fs.unlinkSync(__filename); } catch (e) {}

console.log("V32参考图主页重制已应用");
