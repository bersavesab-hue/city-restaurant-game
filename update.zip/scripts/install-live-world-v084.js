'use strict';

const fs =
  require('fs');

const path =
  require('path');

const childProcess =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

function file(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs.readFileSync(
    file(rel),
    'utf8'
  );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    file(rel),
    content
  );
}

function insertAfter(
  rel,
  anchor,
  addition,
  marker
) {
  let text =
    read(rel);

  if (
    marker &&
    text.includes(
      marker
    )
  ) {
    return false;
  }

  const index =
    text.indexOf(
      anchor
    );

  if (index < 0) {
    throw new Error(
      rel +
      ' 缺少锚点: ' +
      anchor.slice(
        0,
        80
      )
    );
  }

  text =
    text.slice(
      0,
      index +
      anchor.length
    ) +
    addition +
    text.slice(
      index +
      anchor.length
    );

  write(
    rel,
    text
  );

  return true;
}

function replaceBetween(
  rel,
  start,
  end,
  replacement,
  marker
) {
  let text =
    read(rel);

  if (
    marker &&
    text.includes(
      marker
    )
  ) {
    return false;
  }

  const a =
    text.indexOf(
      start
    );

  if (a < 0) {
    throw new Error(
      rel +
      ' 缺少起始锚点: ' +
      start
    );
  }

  const b =
    text.indexOf(
      end,
      a +
      start.length
    );

  if (b < 0) {
    throw new Error(
      rel +
      ' 缺少结束锚点: ' +
      end
    );
  }

  text =
    text.slice(
      0,
      a
    ) +
    replacement +
    '\n\n' +
    text.slice(
      b
    );

  write(
    rel,
    text
  );

  return true;
}

function replaceOnce(
  rel,
  oldText,
  newText,
  marker
) {
  let text =
    read(rel);

  if (
    marker &&
    text.includes(
      marker
    )
  ) {
    return false;
  }

  const count =
    text.split(
      oldText
    ).length -
    1;

  if (count !== 1) {
    throw new Error(
      rel +
      ' 预期唯一锚点，实际=' +
      count
    );
  }

  text =
    text.replace(
      oldText,
      newText
    );

  write(
    rel,
    text
  );

  return true;
}

function log(
  changed,
  label
) {
  console.log(
    changed
      ? '[V0.8.4] 接入: ' +
        label
      : '[V0.8.4] 已存在: ' +
        label
  );
}

const openingImports =
  `

const personRules =
  require('../person/personRulesV10.js');

const personPack =
  require('../person/personPackV10.js');

const { SeededRng } =
  require('../foundation/rng.js');
// V084_PERSON_CANDIDATES
`;

log(
  insertAfter(
    'src/opening/openingPrepSystem.js',
    "const config =\n  require('./openingConfig.js');",
    openingImports,
    'V084_PERSON_CANDIDATES'
  ),
  '招聘候选人接入完整人物引擎'
);

const candidateFunction =
`  generateCandidate(
    shopId,
    role,
    index,
    day
  ) {
    // V084_PERSON_CANDIDATE_GENERATOR
    const seed =
      gameState
        .getSimulation()
        .seed ||
      1;

    const rng =
      new SeededRng(
        'candidate:' +
        seed +
        ':' +
        shopId +
        ':' +
        role.id +
        ':' +
        day +
        ':' +
        index
      );

    const profile =
      personRules
        .createPersonProfile(
          rng,
          {
            age:
              rng.int(
                20,
                49
              )
          }
        );

    profile.id =
      'person_candidate_' +
      role.id +
      '_' +
      day +
      '_' +
      index;

    const roleMap = {
      manager:'manager',
      chef:'chef',
      server:'waiter',
      cashier:'cashier'
    };

    const npcRoleId =
      roleMap[
        role.id
      ] ||
      'waiter';

    personRules
      .assignRole(
        profile,
        npcRoleId,
        {
          allowLowFit:true,
          employerId:null
        }
      );

    const roleDef =
      personPack
        .NPC_ROLES
        .find(
          item =>
            item.id ===
            npcRoleId
        );

    const fit =
      personRules
        .roleFit(
          profile,
          roleDef
        );

    const skillKeys = {
      manager:[
        'management',
        'operations',
        'leadership'
      ],
      chef:[
        'cooking',
        'prep',
        'foodSafety'
      ],
      server:[
        'service',
        'sales'
      ],
      cashier:[
        'cashier',
        'service',
        'digital'
      ]
    };

    const keys =
      skillKeys[
        role.id
      ] ||
      [
        'operations'
      ];

    const skill =
      Math.round(
        keys.reduce(
          (
            sum,
            key
          ) =>
            sum +
            (
              Number(
                profile.skills[
                  key
                ]
              ) ||
              0
            ),
          0
        ) /
        keys.length
      );

    const stability =
      Math.round(
        (
          Number(
            profile
              .personality
              .stability
          ) ||
          50
        ) *
          0.62 +
        (
          Number(
            profile
              .personality
              .conscientiousness
          ) ||
          50
        ) *
          0.38
      );

    const experience =
      Math.max(
        0,
        Math.min(
          16,
          Math.round(
            (
              profile.age -
              18
            ) *
            (
              0.18 +
              rng.next() *
              0.34
            )
          )
        )
      );

    const wage =
      Math.round(
        role.baseWage *
        (
          0.82 +
          skill /
            260 +
          experience /
            120 +
          (
            fit.score ||
            50
          ) /
            500
        ) /
        100
      ) *
      100;

    return {
      id:
        'candidate_' +
        role.id +
        '_' +
        day +
        '_' +
        index,
      roleId:
        role.id,
      roleName:
        role.name,
      name:
        profile.name,
      age:
        profile.age,
      skill,
      stability,
      experience,
      wage,
      score:
        Math.round(
          (
            fit.score ||
            skill
          ) *
            0.45 +
          skill *
            0.30 +
          stability *
            0.15 +
          Math.min(
            100,
            experience *
              8
          ) *
            0.10
        ),
      personalityLabels:
        (
          profile
            .personalityLabels ||
          []
        ).slice(
          0,
          3
        ),
      personProfile:
        profile
    };
  }`;

log(
  replaceBetween(
    'src/opening/openingPrepSystem.js',
    '  generateCandidate(',
    '  refreshCandidates(',
    candidateFunction,
    'V084_PERSON_CANDIDATE_GENERATOR'
  ),
  '候选人性格/背景/技能改为真实人物档案'
);

const oldHire =
`    state.hired.push({
      id:
        'staff_' +
        candidate.id,
      ...clone(
        candidate
      ),
      hiredDay:
        this.getCurrentDay(),
      signOnCost
    });`;

const newHire =
`    // V084_HIRE_PERSON_ID
    state.hired.push({
      ...clone(
        candidate
      ),
      id:
        'staff_' +
        candidate.id,
      personId:
        candidate
          .personProfile &&
        candidate
          .personProfile
          .id ||
        candidate.id,
      hiredDay:
        this.getCurrentDay(),
      signOnCost,
      live:
        candidate
          .personProfile &&
        candidate
          .personProfile
          .state
          ? {
              ...clone(
                candidate
                  .personProfile
                  .state
              ),
              turnoverRisk:0,
              entrepreneurship:0,
              lastUpdatedDay:
                this.getCurrentDay()
            }
          : null
    });`;

log(
  replaceOnce(
    'src/opening/openingPrepSystem.js',
    oldHire,
    newHire,
    'V084_HIRE_PERSON_ID'
  ),
  '修复录用后员工ID并保留人物状态'
);

const payrollAnchor =
`    const payroll =
      state.hired.reduce(
        (
          total,
          staff
        ) =>
          total +
          staff.wage,
        0
      );`;

const peopleSummary =
`

    // V084_STAFF_OVERVIEW
    const people =
      state.hired.map(
        staff =>
          staff.live ||
          staff.personProfile &&
          staff.personProfile.state ||
          {}
      );

    const peopleSummary =
      people.length
        ? {
            count:
              people.length,
            avgMood:
              Math.round(
                people.reduce(
                  (
                    sum,
                    row
                  ) =>
                    sum +
                    (
                      Number(
                        row.mood
                      ) ||
                      65
                    ),
                  0
                ) /
                people.length
              ),
            avgStress:
              Math.round(
                people.reduce(
                  (
                    sum,
                    row
                  ) =>
                    sum +
                    (
                      Number(
                        row.stress
                      ) ||
                      25
                    ),
                  0
                ) /
                people.length
              ),
            avgLoyalty:
              Math.round(
                people.reduce(
                  (
                    sum,
                    row
                  ) =>
                    sum +
                    (
                      Number(
                        row.loyalty
                      ) ||
                      55
                    ),
                  0
                ) /
                people.length
              ),
            highTurnoverRisk:
              people.filter(
                row =>
                  Number(
                    row.turnoverRisk
                  ) >=
                  68
              ).length
          }
        : {
            count:0,
            avgMood:0,
            avgStress:0,
            avgLoyalty:0,
            highTurnoverRisk:0
          };
`;

log(
  insertAfter(
    'src/opening/openingPrepSystem.js',
    payrollAnchor,
    peopleSummary,
    'V084_STAFF_OVERVIEW'
  ),
  '招聘页增加团队情绪与离职风险汇总'
);

log(
  replaceOnce(
    'src/opening/openingPrepSystem.js',
    `      payroll,
      coverage:`,
    `      payroll,
      peopleSummary,
      coverage:`,
    'peopleSummary,\n      coverage:'
  ),
  '团队状态暴露给UI'
);

const simImport =
`

const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');
// V084_LIVE_WORLD_SIMULATION
`;

log(
  insertAfter(
    'src/core/simulationSystem.js',
    "const dynamicWorldSystem =\n  require('../world/dynamicWorldSystemV0815.js');",
    simImport,
    'V084_LIVE_WORLD_SIMULATION'
  ),
  '城市日推进接入活人/竞品世界'
);

const dynamicCall =
`    dynamicWorldSystem
      .processDay(
        dayOrdinal,
        {
          weather:
            weather.weather,
          temperature:
            weather.temperature
        }
      );`;

log(
  insertAfter(
    'src/core/simulationSystem.js',
    dynamicCall,
    `

    // V084_WORLD_DAILY_TICK
    liveWorldSystem
      .processDay(
        dayOrdinal,
        {
          weather:
            weather.weather,
          temperature:
            weather.temperature
        }
      );`,
    'V084_WORLD_DAILY_TICK'
  ),
  '每天驱动员工和竞品状态'
);

const restImport =
`

const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');
// V084_RESTAURANT_LIVE_WORLD
`;

log(
  insertAfter(
    'src/operations/restaurantSimulationV081.js',
    "const dynamicWorldSystem =\n  require('../world/dynamicWorldSystemV0815.js');",
    restImport,
    'V084_RESTAURANT_LIVE_WORLD'
  ),
  '门店经营读取员工与竞品实时状态'
);

const staffCoverageStart =
`function staffCoverage(
  shop
) {`;

const staffCoverageEnd =
`function dailyPayroll(`;

const newStaffCoverage =
`function staffCoverage(
  shop
) {
  // V084_STAFF_CAPACITY
  try {
    const readiness =
      openingPrepSystem
        .getReadiness(
          shop.id
        );

    const base =
      clamp(
        readiness &&
        readiness.staffing
          ? readiness
              .staffing
              .coverage
          : 0.85,
        0.3,
        1.2
      );

    const people =
      liveWorldSystem
        .getStaffModifier(
          shop.id
        );

    return clamp(
      base *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ),
      0.25,
      1.2
    );
  } catch (error) {
    return 0.85;
  }
}`;

log(
  replaceBetween(
    'src/operations/restaurantSimulationV081.js',
    staffCoverageStart,
    staffCoverageEnd,
    newStaffCoverage,
    'V084_STAFF_CAPACITY'
  ),
  '员工情绪/精力/压力进入真实产能'
);

const demandMarker =
`  const dynamicDemandFactor =
    Number(
      worldModifiers
        .demandMultiplier
    ) || 1;`;

log(
  insertAfter(
    'src/operations/restaurantSimulationV081.js',
    demandMarker,
    `

  // V084_COMPETITION_DEMAND
  const competitiveMarket =
    liveWorldSystem
      .getDistrictDashboard(
        shop.districtId
      );

  const competitionFactor =
    Number(
      competitiveMarket
        .playerDemandMultiplier
    ) || 1;`,
    'V084_COMPETITION_DEMAND'
  ),
  '竞品行动进入玩家真实客流'
);

log(
  replaceOnce(
    'src/operations/restaurantSimulationV081.js',
    `      dynamicDemandFactor *
      nightFactor`,
    `      dynamicDemandFactor *
      competitionFactor *
      nightFactor`,
    'competitionFactor *\n      nightFactor'
  ),
  '竞争压力真正影响进店量'
);

const gameDefaultAnchor =
`    dynamicWorld: {
      version: '0.8.15',
      lastProcessedDay: null,
      eventState: null,
      policyState: null,
      npcPool: [],
      dialogueFeed: [],
      barrageFeed: [],
      signalHistory: [],
      modifiers: {},
      metrics: {
        eventsTriggered: 0,
        policiesProposed: 0,
        dialoguesGenerated: 0,
        barragesGenerated: 0
      }
    }`;

const liveWorldDefault =
`,

    // V084_LIVE_WORLD_STATE
    liveWorld: {
      version:'0.8.4',
      initialized:false,
      lastProcessedDay:null,
      competitors:[],
      competitorCounts:{
        core:0,
        local:0,
        background:0
      },
      districtPressure:{},
      staffHistory:[],
      marketHistory:[],
      metrics:{
        competitorActions:0,
        openings:0,
        closures:0,
        staffDepartures:0,
        staffEntrepreneurs:0
      }
    }`;

log(
  insertAfter(
    'src/core/gameState.js',
    gameDefaultAnchor,
    liveWorldDefault,
    'V084_LIVE_WORLD_STATE'
  ),
  '存档增加活人世界状态'
);

const getDynamicAnchor =
`  getDynamicWorld() {
    const world =
      this.data.world;`;

const liveWorldGetter =
`  // V084_GET_LIVE_WORLD
  getLiveWorld() {
    const world =
      this.data.world;

    if (
      !world.liveWorld ||
      typeof world.liveWorld !==
        'object'
    ) {
      world.liveWorld = {
        version:'0.8.4',
        initialized:false,
        lastProcessedDay:null,
        competitors:[],
        competitorCounts:{
          core:0,
          local:0,
          background:0
        },
        districtPressure:{},
        staffHistory:[],
        marketHistory:[],
        metrics:{
          competitorActions:0,
          openings:0,
          closures:0,
          staffDepartures:0,
          staffEntrepreneurs:0
        }
      };
    }

    return world.liveWorld;
  }

`;

let gameStateText =
  read(
    'src/core/gameState.js'
  );

if (
  !gameStateText.includes(
    'V084_GET_LIVE_WORLD'
  )
) {
  const dynIndex =
    gameStateText.indexOf(
      '  getDynamicWorld() {'
    );

  if (dynIndex < 0) {
    throw new Error(
      'gameState缺少getDynamicWorld'
    );
  }

  gameStateText =
    gameStateText.slice(
      0,
      dynIndex
    ) +
    liveWorldGetter +
    gameStateText.slice(
      dynIndex
    );

  write(
    'src/core/gameState.js',
    gameStateText
  );

  console.log(
    '[V0.8.4] 接入: GameState.getLiveWorld'
  );
}

const staffCandidateLine =
`        '技能 ' +
          candidate.skill +
          ' · 稳定 ' +
          candidate.stability +
          ' · 综合 ' +
          candidate.score,`;

const staffCandidateNew =
`        '技能 ' +
          candidate.skill +
          ' · ' +
          (
            candidate
              .personalityLabels &&
            candidate
              .personalityLabels
              .length
              ? candidate
                  .personalityLabels
                  .slice(
                    0,
                    2
                  )
                  .join(
                    '/'
                  )
              : '稳定 ' +
                candidate.stability
          ) +
          ' · 综合 ' +
          candidate.score,`;

log(
  replaceOnce(
    'src/scenes/staffScene.js',
    staffCandidateLine,
    staffCandidateNew,
    "personalityLabels\n              .length"
  ),
  '招聘卡片展示候选人性格'
);

const staffActionText =
`      overview.coverage >=
        0.9
        ? '基本班组已齐备'
        : '候选人次日会自动更新',`;

const staffActionNew =
`      overview
        .peopleSummary &&
      overview
        .peopleSummary
        .count
        ? '团队情绪 ' +
          overview
            .peopleSummary
            .avgMood +
          ' · 压力 ' +
          overview
            .peopleSummary
            .avgStress +
          ' · 高离职风险 ' +
          overview
            .peopleSummary
            .highTurnoverRisk
        : overview.coverage >=
            0.9
          ? '基本班组已齐备'
          : '候选人次日会自动更新',`;

log(
  replaceOnce(
    'src/scenes/staffScene.js',
    staffActionText,
    staffActionNew,
    "'团队情绪 ' +"
  ),
  '招聘页显示团队实时状态'
);

const businessImport =
`

const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');
// V084_BUSINESS_WORLD
`;

log(
  insertAfter(
    'src/scenes/businessScene.js',
    "const operations =\n  require('../operations/operationsStoreV080.js');",
    businessImport,
    'V084_BUSINESS_WORLD'
  ),
  '数据页接入竞争/员工状态'
);

const businessData =
`    const data =
      operations
        .dashboard(
          shop.id
        );`;

log(
  insertAfter(
    'src/scenes/businessScene.js',
    businessData,
    `

    // V084_BUSINESS_WORLD_DATA
    const market =
      liveWorldSystem
        .getDistrictDashboard(
          shop.districtId
        );

    const people =
      liveWorldSystem
        .getStaffSummary(
          shop.id
        );`,
    'V084_BUSINESS_WORLD_DATA'
  ),
  '数据页读取竞争压力和员工风险'
);

const businessCard =
`      362,
      112,`;

const businessCardNew =
`      362,
      174,`;

const btxt =
  read(
    'src/scenes/businessScene.js'
  );

const cardAnchor =
  btxt.indexOf(
    `      14,
      468,
      362,
      112,`
  );

if (
  cardAnchor >= 0 &&
  !btxt.includes(
    'V084_COMPETITION_METRICS'
  )
) {
  const replaced =
    btxt.slice(
      0,
      cardAnchor
    ) +
    btxt.slice(
      cardAnchor
    ).replace(
      `      14,
      468,
      362,
      112,`,
      `      14,
      468,
      362,
      174,`
    );

  write(
    'src/scenes/businessScene.js',
    replaced
  );
}

const purchaseBlock =
`    ui.text(
      ctx,
      data.purchaseOrderCount +
        ' 笔',
      352,
      572,
      7.8,
      '#173D54',
      '800',
      'right'
    );`;

const businessExtra =
`

    // V084_COMPETITION_METRICS
    ui.text(
      ctx,
      '竞争压力',
      28,
      598,
      7.3,
      '#728792',
      '600'
    );

    ui.text(
      ctx,
      market.intensityLabel +
        ' · ' +
        market.competitorCount +
        '店',
      352,
      598,
      7.8,
      market.intensity >=
        70
        ? '#C85242'
        : '#173D54',
      '800',
      'right'
    );

    ui.text(
      ctx,
      '员工状态',
      28,
      624,
      7.3,
      '#728792',
      '600'
    );

    ui.text(
      ctx,
      people.count
        ? '情绪' +
          people.avgMood +
          ' · 高风险' +
          people.highTurnoverRisk
        : '暂无员工',
      352,
      624,
      7.8,
      people.highTurnoverRisk >
        0
        ? '#C85242'
        : '#173D54',
      '800',
      'right'
    );`;

log(
  insertAfter(
    'src/scenes/businessScene.js',
    purchaseBlock,
    businessExtra,
    'V084_COMPETITION_METRICS'
  ),
  '数据页增加竞争压力/员工风险'
);

const pkgPath =
  file(
    'package.json'
  );

const pkg =
  JSON.parse(
    fs.readFileSync(
      pkgPath,
      'utf8'
    )
  );

pkg.version =
  '0.8.4';

const installerCmd =
  'node scripts/install-live-world-v084.js';

const testCmd =
  'node tests/liveWorldV084.test.js';

const parts =
  String(
    pkg.scripts.pretest ||
    ''
  )
    .split(
      ' && '
    )
    .filter(
      part =>
        part &&
        part !==
          installerCmd
    );

if (
  parts.indexOf(
    testCmd
  ) < 0
) {
  parts.unshift(
    testCmd
  );
}

pkg.scripts.pretest =
  parts.join(
    ' && '
  );

fs.writeFileSync(
  pkgPath,
  JSON.stringify(
    pkg,
    null,
    2
  ) +
  '\n'
);

const checks = [
  'src/world/liveWorldSystemV084.js',
  'src/opening/openingPrepSystem.js',
  'src/core/simulationSystem.js',
  'src/operations/restaurantSimulationV081.js',
  'src/core/gameState.js',
  'src/scenes/staffScene.js',
  'src/scenes/businessScene.js'
];

for (
  const rel
  of checks
) {
  const checked =
    childProcess
      .spawnSync(
        process.execPath,
        [
          '--check',
          file(rel)
        ],
        {
          encoding:'utf8'
        }
      );

  if (
    checked.status !==
    0
  ) {
    throw new Error(
      rel +
      ' 语法检查失败: ' +
      (
        checked.stderr ||
        checked.stdout ||
        ''
      )
    );
  }
}

console.log(
  '[V0.8.4] 全部修改文件语法检查通过'
);

console.log(
  '[V0.8.4] 活人世界与竞品世界接线完成'
);

try {
  fs.unlinkSync(
    __filename
  );
  console.log(
    '[V0.8.4] 安装器已自清理'
  );
} catch (error) {
  console.warn(
    '[V0.8.4] 安装器清理失败:',
    error.message
  );
}
