"use strict";

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const mainPath = path.join(ROOT, 'src/main.js');
const marker = '\n/* =========================\n   启动\n========================= */';

let source = fs.readFileSync(mainPath, 'utf8');

if (source.includes('V24_FINAL_HOME_PACK')) {
  console.log('V24最终主页资源包已存在');
} else {
  const index = source.indexOf(marker);
  if (index < 0) {
    throw new Error('V24无法找到启动标记');
  }

  const block = String.raw`
/* V24_FINAL_HOME_PACK */

const V24_DISTRICT_PREVIEW_KEYS = {
  university: 'v24_preview_university',
  hightech: 'v24_preview_hightech',
  cbd: 'v24_preview_cbd',
  oldtown: 'v24_preview_oldtown',
  village: 'v24_preview_village',
  market: 'v24_preview_market',
  industry: 'v24_preview_industry'
};

const v24OriginalLoadResources = loadResources;
const v24OriginalDrawDistrictCard = drawDistrictCard;
const v24OriginalDrawMapBase = drawMapBase;

loadResources = function () {
  const previews = [
    ['v24_preview_university', 'district_preview_university.png'],
    ['v24_preview_hightech', 'district_preview_hightech.png'],
    ['v24_preview_cbd', 'district_preview_cbd.png'],
    ['v24_preview_oldtown', 'district_preview_oldtown.png'],
    ['v24_preview_village', 'district_preview_village.png'],
    ['v24_preview_market', 'district_preview_market.png'],
    ['v24_preview_industry', 'district_preview_industry.png']
  ];

  const tasks = [];
  for (let i = 0; i < previews.length; i++) {
    tasks.push(
      resourceManager.loadImage(
        previews[i][0],
        'assets/images/v24/' + previews[i][1],
        'v24-ui'
      )
    );
  }

  return Promise.all(tasks).then(function () {
    return v24OriginalLoadResources();
  });
};

drawMapBase = function () {
  const image = resourceManager.getImage('city_base_01');
  if (!image) {
    return v24OriginalDrawMapBase();
  }

  drawImageFocus(
    ctx,
    image,
    MAP_X,
    MAP_Y,
    MAP_W,
    MAP_H,
    1.58,
    0.51,
    0.52
  );

  const topFade = ctx.createLinearGradient(0, MAP_Y, 0, MAP_Y + 120);
  topFade.addColorStop(0, 'rgba(5,35,54,0.20)');
  topFade.addColorStop(1, 'rgba(5,35,54,0.00)');
  ctx.fillStyle = topFade;
  ctx.fillRect(MAP_X, MAP_Y, MAP_W, 120);
};

drawDistrictCard = function () {
  const district = (typeof v23EnsureSelectedDistrict === 'function')
    ? v23EnsureSelectedDistrict()
    : ((getDistricts() || [])[0] || null);

  if (!district) {
    return v24OriginalDrawDistrictCard();
  }

  const meta = getDistrictVisualMeta(district);
  const x = CARD_X;
  const y = CARD_Y;
  const w = CARD_W;
  const h = CARD_H;

  roundedRect(x, y, w, h, 17, 'rgba(255,255,255,0.988)', 'rgba(10,56,79,0.16)', 1.1);

  const previewKey = V24_DISTRICT_PREVIEW_KEYS[district.id];
  const preview = resourceManager.getImage(previewKey);
  const px = x + 11;
  const py = y + 10;
  const pw = 88;
  const ph = h - 20;
  if (preview) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(px + 14, py);
    ctx.arcTo(px + pw, py, px + pw, py + ph, 14);
    ctx.arcTo(px + pw, py + ph, px, py + ph, 14);
    ctx.arcTo(px, py + ph, px, py, 14);
    ctx.arcTo(px, py, px + pw, py, 14);
    ctx.closePath();
    ctx.clip();
    drawImageFocus(ctx, preview, px, py, pw, ph, 1.02, 0.5, 0.5);
    ctx.restore();
  } else {
    return v24OriginalDrawDistrictCard();
  }

  const iconKey = V21_DISTRICT_ICON_KEYS && V21_DISTRICT_ICON_KEYS[district.id];
  if (iconKey && typeof v21DrawImage === 'function') {
    v21DrawImage(iconKey, x + 118, y + 19, 19, 24);
  }

  drawText(district.name, x + 130, y + 18, 13.2, '#103655', '800');
  drawText('›', x + 194, y + 18, 12.4, '#2F5673', '800', 'center');

  let summary = '客群活跃 · 仍有经营机会';
  if (meta.badge === '租金低') summary = '租金较低 · 适合抢先布局';
  if (meta.badge === '竞争高') summary = '竞争激烈 · 适合差异化经营';
  if (meta.badge === '需求↑') summary = '需求上涨 · 可优先进入';
  if (meta.badge === '人气高') summary = '客群活跃 · 仍有经营机会';
  if (meta.myShopCount > 0) summary = '已开门店 · 可继续深耕经营';

  drawText(summary, x + 110, y + 35, 6.2, '#39627E', '700');

  const metrics = [
    ['人口', district.population.toLocaleString(), '#1E76C5'],
    ['需求', demandSystem.getTotalDemand(district.id).toLocaleString(), '#1E9A5E'],
    ['客单', '¥' + district.avgSpend, '#164A86'],
    ['餐饮店', district.restaurantCount + '家', '#164A86'],
    ['饱和度', district.saturation + '%', '#1E76C5'],
    ['租金', district.rentIndex.toFixed(2), '#164A86']
  ];

  const metricX = x + 103;
  const metricY = y + 47;
  const metricGap = 4;
  const metricW = Math.floor((w - 220 - metricGap * 5) / 6);
  for (let i = 0; i < metrics.length; i++) {
    const mx = metricX + i * (metricW + metricGap);
    roundedRect(mx, metricY, metricW, 39, 8, '#FAF8F3', 'rgba(17,62,92,0.10)');
    drawMetricSymbol(metrics[i][0], mx + metricW / 2, metricY + 9.5, metrics[i][2]);
    drawText(metrics[i][0], mx + metricW / 2, metricY + 20.5, 4.9, '#245276', '700', 'center');
    drawText(metrics[i][1], mx + metricW / 2, metricY + 33.5, 6.2, metrics[i][2], '800', 'center');
  }

  drawText('实时数据会随人口、城市事件、竞争和租金变化', x + 109, y + h - 17, 5.5, '#607D92', '600');
  roundedRect(x + w - 116, y + h - 42, 106, 34, 18, '#FFC22D', '#DFA01B', 1.2);
  drawText('进入商圈  ›', x + w - 63, y + h - 25, 8.4, '#123A53', '800', 'center');
  addButton('district:details', x + w - 120, y + h - 46, 112, 42);
};

console.log('V24_FINAL_HOME_PACK loaded');
`;

  source = source.slice(0, index) + block + source.slice(index);
  source = source.replace(
    '城市餐饮经营小游戏 V23 主页锚点与版式重构版启动成功',
    '城市餐饮经营小游戏 V24 最终主页资源版启动成功'
  );
  source = source.replace(
    '城市餐饮经营小游戏 V22 主页一对一复刻版启动成功',
    '城市餐饮经营小游戏 V24 最终主页资源版启动成功'
  );

  fs.writeFileSync(mainPath, source, 'utf8');
}

const pkgPath = path.join(ROOT, 'package.json');
const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
if (pkg.scripts) {
  delete pkg.scripts.pretest;
}
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');

try {
  fs.unlinkSync(__filename);
} catch (error) {
}

console.log('V24最终主页资源包已应用');
