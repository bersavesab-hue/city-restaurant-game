'use strict';
const fs=require('fs');const path=require('path');const cp=require('child_process');
const root=path.resolve(__dirname,'..');
function runNode(rel,required){const abs=path.join(root,rel);if(!fs.existsSync(abs)){if(required){console.error('[TEST] 必需文件缺失:',rel);process.exit(1);}return false;}console.log('\n[TEST]',rel);const r=cp.spawnSync(process.execPath,[abs],{cwd:root,stdio:'inherit'});if(r.status!==0)process.exit(r.status||1);return true;}
function walk(dir){const abs=path.join(root,dir);if(!fs.existsSync(abs))return[];const out=[],st=[abs];while(st.length){const cur=st.pop();for(const e of fs.readdirSync(cur,{withFileTypes:true})){const p=path.join(cur,e.name);if(e.isDirectory())st.push(p);else if(e.isFile()&&e.name.endsWith('.js'))out.push(p);}}return out.sort();}
for(const f of walk('src')){const r=cp.spawnSync(process.execPath,['--check',f],{cwd:root,stdio:'inherit'});if(r.status!==0)process.exit(r.status||1);}
for(const rel of ['tests/core.test.js','tests/propertyFoundation.test.js','tests/propertyMarket.test.js','tests/simulation.test.js'])runNode(rel,false);
for(const rel of ['tests/layoutRepairV050.test.js','tests/foundationSrcV050.test.js','tests/propertyFullPackV100Src.test.js','tests/personNpcFullPackV100Src.test.js','tests/competitorFullPackV110.test.js','tests/customerFullPackV100.test.js','tests/easterEggPackV100Src.test.js','tests/foodMenuFullPackV200.test.js','tests/foodMenuCompatibilityV210.test.js','tests/recoveryContractV053.test.js'])runNode(rel,true);
console.log('\nRECOVERY V0.5.3 + FOOD V2.1 TESTS PASS');
