'use strict';

// V0851_AUTO_DISCOVERY_TEST_RUNNER
// Replaces the fragile historical hard-coded test list.

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');

function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  const out = [];
  for (const ent of fs.readdirSync(dir, {withFileTypes:true})) {
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) out.push(...walk(p));
    else if (ent.isFile()) out.push(p);
  }
  return out;
}

function runNode(abs) {
  const rel = path.relative(ROOT, abs).replace(/\\/g, '/');
  console.log('\n[TEST]', rel);
  const r = cp.spawnSync(process.execPath, [abs], {cwd:ROOT, stdio:'inherit'});
  if (r.status !== 0) process.exit(r.status || 1);
}

function checkSyntax(abs) {
  const rel = path.relative(ROOT, abs).replace(/\\/g, '/');
  const r = cp.spawnSync(process.execPath, ['--check', abs], {cwd:ROOT, stdio:'inherit'});
  if (r.status !== 0) {
    console.error('[SYNTAX FAIL]', rel);
    process.exit(r.status || 1);
  }
}

// Keep the historical audit when present, but do not require it on partial/dev clones.
const audit = path.join(ROOT, 'scripts/v60-audit.js');
if (fs.existsSync(audit)) runNode(audit);

for (const dir of ['src', 'scripts']) {
  for (const file of walk(path.join(ROOT, dir)).filter(p => p.endsWith('.js')).sort()) {
    // apply-update-patch.js has already been deleted by workflow before npm test,
    // but skip it defensively if a local developer runs tests before applying.
    if (file.endsWith(path.join('scripts','apply-update-patch.js'))) continue;
    checkSyntax(file);
  }
}

const tests = walk(path.join(ROOT, 'tests'))
  .filter(p => /\.test\.js$/i.test(p))
  .sort((a,b) => a.localeCompare(b, 'en'));

if (!tests.length) {
  console.error('[TEST] no *.test.js files discovered');
  process.exit(1);
}

console.log('[TEST] auto-discovered', tests.length, 'test files');
for (const test of tests) runNode(test);

console.log('\n[TEST] ALL PASS');
