'use strict';

const fs = require('fs');
const cp = require('child_process');
const path = require('path');

const root = process.cwd();
const required = [
  'src/operating/eventCatalogV105.js',
  'src/operating/businessOperatingSystemV105.js',
  'src/operating/operatingRuntimeBridgeV105.js',
  'tests/operatingSystemsV105.test.js',
  'src/main.js',
  'src/city/demandSystem.js',
  'package.json'
];

const problems = [];
for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) problems.push('缺少文件：' + rel);
}

if (!problems.length) {
  const main = fs.readFileSync(path.join(root, 'src/main.js'), 'utf8');
  const demand = fs.readFileSync(path.join(root, 'src/city/demandSystem.js'), 'utf8');
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));

  if (!main.includes("require('./operating/operatingRuntimeBridgeV105.js')")) problems.push('main.js 未接入 operatingRuntimeBridgeV105');
  if (!main.includes('operatingRuntimeBridgeV105.openEventCenter')) problems.push('事件按钮未接入经营中枢');
  if (!demand.includes('RestaurantOperatingV105.getDemandMultiplier')) problems.push('需求系统未接入事件需求倍率');
  if (!String(pkg.scripts && pkg.scripts.test || '').includes('operatingSystemsV105.test.js')) problems.push('npm test 未包含经营中枢测试');
  if (pkg.cityRestaurantOperatingVersion !== '1.0.5') problems.push('package.json 经营中枢版本标记错误');

  const duplicateRequire = (main.match(/operatingRuntimeBridgeV105\.js/g) || []).length;
  if (duplicateRequire !== 1) problems.push('main.js 经营中枢 require 数量异常：' + duplicateRequire);
}

for (const rel of required.filter(x => x.endsWith('.js'))) {
  const full = path.join(root, rel);
  if (!fs.existsSync(full)) continue;
  const result = cp.spawnSync(process.execPath, ['--check', full], { encoding: 'utf8' });
  if (result.status !== 0) problems.push(rel + ' 语法检查失败：' + (result.stderr || result.stdout || '').trim());
}

if (problems.length) {
  console.error('[V1.0.5 AUDIT] FAIL');
  for (const problem of problems) console.error(' - ' + problem);
  process.exit(1);
}

console.log('[V1.0.5 AUDIT] PASS');
console.log(' - 事件引擎/强制弹窗：已接线');
console.log(' - 时间暂停/恢复：已接线');
console.log(' - 事件需求倍率：已接线');
console.log(' - 金融/结算/员工/菜品/评分/排行/奖项/漏斗统一中枢：已加载');
console.log(' - 幂等版本标记：1.0.5');
