'use strict';

// 轻量校验器：资源生产由素材流水线生成，本脚本用于仓库内复核清单与文件。
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const root = path.resolve(__dirname, '../..');
const manifestPath = path.join(root, 'assets/ui/home/manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

function hash(file) {
  const h = crypto.createHash('sha256');
  h.update(fs.readFileSync(file));
  return h.digest('hex');
}

let checked = 0;
for (const item of manifest.entries || []) {
  const file = path.join(root, item.path);
  if (!fs.existsSync(file)) throw new Error('资源不存在：' + item.path);
  if (item.sha256 && hash(file) !== item.sha256) throw new Error('资源哈希不一致：' + item.path);
  checked++;
}
for (const item of Object.values(manifest.atlases || {})) {
  const file = path.join(root, item.path);
  if (!fs.existsSync(file)) throw new Error('图集不存在：' + item.path);
  if (item.sha256 && hash(file) !== item.sha256) throw new Error('图集哈希不一致：' + item.path);
  checked++;
}
console.log('[asset-v054] manifest verified:', checked, 'files');
