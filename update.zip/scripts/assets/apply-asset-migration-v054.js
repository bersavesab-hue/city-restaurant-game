'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '../..');
const homeRoot = path.join(root, 'assets/ui/home');
const manifestPath = path.join(homeRoot, 'manifest.json');
const deleteListPath = path.join(homeRoot, 'delete-list-v2.json');

function fail(message) {
  console.error('[asset-v054] ' + message);
  process.exit(1);
}

if (!fs.existsSync(manifestPath)) fail('缺少 assets/ui/home/manifest.json');
if (!fs.existsSync(deleteListPath)) fail('缺少 assets/ui/home/delete-list-v2.json');

const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const deleteList = JSON.parse(fs.readFileSync(deleteListPath, 'utf8'));

if (manifest.schema !== 2 || manifest.version !== '2.0.0') {
  fail('资源清单版本不正确');
}

const required = [];
for (const item of manifest.entries || []) required.push(item.path);
for (const atlas of Object.values(manifest.atlases || {})) required.push(atlas.path);

if (required.length < 48) fail('优化资源数量异常：' + required.length);
for (const rel of required) {
  const full = path.resolve(root, rel);
  if (!full.startsWith(root + path.sep)) fail('非法资源路径：' + rel);
  if (!fs.existsSync(full)) fail('优化资源缺失：' + rel);
}

let removed = 0;
let releasedBytes = 0;
for (const rel of deleteList.delete || []) {
  if (!rel.startsWith('assets/ui/home/') || rel.includes('..') || !rel.endsWith('.png')) {
    fail('拒绝删除非法路径：' + rel);
  }
  const full = path.resolve(root, rel);
  if (!full.startsWith(homeRoot + path.sep)) fail('删除路径越界：' + rel);
  if (fs.existsSync(full)) {
    const stat = fs.statSync(full);
    releasedBytes += stat.size;
    fs.unlinkSync(full);
    removed++;
  }
}

for (const dir of ['nav','hud','functions','facilities','status','decorative']) {
  const full = path.join(homeRoot, dir);
  if (fs.existsSync(full) && fs.readdirSync(full).length === 0) fs.rmdirSync(full);
}

const marker = path.join(homeRoot, '.asset-v2-ready');
fs.writeFileSync(marker, 'homepage-assets-v2\n', 'utf8');
console.log('[asset-v054] 优化资源验证通过；删除旧PNG ' + removed + ' 个，释放约 ' + (releasedBytes / 1024 / 1024).toFixed(1) + ' MB。');
