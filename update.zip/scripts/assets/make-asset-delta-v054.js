'use strict';

const fs = require('fs');
const path = require('path');

const [oldFile, newFile] = process.argv.slice(2);
if (!oldFile || !newFile) {
  console.error('用法: node scripts/assets/make-asset-delta-v054.js old-manifest.json new-manifest.json');
  process.exit(2);
}

const oldM = JSON.parse(fs.readFileSync(oldFile, 'utf8'));
const newM = JSON.parse(fs.readFileSync(newFile, 'utf8'));

function flatten(m) {
  const map = new Map();
  for (const x of m.entries || []) map.set(x.path, x.sha256 || '');
  for (const x of Object.values(m.atlases || {})) map.set(x.path, x.sha256 || '');
  return map;
}

const oldMap = flatten(oldM);
const newMap = flatten(newM);
const addOrChange = [];
const remove = [];
for (const [p, h] of newMap) if (!oldMap.has(p) || oldMap.get(p) !== h) addOrChange.push(p);
for (const p of oldMap.keys()) if (!newMap.has(p)) remove.push(p);

process.stdout.write(JSON.stringify({addOrChange, remove}, null, 2) + '\n');
