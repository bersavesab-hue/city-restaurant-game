'use strict';

const fs = require('fs');

function read(path) {
  if (!fs.existsSync(path)) {
    throw new Error('[V0.8.3] 缺少目标文件: ' + path);
  }
  return fs.readFileSync(path, 'utf8');
}

function write(path, source) {
  fs.writeFileSync(path, source, 'utf8');
}

function replaceExact(path, before, after, label) {
  let source = read(path);
  if (source.includes(after)) {
    console.log('[V0.8.3] 已存在: ' + label);
    return false;
  }
  if (!source.includes(before)) {
    throw new Error('[V0.8.3] 找不到修复锚点: ' + label + ' @ ' + path);
  }
  source = source.replace(before, after);
  write(path, source);
  console.log('[V0.8.3] 修复: ' + label);
  return true;
}

function replaceSection(path, startMarker, endMarker, replacement, marker, label) {
  let source = read(path);
  if (source.includes(marker)) {
    console.log('[V0.8.3] 已存在: ' + label);
    return false;
  }
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start + startMarker.length);
  if (start < 0 || end < 0 || end <= start) {
    throw new Error('[V0.8.3] 找不到区段锚点: ' + label + ' @ ' + path);
  }
  source = source.slice(0, start) + replacement.trimEnd() + '\n\n' + source.slice(end);
  write(path, source);
  console.log('[V0.8.3] 修复: ' + label);
  return true;
}

// ---------------------------------------------------------------------------
// 1. 同步存档节流：高倍速运行时不再每次经营变化都 setStorageSync。
// ---------------------------------------------------------------------------
replaceExact(
  'src/core/saveSystem.js',
  `  constructor() {\n    this.api =\n      globalThis.GameRuntime &&\n      globalThis.GameRuntime.api;\n  }`,
  `  constructor() {\n    this.api =\n      globalThis.GameRuntime &&\n      globalThis.GameRuntime.api;\n\n    // V083_SAVE_THROTTLE\n    this.lastAutoSaveAt = 0;\n    this.autoSaveIntervalMs = 20000;\n    this.dirty = false;\n  }`,
  '20秒自动存档节流状态'
);

replaceExact(
  'src/core/saveSystem.js',
  `        this.api.setStorageSync(\n          SAVE_KEY,\n          saveData\n        );\n\n        console.log(\n          '游戏保存成功'\n        );`,
  `        this.api.setStorageSync(\n          SAVE_KEY,\n          saveData\n        );\n\n        this.lastAutoSaveAt = Date.now();\n        this.dirty = false;\n\n        console.log(\n          '游戏保存成功'\n        );`,
  '保存成功后刷新节流状态'
);

replaceExact(
  'src/core/saveSystem.js',
  `  /**\n   * 自动保存\n   */\n  autoSave() {\n    return this.save();\n  }`,
  `  /**\n   * 自动保存。高频模拟只标记脏状态，默认每20秒最多同步写一次。\n   * 切后台、重大交易仍可直接调用 save() 强制落盘。\n   */\n  autoSave(force) {\n    // V083_SAVE_THROTTLE_AUTO\n    this.dirty = true;\n\n    const now = Date.now();\n    const elapsed = now - Number(this.lastAutoSaveAt || 0);\n\n    if (\n      force !== true &&\n      this.lastAutoSaveAt > 0 &&\n      elapsed < this.autoSaveIntervalMs\n    ) {\n      return true;\n    }\n\n    return this.save();\n  }\n\n  flush() {\n    if (!this.dirty) {\n      return true;\n    }\n\n    return this.save();\n  }`,
  '自动存档节流与flush'
);

// ---------------------------------------------------------------------------
// 2. 统一真实客流：门店与商圈UI共同读取 demandSystem，修正 heavyRain/周末分叉。
//    同时接入营业时段、营销效率。
// ---------------------------------------------------------------------------
replaceExact(
  'src/operations/restaurantSimulationV081.js',
  `const citySystem =\n  require('../city/citySystem.js');\n\nconst openingPrepSystem =`,
  `const citySystem =\n  require('../city/citySystem.js');\n\nconst demandSystem =\n  require('../city/demandSystem.js');\n\nconst openingPrepSystem =`,
  '接入统一需求系统'
);

replaceSection(
  'src/operations/restaurantSimulationV081.js',
  'function expectedArrivalsPerMinute(',
  'function chooseCustomer(',
  `function businessHours(shop) {\n  // V083_UNIFIED_DEMAND\n  const raw =\n    shop &&\n    shop.businessHours &&\n    typeof shop.businessHours === 'object'\n      ? shop.businessHours\n      : {};\n\n  const openHour =\n    Number.isFinite(Number(raw.openHour))\n      ? Number(raw.openHour)\n      : Number.isFinite(Number(shop && shop.openHour))\n        ? Number(shop.openHour)\n        : 6;\n\n  const closeHour =\n    Number.isFinite(Number(raw.closeHour))\n      ? Number(raw.closeHour)\n      : Number.isFinite(Number(shop && shop.closeHour))\n        ? Number(shop.closeHour)\n        : 23;\n\n  return {\n    openHour: clamp(openHour, 0, 24),\n    closeHour: clamp(closeHour, 0, 24)\n  };\n}\n\nfunction isWithinBusinessHours(shop, time) {\n  const hours = businessHours(shop);\n  const t = time || gameState.getTime();\n  const value =\n    Number(t.hour || 0) +\n    Number(t.minute || 0) / 60;\n\n  if (hours.openHour === hours.closeHour) {\n    return true;\n  }\n\n  if (hours.closeHour > hours.openHour) {\n    return value >= hours.openHour && value < hours.closeHour;\n  }\n\n  return value >= hours.openHour || value < hours.closeHour;\n}\n\nfunction expectedArrivalsPerMinute(\n  shop,\n  runtime\n) {\n  const district =\n    citySystem\n      .getDistrict(\n        shop.districtId\n      );\n\n  if (!district) {\n    return 0;\n  }\n\n  const time =\n    gameState.getTime();\n\n  if (!isWithinBusinessHours(shop, time)) {\n    return 0;\n  }\n\n  const period =\n    mealPeriod(\n      Number(\n        time.hour\n      ) ||\n      0\n    );\n\n  const demandBreakdown =\n    demandSystem\n      .getDemandBreakdown(\n        shop.districtId\n      );\n\n  const periodDemand =\n    Math.max(\n      0,\n      Number(\n        demandBreakdown &&\n        demandBreakdown.total\n      ) ||\n      0\n    );\n\n  const restaurants =\n    Math.max(\n      1,\n      Number(\n        district.restaurantCount\n      ) ||\n      1\n    );\n\n  const periodMinutes =\n    PERIOD_MINUTES[\n      period\n    ] ||\n    240;\n\n  const averageRestaurantDemand =\n    periodDemand /\n    restaurants;\n\n  const rating =\n    clamp(\n      runtime.shop.rating ||\n      4,\n      1,\n      5\n    );\n\n  const ratingFactor =\n    0.72 +\n    (\n      rating -\n      3\n    ) *\n      0.14;\n\n  const awareness =\n    clamp(\n      runtime.brand &&\n      runtime.brand.awareness,\n      0,\n      100\n    );\n\n  const brandFactor =\n    0.88 +\n    awareness /\n      500;\n\n  const worldModifiers =\n    dynamicWorldSystem\n      .getModifiers(\n        {\n          districtId:\n            shop.districtId,\n          shopId:\n            shop.id\n        }\n      );\n\n  const rawMarketingFactor =\n    marketingEngine\n      .demandMultiplier(\n        runtime.campaigns ||\n        []\n      );\n\n  const marketingEfficiency =\n    clamp(\n      Number(\n        worldModifiers\n          .marketingEfficiencyMultiplier\n      ) || 1,\n      0.45,\n      1.75\n    );\n\n  const marketingFactor =\n    1 +\n    (\n      rawMarketingFactor -\n      1\n    ) *\n    marketingEfficiency;\n\n  const coverage =\n    staffCoverage(\n      shop\n    );\n\n  const dynamicDemandFactor =\n    Number(\n      worldModifiers\n        .demandMultiplier\n    ) || 1;\n\n  const nightFactor =\n    period ===\n      'night'\n      ? Number(\n          worldModifiers\n            .nightDemandMultiplier\n        ) || 1\n      : 1;\n\n  const saturationFactor =\n    clamp(\n      1.18 -\n      (\n        Number(\n          district.saturation\n        ) ||\n        70\n      ) /\n      260,\n      0.62,\n      1.08\n    );\n\n  return Math.max(\n    0,\n    averageRestaurantDemand /\n      periodMinutes *\n      ratingFactor *\n      brandFactor *\n      marketingFactor *\n      saturationFactor *\n      (\n        0.7 +\n        coverage *\n          0.3\n      ) *\n      dynamicDemandFactor *\n      nightFactor\n  );\n}
`,
  'V083_UNIFIED_DEMAND',
  '统一天气/周末/营业时段/营销后的客流公式'
);

// ---------------------------------------------------------------------------
// 3. 欠款闭环：分类记账、自动偿还、逾期产能惩罚；合规成本进入真实利润。
// ---------------------------------------------------------------------------
replaceSection(
  'src/operations/restaurantSimulationV081.js',
  'function spendOperatingCash(',
  'function maybeRestock(',
  `function ensurePayableState(runtime) {\n  // V083_PAYABLES\n  runtime.simulation =\n    runtime.simulation ||\n    {};\n\n  runtime.simulation.unpaidOperatingPayables =\n    Math.max(\n      0,\n      Number(\n        runtime.simulation.unpaidOperatingPayables\n      ) || 0\n    );\n\n  runtime.simulation.operatingPayablesByType =\n    runtime.simulation.operatingPayablesByType &&\n    typeof runtime.simulation.operatingPayablesByType === 'object'\n      ? runtime.simulation.operatingPayablesByType\n      : {};\n\n  return runtime.simulation;\n}\n\nfunction spendOperatingCash(\n  amount,\n  runtime,\n  category='other'\n) {\n  const value =\n    Math.max(\n      0,\n      Number(\n        amount\n      ) ||\n      0\n    );\n\n  if (\n    value <=\n    0\n  ) {\n    return {\n      paid: 0,\n      unpaid: 0\n    };\n  }\n\n  const sim =\n    ensurePayableState(\n      runtime\n    );\n\n  const player =\n    gameState\n      .getPlayer();\n\n  const cash =\n    Number(\n      player.cash\n    ) ||\n    0;\n\n  const paid =\n    Math.min(\n      cash,\n      value\n    );\n\n  if (\n    paid >\n    0\n  ) {\n    gameState\n      .spendCash(\n        paid\n      );\n  }\n\n  const unpaid =\n    value -\n    paid;\n\n  if (\n    unpaid >\n    0\n  ) {\n    sim.unpaidOperatingPayables +=\n      unpaid;\n\n    sim.operatingPayablesByType[category] =\n      (\n        Number(\n          sim.operatingPayablesByType[category]\n        ) || 0\n      ) +\n      unpaid;\n\n    if (\n      sim.oldestPayableDay ==\n      null\n    ) {\n      sim.oldestPayableDay =\n        simulationSystem\n          .getDayOrdinal(\n            gameState.getTime()\n          );\n    }\n  }\n\n  return {\n    paid,\n    unpaid\n  };\n}\n\nfunction serviceOperatingPayables(\n  runtime\n) {\n  const sim =\n    ensurePayableState(\n      runtime\n    );\n\n  const debt =\n    Math.max(\n      0,\n      Number(\n        sim.unpaidOperatingPayables\n      ) || 0\n    );\n\n  const day =\n    simulationSystem\n      .getDayOrdinal(\n        gameState.getTime()\n      );\n\n  if (\n    debt <=\n    0.01\n  ) {\n    sim.unpaidOperatingPayables = 0;\n    sim.operatingPayablesByType = {};\n    sim.oldestPayableDay = null;\n    sim.payableAgeDays = 0;\n    return { paid:0, remaining:0, ageDays:0 };\n  }\n\n  if (\n    sim.oldestPayableDay ==\n    null\n  ) {\n    sim.oldestPayableDay =\n      day;\n  }\n\n  sim.payableAgeDays =\n    Math.max(\n      0,\n      day -\n      Number(\n        sim.oldestPayableDay\n      )\n    );\n\n  const now =\n    absoluteMinute();\n\n  if (\n    Number.isFinite(\n      Number(\n        sim.lastPayableServiceMinute\n      )\n    ) &&\n    now -\n      Number(\n        sim.lastPayableServiceMinute\n      ) <\n      60\n  ) {\n    return {\n      paid:0,\n      remaining:debt,\n      ageDays:sim.payableAgeDays\n    };\n  }\n\n  sim.lastPayableServiceMinute =\n    now;\n\n  const cash =\n    Number(\n      gameState\n        .getPlayer()\n        .cash\n    ) || 0;\n\n  const reserve = 1000;\n  const available =\n    Math.max(\n      0,\n      cash -\n      reserve\n    );\n\n  const payment =\n    Math.min(\n      debt,\n      available *\n      0.6\n    );\n\n  if (\n    payment <=\n    0\n  ) {\n    return {\n      paid:0,\n      remaining:debt,\n      ageDays:sim.payableAgeDays\n    };\n  }\n\n  gameState\n    .spendCash(\n      payment\n    );\n\n  let remainingPayment =\n    payment;\n\n  const priority = [\n    'labor',\n    'utilities',\n    'rent',\n    'compliance',\n    'marketing',\n    'other'\n  ];\n\n  for (\n    const key\n    of priority\n  ) {\n    const amount =\n      Math.max(\n        0,\n        Number(\n          sim.operatingPayablesByType[key]\n        ) || 0\n      );\n\n    if (\n      amount <=\n        0 ||\n      remainingPayment <=\n        0\n    ) {\n      continue;\n    }\n\n    const used =\n      Math.min(\n        amount,\n        remainingPayment\n      );\n\n    sim.operatingPayablesByType[key] =\n      Math.max(\n        0,\n        amount -\n        used\n      );\n\n    remainingPayment -=\n      used;\n  }\n\n  sim.unpaidOperatingPayables =\n    Math.max(\n      0,\n      debt -\n      payment\n    );\n\n  if (\n    sim.unpaidOperatingPayables <=\n    0.01\n  ) {\n    sim.unpaidOperatingPayables = 0;\n    sim.operatingPayablesByType = {};\n    sim.oldestPayableDay = null;\n    sim.payableAgeDays = 0;\n  }\n\n  return {\n    paid:payment,\n    remaining:\n      sim.unpaidOperatingPayables,\n    ageDays:\n      sim.payableAgeDays\n  };\n}\n\nfunction operatingRestriction(\n  runtime\n) {\n  const sim =\n    ensurePayableState(\n      runtime\n    );\n\n  const debt =\n    Number(\n      sim.unpaidOperatingPayables\n    ) || 0;\n\n  if (\n    debt <=\n    0\n  ) {\n    return 1;\n  }\n\n  const age =\n    Math.max(\n      0,\n      Number(\n        sim.payableAgeDays\n      ) || 0\n    );\n\n  if (age >= 7) return 0.55;\n  if (age >= 3) return 0.72;\n  if (age >= 1) return 0.88;\n  return 0.96;\n}\n\nfunction accrueFixedCosts(\n  shop,\n  runtime,\n  minutes\n) {\n  const ratio =\n    Math.max(\n      0,\n      Number(\n        minutes\n      ) ||\n      0\n    ) /\n    1440;\n\n  if (\n    ratio <=\n    0\n  ) {\n    return {\n      rent: 0,\n      labor: 0,\n      utilities: 0,\n      marketing: 0,\n      compliance: 0\n    };\n  }\n\n  const worldModifiers =\n    dynamicWorldSystem\n      .getModifiers(\n        {\n          districtId:\n            shop.districtId,\n          shopId:\n            shop.id\n        }\n      );\n\n  const rent =\n    (\n      Number(\n        shop.monthlyRent\n      ) ||\n      0\n    ) /\n    30 *\n    ratio *\n    (\n      Number(\n        worldModifiers\n          .rentCostMultiplier\n      ) || 1\n    );\n\n  const labor =\n    dailyPayroll(\n      shop\n    ) *\n    ratio *\n    (\n      Number(\n        worldModifiers\n          .laborCostMultiplier\n      ) || 1\n    );\n\n  const area =\n    Math.max(\n      20,\n      Number(\n        shop.usableArea ||\n        shop.grossArea\n      ) ||\n      60\n    );\n\n  const utilities =\n    (\n      32 +\n      area *\n        0.42\n    ) *\n    ratio *\n    (\n      Number(\n        worldModifiers\n          .utilityCostMultiplier\n      ) || 1\n    );\n\n  const marketing =\n    (\n      runtime.campaigns ||\n      []\n    )\n      .filter(\n        item =>\n          item.status ===\n          'active'\n      )\n      .reduce(\n        (\n          sum,\n          item\n        ) =>\n          sum +\n          (\n            Number(\n              item.budget\n            ) ||\n            0\n          ) /\n          Math.max(\n            1,\n            Number(\n              item.days\n            ) ||\n            1\n          ) *\n          ratio,\n        0\n      );\n\n  const compliance =\n    (\n      10 +\n      area *\n        0.08\n    ) *\n    ratio *\n    (\n      Number(\n        worldModifiers\n          .complianceCostMultiplier\n      ) || 1\n    );\n\n  settlementEngine\n    .addFixedCosts(\n      runtime.ledger,\n      {\n        rent,\n        labor,\n        utilities,\n        marketing,\n        compliance\n      }\n    );\n\n  spendOperatingCash(\n    rent,\n    runtime,\n    'rent'\n  );\n\n  spendOperatingCash(\n    labor,\n    runtime,\n    'labor'\n  );\n\n  spendOperatingCash(\n    utilities,\n    runtime,\n    'utilities'\n  );\n\n  spendOperatingCash(\n    marketing,\n    runtime,\n    'marketing'\n  );\n\n  spendOperatingCash(\n    compliance,\n    runtime,\n    'compliance'\n  );\n\n  return {\n    rent,\n    labor,\n    utilities,\n    marketing,\n    compliance\n  };\n}
`,
  'V083_PAYABLES',
  '应付账款闭环与合规成本'
);

replaceExact(
  'src/operations/restaurantSimulationV081.js',
  `  let changed =\n    closeElapsedDays(\n      shop,\n      runtime,\n      currentDay\n    );\n\n  accrueFixedCosts(`,
  `  let changed =\n    closeElapsedDays(\n      shop,\n      runtime,\n      currentDay\n    );\n\n  serviceOperatingPayables(\n    runtime\n  );\n\n  accrueFixedCosts(`,
  '每次经营推进先偿还历史欠款'
);

replaceExact(
  'src/operations/restaurantSimulationV081.js',
  `          capacityMultiplier:\n            Number(\n              worldModifiers\n                .capacityMultiplier\n            ) || 1,\n          seats:`,
  `          capacityMultiplier:\n            (\n              Number(\n                worldModifiers\n                  .capacityMultiplier\n              ) || 1\n            ) *\n            operatingRestriction(\n              runtime\n            ) *\n            clamp(\n              1 -\n              (\n                Number(\n                  worldModifiers\n                    .inspectionRisk\n                ) || 0\n              ) *\n              0.22,\n              0.72,\n              1\n            ),\n          deliveryDemandMultiplier:\n            Number(\n              worldModifiers\n                .deliveryDemandMultiplier\n            ) || 1,\n          platformCostMultiplier:\n            Number(\n              worldModifiers\n                .platformCostMultiplier\n            ) || 1,\n          reputationMultiplier:\n            Number(\n              worldModifiers\n                .reputationMultiplier\n            ) || 1,\n          seats:`,
  '检查风险/外卖/平台/口碑修正进入现场经营'
);

replaceExact(
  'src/operations/restaurantSimulationV081.js',
  `  absoluteMinute,\n  staffCoverage,`,
  `  absoluteMinute,\n  businessHours,\n  isWithinBusinessHours,\n  staffCoverage,`,
  '导出营业时间助手'
);

replaceExact(
  'src/operations/restaurantSimulationV081.js',
  `  accrueFixedCosts,\n  maybeRestock,`,
  `  accrueFixedCosts,\n  serviceOperatingPayables,\n  operatingRestriction,\n  maybeRestock,`,
  '导出欠款助手'
);

// ---------------------------------------------------------------------------
// 4. 现场经营：外卖需求、平台成本、口碑修正真正生效。
// ---------------------------------------------------------------------------
replaceExact(
  'src/operations/floorSimulationV082.js',
  `  floor.metrics\n    .arrivedToday +=`,
  `  // V083_DYNAMIC_MODIFIERS\n  const deliveryDemandMultiplier =\n    clamp(\n      Number(\n        ctx.deliveryDemandMultiplier\n      ) || 1,\n      0.5,\n      1.8\n    );\n\n  if (\n    visit.channel === 'dine_in' &&\n    deliveryDemandMultiplier > 1 &&\n    runtime.rng.next() <\n      Math.min(\n        0.35,\n        (\n          deliveryDemandMultiplier -\n          1\n        ) *\n        0.45\n      )\n  ) {\n    visit.channel = 'delivery';\n  } else if (\n    visit.channel === 'delivery' &&\n    deliveryDemandMultiplier < 1 &&\n    runtime.rng.next() <\n      Math.min(\n        0.75,\n        (\n          1 -\n          deliveryDemandMultiplier\n        ) *\n        0.9\n      )\n  ) {\n    visit.channel =\n      runtime.rng.next() < 0.35\n        ? 'pickup'\n        : 'dine_in';\n  }\n\n  floor.metrics\n    .arrivedToday +=`,
  '外卖需求修正进入渠道选择'
);

replaceSection(
  'src/operations/floorSimulationV082.js',
  '  const platformRate =',
  '  const settled =',
  `  const basePlatformRate =\n    order.channel ===\n      'delivery'\n      ? Number(\n          delivery &&\n          delivery\n            .commissionRate ||\n          0.18\n        )\n      : 0;\n\n  const platformRate =\n    basePlatformRate *\n    clamp(\n      Number(\n        ctx.platformCostMultiplier\n      ) || 1,\n      0.45,\n      1.8\n    );\n`,
  'basePlatformRate',
  '平台成本修正进入外卖结算'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
  `    retentionEngine\n      .updateShopReputation(\n        runtime.shop,\n        retention\n      );`,
  `    const reputationMultiplier =\n      clamp(\n        Number(\n          ctx.reputationMultiplier\n        ) || 1,\n        0.5,\n        1.6\n      );\n\n    if (\n      retention.reviewStars !=\n      null\n    ) {\n      retention.reviewStars =\n        clamp(\n          3 +\n          (\n            Number(\n              retention.reviewStars\n            ) -\n            3\n          ) *\n          reputationMultiplier,\n          1,\n          5\n        );\n    }\n\n    retention.wordOfMouth =\n      clamp(\n        Number(\n          retention.wordOfMouth\n        ) *\n        reputationMultiplier,\n        -1,\n        1\n      );\n\n    retentionEngine\n      .updateShopReputation(\n        runtime.shop,\n        retention\n      );`,
  '口碑修正进入评分与传播'
);

// ---------------------------------------------------------------------------
// 5. 财务账本加入合规成本。
// ---------------------------------------------------------------------------
const settlementPath =
  'src/operations/settlementEngineV10.js';
let settlement = read(settlementPath);
if (!settlement.includes('V083_COMPLIANCE_LEDGER')) {
  settlement = `'use strict';\n\n// V083_COMPLIANCE_LEDGER\nfunction createLedger(){\n  return {\n    revenue:0,foodCost:0,labor:0,rent:0,utilities:0,platformFees:0,\n    packaging:0,marketing:0,compliance:0,waste:0,refunds:0,\n    orders:0,customers:0,entries:[]\n  };\n}\nfunction settleOrder(ledger,order,ctx={}){\n  const revenue=Math.max(0,Number(order.total)||0);\n  const foodCost=Math.max(0,Number(ctx.foodCost)||0);\n  const platformFee=order.channel==='delivery'?revenue*Math.max(0,Number(ctx.platformRate??.18)):0;\n  const packaging=order.channel==='delivery'||order.channel==='pickup'?Math.max(0,Number(ctx.packagingCost??1.2)):0;\n  const refund=Math.max(0,Number(ctx.refund)||0);\n  const net=revenue-foodCost-platformFee-packaging-refund;\n  ledger.revenue+=revenue;ledger.foodCost+=foodCost;ledger.platformFees+=platformFee;\n  ledger.packaging=(Number(ledger.packaging)||0)+packaging;ledger.refunds+=refund;ledger.orders++;\n  ledger.customers+=Math.max(1,Number(order.partySize)||1);\n  ledger.entries.push({type:'order',orderId:order.id,revenue,foodCost,platformFee,packaging,refund,net});\n  return {revenue,foodCost,platformFee,packaging,refund,contribution:Math.round(net*100)/100};\n}\nfunction addFixedCosts(ledger,costs={}){\n  ledger.labor+=Number(costs.labor)||0;\n  ledger.rent+=Number(costs.rent)||0;\n  ledger.utilities+=Number(costs.utilities)||0;\n  ledger.marketing+=Number(costs.marketing)||0;\n  ledger.compliance=(Number(ledger.compliance)||0)+(Number(costs.compliance)||0);\n  ledger.waste+=Number(costs.waste)||0;\n}\nfunction summary(ledger){\n  const cost=(Number(ledger.foodCost)||0)+(Number(ledger.labor)||0)+(Number(ledger.rent)||0)+\n    (Number(ledger.utilities)||0)+(Number(ledger.platformFees)||0)+(Number(ledger.packaging)||0)+\n    (Number(ledger.marketing)||0)+(Number(ledger.compliance)||0)+(Number(ledger.waste)||0)+\n    (Number(ledger.refunds)||0);\n  const profit=ledger.revenue-cost;\n  return {...ledger,totalCost:Math.round(cost*100)/100,profit:Math.round(profit*100)/100,\n    foodCostRate:ledger.revenue?Math.round(ledger.foodCost/ledger.revenue*1000)/10:0,\n    profitRate:ledger.revenue?Math.round(profit/ledger.revenue*1000)/10:0,\n    avgTicket:ledger.orders?Math.round(ledger.revenue/ledger.orders*100)/100:0};\n}\nmodule.exports={createLedger,settleOrder,addFixedCosts,summary};\n`;
  write(settlementPath, settlement);
  console.log('[V0.8.3] 修复: 合规成本进入账本');
} else {
  console.log('[V0.8.3] 已存在: 合规成本进入账本');
}

// ---------------------------------------------------------------------------
// 6. 运行时存档版本/欠款字段兼容。
// ---------------------------------------------------------------------------
for (const oldVersion of ["version: '0.8.0'", "version: '0.8.1'"]) {
  let source = read('src/operations/operationsStoreV080.js');
  if (source.includes(oldVersion)) {
    source = source.split(oldVersion).join("version: '0.8.3'");
    write('src/operations/operationsStoreV080.js', source);
  }
}

replaceExact(
  'src/operations/operationsStoreV080.js',
  `  root.version =\n    '0.8.1';`,
  `  root.version =\n    '0.8.3';`,
  '运行时根版本升级到0.8.3'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
  `  if (\n    !Array.isArray(\n      runtime.dailySnapshots\n    )\n  ) {`,
  `  runtime.simulation.unpaidOperatingPayables =\n    Math.max(\n      0,\n      Number(\n        runtime.simulation.unpaidOperatingPayables\n      ) || 0\n    );\n\n  runtime.simulation.operatingPayablesByType =\n    runtime.simulation.operatingPayablesByType &&\n    typeof runtime.simulation.operatingPayablesByType === 'object'\n      ? runtime.simulation.operatingPayablesByType\n      : {};\n\n  if (runtime.simulation.oldestPayableDay === undefined) {\n    runtime.simulation.oldestPayableDay = null;\n  }\n\n  if (runtime.simulation.payableAgeDays === undefined) {\n    runtime.simulation.payableAgeDays = 0;\n  }\n\n  if (runtime.simulation.lastPayableServiceMinute === undefined) {\n    runtime.simulation.lastPayableServiceMinute = null;\n  }\n\n  if (\n    !Array.isArray(\n      runtime.dailySnapshots\n    )\n  ) {`,
  '旧存档自动补齐欠款字段'
);

let gameState = read('src/core/gameState.js');
gameState = gameState
  .split("version: '0.8.0'")
  .join("version: '0.8.3'");
write('src/core/gameState.js', gameState);
console.log('[V0.8.3] 修复: GameState经营版本升级');

// ---------------------------------------------------------------------------
// 7. 门店页显示欠款风险。
// ---------------------------------------------------------------------------
replaceExact(
  'src/scenes/storeScene.js',
  `      mistakesToday:\n        live.mistakesToday,\n      realOperation:`,
  `      mistakesToday:\n        live.mistakesToday,\n      unpaidOperatingPayables:\n        runtime &&\n        runtime.simulation\n          ? Number(\n              runtime.simulation.unpaidOperatingPayables\n            ) || 0\n          : 0,\n      payableAgeDays:\n        runtime &&\n        runtime.simulation\n          ? Number(\n              runtime.simulation.payableAgeDays\n            ) || 0\n          : 0,\n      realOperation:`,
  '门店快照暴露欠款信息'
);

replaceExact(
  'src/scenes/storeScene.js',
  `    const warning =\n      snap.walkawaysToday > 0`,
  `    const warning =\n      snap.unpaidOperatingPayables > 0\n        ? '待付经营款 ' +\n          compactMoney(\n            snap.unpaidOperatingPayables\n          ) +\n          (\n            snap.payableAgeDays > 0\n              ? ' · 已逾期' + snap.payableAgeDays + '天'\n              : ''\n          )\n        : snap.walkawaysToday > 0`,
  '门店页优先提示欠款风险'
);

// ---------------------------------------------------------------------------
// 8. 首页目标条不再使用后置硬编码错误流程。
// ---------------------------------------------------------------------------
replaceExact(
  'src/main.js',
  `  drawText('开设餐厅', x + 83, y + 13.5, 7.2, '#FFFFFF', '800');\n\n  const labels = ['选址', '装修', '试营业', '经营', '签约'];`,
  `  drawText(goal.title || '开设首店', x + 83, y + 13.5, 7.2, '#FFFFFF', '800');\n\n  // V083_DYNAMIC_GOAL_STEPS\n  const labels =\n    Array.isArray(goal.steps) &&\n    goal.steps.length === 5\n      ? goal.steps\n      : ['选址', '看铺', '谈判', '签约', '装修'];`,
  '首页目标条读取真实开店流程'
);

replaceExact(
  'src/main.js',
  `'城市餐饮经营小游戏 V0.8.1 真实营业循环启动成功'`,
  `'城市餐饮经营小游戏 V0.8.3 基础修复版启动成功'`,
  '启动版本日志升级'
);

// ---------------------------------------------------------------------------
// 9. 删除仓库根目录误传的假工作流，避免再次覆盖错路径。
// ---------------------------------------------------------------------------
if (fs.existsSync('apply-update.yml')) {
  fs.unlinkSync('apply-update.yml');
  console.log('[V0.8.3] 清理: 删除根目录错误 apply-update.yml');
}

// ---------------------------------------------------------------------------
// 10. 安装器只允许在 update.zip 应用阶段存在。完成后从 pretest 移除并自删除，
//     保证正式树继续满足 v60CleanBase 的“无 apply-v 补丁器”约束。
// ---------------------------------------------------------------------------
{
  const packagePath = 'package.json';
  const pkg = JSON.parse(read(packagePath));
  const selfCommand = 'node scripts/apply-v083-foundation-fixes.js';

  if (
    pkg.scripts &&
    typeof pkg.scripts.pretest === 'string' &&
    pkg.scripts.pretest.includes(selfCommand)
  ) {
    pkg.scripts.pretest =
      pkg.scripts.pretest
        .replace(selfCommand + ' && ', '')
        .replace(' && ' + selfCommand, '')
        .replace(selfCommand, '')
        .trim();

    write(
      packagePath,
      JSON.stringify(pkg, null, 2) + '\n'
    );

    console.log('[V0.8.3] 清理: 已从 pretest 移除一次性安装器');
  }

  const selfPath = __filename;
  if (fs.existsSync(selfPath)) {
    fs.unlinkSync(selfPath);
    console.log('[V0.8.3] 清理: 已删除一次性 apply-v083 安装器');
  }
}

console.log('[V0.8.3] 基础修复已全部接入');
