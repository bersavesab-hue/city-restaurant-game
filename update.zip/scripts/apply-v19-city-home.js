'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const FILE =
  path.join(
    ROOT,
    'src/main.js'
  );

const MARK =
  'V19_CITY_HOME_POLISH';

function read() {
  return fs.readFileSync(
    FILE,
    'utf8'
  );
}

function write(value) {
  fs.writeFileSync(
    FILE,
    value
  );
}

function replaceBetween(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V19找不到开始标记：' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
        startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V19找不到结束标记：' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    source.slice(
      end
    )
  );
}

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    !source.includes(
      before
    )
  ) {
    throw new Error(
      'V19找不到替换目标：' +
      label
    );
  }

  return source.replace(
    before,
    after
  );
}

let source =
  read();

if (
  source.includes(
    MARK
  )
) {
  console.log(
    'V19城市首页精修已经应用'
  );
  process.exit(
    0
  );
}

source =
  source.replace(
    "'use strict';",
    "'use strict';\n\n// " +
      MARK
  );

const helpers = `function getBrandState(
  player
) {
  const reputation =
    Math.max(
      0,
      Number(
        player &&
        player.reputation
      ) ||
      0
    );

  const thresholds = [
    0,
    80,
    200,
    420,
    760,
    1200,
    1800,
    2600,
    3600,
    5000
  ];

  let level =
    1;

  for (
    let i = 1;
    i <
    thresholds.length;
    i++
  ) {
    if (
      reputation >=
      thresholds[i]
    ) {
      level =
        i + 1;
    }
  }

  const currentIndex =
    Math.min(
      level - 1,
      thresholds.length - 1
    );

  const current =
    thresholds[
      currentIndex
    ];

  const next =
    thresholds[
      Math.min(
        currentIndex + 1,
        thresholds.length - 1
      )
    ];

  const progress =
    next <= current
      ? 1
      : Math.max(
          0,
          Math.min(
            1,
            (
              reputation -
              current
            ) /
            (
              next -
              current
            )
          )
        );

  return {
    level,
    reputation,
    progress
  };
}

function drawCityBadge(
  cityName,
  x,
  y,
  size
) {
  const first =
    String(
      cityName ||
      '城'
    ).charAt(
      0
    ) ||
    '城';

  roundedRect(
    x,
    y,
    size,
    size,
    10,
    'rgba(6,49,72,0.96)',
    '#F6C64E',
    1.2
  );

  roundedRect(
    x + 4,
    y + 4,
    size - 8,
    size - 8,
    8,
    'rgba(255,255,255,0.08)',
    'rgba(255,255,255,0.28)',
    0.8
  );

  drawText(
    first,
    x +
      size / 2,
    y +
      size * 0.47,
    17,
    '#FFE49A',
    '800',
    'center'
  );

  drawText(
    '城',
    x +
      size / 2,
    y +
      size * 0.76,
    6.2,
    '#E4F0F4',
    '700',
    'center'
  );
}

function drawDistrictThumb(
  districtId,
  x,
  y,
  w,
  h
) {
  const image =
    resourceManager
      .getImage(
        'city_base_01'
      );

  const layout =
    DISTRICT_LAYOUT[
      districtId
    ] ||
    {
      x: 0.5,
      y: 0.5
    };

  ctx.save();

  roundedPath(
    ctx,
    x,
    y,
    w,
    h,
    11
  );

  ctx.clip();

  if (image) {
    drawImageFocus(
      ctx,
      image,
      x,
      y,
      w,
      h,
      2.6,
      Math.max(
        0.08,
        Math.min(
          0.92,
          layout.x
        )
      ),
      Math.max(
        0.08,
        Math.min(
          0.92,
          layout.y
        )
      )
    );

    const shade =
      ctx.createLinearGradient(
        x,
        y,
        x,
        y + h
      );

    shade.addColorStop(
      0,
      'rgba(5,37,55,0.02)'
    );

    shade.addColorStop(
      1,
      'rgba(5,37,55,0.28)'
    );

    ctx.fillStyle =
      shade;

    ctx.fillRect(
      x,
      y,
      w,
      h
    );
  } else {
    ctx.fillStyle =
      '#D9E8E7';

    ctx.fillRect(
      x,
      y,
      w,
      h
    );
  }

  ctx.restore();

  roundedRect(
    x,
    y,
    w,
    h,
    11,
    null,
    'rgba(8,48,67,0.18)',
    1
  );
}

function drawNavIcon(
  id,
  cx,
  cy,
  active
) {
  const color =
    active
      ? '#173545'
      : '#E7F2F5';

  ctx.save();

  ctx.strokeStyle =
    color;

  ctx.fillStyle =
    color;

  ctx.lineWidth =
    1.8;

  ctx.lineCap =
    'round';

  ctx.lineJoin =
    'round';

  if (
    id ===
    'city'
  ) {
    ctx.strokeRect(
      cx - 10,
      cy - 6,
      7,
      13
    );

    ctx.strokeRect(
      cx - 1,
      cy - 10,
      8,
      17
    );

    ctx.strokeRect(
      cx + 9,
      cy - 3,
      5,
      10
    );

    ctx.fillRect(
      cx + 1,
      cy - 6,
      2,
      2
    );

    ctx.fillRect(
      cx + 1,
      cy - 1,
      2,
      2
    );
  } else if (
    id ===
    'shop'
  ) {
    ctx.strokeRect(
      cx - 11,
      cy - 4,
      22,
      12
    );

    ctx.beginPath();
    ctx.moveTo(
      cx - 12,
      cy - 4
    );
    ctx.lineTo(
      cx - 9,
      cy - 10
    );
    ctx.lineTo(
      cx + 9,
      cy - 10
    );
    ctx.lineTo(
      cx + 12,
      cy - 4
    );
    ctx.stroke();

    for (
      let i = -6;
      i <= 6;
      i += 6
    ) {
      ctx.beginPath();
      ctx.moveTo(
        cx + i,
        cy - 10
      );
      ctx.lineTo(
        cx + i,
        cy - 4
      );
      ctx.stroke();
    }

    ctx.strokeRect(
      cx - 3,
      cy + 1,
      6,
      7
    );
  } else if (
    id ===
    'renovation'
  ) {
    ctx.beginPath();
    ctx.moveTo(
      cx - 8,
      cy + 8
    );
    ctx.lineTo(
      cx + 4,
      cy - 4
    );
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(
      cx,
      cy - 8
    );
    ctx.lineTo(
      cx + 8,
      cy
    );
    ctx.lineTo(
      cx + 4,
      cy + 4
    );
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(
      cx - 10,
      cy + 5
    );
    ctx.lineTo(
      cx - 5,
      cy + 10
    );
    ctx.stroke();
  } else if (
    id ===
    'research'
  ) {
    ctx.beginPath();
    ctx.arc(
      cx - 1,
      cy,
      8,
      0,
      Math.PI *
        2
    );
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(
      cx + 9,
      cy - 10
    );
    ctx.lineTo(
      cx + 4,
      cy + 10
    );
    ctx.moveTo(
      cx + 13,
      cy - 9
    );
    ctx.lineTo(
      cx + 8,
      cy + 10
    );
    ctx.stroke();
  } else if (
    id ===
    'supply'
  ) {
    ctx.strokeRect(
      cx - 12,
      cy - 7,
      14,
      11
    );

    ctx.beginPath();
    ctx.moveTo(
      cx + 2,
      cy - 4
    );
    ctx.lineTo(
      cx + 8,
      cy - 4
    );
    ctx.lineTo(
      cx + 12,
      cy
    );
    ctx.lineTo(
      cx + 12,
      cy + 4
    );
    ctx.lineTo(
      cx + 2,
      cy + 4
    );
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(
      cx - 6,
      cy + 7,
      2.4,
      0,
      Math.PI *
        2
    );
    ctx.arc(
      cx + 8,
      cy + 7,
      2.4,
      0,
      Math.PI *
        2
    );
    ctx.stroke();
  } else if (
    id ===
    'business'
  ) {
    ctx.fillRect(
      cx - 11,
      cy + 1,
      4,
      8
    );

    ctx.fillRect(
      cx - 3,
      cy - 4,
      4,
      13
    );

    ctx.fillRect(
      cx + 5,
      cy - 9,
      4,
      18
    );

    ctx.beginPath();
    ctx.moveTo(
      cx - 12,
      cy + 10
    );
    ctx.lineTo(
      cx + 12,
      cy + 10
    );
    ctx.stroke();
  } else {
    ctx.beginPath();
    ctx.arc(
      cx,
      cy,
      5.5,
      0,
      Math.PI *
        2
    );
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(
      cx,
      cy,
      1.7,
      0,
      Math.PI *
        2
    );
    ctx.fill();

    for (
      let i = 0;
      i < 8;
      i++
    ) {
      const a =
        i *
        Math.PI /
        4;

      ctx.beginPath();

      ctx.moveTo(
        cx +
          Math.cos(
            a
          ) *
          7,
        cy +
          Math.sin(
            a
          ) *
          7
      );

      ctx.lineTo(
        cx +
          Math.cos(
            a
          ) *
          10,
        cy +
          Math.sin(
            a
          ) *
          10
      );

      ctx.stroke();
    }
  }

  ctx.restore();
}

`;

source =
  replaceOnce(
    source,
    'function addButton(\n',
    helpers +
      'function addButton(\n',
    '首页辅助绘图函数'
  );

source =
  replaceBetween(
    source,
    'function drawTopHud() {',
    '\n/* =========================\n   城市地图',
    `function drawTopHud() {
  const player =
    gameState
      .getPlayer();

  const world =
    gameState
      .getWorld();

  const display =
    timeSystem
      .getDisplayState();

  let cityName =
    gameState
      .getCityName();

  if (
    !cityName ||
    cityName ===
      '未命名城市'
  ) {
    cityName =
      '云州市';
  }

  const cityImage =
    resourceManager
      .getImage(
        'city_base_01'
      );

  if (cityImage) {
    drawImageFocus(
      ctx,
      cityImage,
      0,
      0,
      VIEW_W,
      TOP_H,
      1.65,
      0.53,
      0.16
    );

    ctx.fillStyle =
      'rgba(4,35,58,0.67)';

    ctx.fillRect(
      0,
      0,
      VIEW_W,
      TOP_H
    );
  } else {
    ctx.fillStyle =
      COLORS.navy;

    ctx.fillRect(
      0,
      0,
      VIEW_W,
      TOP_H
    );
  }

  drawCityBadge(
    cityName,
    10,
    8 +
      SAFE_TOP,
    45
  );

  drawText(
    fitText(
      cityName,
      102,
      15.5,
      '800'
    ),
    66,
    20 +
      SAFE_TOP,
    15.5,
    COLORS.white,
    '800'
  );

  drawText(
    '打造属于你的美食帝国',
    66,
    42 +
      SAFE_TOP,
    7.2,
    '#DFEEF4',
    '600'
  );

  drawText(
    WEATHER_NAMES[
      world.weather
    ] ||
    '晴',
    181,
    21 +
      SAFE_TOP,
    7.7,
    '#FFF1B2',
    '700',
    'center'
  );

  drawText(
    (
      Number.isFinite(
        Number(
          world.temperature
        )
      )
        ? world.temperature +
          '℃'
        : '--℃'
    ),
    181,
    42 +
      SAFE_TOP,
    6.8,
    '#D7E8EE',
    '600',
    'center'
  );

  roundedRect(
    211,
    9 +
      SAFE_TOP,
    105,
    45,
    12,
    'rgba(5,39,60,0.88)',
    'rgba(255,255,255,0.30)'
  );

  drawText(
    fitText(
      '¥' +
        player.cash
          .toLocaleString(),
      91,
      11,
      '800'
    ),
    263.5,
    24 +
      SAFE_TOP,
    11,
    '#FFF0A8',
    '800',
    'center'
  );

  drawText(
    '可用资金',
    263.5,
    42 +
      SAFE_TOP,
    6.3,
    '#D6E7ED',
    '600',
    'center'
  );

  const brand =
    getBrandState(
      player
    );

  roundedRect(
    323,
    9 +
      SAFE_TOP,
    58,
    45,
    12,
    'rgba(5,39,60,0.88)',
    'rgba(255,255,255,0.30)'
  );

  drawText(
    '♛ Lv.' +
      brand.level,
    352,
    23 +
      SAFE_TOP,
    7.8,
    '#FFE081',
    '800',
    'center'
  );

  roundedRect(
    333,
    42 +
      SAFE_TOP,
    38,
    3,
    1.5,
    'rgba(255,255,255,0.24)'
  );

  roundedRect(
    333,
    42 +
      SAFE_TOP,
    Math.max(
      3,
      38 *
        brand.progress
    ),
    3,
    1.5,
    COLORS.gold
  );

  const speedItems = [
    [
      'time:pause',
      timeSystem
        .isPaused()
        ? '▶'
        : 'Ⅱ'
    ],
    [
      'time:speed:1',
      '1×'
    ],
    [
      'time:speed:2',
      '2×'
    ],
    [
      'time:speed:5',
      '5×'
    ],
    [
      'time:speed:10',
      '10×'
    ]
  ];

  const y =
    TOP_H -
    27;

  for (
    let i = 0;
    i <
    speedItems.length;
    i++
  ) {
    const id =
      speedItems[i][0];

    const speed =
      timeSystem
        .getSpeed();

    const paused =
      timeSystem
        .isPaused();

    const active =
      id ===
        'time:pause'
        ? paused
        : (
            !paused &&
            Number(
              id.split(':')[2]
            ) ===
              speed
          );

    const x =
      12 +
      i *
        45;

    roundedRect(
      x,
      y,
      39,
      21,
      8,
      active
        ? COLORS.gold
        : 'rgba(4,40,60,0.84)',
      active
        ? '#FFE38D'
        : 'rgba(255,255,255,0.20)'
    );

    drawText(
      speedItems[i][1],
      x +
        19.5,
      y +
        10.5,
      8,
      active
        ? '#173444'
        : COLORS.white,
      '800',
      'center'
    );

    addButton(
      id,
      x -
        3,
      y -
        5,
      45,
      31
    );
  }

  drawText(
    fitText(
      display.date +
        ' · ' +
        display.time +
        ' · ' +
        (
          MEAL_NAMES[
            display.mealPeriod
          ] ||
          ''
        ),
      148,
      6.5,
      '600'
    ),
    376,
    y +
      10.5,
    6.5,
    '#DCEBF0',
    '600',
    'right'
  );
}
`,
    '顶部HUD'
  );

source =
  replaceBetween(
    source,
    'function drawDistrictMarker(',
    '\nfunction startDistrictFx(',
    `function drawDistrictMarker(
  district
) {
  const point =
    getDistrictPoint(
      district.id
    );

  if (!point) {
    return;
  }

  const x =
    point.x;

  const y =
    point.y;

  const selected =
    selectedDistrictId ===
      district.id;

  const animated =
    districtFx.id ===
      district.id;

  const markerScale =
    animated
      ? districtFx.scale
      : 1;

  const markerKeys = {
    university:
      'district_marker_gold',
    hightech:
      'district_marker_blue',
    cbd:
      'district_marker_orange',
    oldtown:
      'district_marker_purple',
    village:
      'district_marker_green',
    market:
      'district_marker_red',
    industry:
      'district_marker_blue'
  };

  const image =
    resourceManager
      .getImage(
        markerKeys[
          district.id
        ]
      );

  if (selected) {
    ctx.beginPath();

    ctx.arc(
      x,
      y,
      21 +
        districtFx.flash *
          5,
      0,
      Math.PI *
        2
    );

    ctx.fillStyle =
      'rgba(255,191,45,0.24)';

    ctx.fill();
  }

  ctx.save();

  ctx.translate(
    x,
    y
  );

  ctx.scale(
    markerScale,
    markerScale
  );

  if (image) {
    ctx.drawImage(
      image,
      -16,
      -23,
      32,
      44
    );
  } else {
    ctx.beginPath();

    ctx.arc(
      0,
      0,
      8,
      0,
      Math.PI *
        2
    );

    ctx.fillStyle =
      COLORS.gold;

    ctx.fill();
  }

  ctx.restore();

  const labelW =
    Math.max(
      63,
      Math.min(
        94,
        31 +
          district.name.length *
            10
      )
    );

  const preferLeft =
    x >
    VIEW_W *
      0.64;

  let labelX =
    preferLeft
      ? x -
        labelW -
        10
      : x +
        10;

  labelX =
    Math.max(
      6,
      Math.min(
        VIEW_W -
          labelW -
          6,
        labelX
      )
    );

  const labelY =
    Math.max(
      MAP_Y +
        43,
      Math.min(
        CARD_Y -
          31,
        y -
          11
      )
    );

  roundedRect(
    labelX,
    labelY,
    labelW,
    23,
    11,
    selected
      ? '#0A4969'
      : '#063C5B',
    selected
      ? '#FFD25A'
      : '#F0BA37',
    selected
      ? 1.4
      : 1
  );

  drawText(
    district.name +
      '  ›',
    labelX +
      labelW /
        2,
    labelY +
      11.5,
    7.6,
    '#F8FBFC',
    '800',
    'center'
  );

  const hitLeft =
    Math.min(
      x -
        20,
      labelX -
        3
    );

  const hitRight =
    Math.max(
      x +
        20,
      labelX +
        labelW +
        3
    );

  addButton(
    'district:' +
      district.id,
    hitLeft,
    Math.min(
      y -
        28,
      labelY -
        6
    ),
    hitRight -
      hitLeft,
    Math.max(
      56,
      (
        labelY +
        29
      ) -
      Math.min(
        y -
          28,
        labelY -
          6
      )
    )
  );
}
`,
    '商圈地图标签'
  );

source =
  replaceBetween(
    source,
    'function drawDistrictCard() {',
    '\n/* =========================\n   底部导航',
    `function drawDistrictCard() {
  const x =
    CARD_X;

  const y =
    CARD_Y;

  const w =
    CARD_W;

  const h =
    CARD_H;

  roundedRect(
    x,
    y,
    w,
    h,
    16,
    'rgba(255,253,247,0.988)',
    'rgba(17,53,72,0.25)',
    1
  );

  if (
    !selectedDistrictId
  ) {
    drawText(
      '请选择一个商圈',
      18,
      y +
        22,
      12.3,
      COLORS.text,
      '800'
    );

    drawText(
      '点击地图地点，查看经营数据与开店机会',
      18,
      y +
        43,
      6.8,
      COLORS.muted,
      '600'
    );

    drawMetricChip(
      18,
      y +
        58,
      108,
      '人口',
      '--',
      COLORS.blue
    );

    drawMetricChip(
      141,
      y +
        58,
      108,
      '日需求',
      '--',
      COLORS.danger
    );

    drawMetricChip(
      264,
      y +
        58,
      108,
      '客单价',
      '--',
      COLORS.green
    );

    return;
  }

  const district =
    citySystem
      .getDistrict(
        selectedDistrictId
      );

  if (!district) {
    return;
  }

  const currentDemand =
    demandSystem
      .getTotalDemand(
        district.id
      );

  drawDistrictThumb(
    district.id,
    x +
      9,
    y +
      9,
    93,
    h -
      18
  );

  roundedRect(
    x +
      17,
    y +
      h -
      34,
    77,
    19,
    9,
    'rgba(5,42,61,0.86)',
    'rgba(255,220,122,0.55)'
  );

  drawText(
    district.name,
    x +
      55.5,
    y +
      h -
      24.5,
    6.7,
    '#FFF7D4',
    '800',
    'center'
  );

  drawText(
    fitText(
      district.name,
      118,
      13.4,
      '800'
    ),
    x +
      113,
    y +
      22,
    13.4,
    COLORS.text,
    '800'
  );

  const demandDelta =
    Number(
      district
        .demandDeltaRatio
    ) ||
    0;

  let statusText =
    '客群活跃 · 仍有经营机会';

  let statusColor =
    COLORS.blue;

  if (
    district.saturation >=
      95
  ) {
    statusText =
      '竞争激烈 · 建议谨慎选址';

    statusColor =
      COLORS.danger;
  } else if (
    demandDelta >=
      0.04
  ) {
    statusText =
      '需求升温 · 当前机会较好';

    statusColor =
      COLORS.green;
  } else if (
    demandDelta <=
      -0.04
  ) {
    statusText =
      '需求回落 · 注意经营风险';

    statusColor =
      COLORS.orange;
  }

  drawText(
    statusText,
    x +
      113,
    y +
      42,
    6.3,
    statusColor,
    '600'
  );

  const metrics = [
    [
      '人口',
      district.population
        .toLocaleString(),
      COLORS.blue
    ],
    [
      '需求',
      currentDemand
        .toLocaleString(),
      COLORS.green
    ],
    [
      '客单',
      '¥' +
        district.avgSpend,
      COLORS.navy
    ],
    [
      '餐饮店',
      district.restaurantCount +
        '家',
      COLORS.navy
    ],
    [
      '饱和度',
      district.saturation +
        '%',
      district.saturation >=
        95
        ? COLORS.danger
        : COLORS.blue
    ],
    [
      '租金',
      district.rentIndex
        .toFixed(
          2
        ),
      COLORS.navy
    ]
  ];

  for (
    let i = 0;
    i <
    metrics.length;
    i++
  ) {
    drawMetricChip(
      x +
        112 +
        i *
          42,
      y +
        53,
      39,
      metrics[i][0],
      metrics[i][1],
      metrics[i][2]
    );
  }

  drawText(
    '实时数据随人口、事件、竞争与租金变化',
    x +
      113,
    y +
      107,
    5.8,
    COLORS.muted,
    '600'
  );

  roundedRect(
    x +
      258,
    y +
      h -
      39,
    106,
    31,
    15,
    COLORS.gold,
    '#D99E22'
  );

  drawText(
    '进入商圈  ›',
    x +
      311,
    y +
      h -
      23.5,
    8,
    '#213541',
    '800',
    'center'
  );

  addButton(
    'district:details',
    x +
      250,
    y +
      h -
      45,
    122,
    44
  );
}
`,
    '商圈数据卡'
  );

source =
  replaceBetween(
    source,
    'function drawBottomNav() {',
    '\n/* =========================\n   城市场景',
    `function drawBottomNav() {
  const gradient =
    ctx.createLinearGradient(
      0,
      NAV_Y,
      0,
      VIEW_H
    );

  gradient.addColorStop(
    0,
    '#0A405E'
  );

  gradient.addColorStop(
    1,
    '#05263A'
  );

  ctx.fillStyle =
    gradient;

  ctx.fillRect(
    0,
    NAV_Y,
    VIEW_W,
    NAV_H
  );

  ctx.fillStyle =
    'rgba(84,194,237,0.28)';

  ctx.fillRect(
    0,
    NAV_Y,
    VIEW_W,
    1
  );

  const current =
    sceneManager
      .getCurrentId();

  const cellW =
    VIEW_W /
    NAV_ITEMS.length;

  for (
    let i = 0;
    i <
    NAV_ITEMS.length;
    i++
  ) {
    const item =
      NAV_ITEMS[i];

    const cx =
      i *
        cellW +
      cellW /
        2;

    const active =
      item.id ===
        current ||
      (
        item.id ===
          'city' &&
        current ===
          'district'
      ) ||
      (
        item.id ===
          'shop' &&
        (
          current ===
            'propertyMarket' ||
          current ===
            'equipment' ||
          current ===
            'license' ||
          current ===
            'staff'
        )
      ) ||
      (
        item.id ===
          'renovation' &&
        current ===
          'renovation'
      );

    if (
      active
    ) {
      roundedRect(
        i *
          cellW +
          4,
        NAV_Y +
          6,
        cellW -
          8,
        NAV_H -
          12,
        11,
        COLORS.gold,
        '#FFE09A'
      );
    }

    drawNavIcon(
      item.id,
      cx,
      NAV_Y +
        NAV_H *
          0.34,
      active
    );

    drawText(
      item.name,
      cx,
      NAV_Y +
        NAV_H *
          0.73,
      6.4,
      active
        ? '#153342'
        : '#E0EBEF',
      active
        ? '800'
        : '600',
      'center'
    );

    addButton(
      'nav:' +
        item.id,
      i *
        cellW,
      NAV_Y,
      cellW,
      NAV_H
    );
  }
}
`,
    '正式底栏图标'
  );

source =
  replaceOnce(
    source,
    `    if (
      toolId ===
      'news'
    ) {
      const bulletin =
        simulationSystem
          .getBulletin();

      showToast(
        bulletin.title +
        '：' +
        bulletin.detail
      );
    } else {
      showToast(
        '该城市功能已预留'
      );
    }`,
    `    if (
      toolId ===
      'news'
    ) {
      const bulletin =
        simulationSystem
          .getBulletin();

      if (
        bulletin &&
        bulletin.districtId &&
        citySystem
          .getDistrict(
            bulletin.districtId
          )
      ) {
        selectedDistrictId =
          bulletin.districtId;

        citySystem
          .setCurrentDistrict(
            bulletin.districtId
          );

        startDistrictFx(
          bulletin.districtId
        );
      }

      showToast(
        bulletin.title +
        '：' +
        bulletin.detail
      );
    } else {
      showToast(
        '该城市功能已预留'
      );
    }`,
    '城市通报联动商圈'
  );

source =
  source.replace(
    '城市餐饮经营小游戏 V18 核心四页全量重构版启动成功',
    '城市餐饮经营小游戏 V19 城市首页精修版启动成功'
  );

write(
  source
);

const packagePath =
  path.join(
    ROOT,
    'package.json'
  );

const pkg =
  JSON.parse(
    fs.readFileSync(
      packagePath,
      'utf8'
    )
  );

if (
  pkg.scripts &&
  pkg.scripts.pretest ===
    'node scripts/apply-v19-city-home.js'
) {
  delete pkg.scripts.pretest;
}

fs.writeFileSync(
  packagePath,
  JSON.stringify(
    pkg,
    null,
    2
  ) +
    '\n'
);

try {
  fs.unlinkSync(
    path.join(
      ROOT,
      'scripts/apply-v19-city-home.js'
    )
  );
} catch (
  error
) {
}

console.log(
  'V19城市首页精修补丁已应用'
);
