'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const MAIN = path.join(ROOT, 'src/main.js');
const STORE = path.join(ROOT, 'src/scenes/storeScene.js');
const PKG = path.join(ROOT, 'package.json');
const MARKER = 'V36_HEADER_MONEY_WEATHER_FINAL';

function replaceOnce(source, from, to, label) {
  const index = source.indexOf(from);
  if (index < 0) {
    throw new Error('[V36] 找不到替换锚点：' + label);
  }
  if (source.indexOf(from, index + from.length) >= 0) {
    throw new Error('[V36] 替换锚点不唯一：' + label);
  }
  return source.slice(0, index) + to + source.slice(index + from.length);
}

function ensurePackageFinalState() {
  const pkg = JSON.parse(fs.readFileSync(PKG, 'utf8'));
  pkg.scripts = pkg.scripts || {};
  pkg.scripts.pretest = 'node scripts/repo-cleanup.js --ci-auto';
  if (!String(pkg.scripts.test || '').includes('tests/v36HeaderMoneyWeather.test.js')) {
    pkg.scripts.test = String(pkg.scripts.test || '') + ' && node tests/v36HeaderMoneyWeather.test.js';
  }
  fs.writeFileSync(PKG, JSON.stringify(pkg, null, 2) + '\n');
}

function patchMain() {
  let source = fs.readFileSync(MAIN, 'utf8');
  if (source.includes(MARKER)) return false;

  const helperAnchor = "function v32DrawImage(key, x, y, w, h, alpha) {";
  const helper = `/* ${MARKER} */\nfunction v36CompactHeaderMoney(value) {\n  const n = Number(value) || 0;\n  const abs = Math.abs(n);\n\n  function trim(v, decimals) {\n    return Number(v)\n      .toFixed(decimals)\n      .replace(/\\.0+$/, '')\n      .replace(/(\\.\\d*?[1-9])0+$/, '$1');\n  }\n\n  if (abs >= 1000000000000) {\n    const v = n / 1000000000000;\n    return trim(v, Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2) + '万亿';\n  }\n\n  if (abs >= 100000000) {\n    const v = n / 100000000;\n    return trim(v, Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2) + '亿';\n  }\n\n  if (abs >= 10000) {\n    const v = n / 10000;\n    return trim(v, Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2) + '万';\n  }\n\n  return Math.round(n).toLocaleString();\n}\n\n`;
  source = replaceOnce(source, helperAnchor, helper + helperAnchor, '主页短金额格式化函数');

  source = replaceOnce(
    source,
    "fitText(cityName, 112, 18.8, '800')",
    "fitText(cityName, 82, 18.8, '800')",
    '城市名宽度'
  );

  const oldWeather = `  drawWeatherGlyph(world.weather, 180, 27 + SAFE_TOP);\n  drawText(\n    WEATHER_NAMES[world.weather] || '晴',\n    200,\n    18 + SAFE_TOP,\n    7.6,\n    '#FFFFFF',\n    '800',\n    'center'\n  );\n  drawText(\n    (Number(world.temperature) || 22) + '℃',\n    200,\n    37 + SAFE_TOP,\n    7.6,\n    '#F4FAFD',\n    '700',\n    'center'\n  );\n\n  const levelW = 68;\n  const moneyW = 106;`;

  const newWeather = `  // V36：天气独立成紧凑胶囊，不再与资金卡互相遮挡。\n  const weatherX = 164;\n  const weatherY = 10 + SAFE_TOP;\n  const weatherW = 62;\n  const weatherH = 22;\n\n  roundedRect(\n    weatherX,\n    weatherY,\n    weatherW,\n    weatherH,\n    10,\n    'rgba(3,57,91,0.82)',\n    'rgba(72,183,236,0.42)'\n  );\n\n  if (!v29Img('v29_hud_weather', weatherX + 12, weatherY + 11, 18, 15, 1)) {\n    drawWeatherGlyph(world.weather, weatherX + 12, weatherY + 11);\n  }\n\n  drawText(\n    fitText(\n      (WEATHER_NAMES[world.weather] || '晴') + ' ' +\n        (Number(world.temperature) || 22) + '°',\n      39,\n      7.0,\n      '700'\n    ),\n    weatherX + 23,\n    weatherY + 11,\n    7.0,\n    '#F4FAFD',\n    '700'\n  );\n\n  const levelW = 65;\n  const moneyW = 82;`;
  source = replaceOnce(source, oldWeather, newWeather, '首页天气与卡片宽度');

  const oldMoney = `  drawCashGlyph(moneyX + 18, 26 + SAFE_TOP);\n\n  const moneyText = v32FormatMoney(player.cash);\n  const moneyFont = moneyText.length <= 7 ? 11.9 : moneyText.length <= 9 ? 10.9 : 9.9;\n\n  drawText(\n    fitText(moneyText, moneyW - 44, moneyFont, '800'),\n    moneyX + 63,\n    21 + SAFE_TOP,\n    moneyFont,\n    '#FFF5A9',\n    '800',\n    'center'\n  );\n\n  drawText(\n    '可用资金',\n    moneyX + 63,\n    42 + SAFE_TOP,\n    6.9,\n    '#E5F2F7',\n    '600',\n    'center'\n  );\n\n  roundedRect(\n    moneyX + moneyW - 18,\n    16 + SAFE_TOP,\n    13,\n    13,\n    4,\n    '#FFB72B',\n    '#FFE68D'\n  );\n  drawText('+', moneyX + moneyW - 11.5, 22.5 + SAFE_TOP, 8.6, '#FFFFFF', '800', 'center');`;

  const newMoney = `  // V36：资金只保留“钱图标 + 短金额 + 资金”，取消“+”按钮。\n  if (!v29Img('v29_hud_money', moneyX + 14, 25 + SAFE_TOP, 19, 16, 1)) {\n    drawCashGlyph(moneyX + 14, 25 + SAFE_TOP);\n  }\n\n  const moneyText = v36CompactHeaderMoney(player.cash);\n  const moneyFont = moneyText.length <= 4 ? 11.2 : moneyText.length <= 6 ? 10.3 : 9.4;\n\n  drawText(\n    fitText(moneyText, moneyW - 31, moneyFont, '800'),\n    moneyX + 50,\n    21 + SAFE_TOP,\n    moneyFont,\n    '#FFF1A2',\n    '800',\n    'center'\n  );\n\n  drawText(\n    '资金',\n    moneyX + 50,\n    42 + SAFE_TOP,\n    6.4,\n    '#DDEFF6',\n    '600',\n    'center'\n  );`;
  source = replaceOnce(source, oldMoney, newMoney, '首页资金卡');

  source = replaceOnce(
    source,
    "  drawCrownGlyph(levelX + 15, 26 + SAFE_TOP);",
    "  if (!v29Img('v29_hud_crown', levelX + 14, 25 + SAFE_TOP, 20, 17, 1)) {\n    drawCrownGlyph(levelX + 14, 25 + SAFE_TOP);\n  }",
    '等级图标缩小'
  );

  fs.writeFileSync(MAIN, source);
  return true;
}

function patchStore() {
  let source = fs.readFileSync(STORE, 'utf8');
  if (source.includes(MARKER)) return false;

  const clampAnchor = `function clamp(\n  value,\n  min,\n  max\n) {`;
  const compact = `/* ${MARKER} */\nfunction compactHeaderMoney(value) {\n  const n = Math.max(0, Number(value) || 0);\n  const abs = Math.abs(n);\n\n  function trim(v, decimals) {\n    return Number(v)\n      .toFixed(decimals)\n      .replace(/\\.0+$/, '')\n      .replace(/(\\.\\d*?[1-9])0+$/, '$1');\n  }\n\n  if (abs >= 1000000000000) {\n    const v = n / 1000000000000;\n    return trim(v, Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2) + '万亿';\n  }\n\n  if (abs >= 100000000) {\n    const v = n / 100000000;\n    return trim(v, Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2) + '亿';\n  }\n\n  if (abs >= 10000) {\n    const v = n / 10000;\n    return trim(v, Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2) + '万';\n  }\n\n  return Math.round(n).toLocaleString();\n}\n\n`;
  source = replaceOnce(source, clampAnchor, compact + clampAnchor, '门店页短金额函数');

  const oldCityName = `    const cityName =\n      gameState\n        .getCityName() ||\n      '城市名称';`;
  const newCityName = `    let cityName =\n      gameState\n        .getCityName();\n\n    if (\n      !cityName ||\n      cityName ===\n        '未命名城市'\n    ) {\n      cityName =\n        '美食市';\n    }`;
  source = replaceOnce(source, oldCityName, newCityName, '门店页城市名兜底');

  const oldCard = `    ui.card(\n      ctx,\n      285,\n      11,\n      96,\n      43,\n      {\n        radius:\n          12,\n        fill:\n          'rgba(5,39,59,0.86)',\n        stroke:\n          'rgba(255,255,255,0.30)',\n        shadow:\n          false\n      }\n    );\n\n    ui.text(\n      ctx,\n      money(\n        gameState\n          .getPlayer()\n          .cash\n      ),\n      333,\n      26,\n      11.4,\n      '#FFF0A9',\n      '800',\n      'center'\n    );\n\n    ui.text(\n      ctx,\n      '可用资金',\n      333,\n      44,\n      6.3,\n      '#D9E9EE',\n      '600',\n      'center'\n    );`;

  const newCard = `    // V36：门店页与首页统一为短金额，不再显示“¥50,000”式长数字。\n    ui.card(\n      ctx,\n      297,\n      13,\n      84,\n      39,\n      {\n        radius:\n          11,\n        fill:\n          'rgba(3,57,91,0.80)',\n        stroke:\n          'rgba(72,183,236,0.42)',\n        shadow:\n          false\n      }\n    );\n\n    ui.text(\n      ctx,\n      compactHeaderMoney(\n        gameState\n          .getPlayer()\n          .cash\n      ),\n      339,\n      27,\n      11.8,\n      '#FFF1A2',\n      '800',\n      'center'\n    );\n\n    ui.text(\n      ctx,\n      '资金',\n      339,\n      44,\n      6.1,\n      '#DDEFF6',\n      '600',\n      'center'\n    );`;
  source = replaceOnce(source, oldCard, newCard, '门店页资金卡');

  fs.writeFileSync(STORE, source);
  return true;
}

try {
  const mainChanged = patchMain();
  const storeChanged = patchStore();
  ensurePackageFinalState();
  console.log('[V36] 顶部资金/天气UI修复完成。main=' + mainChanged + ', store=' + storeChanged);
  try {
    fs.unlinkSync(__filename);
  } catch (error) {
    console.warn('[V36] 临时补丁脚本未能自删除：' + error.message);
  }
} catch (error) {
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
}
