"use strict";

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const mainPath = path.join(ROOT, "src/main.js");
const pkgPath = path.join(ROOT, "package.json");
const startupMarker = "/* =========================\n   启动\n========================= */";

let source = fs.readFileSync(mainPath, "utf8");

if (!source.includes("V34_MONEY_FORMAT_FIX")) {
  const insertAt = source.indexOf(startupMarker);
  if (insertAt < 0) throw new Error("V34无法找到启动标记");

  const block = String.raw`
/* V34_MONEY_FORMAT_FIX */

function v34TrimMoneyNumber(value, decimals) {
  return Number(value)
    .toFixed(decimals)
    .replace(/\.0+$/, '')
    .replace(/(\.\d*?[1-9])0+$/, '$1');
}

v32FormatMoney = function (value) {
  const n = Number(value) || 0;
  const abs = Math.abs(n);

  if (abs >= 1000000000000) {
    const v = n / 1000000000000;
    return '¥' + v34TrimMoneyNumber(
      v,
      Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2
    ) + '万亿';
  }

  if (abs >= 100000000) {
    const v = n / 100000000;
    return '¥' + v34TrimMoneyNumber(
      v,
      Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2
    ) + '亿';
  }

  if (abs >= 10000) {
    const v = n / 10000;
    return '¥' + v34TrimMoneyNumber(
      v,
      Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2
    ) + '万';
  }

  return '¥' + Math.round(n).toLocaleString();
};

console.log('V34_MONEY_FORMAT_FIX loaded');
`;

  source = source.slice(0, insertAt) + block + source.slice(insertAt);

  source = source.replace(
    '城市餐饮经营小游戏 V33 全局统一底栏版启动成功',
    '城市餐饮经营小游戏 V34 资金显示修正版启动成功'
  );

  fs.writeFileSync(mainPath, source, "utf8");
}

const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
if (pkg.scripts) delete pkg.scripts.pretest;
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n", "utf8");

try { fs.unlinkSync(__filename); } catch (e) {}

console.log("V34资金显示修复已应用");
