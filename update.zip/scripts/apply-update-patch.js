'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.19';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.19 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function replaceSection(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  if (
    source.includes(
      replacement
    )
  ) {
    return source;
  }

  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V0.8.19 section start missing: ' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
      startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V0.8.19 section end missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    '\n\n' +
    source.slice(
      end
    )
  );
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      '0.8.18' &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.19 requires formal V0.8.18 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateInventoryRules() {
  write(
    'src/inventory/inventoryRulesV10.js',
`'use strict';

const database =
  require('./ingredientInventoryDatabaseV0819.js');

const STORAGE_BY_CATEGORY =
  database.STORAGE_BY_CATEGORY;

function storageFor(
  ingredient
) {
  if (
    ingredient &&
    ingredient.id
  ) {
    const row =
      database
        .getIngredient(
          ingredient.id
        );

    if (row) {
      return row
        .storageZoneId;
    }
  }

  return (
    STORAGE_BY_CATEGORY[
      ingredient &&
      ingredient.category
    ] ||
    'ambient'
  );
}

function freshness(
  lot,
  day
) {
  return (
    database
      .freshnessScore(
        lot,
        day
      )
  );
}

function lotStatus(
  lot,
  day
) {
  return (
    database
      .lotStatus(
        lot,
        day
      )
  );
}

function lotValue(
  lot
) {
  return (
    Math.round(
      (
        Number(
          lot &&
          lot.grams
        ) ||
        0
      ) /
      1000 *
      Number(
        lot &&
        lot.unitCostPerKg ||
        0
      ) *
      100
    ) /
    100
  );
}

module.exports = {
  STORAGE_BY_CATEGORY,
  storageFor,
  freshness,
  lotStatus,
  lotValue
};
`
  );
}

function updateInventoryEngine() {
  const rel =
    'src/inventory/inventoryEngineV10.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const food=require('../food/foodPackV10.js');
const rules=require('./inventoryRulesV10.js');`,
`const food=require('../food/foodPackV10.js');
const rules=require('./inventoryRulesV10.js');
const database=require('./ingredientInventoryDatabaseV0819.js');`,
      'inventory database import'
    );

  source =
    replaceOnce(
      source,
`  const ingredient=food.INGREDIENTS.find(x=>x.id===line.ingredientId);
  if(!ingredient)return {ok:false,reason:'食材不存在'};`,
`  const ingredient=database.getIngredient(line.ingredientId);
  if(!ingredient)return {ok:false,reason:'食材不存在'};`,
      'inventory ingredient lookup'
    );

  source =
    replaceOnce(
      source,
`  const lot={
    id:\`lot_\${++state.sequence}\`,ingredientId:ingredient.id,ingredientName:ingredient.name,grams,
    originalGrams:grams,storage,receivedDay:day,expiryDay:day+Math.max(1,Number(line.shelfDays??ingredient.shelfDays)),
    unitCostPerKg:Number(line.unitCostPerKg)||0,supplierId:line.supplierId||null,quality:Number(line.quality??75)
  };`,
`  const lotId=
    \`lot_\${++state.sequence}\`;

  const lot={
    id:lotId,
    batchNo:
      line.batchNo||
      lotId,
    databaseVersion:
      database.VERSION,
    ingredientId:ingredient.id,
    ingredientName:ingredient.name,
    grams,
    originalGrams:grams,
    storage,
    receivedDay:day,
    expiryDay:
      day+
      Math.max(
        1,
        Number(
          line.shelfDays??
          ingredient.shelfDays
        )
      ),
    unitCostPerKg:
      Number(
        line.unitCostPerKg
      )||0,
    supplierId:
      line.supplierId||null,
    quality:
      Number(
        line.quality??75
      )
  };`,
      'inventory batch metadata'
    );

  const observability =
`function lotRows(
  state
) {
  return (
    database
      .lotRows(
        state
      )
  );
}

function capacitySummary(
  state
) {
  return (
    database
      .capacitySummary(
        state
      )
  );
}

function inventoryAlerts(
  state
) {
  const rows =
    lotRows(
      state
    );

  const alerts = [];

  for (
    const row
    of rows
  ) {
    if (
      row.status.expired
    ) {
      alerts.push({
        type:'expired',
        severity:'critical',
        lotId:row.id,
        batchNo:row.batchNo,
        ingredientId:row.ingredientId,
        ingredientName:row.ingredientName,
        grams:row.grams,
        daysRemaining:
          row.status.daysRemaining
      });

      continue;
    }

    if (
      row.status.status ===
        'expires_today'
    ) {
      alerts.push({
        type:'expires_today',
        severity:'critical',
        lotId:row.id,
        batchNo:row.batchNo,
        ingredientId:row.ingredientId,
        ingredientName:row.ingredientName,
        grams:row.grams,
        daysRemaining:0
      });

      continue;
    }

    if (
      row.status.nearExpiry
    ) {
      alerts.push({
        type:'near_expiry',
        severity:'warning',
        lotId:row.id,
        batchNo:row.batchNo,
        ingredientId:row.ingredientId,
        ingredientName:row.ingredientName,
        grams:row.grams,
        daysRemaining:
          row.status.daysRemaining
      });
    }

    if (
      Number(
        row.quality
      ) <
      60
    ) {
      alerts.push({
        type:'low_quality',
        severity:'warning',
        lotId:row.id,
        batchNo:row.batchNo,
        ingredientId:row.ingredientId,
        ingredientName:row.ingredientName,
        quality:
          Number(
            row.quality
          )||0
      });
    }
  }

  const capacity =
    capacitySummary(
      state
    );

  for (
    const zone
    of capacity.rows
  ) {
    if (
      zone.status !==
      'ok'
    ) {
      alerts.push({
        type:'capacity',
        severity:
          zone.status ===
            'critical'
            ? 'critical'
            : 'warning',
        storage:
          zone.id,
        storageName:
          zone.name,
        usageRatio:
          zone.usageRatio,
        usedKg:
          zone.usedKg,
        capacityKg:
          zone.capacityKg
      });
    }
  }

  return alerts;
}

function stockSummary(
  state
) {
  const byIngredient={};
  const byStorage={
    ambient:0,
    chilled:0,
    frozen:0
  };

  const rows=
    lotRows(
      state
    );

  for(
    const lot
    of rows
  ){
    if(
      lot.status.expired
    ){
      continue;
    }

    byIngredient[
      lot.ingredientId
    ]=
      (
        byIngredient[
          lot.ingredientId
        ]||0
      )+
      lot.grams;

    if(
      byStorage[
        lot.storage
      ]==
      null
    ){
      byStorage[
        lot.storage
      ]=0;
    }

    byStorage[
      lot.storage
    ]+=
      lot.grams/
      1000;
  }

  return {
    databaseVersion:
      database.VERSION,
    day:state.day,
    byIngredient,
    byStorage,
    totalKg:
      Object
        .values(
          byIngredient
        )
        .reduce(
          (s,x)=>s+x,
          0
        )/
      1000,
    lotCount:
      rows.length,
    nearExpiryLotCount:
      rows.filter(
        row=>
          row.status.nearExpiry
      ).length,
    expiredLotCount:
      rows.filter(
        row=>
          row.status.expired
      ).length,
    capacity:
      capacitySummary(
        state
      ),
    alerts:
      inventoryAlerts(
        state
      ),
    waste:
      clone(
        state.waste
      )
  };
}

function inventoryHealth(
  state
) {
  const rows =
    lotRows(
      state
    );

  const summary =
    stockSummary(
      state
    );

  return {
    databaseVersion:
      database.VERSION,
    day:
      state.day,
    totalLots:
      rows.length,
    sellableLots:
      rows.filter(
        row=>
          !row.status.expired
      ).length,
    nearExpiryLots:
      rows.filter(
        row=>
          row.status.nearExpiry
      ).length,
    expiredLots:
      rows.filter(
        row=>
          row.status.expired
      ).length,
    lowQualityLots:
      rows.filter(
        row=>
          Number(
            row.quality
          )<
          60
      ).length,
    totalKg:
      summary.totalKg,
    capacity:
      summary.capacity,
    alerts:
      summary.alerts,
    waste:
      clone(
        state.waste
      )
  };
}

function reorderSuggestions(
  state,
  targets={}
){
  const out=[];

  for(
    const [
      ingredientId,
      targetGrams
    ]
    of Object.entries(
      targets
    )
  ){
    const have=
      availableGrams(
        state,
        ingredientId
      );

    if(
      have<
      targetGrams*.45
    ){
      const ingredient=
        database
          .getIngredient(
            ingredientId
          );

      out.push({
        ingredientId,
        ingredientName:
          ingredient
            ? ingredient.name
            : ingredientId,
        storage:
          ingredient
            ? ingredient
                .storageZoneId
            : 'ambient',
        shelfDays:
          ingredient
            ? ingredient
                .shelfDays
            : null,
        perishability:
          ingredient
            ? ingredient
                .perishability
            : null,
        haveGrams:have,
        targetGrams,
        reorderGrams:
          Math.max(
            0,
            targetGrams-have
          ),
        priority:
          have<
          targetGrams*.15
            ? 'critical'
            : 'normal'
      });
    }
  }

  return out.sort(
    (
      a,
      b
    )=>
      (
        a.priority===
          'critical'
          ? -1
          : 1
      )-
      (
        b.priority===
          'critical'
          ? -1
          : 1
      )
  );
}`;

  source =
    replaceSection(
      source,
      'function stockSummary(state){',
      'module.exports=',
      observability,
      'inventory observability'
    );

  source =
    replaceOnce(
      source,
`module.exports={createInventory,receive,availableGrams,consume,consumeRequirements,advanceDay,stockSummary,reorderSuggestions,usedKg};`,
`module.exports={
  createInventory,
  receive,
  availableGrams,
  consume,
  consumeRequirements,
  advanceDay,
  lotRows,
  capacitySummary,
  inventoryAlerts,
  stockSummary,
  inventoryHealth,
  reorderSuggestions,
  usedKg
};`,
      'inventory exports'
    );

  write(
    rel,
    source
  );
}

function updateInventoryIndex() {
  write(
    'src/inventory/index.js',
`'use strict';

module.exports = {
  database:
    require('./ingredientInventoryDatabaseV0819.js'),
  rules:
    require('./inventoryRulesV10.js'),
  engine:
    require('./inventoryEngineV10.js')
};
`
  );
}

function updateOperationsStore() {
  const rel =
    'src/operations/operationsStoreV080.js';

  let source =
    read(rel);

  if (
    !source.includes(
      'function inventoryLotRows('
    )
  ) {
    const anchor =
      'function autoRestock(\n  shopId\n) {';

    const index =
      source.indexOf(
        anchor
      );

    if (index < 0) {
      throw new Error(
        'V0.8.19 operations inventory API anchor missing'
      );
    }

    const block =
`function inventoryLotRows(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return [];
  }

  return (
    inventoryEngine
      .lotRows(
        runtime.inventory
      )
  );
}

function inventoryHealth(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return null;
  }

  return (
    inventoryEngine
      .inventoryHealth(
        runtime.inventory
      )
  );
}

`;

    source =
      source.slice(
        0,
        index
      ) +
      block +
      source.slice(
        index
      );
  }

  source =
    replaceOnce(
      source,
`  inventoryRows,
  autoRestock,`,
`  inventoryRows,
  inventoryLotRows,
  inventoryHealth,
  autoRestock,`,
      'operations inventory exports'
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0819.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/foodResearchDatabaseV0818.test.js',
    'tests/foodResearchSystemV0818.test.js',
    'tests/foodMenuResearchIntegrationV0818.test.js',
    'tests/updateInfrastructureV0818.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/foodResearchDatabaseV0818.test.js',
    'tests/foodResearchSystemV0818.test.js',
    'tests/foodMenuResearchIntegrationV0818.test.js',
    'tests/updateInfrastructureV0818.test.js',
    'tests/ingredientInventoryDatabaseV0819.test.js',
    'tests/inventoryIntegrationV0819.test.js',
    'tests/updateInfrastructureV0819.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0819'
    );

  write(
    rel,
    source
  );
}

function updateMainLabel() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.18 菜品菜单研发数据库版启动成功',
      '城市餐饮经营小游戏 V0.8.19 食材库存数据库版启动成功'
    );

  write(
    rel,
    source
  );
}

// setup-android@v3 compatibility for the ephemeral GitHub runner only.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const binDir =
    path.join(
      latestDir,
      'bin'
    );

  const sdkmanager =
    path.join(
      binDir,
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.19] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const realSdkmanager =
    path.join(
      binDir,
      'sdkmanager.v0819-real'
    );

  if (
    !fs.existsSync(
      realSdkmanager
    )
  ) {
    fs.renameSync(
      sdkmanager,
      realSdkmanager
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0819-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.19] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.19 package version finalize failed'
    );
  }

  for (
    const rel
    of [
      'src/inventory/ingredientInventoryDatabaseV0819.js',
      'tests/ingredientInventoryDatabaseV0819.test.js',
      'tests/inventoryIntegrationV0819.test.js',
      'tests/updateInfrastructureV0819.test.js'
    ]
  ) {
    if (
      !fs.existsSync(
        abs(rel)
      )
    ) {
      throw new Error(
        'V0.8.19 required file missing: ' +
        rel
      );
    }
  }

  const engine =
    read(
      'src/inventory/inventoryEngineV10.js'
    );

  for (
    const marker
    of [
      'ingredientInventoryDatabaseV0819.js',
      'function lotRows(',
      'function capacitySummary(',
      'function inventoryAlerts(',
      'function inventoryHealth(',
      'databaseVersion:'
    ]
  ) {
    if (
      !engine.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.19 inventory validation missing ' +
        marker
      );
    }
  }

  const operations =
    read(
      'src/operations/operationsStoreV080.js'
    );

  for (
    const marker
    of [
      'function inventoryLotRows(',
      'function inventoryHealth('
    ]
  ) {
    if (
      !operations.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.19 operations validation missing ' +
        marker
      );
    }
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/ingredientInventoryDatabaseV0819.test.js',
      'tests/inventoryIntegrationV0819.test.js',
      'tests/updateInfrastructureV0819.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.19 runner validation missing ' +
        marker
      );
    }
  }
}

updatePackage();
updatePackageLock();
updateInventoryRules();
updateInventoryEngine();
updateInventoryIndex();
updateOperationsStore();
updateRunner();
updateMainLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.19] PASS：食材 / 库存数据库统一完成'
);
