'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.13';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs.readFileSync(
    abs(rel),
    'utf8'
  );
}

function write(rel, content) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (source.includes(to)) {
    return source;
  }

  const index =
    source.indexOf(from);

  if (index < 0) {
    throw new Error(
      'V0.8.13 patch anchor missing: ' +
      label
    );
  }

  return source.slice(0, index) +
    to +
    source.slice(
      index + from.length
    );
}

function insertAfter(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(marker)
  ) {
    return source;
  }

  const index =
    source.indexOf(anchor);

  if (index < 0) {
    throw new Error(
      'V0.8.13 insert anchor missing: ' +
      label
    );
  }

  const end =
    index + anchor.length;

  return source.slice(0, end) +
    addition +
    source.slice(end);
}

function replaceSection(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  const start =
    source.indexOf(startMarker);

  if (start < 0) {
    throw new Error(
      'V0.8.13 section start missing: ' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start + startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V0.8.13 section end missing: ' +
      label
    );
  }

  return source.slice(0, start) +
    replacement +
    '\n\n' +
    source.slice(end);
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read('package.json')
    );

  if (
    pkg.version !== '0.8.12' &&
    pkg.version !== TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.13 requires formal V0.8.12 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) + '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (!fs.existsSync(abs(rel))) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages[''].version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) + '\n'
  );
}

function updateSimulationSystem() {
  const rel =
    'src/core/simulationSystem.js';

  let source =
    read(rel);

  const requireAnchor =
`const timeScheduleCoordinator =
  require('./timeScheduleCoordinatorV0812.js');`;

  source =
    insertAfter(
      source,
      requireAnchor,
`

const seedManager =
  require('./seedManagerV0813.js');`,
      "require('./seedManagerV0813.js')",
      'simulation seed manager require'
    );

  source =
    replaceSection(
      source,
      '  getSeed() {',
      '  chooseWeather(',
`  getSeed() {
    const simulation =
      gameState
        .getSimulation();

    // Preserve explicit/legacy simulation.seed values exactly.
    if (
      simulation.seed ==
      null
    ) {
      simulation.seed =
        seedManager
          .deriveSeed(
            'simulation',
            'world'
          );
    }

    return simulation.seed;
  }`,
      'simulation getSeed'
    );

  write(rel, source);
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0813.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/timeScheduleCoordinatorV0812.test.js',
    'tests/timedProgressionV0812.test.js',
    'tests/updateInfrastructureV0812.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/timeScheduleCoordinatorV0812.test.js',
    'tests/timedProgressionV0812.test.js',
    'tests/updateInfrastructureV0812.test.js',
    'tests/saveMigrationV0813.test.js',
    'tests/seedManagerV0813.test.js',
    'tests/updateInfrastructureV0813.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0813'
    );

  write(rel, source);
}

// GitHub's setup-android@v3 may still request the removed legacy SDK package "tools".
// This only patches the temporary runner filesystem; nothing is committed to the repo.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const binDir =
    path.join(
      latestDir,
      'bin'
    );

  const sdkmanager =
    path.join(
      binDir,
      'sdkmanager'
    );

  if (
    !fs.existsSync(sourceProperties) ||
    !fs.existsSync(sdkmanager)
  ) {
    console.log(
      '[V0.8.13] Android SDK runner compatibility: preinstalled sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const realSdkmanager =
    path.join(
      binDir,
      'sdkmanager.v0813-real'
    );

  if (!fs.existsSync(realSdkmanager)) {
    fs.renameSync(
      sdkmanager,
      realSdkmanager
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0813-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join('\n');

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.13] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read('package.json')
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.13 package version finalize failed'
    );
  }

  const checks = [
    [
      'src/core/saveSystem.js',
      [
        'V083_SAVE_THROTTLE',
        'autoSaveIntervalMs = 20000',
        'flush()',
        "require('./saveMigrationV0813.js')",
        "require('./seedManagerV0813.js')",
        'city_restaurant_save_v1_backup'
      ]
    ],
    [
      'src/core/simulationSystem.js',
      [
        "require('./seedManagerV0813.js')",
        '.deriveSeed('
      ]
    ],
    [
      'scripts/run-ci-tests-v060.js',
      [
        'tests/saveMigrationV0813.test.js',
        'tests/seedManagerV0813.test.js',
        'tests/updateInfrastructureV0813.test.js'
      ]
    ]
  ];

  for (const [file, markers] of checks) {
    const source =
      read(file);

    for (const marker of markers) {
      if (!source.includes(marker)) {
        throw new Error(
          'V0.8.13 validation missing ' +
          marker +
          ' in ' +
          file
        );
      }
    }
  }

  for (
    const file
    of [
      'src/core/saveMigrationV0813.js',
      'src/core/seedManagerV0813.js',
      'tests/saveMigrationV0813.test.js',
      'tests/seedManagerV0813.test.js',
      'tests/updateInfrastructureV0813.test.js'
    ]
  ) {
    if (!fs.existsSync(abs(file))) {
      throw new Error(
        'V0.8.13 required file missing: ' +
        file
      );
    }
  }
}

updatePackage();
updatePackageLock();
updateSimulationSystem();
updateRunner();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.13] PASS：存档 / 版本迁移 / 随机种子增量安装完成'
);
