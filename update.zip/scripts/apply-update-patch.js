'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const TARGET_VERSION = '0.8.11';

function read(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

function write(rel, content) {
  fs.writeFileSync(path.join(ROOT, rel), content, 'utf8');
}

function replaceOnce(source, from, to, label) {
  if (source.includes(to)) {
    return source;
  }

  const index = source.indexOf(from);

  if (index < 0) {
    throw new Error('V0.8.11 patch anchor missing: ' + label);
  }

  return source.slice(0, index) +
    to +
    source.slice(index + from.length);
}

function updatePackage() {
  const rel = 'package.json';
  const pkg = JSON.parse(read(rel));

  if (
    pkg.version !== '0.8.10' &&
    pkg.version !== TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.11 requires formal V0.8.10 baseline; current=' +
      pkg.version
    );
  }

  pkg.version = TARGET_VERSION;

  write(
    rel,
    JSON.stringify(pkg, null, 2) + '\n'
  );
}

function updatePackageLock() {
  const rel = 'package-lock.json';
  const abs = path.join(ROOT, rel);

  if (!fs.existsSync(abs)) return;

  const lock = JSON.parse(read(rel));
  lock.version = TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages[''].version = TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(lock, null, 2) + '\n'
  );
}

function updateMain() {
  const rel = 'src/main.js';
  let source = read(rel);

  const requireAnchor =
`const entryRouter =
  require('./core/entryRouterV0810.js');`;

  const requireReplacement =
`const entryRouter =
  require('./core/entryRouterV0810.js');

const globalStateBus =
  require('./core/globalStateBusV0811.js');

const stateBridge =
  require('./core/stateBridgeV0811.js');`;

  source = replaceOnce(
    source,
    requireAnchor,
    requireReplacement,
    'main require block'
  );

  const bootAnchor =
`// V0810_ENTRY_ROUTER_BOOT
entryRouter.install();`;

  const bootReplacement =
`// V0810_ENTRY_ROUTER_BOOT
entryRouter.install();

// V0811_GLOBAL_STATE_BUS_BOOT
stateBridge.install();
runtime.stateBus =
  globalStateBus;`;

  source = replaceOnce(
    source,
    bootAnchor,
    bootReplacement,
    'main state bus boot'
  );

  if (!source.includes('V0811_STATE_BUS_RUNTIME_SYNC')) {
    const runtimeAnchor =
`  if (
    simulationChanged ||
    timelineChanged ||
    restaurantChanged ||
    lifecycleChanged ||
    staffCareerChanged
  ) {
    saveSystem
      .autoSave();
  }`;

    const runtimeReplacement =
`  // V0811_STATE_BUS_RUNTIME_SYNC
  stateBridge
    .syncRuntime({
      advancedMinutes,
      simulationChanged,
      timelineChanged,
      restaurantChanged,
      lifecycleChanged,
      staffCareerChanged
    });

  if (
    simulationChanged ||
    timelineChanged ||
    restaurantChanged ||
    lifecycleChanged ||
    staffCareerChanged
  ) {
    saveSystem
      .autoSave();
  }`;

    source = replaceOnce(
      source,
      runtimeAnchor,
      runtimeReplacement,
      'main runtime sync'
    );
  }

  source = source.replace(
    '城市餐饮经营小游戏 V0.8.3 基础修复版启动成功',
    '城市餐饮经营小游戏 V0.8.11 全局状态总线启动成功'
  );

  write(rel, source);
}

function updateRunner() {
  const rel = 'scripts/run-ci-tests-v060.js';
  let source = read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0811.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/featureRoutingV0810.test.js',
    'tests/updateInfrastructureV0810.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/featureRoutingV0810.test.js',
    'tests/updateInfrastructureV0810.test.js',
    'tests/globalStateBusV0811.test.js',
    'tests/stateBridgeV0811.test.js',
    'tests/updateInfrastructureV0811.test.js',
    'tests/v60CleanBase.test.js'`;

  source = replaceOnce(
    source,
    anchor,
    replacement,
    'permanent CI runner'
  );

  write(rel, source);
}

function validate() {
  const pkg = JSON.parse(read('package.json'));

  if (pkg.version !== TARGET_VERSION) {
    throw new Error('V0.8.11 package version finalize failed');
  }

  const main = read('src/main.js');
  const runner = read('scripts/run-ci-tests-v060.js');

  for (const marker of [
    'V0811_GLOBAL_STATE_BUS_BOOT',
    'V0811_STATE_BUS_RUNTIME_SYNC',
    "require('./core/globalStateBusV0811.js')",
    "require('./core/stateBridgeV0811.js')"
  ]) {
    if (!main.includes(marker)) {
      throw new Error('V0.8.11 main validation missing: ' + marker);
    }
  }

  for (const test of [
    'tests/globalStateBusV0811.test.js',
    'tests/stateBridgeV0811.test.js',
    'tests/updateInfrastructureV0811.test.js'
  ]) {
    if (!runner.includes(test)) {
      throw new Error('V0.8.11 runner validation missing: ' + test);
    }
  }

  for (const file of [
    'src/core/globalStateBusV0811.js',
    'src/core/stateBridgeV0811.js',
    'tests/globalStateBusV0811.test.js',
    'tests/stateBridgeV0811.test.js',
    'tests/updateInfrastructureV0811.test.js'
  ]) {
    if (!fs.existsSync(path.join(ROOT, file))) {
      throw new Error('V0.8.11 required file missing: ' + file);
    }
  }
}

updatePackage();
updatePackageLock();
updateMain();
updateRunner();
validate();

console.log(
  '[V0.8.11] PASS：全局状态与交互总线增量安装完成'
);
