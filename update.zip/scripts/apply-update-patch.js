'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname,'..');
const TARGET = '0.8.62';
const MIN_BASE = '0.8.61';

function file(rel){ return path.join(ROOT,rel); }
function read(rel){ return fs.readFileSync(file(rel),'utf8'); }
function write(rel,text){ fs.writeFileSync(file(rel),text,'utf8'); }
function versionParts(v){ return String(v||'0').split('.').map(x=>Number(x)||0); }
function cmp(a,b){
  const aa=versionParts(a), bb=versionParts(b), n=Math.max(aa.length,bb.length);
  for(let i=0;i<n;i++){ const av=aa[i]||0,bv=bb[i]||0; if(av>bv)return 1;if(av<bv)return -1; }
  return 0;
}
function insertAfter(rel,marker,anchor,insertion){
  let s=read(rel);
  if(s.includes(marker)) return false;
  const i=s.indexOf(anchor);
  if(i<0) throw new Error('[V0862] anchor missing in '+rel+': '+anchor.slice(0,80));
  const end=i+anchor.length;
  s=s.slice(0,end)+insertion+s.slice(end);
  write(rel,s);
  return true;
}
function replaceRequired(rel,regex,replacement,label){
  let s=read(rel);
  if(!regex.test(s)) throw new Error('[V0862] '+label+' pattern missing in '+rel);
  s=s.replace(regex,replacement);
  write(rel,s);
}

const pkg=JSON.parse(read('package.json'));
if(cmp(pkg.version,MIN_BASE)<0) throw new Error('[V0862] base too old: '+pkg.version+'; need >= '+MIN_BASE);
if(cmp(pkg.version,TARGET)>0) throw new Error('[V0862] future version detected: '+pkg.version+'; refuse unsafe downgrade');
if(pkg.version!==TARGET){ pkg.version=TARGET; write('package.json',JSON.stringify(pkg,null,2)+'\n'); }

if(fs.existsSync(file('package-lock.json'))){
  const lock=JSON.parse(read('package-lock.json'));
  lock.version=TARGET;
  if(lock.packages&&lock.packages['']) lock.packages[''].version=TARGET;
  write('package-lock.json',JSON.stringify(lock,null,2)+'\n');
}

replaceRequired('android/app/build.gradle',/versionCode\s+\d+/, 'versionCode 862','android versionCode');
replaceRequired('android/app/build.gradle',/versionName\s+'[^']+'/, "versionName '0.8.62'",'android versionName');
replaceRequired('src/core/saveSystem.js',/const GAME_VERSION = '[^']+';/, "const GAME_VERSION = '0.8.62';",'save game version');

insertAfter(
  'src/core/entryRouterV0810.js',
  "advancedManagement:{ target: 'advancedManagement'",
  "  business:      { target: 'business',      label: '经营数据' },",
  "\n  advancedManagement:{ target: 'advancedManagement',label: '经营中心' },"
);
insertAfter(
  'src/core/entryRouterV0810.js',
  "management: 'advancedManagement'",
  "  finance: 'business',",
  "\n  management: 'advancedManagement',\n  marketing: 'advancedManagement',\n  membership: 'advancedManagement',"
);

insertAfter(
  'src/core/featureAccessPolicyV0837.js',
  "'advancedManagement'",
  "    'business'",
  ",\n    'advancedManagement'"
);
let policy=read('src/core/featureAccessPolicyV0837.js');
if(!/const trialRoutes = \[[\s\S]*?'advancedManagement'/.test(policy)){
  const anchor="        'business'\n      ];";
  if(!policy.includes(anchor)) throw new Error('[V0862] trialRoutes anchor missing');
  policy=policy.replace(anchor,"        'business',\n        'advancedManagement'\n      ];");
  write('src/core/featureAccessPolicyV0837.js',policy);
}

insertAfter(
  'src/scenes/featureHubSceneV0810.js',
  "['advancedManagement', '经营中心']",
  "  ['business', '经营数据'],",
  "\n  ['advancedManagement', '经营中心'],"
);

insertAfter(
  'src/main.js',
  "const advancedManagementScene =",
  "const businessScene =\n  require('./scenes/businessScene.js');",
  "\n\nconst advancedManagementScene =\n  require('./scenes/advancedManagementSceneV0862.js');"
);
insertAfter(
  'src/main.js',
  "sceneManager.register(\n  'advancedManagement'",
  "sceneManager.register(\n  'business',\n  businessScene\n);",
  "\n\nsceneManager.register(\n  'advancedManagement',\n  advancedManagementScene\n);"
);
let main=read('src/main.js');
main=main.replace(/城市餐饮经营小游戏 V0\.8\.61/g,'城市餐饮经营小游戏 V0.8.62');
write('src/main.js',main);

let routing=read('tests/featureRoutingV0810.test.js');
if(!routing.includes("  'advancedManagement',")){
  const anchor="  'business',\n  'dynamicWorld',";
  if(!routing.includes(anchor)) throw new Error('[V0862] featureRouting test anchor missing');
  routing=routing.replace(anchor,"  'business',\n  'advancedManagement',\n  'dynamicWorld',");
  write('tests/featureRoutingV0810.test.js',routing);
}

let runner=read('scripts/run-ci-tests-v060.js');
if(!runner.includes("'tests/advancedManagementV0862.test.js'")){
  const anchor="    'tests/preparationCommandCenterV0861.test.js',";
  if(!runner.includes(anchor)) throw new Error('[V0862] CI runner anchor missing');
  runner=runner.replace(anchor,anchor+"\n    'tests/advancedManagementV0862.test.js',");
  write('scripts/run-ci-tests-v060.js',runner);
}

console.log('[V0862] player content wiring applied; version '+TARGET);
