'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.17';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.17 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function replaceSection(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  if (
    source.includes(
      replacement
    )
  ) {
    return source;
  }

  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V0.8.17 section start missing: ' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
      startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V0.8.17 section end missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    '\n\n' +
    source.slice(
      end
    )
  );
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      '0.8.16' &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.17 requires formal V0.8.16 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateRenovationSystem() {
  const rel =
    'src/renovation/renovationSystem.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const config =
  require('./renovationConfig.js');`,
`const database =
  require('./renovationEquipmentDatabaseV0817.js');

const config =
  database.renovationConfig;`,
      'renovation database import'
    );

  source =
    replaceOnce(
      source,
`      totalCost,
      buildDays`,
`      totalCost,

      constructionBreakdown:
        database
          .estimateConstructionBreakdown({
            totalArea,
            kitchenArea,
            totalCost,
            buildDays
          }),

      buildDays`,
      'construction breakdown'
    );

  const quoteReplacement =
`  getContractorQuotes(
    shopId
  ) {
    const metrics =
      this.getMetrics(
        shopId
      );

    if (!metrics) {
      return [];
    }

    const seed =
      gameState
        .getSimulation()
        .seed ||
      1;

    return (
      database
        .quoteContractors(
          metrics,
          shopId,
          seed
        )
    );
  }`;

  source =
    replaceSection(
      source,
      '  getContractorQuotes(\n    shopId\n  ) {',
      '  selectContractor(',
      quoteReplacement,
      'contractor database delegation'
    );

  write(
    rel,
    source
  );
}

function updateOpeningPrep() {
  const rel =
    'src/opening/openingPrepSystem.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const config =
  require('./openingConfig.js');`,
`const equipmentDatabase =
  require('../renovation/renovationEquipmentDatabaseV0817.js');

const config =
  equipmentDatabase.openingConfig;`,
      'opening equipment database import'
    );

  source =
    replaceOnce(
      source,
`        reliability:
          grade.reliability
      });`,
`        reliability:
          grade.reliability,

        availableModels:
          equipmentDatabase
            .getEquipmentSkus({
              groupId:
                item.id
            })
      });`,
      'equipment model catalog attachment'
    );

  source =
    replaceOnce(
      source,
`    return {
      shopId,
      lines,`,
`    return {
      databaseVersion:
        equipmentDatabase.VERSION,
      shopId,
      lines,`,
      'equipment quote database version'
    );

  if (
    !source.includes(
      '  getEquipmentCatalog('
    )
  ) {
    const anchor =
      '  adjustEquipment(\n    shopId,';

    const index =
      source.indexOf(
        anchor
      );

    if (index < 0) {
      throw new Error(
        'V0.8.17 equipment catalog insertion anchor missing'
      );
    }

    const method =
`  getEquipmentCatalog(
    groupId
  ) {
    return (
      equipmentDatabase
        .getEquipmentSkus(
          groupId
            ? {
                groupId
              }
            : {}
        )
    );
  }

`;

    source =
      source.slice(
        0,
        index
      ) +
      method +
      source.slice(
        index
      );
  }

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0817.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/shopLifecycleV0816.test.js',
    'tests/shopLifecycleIntegrationV0816.test.js',
    'tests/updateInfrastructureV0816.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/shopLifecycleV0816.test.js',
    'tests/shopLifecycleIntegrationV0816.test.js',
    'tests/updateInfrastructureV0816.test.js',
    'tests/renovationEquipmentDatabaseV0817.test.js',
    'tests/renovationEquipmentIntegrationV0817.test.js',
    'tests/updateInfrastructureV0817.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0817'
    );

  write(
    rel,
    source
  );
}

function updateMainLabel() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.14 完整开局流程版启动成功',
      '城市餐饮经营小游戏 V0.8.17 装修设备施工数据库版启动成功'
    );

  write(
    rel,
    source
  );
}

// setup-android@v3 compatibility for the ephemeral GitHub runner.
// Repository workflow files are not modified.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const binDir =
    path.join(
      latestDir,
      'bin'
    );

  const sdkmanager =
    path.join(
      binDir,
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.17] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const realSdkmanager =
    path.join(
      binDir,
      'sdkmanager.v0817-real'
    );

  if (
    !fs.existsSync(
      realSdkmanager
    )
  ) {
    fs.renameSync(
      sdkmanager,
      realSdkmanager
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0817-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.17] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.17 package version finalize failed'
    );
  }

  const requiredFiles = [
    'src/renovation/renovationEquipmentDatabaseV0817.js',
    'tests/renovationEquipmentDatabaseV0817.test.js',
    'tests/renovationEquipmentIntegrationV0817.test.js',
    'tests/updateInfrastructureV0817.test.js'
  ];

  for (
    const file
    of requiredFiles
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.17 required file missing: ' +
        file
      );
    }
  }

  const renovation =
    read(
      'src/renovation/renovationSystem.js'
    );

  for (
    const marker
    of [
      'renovationEquipmentDatabaseV0817.js',
      '.quoteContractors(',
      '.estimateConstructionBreakdown('
    ]
  ) {
    if (
      !renovation.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.17 renovation validation missing ' +
        marker
      );
    }
  }

  const opening =
    read(
      'src/opening/openingPrepSystem.js'
    );

  for (
    const marker
    of [
      'renovationEquipmentDatabaseV0817.js',
      '.getEquipmentSkus(',
      'getEquipmentCatalog(',
      'databaseVersion:'
    ]
  ) {
    if (
      !opening.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.17 opening validation missing ' +
        marker
      );
    }
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/renovationEquipmentDatabaseV0817.test.js',
      'tests/renovationEquipmentIntegrationV0817.test.js',
      'tests/updateInfrastructureV0817.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.17 runner validation missing ' +
        marker
      );
    }
  }
}

updatePackage();
updatePackageLock();
updateRenovationSystem();
updateOpeningPrep();
updateRunner();
updateMainLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.17] PASS：装修 / 设备 / 施工数据库统一完成'
);
