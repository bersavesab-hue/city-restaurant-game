'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const BASE_VERSION =
  '0.8.21';

const TARGET_VERSION =
  '0.8.25';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.22-25 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function insertBefore(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      anchor
    );

  if (index < 0) {
    throw new Error(
      'V0.8.22-25 insertion anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    addition +
    source.slice(
      index
    )
  );
}

function cleanupLegacyRootWorkflow() {
  const rel =
    'apply-update.yml';

  if (
    fs.existsSync(
      abs(rel)
    )
  ) {
    fs.unlinkSync(
      abs(rel)
    );

    console.log(
      '[V0.8.22-25] removed stray root apply-update.yml'
    );
  }
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      BASE_VERSION &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.22-25 requires formal V0.8.21 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateOperationsStore() {
  const rel =
    'src/operations/operationsStoreV080.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const runtimeEngine =
  require('./restaurantRuntimeV10.js');

const customerRandomDatabase =`,
`const runtimeEngine =
  require('./restaurantRuntimeV10.js');

const staffManagement =
  require('./staffManagementCoordinatorV0823.js');

const liveOperations =
  require('./liveOperationsCoordinatorV0824.js');

const completeFinanceSystem =
  require('../finance/completeFinanceSystemV0825.js');

const customerRandomDatabase =`,
      'operations coordinator imports'
    );

  source =
    replaceOnce(
      source,
`  runtime.customers =
    customerRandomDatabase
      .normalizeCustomerMap(
        runtime.customers
      );

  normalizeLegacyCalendar(
    runtime
  );`,
`  runtime.customers =
    customerRandomDatabase
      .normalizeCustomerMap(
        runtime.customers
      );

  staffManagement
    .syncRuntimeStaff(
      runtime,
      shopId
    );

  liveOperations
    .ensureRuntime(
      runtime
    );

  normalizeLegacyCalendar(
    runtime
  );`,
      'runtime staff/live synchronization'
    );

  const apis =
`function staffCandidateRows(
  shopId
) {
  return (
    staffManagement
      .candidatePool(
        shopId
      )
  );
}

function hireStaffCandidate(
  shopId,
  candidateId
) {
  const result =
    staffManagement
      .hireCandidate(
        shopId,
        candidateId
      );

  if (
    result &&
    result.ok
  ) {
    const runtime =
      getRuntime(
        shopId
      );

    staffManagement
      .syncRuntimeStaff(
        runtime,
        shopId
      );

    completeFinanceSystem
      .recordStaffExpense(
        shopId,
        'hiring',
        Number(
          result.signOnCost
        ) ||
        0,
        {
          day:
            currentDay(),
          referenceId:
            'hire:' +
            (
              result.staff &&
              result.staff.id ||
              candidateId
            ),
          note:'招聘入职成本'
        }
      );

    persist(
      shopId
    );
  }

  return result;
}

function dismissStaffMember(
  shopId,
  staffId
) {
  const ok =
    staffManagement
      .dismissStaff(
        shopId,
        staffId
      );

  if (ok) {
    const runtime =
      getRuntime(
        shopId
      );

    staffManagement
      .syncRuntimeStaff(
        runtime,
        shopId
      );

    persist(
      shopId
    );
  }

  return ok;
}

function staffManagementSnapshot(
  shopId
) {
  return (
    staffManagement
      .teamSnapshot(
        shopId,
        gameState
          .getTime()
      )
  );
}

function trainStaffMember(
  shopId,
  staffId
) {
  const result =
    staffManagement
      .startTraining(
        shopId,
        staffId
      );

  if (
    result &&
    result.ok
  ) {
    completeFinanceSystem
      .recordStaffExpense(
        shopId,
        'training',
        Number(
          result.cost
        ) ||
        0,
        {
          day:
            currentDay(),
          referenceId:
            [
              'training',
              staffId,
              currentDay()
            ].join(':'),
          note:'员工培训'
        }
      );
  }

  return result;
}

function raiseStaffMember(
  shopId,
  staffId
) {
  return (
    staffManagement
      .giveRaise(
        shopId,
        staffId
      )
  );
}

function promoteStaffMember(
  shopId,
  staffId
) {
  return (
    staffManagement
      .promote(
        shopId,
        staffId
      )
  );
}

function approveStaffLeave(
  shopId,
  staffId,
  days
) {
  return (
    staffManagement
      .approveLeave(
        shopId,
        staffId,
        days
      )
  );
}

function coachStaffMember(
  shopId,
  staffId
) {
  return (
    staffManagement
      .coach(
        shopId,
        staffId
      )
  );
}

function liveOperationsSnapshot(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return null;
  }

  return (
    liveOperations
      .snapshot(
        runtime,
        {
          staff:
            staffManagement
              .teamSnapshot(
                shopId,
                gameState
                  .getTime()
              )
        }
      )
  );
}

function simulateCustomerVisit(
  shopId,
  customerId,
  options
) {
  return mutate(
    shopId,
    runtime => {
      staffManagement
        .syncRuntimeStaff(
          runtime,
          shopId
        );

      const profile =
        customerId &&
        runtime.customers[
          customerId
        ]
          ? runtime
              .customers[
                customerId
              ]
          : liveOperations
              .resolveCustomer(
                runtime,
                null,
                options ||
                {}
              );

      const result =
        liveOperations
          .simulateVisit(
            runtime,
            profile,
            options ||
            {}
          );

      if (
        result &&
        result.ok
      ) {
        completeFinanceSystem
          .recordOrderSettlement(
            shopId,
            result.settlement,
            {
              day:
                runtime.day,
              orderId:
                result.order &&
                result.order.id,
              referenceId:
                'order:' +
                (
                  result.order &&
                  result.order.id ||
                  runtime
                    .history
                    .length
                ),
              applyCash:true
            }
          );
      }

      return result;
    }
  );
}

function closeOperatingDay(
  shopId,
  options
) {
  return mutate(
    shopId,
    runtime => {
      const result =
        liveOperations
          .closeDay(
            runtime,
            options ||
            {}
          );

      if (
        result &&
        result.ok &&
        result.result &&
        result.result.financial
      ) {
        completeFinanceSystem
          .syncDailyStatement(
            shopId,
            result
              .result
              .financial,
            result
              .result
              .day
          );
      }

      return result;
    }
  );
}

function financeSnapshot(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  return (
    completeFinanceSystem
      .snapshot(
        shopId,
        runtime &&
        runtime.ledger
      )
  );
}

function financeTransactions(
  shopId,
  filters
) {
  return (
    completeFinanceSystem
      .getTransactions(
        shopId,
        filters ||
        {}
      )
  );
}

function recordFinanceExpense(
  shopId,
  category,
  amount,
  options
) {
  return (
    completeFinanceSystem
      .recordExternalExpense(
        shopId,
        category,
        amount,
        {
          ...(options || {}),
          applyCash:
            options &&
            options.applyCash ===
              false
              ? false
              : true
        }
      )
  );
}

function openingCreditStatus(
  shopId
) {
  return (
    completeFinanceSystem
      .openingCreditStatus(
        shopId
      )
  );
}

`;

  source =
    insertBefore(
      source,
      'function supplierCatalog(\n  shopId,',
      apis,
      'function staffCandidateRows(',
      'staff/live/finance operation APIs'
    );

  source =
    replaceOnce(
      source,
`      po.paymentStatus =
        'paid';

      po.paidDay =
        runtime.day;

      return {
        ok:true,
        po,
        lot:
          received.lot
      };`,
`      po.paymentStatus =
        'paid';

      po.paidDay =
        runtime.day;

      completeFinanceSystem
        .recordProcurement(
          shopId,
          po,
          {
            day:
              runtime.day,
            referenceId:
              'po:' +
              po.id
          }
        );

      return {
        ok:true,
        po,
        lot:
          received.lot
      };`,
      'manual procurement finance bridge'
    );

  source =
    replaceOnce(
      source,
`        spent +=
          quote.total;

        count +=
          1;`,
`        completeFinanceSystem
          .recordProcurement(
            shopId,
            created.po,
            {
              day:
                runtime.day,
              referenceId:
                'po:' +
                created.po.id
            }
          );

        spent +=
          quote.total;

        count +=
          1;`,
      'auto procurement finance bridge'
    );

  source =
    replaceOnce(
      source,
`  inventoryLotRows,
  inventoryHealth,
  generateCustomer,`,
`  inventoryLotRows,
  inventoryHealth,
  staffCandidateRows,
  hireStaffCandidate,
  dismissStaffMember,
  staffManagementSnapshot,
  trainStaffMember,
  raiseStaffMember,
  promoteStaffMember,
  approveStaffLeave,
  coachStaffMember,
  liveOperationsSnapshot,
  simulateCustomerVisit,
  closeOperatingDay,
  financeSnapshot,
  financeTransactions,
  recordFinanceExpense,
  openingCreditStatus,
  generateCustomer,`,
      'operations exports V0822-25'
    );

  write(
    rel,
    source
  );
}

function updateOperationsIndex() {
  write(
    'src/operations/index.js',
`'use strict';

module.exports = {
  settlement:
    require('./settlementEngineV10.js'),
  retention:
    require('./retentionEngineV10.js'),
  staff:
    require('./staffOperationsEngineV10.js'),
  staffManagement:
    require('./staffManagementCoordinatorV0823.js'),
  live:
    require('./liveOperationsCoordinatorV0824.js'),
  delivery:
    require('./deliveryEngineV10.js'),
  marketing:
    require('./marketingEngineV10.js'),
  brand:
    require('./brandGrowthEngineV10.js'),
  events:
    require('./restaurantEventEngineV10.js'),
  runtime:
    require('./restaurantRuntimeV10.js'),
  finance:
    require('../finance/completeFinanceSystemV0825.js')
};
`
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0825.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/customerRandomDatabaseV0821.test.js',
    'tests/customerEngineIntegrationV0821.test.js',
    'tests/customerOperationsIntegrationV0821.test.js',
    'tests/updateInfrastructureV0821.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/customerRandomDatabaseV0821.test.js',
    'tests/customerEngineIntegrationV0821.test.js',
    'tests/customerOperationsIntegrationV0821.test.js',
    'tests/updateInfrastructureV0821.test.js',
    'tests/personEmployeeDatabaseV0822.test.js',
    'tests/staffManagementCoordinatorV0823.test.js',
    'tests/liveOperationsCoordinatorV0824.test.js',
    'tests/completeFinanceSystemV0825.test.js',
    'tests/megaOperationsFinanceV0825.test.js',
    'tests/updateInfrastructureV0825.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0822-25'
    );

  write(
    rel,
    source
  );
}

function updateMainLabel() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.21 顾客随机数据库版启动成功',
      '城市餐饮经营小游戏 V0.8.25 员工经营财务四合一版启动成功'
    );

  write(
    rel,
    source
  );
}

// Temporary workaround for obsolete "sdkmanager tools" in the existing workflow.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const sdkmanager =
    path.join(
      latestDir,
      'bin',
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.22-25] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const binDir =
    path.dirname(
      sdkmanager
    );

  const real =
    path.join(
      binDir,
      'sdkmanager.v0825-real'
    );

  if (
    !fs.existsSync(
      real
    )
  ) {
    fs.renameSync(
      sdkmanager,
      real
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0825-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.22-25] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.22-25 package version finalize failed'
    );
  }

  if (
    fs.existsSync(
      abs(
        'apply-update.yml'
      )
    )
  ) {
    throw new Error(
      'V0.8.22-25 stray root workflow cleanup failed'
    );
  }

  const required = [
    'src/person/personEmployeeDatabaseV0822.js',
    'src/operations/staffManagementCoordinatorV0823.js',
    'src/operations/liveOperationsCoordinatorV0824.js',
    'src/finance/completeFinanceSystemV0825.js',
    'tests/personEmployeeDatabaseV0822.test.js',
    'tests/staffManagementCoordinatorV0823.test.js',
    'tests/liveOperationsCoordinatorV0824.test.js',
    'tests/completeFinanceSystemV0825.test.js',
    'tests/megaOperationsFinanceV0825.test.js',
    'tests/updateInfrastructureV0825.test.js'
  ];

  for (
    const file
    of required
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.22-25 required file missing: ' +
        file
      );
    }
  }

  const operations =
    read(
      'src/operations/operationsStoreV080.js'
    );

  for (
    const marker
    of [
      'staffManagementCoordinatorV0823.js',
      'liveOperationsCoordinatorV0824.js',
      'completeFinanceSystemV0825.js',
      'function staffCandidateRows(',
      'function liveOperationsSnapshot(',
      'function simulateCustomerVisit(',
      'function financeSnapshot('
    ]
  ) {
    if (
      !operations.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.22-25 operations integration missing ' +
        marker
      );
    }
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/personEmployeeDatabaseV0822.test.js',
      'tests/staffManagementCoordinatorV0823.test.js',
      'tests/liveOperationsCoordinatorV0824.test.js',
      'tests/completeFinanceSystemV0825.test.js',
      'tests/megaOperationsFinanceV0825.test.js',
      'tests/updateInfrastructureV0825.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.22-25 runner integration missing ' +
        marker
      );
    }
  }
}

cleanupLegacyRootWorkflow();
updatePackage();
updatePackageLock();
updateOperationsStore();
updateOperationsIndex();
updateRunner();
updateMainLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.25] PASS：13-16/26 员工/NPC、员工管理、实时经营、完整财务四合一升级完成'
);
