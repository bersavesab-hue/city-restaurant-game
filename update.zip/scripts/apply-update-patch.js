'use strict';

/** City Restaurant V1.0.8 adaptive + idempotent installer. */
const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const root = process.cwd();
const VERSION = '1.0.8';
const MARKER = 'CITY_RESTAURANT_OPERATING_V108';

function full(rel){ return path.join(root, rel); }
function norm(p){ return p.split(path.sep).join('/'); }
function exists(rel){ return fs.existsSync(full(rel)); }
function read(rel){ return fs.readFileSync(full(rel), 'utf8'); }
function write(rel,text){ fs.mkdirSync(path.dirname(full(rel)),{recursive:true}); fs.writeFileSync(full(rel),text,'utf8'); }
function fail(msg){ throw new Error('[V1.0.8 installer] ' + msg); }
function assert(ok,msg){ if(!ok) fail(msg); }
function relRequire(fromFile,toFile){ let r=norm(path.relative(path.dirname(full(fromFile)),full(toFile))); if(!r.startsWith('.')) r='./'+r; return r; }
function ignored(rel){ rel=norm(rel); return /(^|\/)(node_modules|\.git|build|dist|coverage)(\/|$)/.test(rel) || /^android\/app\/build\//.test(rel); }
function walk(){
  const out=[], stack=[root];
  while(stack.length){
    const dir=stack.pop();
    for(const ent of fs.readdirSync(dir,{withFileTypes:true})){
      const abs=path.join(dir,ent.name), rel=norm(path.relative(root,abs));
      if(ignored(rel)) continue;
      if(ent.isDirectory()) stack.push(abs); else out.push(rel);
    }
  }
  return out;
}
let allFiles = walk();
function findModule(baseName,tokens,prefs){
  let cands=allFiles.filter(rel=>path.basename(rel)===baseName && /\.[cm]?js$/.test(rel));
  if(!cands.length)cands=allFiles.filter(rel=>/\.[cm]?js$/.test(rel)&&!rel.startsWith('src/operating/')&&!rel.startsWith('scripts/')&&!rel.startsWith('tests/'));
  const scored=[];
  for(const rel of cands){
    let text=''; try{text=read(rel)}catch(_){continue}
    if(tokens.some(t=>!text.includes(t)))continue;
    let score=path.basename(rel)===baseName?100:0;
    for(const p of prefs)if(norm(rel).includes(p))score+=20;
    if(/module\.exports|export\s+/.test(text))score+=5;
    scored.push({rel,score});
  }
  scored.sort((a,b)=>b.score-a.score||a.rel.localeCompare(b.rel));
  return scored[0]&&scored[0].rel;
}
function stripOperatingSegments(script){
  return String(script||'').split('&&').map(x=>x.trim()).filter(Boolean).filter(x=>
    !/operatingSystemsV10[5-8]\.test\.js|runtimeCoreV10[5-8]\.smoke\.js|audit-operating-v10[5-8]\.js/.test(x)
  ).join(' && ');
}
function detectEntry(buildScript){
  const clean=stripOperatingSegments(buildScript);
  const res=[/\besbuild\s+(?:--[^\s]+\s+)*(["']?[^\s"']+\.(?:js|cjs|mjs)["']?)/,/--entry-points?=(["']?[^\s"']+\.(?:js|cjs|mjs)["']?)/];
  for(const re of res){ const m=clean.match(re); if(m){const rel=m[1].replace(/^['"]|['"]$/g,''); if(exists(rel))return norm(rel);} }
  for(const rel of ['android/entry.js','android/src/entry.js','src/android/entry.js'])if(exists(rel))return rel;
  for(const rel of allFiles.filter(x=>/(^|\/)entry\.(js|cjs|mjs)$/.test(x))){ const t=read(rel); if(/GameRuntime/.test(t)&&/require\s*\(/.test(t))return rel; }
  return null;
}

assert(exists('package.json'),'缺少 package.json');
const pkg=JSON.parse(read('package.json'));
assert(pkg.scripts&&typeof pkg.scripts.test==='string','package.json scripts.test 不存在');
assert(typeof pkg.scripts['build:android-js']==='string','package.json scripts.build:android-js 不存在');
const cleanBuild=stripOperatingSegments(pkg.scripts['build:android-js']);
const entry=detectEntry(cleanBuild);
const gameState=findModule('gameState.js',['getPlayer','getWorld','getTime'],['/src/core/','/core/']);
const timeSystem=findModule('timeSystem.js',['update','getSpeed','isPaused'],['/src/core/','/core/']);
const demandSystem=findModule('demandSystem.js',['getTotalDemand'],['/src/city/','/city/']);
assert(entry,'无法从真实构建命令/仓库发现 Android 入口');
assert(gameState,'无法发现 gameState 模块');
assert(timeSystem,'无法发现 timeSystem 模块');
assert(demandSystem,'无法发现 demandSystem 模块');

for(const rel of ['src/operating/eventCatalogV108.js','src/operating/businessOperatingSystemV108.js','src/operating/operatingRuntimeCoreV108.js','tests/operatingSystemsV108.test.js','tests/runtimeCoreV108.smoke.js','scripts/audit-operating-v108.js']) assert(exists(rel),'更新包缺少文件：'+rel);

let entryText=read(entry);
// 移除 V105~V108 的旧标记、require 与遗留空行，保证重复安装字节级稳定。
entryText=entryText
  .replace(/^\s*\/\*\s*CITY_RESTAURANT_OPERATING_V10[5-8]\s*\*\/\s*\r?\n?/gm,'')
  .replace(/^.*operatingRuntimeBridgeV10[5-8]\.js.*\r?\n?/gm,'')
  .replace(/^.*operatingBootstrapV10[5-8](?:\.generated)?\.js.*\r?\n?/gm,'')
  .replace(/[ \t]+$/gm,'')
  .replace(/\n{3,}/g,'\n\n')
  .replace(/\s*$/,'');

const bootstrap='src/operating/operatingBootstrapV108.generated.js';
const bootstrapText=`'use strict';\n\n`+
  `const { createOperatingRuntimeV108 } = require('./operatingRuntimeCoreV108.js');\n`+
  `const gameState = require(${JSON.stringify(relRequire(bootstrap,gameState))});\n`+
  `const timeSystem = require(${JSON.stringify(relRequire(bootstrap,timeSystem))});\n`+
  `const demandSystem = require(${JSON.stringify(relRequire(bootstrap,demandSystem))});\n\n`+
  `if (!globalThis.RestaurantOperatingV108) {\n  createOperatingRuntimeV108({ gameState, timeSystem, demandSystem, runtime: globalThis.GameRuntime });\n}\n`;
write(bootstrap,bootstrapText);
const requireLine=`require(${JSON.stringify(relRequire(entry,bootstrap))});`;
entryText += `\n\n/* ${MARKER} */\n${requireLine}\n`;
assert((entryText.match(/operatingBootstrapV108\.generated\.js/g)||[]).length===1,'V1.0.8 入口接线重复');
write(entry,entryText);

const report={version:VERSION,discovered:{entry,gameState,timeSystem,demandSystem,bootstrap},baseBuildScript:cleanBuild};
write('scripts/operating-v108-paths.json',JSON.stringify(report,null,2)+'\n');

// 清理仅属于我们旧补丁的已知文件。
const old=[];
for(const v of ['105','106','107']) old.push(
 `src/operating/eventCatalogV${v}.js`,`src/operating/businessOperatingSystemV${v}.js`,`src/operating/operatingRuntimeBridgeV${v}.js`,`src/operating/operatingRuntimeCoreV${v}.js`,`src/operating/operatingBootstrapV${v}.generated.js`,
 `tests/operatingSystemsV${v}.test.js`,`tests/runtimeCoreV${v}.smoke.js`,`scripts/audit-operating-v${v}.js`,`scripts/operating-v${v}-paths.json`
);
for(const rel of old){try{if(exists(rel))fs.unlinkSync(full(rel));}catch(_){}}

pkg.scripts.test=stripOperatingSegments(pkg.scripts.test);
pkg.scripts.test += (pkg.scripts.test?' && ':'')+'node tests/operatingSystemsV108.test.js && node tests/runtimeCoreV108.smoke.js && node scripts/audit-operating-v108.js';
pkg.scripts['build:android-js']='node scripts/audit-operating-v108.js && '+cleanBuild;
fs.writeFileSync(full('package.json'),JSON.stringify(pkg,null,2)+'\n','utf8');

const syntax=[entry,bootstrap,'src/operating/eventCatalogV108.js','src/operating/businessOperatingSystemV108.js','src/operating/operatingRuntimeCoreV108.js','tests/operatingSystemsV108.test.js','tests/runtimeCoreV108.smoke.js','scripts/audit-operating-v108.js'];
for(const rel of syntax){const r=cp.spawnSync(process.execPath,['--check',full(rel)],{encoding:'utf8'});if(r.status!==0){process.stderr.write(r.stderr||r.stdout||'');fail('语法检查失败：'+rel)}}
for(const rel of ['tests/operatingSystemsV108.test.js','tests/runtimeCoreV108.smoke.js','scripts/audit-operating-v108.js']){const r=cp.spawnSync(process.execPath,[full(rel)],{cwd:root,encoding:'utf8'});process.stdout.write(r.stdout||'');process.stderr.write(r.stderr||'');assert(r.status===0,'执行失败：'+rel)}
console.log('[V1.0.8 installer] PASS');
console.log('[V1.0.8 paths] '+JSON.stringify(report.discovered));
