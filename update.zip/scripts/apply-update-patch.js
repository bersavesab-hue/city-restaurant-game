'use strict';
const fs=require('fs');
const path=require('path');
const ROOT=path.resolve(__dirname,'..');
const BASE_VERSION='0.8.51';
const TARGET_VERSION='0.8.60';
function fp(rel){return path.join(ROOT,rel);}
function read(rel){return fs.readFileSync(fp(rel),'utf8');}
function write(rel,content){const full=fp(rel);fs.mkdirSync(path.dirname(full),{recursive:true});fs.writeFileSync(full,content,'utf8');}
function replaceExact(rel,before,after,label){const source=read(rel);const count=source.split(before).length-1;if(count!==1)throw new Error(`[V0860] ${label||rel}: expected exactly 1 match, found ${count}`);write(rel,source.replace(before,after));}
function replaceCount(rel,before,after,expected,label){const source=read(rel);const count=source.split(before).length-1;if(count!==expected)throw new Error(`[V0860] ${label||rel}: expected ${expected} matches, found ${count}`);write(rel,source.split(before).join(after));}
function replaceBetween(rel,startMarker,endMarker,replacement,label){const source=read(rel);const start=source.indexOf(startMarker);const end=source.indexOf(endMarker,start+startMarker.length);if(start<0||end<0)throw new Error(`[V0860] ${label||rel}: marker not found`);if(source.indexOf(startMarker,start+1)>=0)throw new Error(`[V0860] ${label||rel}: start marker is not unique`);write(rel,source.slice(0,start)+replacement+source.slice(end));}
function updateJson(rel,updater){const data=JSON.parse(read(rel));updater(data);write(rel,JSON.stringify(data,null,2)+'\n');}
const pkgBefore=JSON.parse(read('package.json'));
if(pkgBefore.version!==BASE_VERSION)throw new Error(`[V0860] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`);

/* A. 修复运行日与世界日期漂移 */
replaceBetween('src/operations/operationsStoreV080.js',
'function normalizeLegacyCalendar(\n  runtime\n) {','\nfunction getRoot()',`function normalizeLegacyCalendar(
  runtime
) {
  const expected = currentDay();
  const oldDay = Number(runtime.day) || expected;
  if (oldDay === expected) return;
  // 正常落后1~90天交给自动跨日逐日结算；领先则属于旧版手动日结漂移。
  if (oldDay < expected && expected - oldDay <= 90) return;
  const delta = expected - oldDay;
  runtime.day = expected;
  if (runtime.inventory) {
    runtime.inventory.day = (Number(runtime.inventory.day) || oldDay) + delta;
    for (const lot of runtime.inventory.lots || []) {
      lot.receivedDay = (Number(lot.receivedDay) || oldDay) + delta;
      lot.expiryDay = (Number(lot.expiryDay) || oldDay) + delta;
    }
  }
  if (runtime.procurement && Array.isArray(runtime.procurement.purchaseOrders)) {
    for (const po of runtime.procurement.purchaseOrders) {
      for (const key of ['orderedDay','expectedDay','paymentDueDay','receivedDay']) {
        if (po[key] != null) po[key] = Number(po[key]) + delta;
      }
    }
  }
}
`,'normalize future-day drift');

/* B. 每日目标公平化 + 稳定度 */
replaceExact('src/operations/dailyOperatingCycleV0840.js',`        goalsCompleted:0,
        goalsMissed:0,
        goalStreak:0,
        bestGoalStreak:0`,`        goalsCompleted:0,
        goalsNear:0,
        goalsMissed:0,
        goalStreak:0,
        bestGoalStreak:0,
        stabilityLevel:0,
        bestStabilityLevel:0`,'daily metric defaults');

replaceExact('src/operations/dailyOperatingCycleV0840.js',`  state.metrics =
    state.metrics &&
    typeof state.metrics ===
      'object'
      ? state.metrics
      : {};

  return state;`,`  state.metrics =
    state.metrics &&
    typeof state.metrics ===
      'object'
      ? state.metrics
      : {};

  const metricDefaults = {
    daysOpened:0,
    visits:0,
    failedVisits:0,
    totalRevenue:0,
    totalProfit:0,
    goalsCompleted:0,
    goalsNear:0,
    goalsMissed:0,
    goalStreak:0,
    bestGoalStreak:0,
    stabilityLevel:0,
    bestStabilityLevel:0
  };

  for (const [key,value] of Object.entries(metricDefaults)) {
    if (state.metrics[key] == null) state.metrics[key] = value;
  }

  return state;`,'legacy goal metric migration');

replaceBetween('src/operations/dailyOperatingCycleV0840.js',
'function buildDailyGoal(\n  state\n) {','\nfunction evaluateDailyGoal(',`function buildDailyGoal(
  state
) {
  const previous = state.history.find(
    item => item && item.status === 'closed' && item.financial && typeof item.financial === 'object'
  ) || null;

  if (!previous) {
    return {id:'first_order',kind:'orders_at_least',label:'完成今天第一笔有效订单',target:1,routeId:'shop',sourceDay:null,status:'active'};
  }

  const financial = previous.financial || {};
  const end = previous.endSnapshot || {};

  if (Number(end.tensionScore) >= 90) {
    return {id:'cash_relief',kind:'tension_at_most',label:'把现金压力降到90以下',target:89,routeId:'business',sourceDay:previous.day,status:'active'};
  }

  const alerts = Math.max(0,Number(end.inventoryAlerts)||0);
  if (alerts > 0) {
    const target=Math.max(0,alerts-1);
    return {id:'reduce_inventory_alerts',kind:'inventory_alerts_at_most',label:target===0?'解决现有库存预警':'把库存预警降到'+target+'项以内',target,routeId:'supply',sourceDay:previous.day,status:'active'};
  }

  const foodCostRate=Number(financial.foodCostRate)||0;
  if (Number(financial.orders)>0 && foodCostRate>42) {
    const target=Math.max(38,Math.min(42,round(foodCostRate-1)));
    return {id:'food_cost_control',kind:'food_cost_at_most',label:'把食材成本率控制到'+target+'%以内',target,routeId:'research',sourceDay:previous.day,status:'active'};
  }

  if (Number(financial.profit)<=0) {
    return {id:'profit_turnaround',kind:'profit_at_least',label:'争取今天实现正利润',target:1,routeId:'business',sourceDay:previous.day,status:'active'};
  }

  // 删除“昨天越赚、今天任务越难”的利润+5%反向惩罚。
  return {id:'sustain_profit',kind:'profit_at_least',label:'保持今天继续盈利',target:1,routeId:'shop',sourceDay:previous.day,status:'active'};
}
`,'fair daily goals');

replaceBetween('src/operations/dailyOperatingCycleV0840.js',
'function evaluateDailyGoal(\n  goal,\n  financial,\n  endSnapshot\n) {','\nfunction buildReasons(',`function evaluateDailyGoal(
  goal,
  financial,
  endSnapshot
) {
  if (!goal || typeof goal !== 'object') return null;
  let actual=0;
  let completed=false;
  let near=false;

  if (goal.kind==='orders_at_least') {
    actual=Math.max(0,Number(financial.orders)||0);
    completed=actual>=Number(goal.target);
  } else if (goal.kind==='profit_at_least') {
    actual=round(financial.profit);
    completed=actual>=Number(goal.target);
    if (!completed) {
      const tolerance=Math.max(100,(Number(financial.revenue)||0)*0.05);
      near=actual>=-tolerance;
    }
  } else if (goal.kind==='food_cost_at_most') {
    actual=round(financial.foodCostRate);
    completed=Number(financial.orders)>0 && actual<=Number(goal.target);
    near=!completed && Number(financial.orders)>0 && actual<=Number(goal.target)+2;
  } else if (goal.kind==='inventory_alerts_at_most') {
    actual=Math.max(0,Number(endSnapshot.inventoryAlerts)||0);
    completed=actual<=Number(goal.target);
    near=!completed && actual<=Number(goal.target)+1;
  } else if (goal.kind==='tension_at_most') {
    actual=round(endSnapshot.tensionScore);
    completed=actual<=Number(goal.target);
    near=!completed && actual<=95;
  }

  const status=completed?'completed':near?'near':'missed';
  return {...clone(goal),status,completed,near,actual,message:completed?'今日目标完成':near?'今日目标接近完成':'今日目标未完成'};
}
`,'daily goal tolerance');
replaceBetween('src/operations/dailyOperatingCycleV0840.js',
'  if (goalResult) {\n    if (\n      goalResult.completed\n    ) {','  state.metrics.totalRevenue =',`  if (goalResult) {
    if (goalResult.completed) {
      state.metrics.goalsCompleted=(Number(state.metrics.goalsCompleted)||0)+1;
      state.metrics.goalStreak=(Number(state.metrics.goalStreak)||0)+1;
      state.metrics.bestGoalStreak=Math.max(Number(state.metrics.bestGoalStreak)||0,state.metrics.goalStreak);
      state.metrics.stabilityLevel=Math.min(30,(Number(state.metrics.stabilityLevel)||0)+1);
    } else if (goalResult.near) {
      state.metrics.goalsNear=(Number(state.metrics.goalsNear)||0)+1;
      // 连续完成保持严格语义，但长期稳定度不因“差一点”而归零。
      state.metrics.goalStreak=0;
    } else {
      state.metrics.goalsMissed=(Number(state.metrics.goalsMissed)||0)+1;
      state.metrics.goalStreak=0;
      state.metrics.stabilityLevel=Math.max(0,(Number(state.metrics.stabilityLevel)||0)-1);
    }
    state.metrics.bestStabilityLevel=Math.max(Number(state.metrics.bestStabilityLevel)||0,Number(state.metrics.stabilityLevel)||0);
  }

`,'stable goal progression');

/* C. 唯一日结结算管线 */
replaceBetween('src/operations/operationsStoreV080.js',
'function closeOperatingDay(\n  shopId,\n  options\n) {','\nfunction financeSnapshot(',`function normalizeClosedResult(closeResult) {
  if (closeResult && closeResult.result && closeResult.result.financial) {
    return {ok:closeResult.ok!==false,envelope:closeResult,closed:closeResult.result};
  }
  if (closeResult && closeResult.financial) {
    return {ok:true,envelope:{ok:true,result:closeResult},closed:closeResult};
  }
  return {ok:false,envelope:closeResult||{ok:false,reason:'缺少日结结果'},closed:null};
}

function profitStreakFromStatements(rows) {
  const ordered=(Array.isArray(rows)?rows:[]).slice().sort((a,b)=>Number(b.day)-Number(a.day));
  let streak=0;
  for (const row of ordered) {
    if (Number(row.profit)>0) streak+=1;
    else break;
  }
  return streak;
}

function finalizeClosedOperatingDay(shopId,runtime,closeResult,options) {
  const normalized=normalizeClosedResult(closeResult);
  if (!normalized.ok || !normalized.closed) return normalized.envelope;
  const envelope=normalized.envelope;
  const closed=normalized.closed;
  const closedDay=Number(closed.day)||Math.max(1,Number(runtime&&runtime.day)-1);

  runtime.simulation=runtime.simulation||{};

  const existingCycle=dailyOperatingCycle.history(shopId,120).find(
    item=>item&&item.status==='closed'&&Number(item.day)===closedDay&&item.financial
  );

  // 旧版可能已人工结算过同一天；自动跨日再次遇到时禁止二次跑口碑/监管/成长。
  if (existingCycle) {
    runtime.simulation.lastUnifiedClosedDay=Math.max(Number(runtime.simulation.lastUnifiedClosedDay)||0,closedDay);
    return {...envelope,ok:true,existing:true,dailyBrief:existingCycle};
  }

  dailyOperatingCycle.beginDay(shopId,closedDay,decisionContextSnapshot(shopId,runtime,closed.financial));
  completeFinanceSystem.syncDailyStatement(shopId,closed.financial,closedDay);
  reputationMediaSystem.processDay(shopId,closedDay);
  commercialEcologySystem.processDay(closedDay,{shopId});
  processEnvironmentDay(closedDay,shopId,{});

  const shop=getShop(shopId);
  regulatoryFoodSafetySystem.processDay(shopId,closedDay,{districtId:shop&&shop.districtId});

  const financeView=completeFinanceSystem.snapshot(shopId,runtime&&runtime.ledger);
  const dailyStatements=financeView&&Array.isArray(financeView.dailyStatements)?financeView.dailyStatements:[];
  const marketingView=marketingPlatformMembership.overview(shopId,runtime);
  const regulatoryView=regulatoryFoodSafetySystem.overview(shopId);
  const staffView=staffManagement.teamSnapshot(shopId,gameState.getTime());

  const profitDays=dailyStatements.filter(item=>Number(item.profit)>0).length;
  const profitStreak=profitStreakFromStatements(dailyStatements);
  const bestDailyRevenue=dailyStatements.reduce((best,item)=>Math.max(best,Number(item.revenue)||0),0);
  const totalCustomers=dailyStatements.reduce((total,item)=>total+(Number(item.customers)||0),0);
  const latestViolation=regulatoryView&&Array.isArray(regulatoryView.latestInspections)
    ? regulatoryView.latestInspections.find(item=>item.result!=='pass')
    : null;
  const noViolationStreak=latestViolation?Math.max(0,closedDay-Number(latestViolation.day)):closedDay;

  const growthResult=growthAchievementSystem.evaluate(shopId,runtime,{
    daysPlayed:closedDay,
    profitDays,
    profitStreak,
    bestDailyRevenue,
    dailyRevenue:closed.financial.revenue,
    totalCustomers,
    reviewCount:Number(runtime&&runtime.shop&&runtime.shop.reviewCount)||0,
    rating:Number(runtime&&runtime.shop&&runtime.shop.rating)||4,
    memberCount:marketingView&&marketingView.memberCount||0,
    staffCount:staffView&&staffView.headcount||0,
    campaignCount:marketingView&&marketingView.metrics&&marketingView.metrics.campaignsStarted||0,
    supplierCount:runtime&&Array.isArray(runtime.supplierNetwork)?runtime.supplierNetwork.length:0,
    inspectionsPassed:regulatoryView&&regulatoryView.metrics?regulatoryView.metrics.passed||0:0,
    noViolationStreak
  });

  multiStoreBrandRanking.registerShop(shopId,runtime,{day:closedDay});
  growthAchievementSystem.rollHidden(shopId,{
    daysPlayed:closedDay,
    reviewCount:Number(runtime&&runtime.shop&&runtime.shop.reviewCount)||0,
    storeQuality:Math.round((Number(runtime&&runtime.shop&&runtime.shop.rating)||4)*20),
    quality:Math.round((Number(runtime&&runtime.shop&&runtime.shop.rating)||4)*20),
    storeCount:gameState.getBusiness().shops.length,
    minProfitDays:profitDays,
    profitDays,
    cashflowScore:growthResult.achievementPoints
  });

  const endSnapshot=decisionContextSnapshot(shopId,runtime,closed.financial);
  const balanceV2=operatingBalanceTuner.assessDay(closed.financial,{tensionScore:endSnapshot.tensionScore});
  const decisions=decisionFeedback.resolveDay(shopId,closedDay,endSnapshot);
  const daily=dailyOperatingCycle.finalizeDay(shopId,closedDay,closed,endSnapshot,{
    balance:balanceV2,
    decisionFeedback:decisions,
    source:options&&options.source||'unified',
    regulatory:{openViolations:regulatoryView&&Array.isArray(regulatoryView.openViolations)?regulatoryView.openViolations.length:0}
  });
  const health=playtestHealth.record(shopId,playtestContextSnapshot(shopId,runtime));

  runtime.simulation.lastUnifiedClosedDay=closedDay;
  return {...envelope,ok:true,dailyBrief:daily&&daily.brief||null,decisionFeedback:decisions,balanceDiagnosis:balanceV2,playtestHealth:health,growthResult};
}

function finalizeExternalOperatingDay(shopId,runtime,closeResult,options) {
  return finalizeClosedOperatingDay(shopId,runtime,closeResult,options||{source:'automatic'});
}

function closeOperatingDay(shopId,options) {
  return mutate(shopId,runtime=>{
    dailyOperatingCycle.beginDay(shopId,runtime.day,decisionContextSnapshot(shopId,runtime));
    const raw=liveOperations.closeDay(runtime,options||{});
    if (!raw || raw.ok===false) return raw;
    return finalizeClosedOperatingDay(shopId,runtime,raw,{source:'legacy_manual'});
  });
}
`,'unified settlement pipeline');

replaceExact('src/operations/operationsStoreV080.js',`  closeOperatingDay,
  financeSnapshot,`,`  closeOperatingDay,
  finalizeExternalOperatingDay,
  financeSnapshot,`,'export unified finalizer');

/* D. 自动跨日接入唯一结算 */
replaceBetween('src/operations/restaurantSimulationV081.js',
'function closeElapsedDays(\n  shop,\n  runtime,\n  currentDay\n) {','\nfunction simulateShop(',`function closeElapsedDays(
  shop,
  runtime,
  currentDay
) {
  let changed=false;
  while (Number(runtime.day)<currentDay) {
    const closed=runtimeEngine.closeDay(runtime);
    closed.floor=floorSimulation.closeDay(runtime);
    runtime.dailySnapshots.push(closed);
    dynamicWorldSystem.onShopDayClosed(shop,runtime,closed);

    const unified=operations.finalizeExternalOperatingDay(shop.id,runtime,closed,{source:'automatic'});
    runtime.simulation=runtime.simulation||{};
    runtime.simulation.lastAutoCloseResult=unified&&unified.ok
      ? {day:closed.day,ok:true}
      : {day:closed.day,ok:false,reason:unified&&unified.reason||'自动日结后处理失败'};

    if (runtime.dailySnapshots.length>45) runtime.dailySnapshots.splice(0,runtime.dailySnapshots.length-45);
    runtime.simulation.todayOrders=0;
    runtime.simulation.todayCustomers=0;
    changed=true;
  }
  return changed;
}
`,'automatic unified close');

replaceExact('src/operations/restaurantSimulationV081.js',`  let changed =
    closeElapsedDays(
      shop,
      runtime,
      currentDay
    );

  serviceOperatingPayables(`,`  let changed =
    closeElapsedDays(
      shop,
      runtime,
      currentDay
    );

  // 营业日由真实时间自动创建；正式页面不再需要“假开始营业”按钮。
  const operatingDay =
    operations
      .startOperatingDay(
        shop.id
      );

  if (
    operatingDay &&
    operatingDay.ok &&
    !operatingDay.existing
  ) {
    changed = true;
  }

  serviceOperatingPayables(`,'automatic operating day start');
/* E. 经营页：当前营业与最近日结严格分离 */
replaceExact('src/scenes/businessScene.js',`    const source =
      operational
        ? liveFinance
        : latest &&
          latest.financial ||
          {};`,`    const showingCurrent =
      !!active;

    const source =
      showingCurrent
        ? liveFinance
        : latest &&
          latest.financial ||
          {};`,'current vs closed data source');

replaceExact('src/scenes/businessScene.js',`    const balance =
      operations
        .operatingBalanceSnapshot(
          shop.id
        );`,`    const liveBalance =
      operations
        .operatingBalanceSnapshot(
          shop.id
        );

    const balance =
      showingCurrent
        ? liveBalance
        : latest &&
          latest.extra &&
          latest.extra.balance
          ? latest.extra.balance
          : liveBalance;`,'current vs closed balance');

replaceExact('src/scenes/businessScene.js',`      '营业日控制'`,`      '营业日状态'`,'operating day card title');

replaceExact('src/scenes/businessScene.js',`    const goalStreak =
      cycle &&
      cycle.metrics
        ? Number(
            cycle.metrics
              .goalStreak
          ) ||
          0
        : 0;

    const goalLine =
      active &&
      active.goal
        ? '今日目标：' +
          active.goal.label +
          (
            goalStreak >
              0
              ? ' · 连续' +
                goalStreak +
                '天'
              : ''
          )
        : latest &&
          latest.goalResult
          ? (
              latest
                .goalResult
                .completed
                ? '上次目标完成：'
                : '上次目标未完成：'
            ) +
            latest
              .goalResult
              .label
          : shop.status ===
              'trial_opening'
            ? '试营业中 · 顾客订单、营业额和成本会实时计入今日经营'
            : shop.status ===
                'open'
              ? '营业数据、决策和诊断会在日结时统一结算'
              : '完成开店筹备后即可进入试营业';`,`    const stabilityLevel =
      cycle &&
      cycle.metrics
        ? Number(
            cycle.metrics
              .stabilityLevel
          ) ||
          0
        : 0;

    const goalLine =
      active &&
      active.goal
        ? '今日目标：' +
          active.goal.label +
          ' · 稳定度' +
          stabilityLevel +
          '/30'
        : latest &&
          latest.goalResult
          ? (
              latest
                .goalResult
                .completed
                ? '上次目标完成：'
                : latest
                    .goalResult
                    .near
                  ? '上次目标接近完成：'
                  : '上次目标未完成：'
            ) +
            latest
              .goalResult
              .label
          : shop.status ===
              'trial_opening'
            ? '试营业中 · 营业日随游戏时间自动运行'
            : shop.status ===
                'open'
              ? '营业日随游戏时间自动运行并跨日结算'
              : '完成开店筹备后即可进入试营业';`,'goal stability UI');

replaceExact('src/scenes/businessScene.js',`      active &&
      active.goal
        ? '#C08824'
        : latest &&
          latest.goalResult
          ? latest
              .goalResult
              .completed
              ? '#248B63'
              : '#C85242'
          : '#71858F',`,`      active &&
      active.goal
        ? '#C08824'
        : latest &&
          latest.goalResult
          ? latest
              .goalResult
              .completed
              ? '#248B63'
              : latest
                  .goalResult
                  .near
                ? '#C08824'
                : '#C85242'
          : '#71858F',`,'near goal UI tone');

replaceBetween('src/scenes/businessScene.js',
'    if (\n      operational\n    ) {\n      opUi.button(','\n    this.metric(',`    ui.text(
      ctx,
      operational
        ? (
            active
              ? '自动营业 · 跨日后统一结算'
              : '等待下一营业日数据'
          )
        : '当前门店未处于营业状态',
      306,
      184,
      5.9,
      '#71858F',
      '700',
      'center'
    );

`,'remove fake manual day controls');

replaceCount('src/scenes/businessScene.js',`      operational
        ? '今日`,`      showingCurrent
        ? '今日`,4,'metric time labels');

/* F. 试营业必须真实完成3个不同营业日 */
replaceBetween('src/core/businessLifecycleV086.js',
'function buildTrialReport(\n  shop\n) {','\nfunction lifecycleEvidence(',`function getTrialRows(
  shop
) {
  const stored=gameState.getRestaurantOperations().shops[shop.id];
  const snapshots=stored&&Array.isArray(stored.dailySnapshots)?stored.dailySnapshots:[];
  const startDay=Number(shop.trialOpenedDay)||0;
  const byDay=new Map();

  for (const row of snapshots) {
    const day=Number(row&&row.day);
    if (!row || !row.financial || !Number.isFinite(day) || day<startDay || byDay.has(day)) continue;
    byDay.set(day,row);
  }

  return Array.from(byDay.values()).sort((a,b)=>Number(a.day)-Number(b.day)).slice(0,3);
}

function buildTrialReport(
  shop
) {
  const stored=gameState.getRestaurantOperations().shops[shop.id];
  const rows=getTrialRows(shop);
  let revenue=0,profit=0,orders=0,customers=0;

  for (const row of rows) {
    const financial=row.financial||{};
    revenue+=Number(financial.revenue)||0;
    profit+=Number(financial.profit)||0;
    orders+=Number(financial.orders)||0;
    customers+=Number(financial.customers)||0;
  }

  const rating=stored&&stored.shop?Number(stored.shop.rating)||4:4;
  return {
    days:rows.length,
    revenue:Math.round(revenue),
    profit:Math.round(profit),
    orders:Math.round(orders),
    customers:Math.round(customers),
    rating:Number(rating.toFixed(1)),
    generatedDay:currentDay()
  };
}

function processTrial(
  shop,
  day
) {
  if (shop.status!=='trial_opening') return false;
  const endDay=Number(shop.trialEndDay)||(Number(shop.trialOpenedDay)+3);
  if (day<endDay) return false;

  const rows=getTrialRows(shop);
  // 到期但没有3个真实营业日，不能靠空跑日期直接完成试营业。
  if (rows.length<3) return false;

  shop.status='trial_complete';
  shop.trialCompletedDay=day;
  shop.trialReport=buildTrialReport(shop);
  ensureState().metrics.trialsCompleted+=1;
  return true;
}
`,'real three-day trial');

/* G. 累计盈利与连续盈利口径分离 */
replaceExact('src/progress/growthAchievementSystemV0833.js',`    {id:'profit_week',name:'连续盈利基础',metric:'profitDays',target:7,points:35},
    {id:'profit_month',name:'稳定盈利',metric:'profitDays',target:30,points:90},`,`    {id:'profit_week',name:'连续盈利7天',metric:'profitStreak',target:7,points:35},
    {id:'profit_month',name:'连续盈利30天',metric:'profitStreak',target:30,points:90},`,'true profit streak achievements');

replaceExact('src/progress/growthAchievementSystemV0833.js',`        daysPlayed:0,
        profitDays:0,
        bestDailyRevenue:0,`,`        daysPlayed:0,
        profitDays:0,
        profitStreak:0,
        bestDailyRevenue:0,`,'profit streak default');

replaceExact('src/progress/growthAchievementSystemV0833.js',`    profitDays:
      Number(
        ctx.profitDays
      ) ||
      0,
    bestDailyRevenue:`,`    profitDays:
      Number(
        ctx.profitDays
      ) ||
      0,
    profitStreak:
      Math.max(
        0,
        Number(
          ctx.profitStreak
        ) ||
        0
      ),
    bestDailyRevenue:`,'profit streak collection');

/* H. 回归测试 */
replaceExact('tests/operatingDayIntegrationV0843.test.js',`assert.ok(
  operations
    .operatingDaySnapshot(
      'shop_v0843_integration'
    )
    .metrics
    .goalStreak >=
    1,
  '完成目标后必须形成连续完成记录'
);`,`assert.ok(
  operations
    .operatingDaySnapshot(
      'shop_v0843_integration'
    )
    .metrics
    .goalStreak >=
    1,
  '完成目标后必须形成连续完成记录'
);
assert.ok(
  operations.operatingDaySnapshot('shop_v0843_integration').metrics.stabilityLevel>=1,
  '完成目标后必须提升经营稳定度'
);
assert.equal(typeof operations.finalizeExternalOperatingDay,'function','自动跨日必须接入统一日结后处理入口');`,'operating integration stability/unified close');

replaceExact('tests/businessDayUiV0844.test.js',`assert.ok(
  businessSource.includes(
    'renderOperatingDay'
  ) &&`,`const operatingRender =
  businessSource.slice(
    businessSource.indexOf('renderOperatingDay'),
    businessSource.indexOf('renderStaff')
  );

assert.ok(
  !operatingRender.includes("'day:start'") &&
  !operatingRender.includes("'day:close'"),
  '真实营业页不能再暴露假开始/手动推进日结按钮'
);

assert.ok(
  businessSource.includes(
    'renderOperatingDay'
  ) &&`,'business UI no fake day controls');

replaceExact('tests/businessDayUiV0844.test.js',`    'goalStreak'
  ),`,`    'stabilityLevel'
  ) &&
  businessSource.includes(
    'showingCurrent'
  ) &&
  businessSource.includes(
    '自动营业 · 跨日后统一结算'
  ),`,'business UI unified state assertions');

replaceExact('tests/businessLifecycleV086.test.js',`      {
        day:
          day -
          2,
        financial:{`,`      {
        day:
          day -
          3,
        financial:{
          revenue:99999,
          profit:99999,
          orders:999,
          customers:999
        }
      },
      {
        day:
          day -
          2,
        financial:{`,'trial duplicate-day fixture');

replaceExact('tests/businessLifecycleV086.test.js',`assert.equal(
  shop.trialReport.revenue,
  18300,
  '试营业必须生成真实三日经营复盘'
);`,`assert.equal(shop.trialReport.days,3,'试营业复盘必须按3个不同营业日统计');
assert.equal(
  shop.trialReport.revenue,
  18300,
  '同一天重复快照不能重复计入试营业收入'
);`,'trial unique day assertions');

replaceExact('tests/businessLifecycleV086.test.js',`assert.ok(
  restaurantSource.includes(
    "'trial_opening'"
  ) &&
  restaurantSource.includes(
    'trialFactor'
  ),
  '试营业必须进入真实餐厅模拟'
);`,`assert.ok(
  restaurantSource.includes("'trial_opening'") &&
  restaurantSource.includes('trialFactor') &&
  restaurantSource.includes('finalizeExternalOperatingDay') &&
  restaurantSource.includes('.startOperatingDay('),
  '试营业必须进入真实模拟，并由自动营业日统一结算'
);`,'trial automatic settlement wiring');

replaceExact('tests/growthAchievementSystemV0833.test.js',`        daysPlayed:40,
        profitDays:32,
        bestDailyRevenue:56000,`,`        daysPlayed:40,
        profitDays:32,
        profitStreak:8,
        bestDailyRevenue:56000,`,'growth streak fixture');

replaceExact('tests/growthAchievementSystemV0833.test.js',`assert.ok(overview.achievements.length>=10);
assert.ok(overview.unlockedFeatures.length>=5);`,`assert.ok(overview.achievements.length>=10);
assert.ok(overview.unlockedFeatures.length>=5);
assert.ok(overview.achievements.some(item=>item.id==='profit_week'),'连续盈利成就必须读取真实连续盈利天数');
assert.ok(!overview.achievements.some(item=>item.id==='profit_month'),'累计盈利天数不能冒充连续30天盈利');`,'growth streak assertions');

/* I. 版本同步 */
updateJson('package.json',pkg=>{pkg.version=TARGET_VERSION;});
updateJson('package-lock.json',lock=>{lock.version=TARGET_VERSION;if(lock.packages&&lock.packages[''])lock.packages[''].version=TARGET_VERSION;});
replaceExact('android/app/build.gradle',`        versionCode 851
        versionName '0.8.51'`,`        versionCode 860
        versionName '0.8.60'`,'android version');
replaceExact('src/main.js',"'城市餐饮经营小游戏 V0.8.51 每日经营目标版启动成功'","'城市餐饮经营小游戏 V0.8.60 经营核心整合修复版启动成功'",'startup banner');

const genericManifest=fp('PATCH_MANIFEST.json');
if(fs.existsSync(genericManifest))fs.rmSync(genericManifest,{force:true});
console.log('[V0860] 经营核心整合修复完成：'+BASE_VERSION+' -> '+TARGET_VERSION);
