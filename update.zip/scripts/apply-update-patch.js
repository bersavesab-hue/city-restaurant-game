'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = process.cwd();
const VERSION = '0.9.0';
const TEST_CMD = 'node tests/v090_core_rework.test.js';
const DIAG_CMD = 'node scripts/v090-diagnostics.js';

function log(message) {
  process.stdout.write(`[V0.9.0 core] ${message}\n`);
}

function mustExist(relative) {
  const full = path.join(ROOT, relative);
  if (!fs.existsSync(full)) throw new Error(`required file missing after unzip: ${relative}`);
  return full;
}

function patchPackageJson() {
  const full = mustExist('package.json');
  const pkg = JSON.parse(fs.readFileSync(full, 'utf8'));
  pkg.scripts ||= {};

  if (!pkg.scripts.test) {
    pkg.scripts.test = TEST_CMD;
  } else if (!pkg.scripts.test.includes('v090_core_rework.test.js')) {
    pkg.scripts.test = `${pkg.scripts.test} && ${TEST_CMD}`;
  }
  pkg.scripts['test:v090'] = TEST_CMD;
  pkg.scripts['diagnose:v090'] = DIAG_CMD;
  pkg.cityRestaurantCore ||= {};
  pkg.cityRestaurantCore.version = VERSION;
  pkg.cityRestaurantCore.schema = 1;
  pkg.cityRestaurantCore.uiChanged = false;

  fs.writeFileSync(full, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
  log('package.json 已增量接入 V0.9.0 测试与诊断，不覆盖原有 pretest/build 脚本。');
}

function appendOnce(relative, marker, block) {
  const full = path.join(ROOT, relative);
  if (!fs.existsSync(full)) return false;
  let source = fs.readFileSync(full, 'utf8');
  if (source.includes(marker)) return true;
  source += `\n${block.trim()}\n`;
  fs.writeFileSync(full, source, 'utf8');
  return true;
}

function installAndroidBridge() {
  const relative = 'android/entry.js';
  const marker = 'V090_CORE_BRIDGE_BEGIN';
  const block = `
// V090_CORE_BRIDGE_BEGIN
// Backend-only integration. This does not draw or modify any UI.
try {
  const v090Bridge = require('../src/simulation/v090/bridge.js');
  v090Bridge.install(globalThis);
} catch (error) {
  console.error('[V0.9.0 core] bridge install failed', error);
  throw error;
}
// V090_CORE_BRIDGE_END
`;
  if (appendOnce(relative, marker, block)) {
    log('android/entry.js 已注册 V0.9.0 后端桥接。');
  } else {
    log('未找到 android/entry.js；跳过运行时全局桥接，但核心模块与测试仍会安装。');
  }
}

function exposeFromNewestLegacySimulation() {
  const dir = path.join(ROOT, 'src', 'operations');
  if (!fs.existsSync(dir)) return;
  const candidates = fs.readdirSync(dir)
    .filter(name => /^restaurantSimulationV.*\.js$/i.test(name))
    .sort();
  if (!candidates.length) return;
  const newest = candidates[candidates.length - 1];
  const relative = path.posix.join('src/operations', newest);
  const marker = 'V090_CORE_COMPAT_EXPORT_BEGIN';
  const block = `
// V090_CORE_COMPAT_EXPORT_BEGIN
// Keep the legacy simulator API intact; only expose the new backend beside it.
try {
  const __restaurantCoreV090 = require('../simulation/v090/restaurantCore.js');
  if (typeof module !== 'undefined' && module.exports &&
      (typeof module.exports === 'object' || typeof module.exports === 'function')) {
    module.exports.coreV090 = __restaurantCoreV090;
    module.exports.simulateV090Day = __restaurantCoreV090.simulateDay;
    module.exports.simulateV090Days = __restaurantCoreV090.simulateDays;
  }
} catch (error) {
  console.error('[V0.9.0 core] legacy compatibility export failed', error);
}
// V090_CORE_COMPAT_EXPORT_END
`;
  appendOnce(relative, marker, block);
  log(`已在 ${relative} 暴露 V0.9.0 兼容接口，不替换旧接口。`);
}

function syntaxCheck() {
  const targets = [
    'src/simulation/v090/restaurantCore.js',
    'src/simulation/v090/legacyAdapter.js',
    'src/simulation/v090/spaceModel.js',
    'src/simulation/v090/tableModel.js',
    'src/simulation/v090/staffModel.js',
    'src/simulation/v090/dishModel.js',
    'src/simulation/v090/inventoryModel.js',
    'src/simulation/v090/supplyModel.js',
    'src/simulation/v090/kitchenModel.js',
    'src/simulation/v090/competitorModel.js',
    'src/simulation/v090/districtMarketModel.js',
    'src/simulation/v090/customerJourney.js',
    'src/simulation/v090/financeModel.js',
    'src/simulation/v090/dailyReport.js',
    'src/simulation/v090/saveMigration.js',
    'tests/v090_core_rework.test.js',
    'scripts/v090-diagnostics.js'
  ];
  for (const relative of targets) {
    mustExist(relative);
    const result = cp.spawnSync(process.execPath, ['--check', relative], { cwd: ROOT, encoding: 'utf8' });
    if (result.status !== 0) {
      process.stderr.write(result.stdout || '');
      process.stderr.write(result.stderr || '');
      throw new Error(`syntax check failed: ${relative}`);
    }
  }
  log('新增核心模块语法检查全部通过。');
}

function runSelfTest() {
  const result = cp.spawnSync(process.execPath, ['tests/v090_core_rework.test.js'], { cwd: ROOT, encoding: 'utf8' });
  process.stdout.write(result.stdout || '');
  process.stderr.write(result.stderr || '');
  if (result.status !== 0) throw new Error('V0.9.0 self-test failed before npm test');
  log('独立核心自测通过，继续交给仓库原有 npm test。');
}

function main() {
  mustExist('src/simulation/v090/restaurantCore.js');
  patchPackageJson();
  installAndroidBridge();
  exposeFromNewestLegacySimulation();
  syntaxCheck();
  runSelfTest();
  log('安装完成：仅重构后端核心，未覆盖任何 UI 资源、场景布局或 workflow。');
}

main();
