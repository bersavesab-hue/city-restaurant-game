'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = process.cwd();
const VERSION = '0.9.1';
const TEST_V090 = 'node tests/v090_core_rework.test.js';
const TEST_V091 = 'node tests/v091_speed_performance.test.js';
const DIAG_CMD = 'node scripts/v090-diagnostics.js';

function log(message) {
  process.stdout.write(`[V0.9.1 hotfix1] ${message}\n`);
}

function mustExist(relative) {
  const full = path.join(ROOT, relative);
  if (!fs.existsSync(full)) throw new Error(`required file missing after unzip: ${relative}`);
  return full;
}

function patchPackageJson() {
  const full = mustExist('package.json');
  const pkg = JSON.parse(fs.readFileSync(full, 'utf8'));
  pkg.scripts ||= {};

  if (!pkg.scripts.test) {
    pkg.scripts.test = `${TEST_V090} && ${TEST_V091}`;
  } else {
    if (!pkg.scripts.test.includes('v090_core_rework.test.js')) {
      pkg.scripts.test += ` && ${TEST_V090}`;
    }
    if (!pkg.scripts.test.includes('v091_speed_performance.test.js')) {
      pkg.scripts.test += ` && ${TEST_V091}`;
    }
  }

  pkg.scripts['test:v090'] = TEST_V090;
  pkg.scripts['test:v091'] = TEST_V091;
  pkg.scripts['diagnose:v090'] = DIAG_CMD;
  pkg.cityRestaurantCore ||= {};
  pkg.cityRestaurantCore.version = VERSION;
  pkg.cityRestaurantCore.schema = 1;
  pkg.cityRestaurantCore.uiChanged = false;
  pkg.cityRestaurantCore.framePacing = true;

  fs.writeFileSync(full, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
  log('package.json 已增量接入 V0.9.0 核心测试 + V0.9.1 倍速性能测试。');
}

function appendOnce(relative, marker, block) {
  const full = path.join(ROOT, relative);
  if (!fs.existsSync(full)) return false;
  let source = fs.readFileSync(full, 'utf8');
  if (source.includes(marker)) return true;
  source += `\n${block.trim()}\n`;
  fs.writeFileSync(full, source, 'utf8');
  return true;
}

function installAndroidBridge() {
  const relative = 'android/entry.js';
  const marker = 'V090_CORE_BRIDGE_BEGIN';
  const block = `
// V090_CORE_BRIDGE_BEGIN
// Backend-only integration. This does not draw or modify any UI.
try {
  const v090Bridge = require('../src/simulation/v090/bridge.js');
  v090Bridge.install(globalThis);
} catch (error) {
  console.error('[V0.9.x core] bridge install failed', error);
  throw error;
}
// V090_CORE_BRIDGE_END
`;
  if (appendOnce(relative, marker, block)) {
    log('android/entry.js 已注册 V0.9.x 后端桥接。');
  } else {
    log('未找到 android/entry.js；跳过运行时全局桥接。');
  }
}

function exposeFromNewestLegacySimulation() {
  const dir = path.join(ROOT, 'src', 'operations');
  if (!fs.existsSync(dir)) return;
  const candidates = fs.readdirSync(dir)
    .filter(name => /^restaurantSimulationV.*\.js$/i.test(name))
    .sort();
  if (!candidates.length) return;
  const newest = candidates[candidates.length - 1];
  const relative = path.posix.join('src/operations', newest);
  const marker = 'V090_CORE_COMPAT_EXPORT_BEGIN';
  const block = `
// V090_CORE_COMPAT_EXPORT_BEGIN
// Keep the legacy simulator API intact; only expose the new backend beside it.
try {
  const __restaurantCoreV090 = require('../simulation/v090/restaurantCore.js');
  if (typeof module !== 'undefined' && module.exports &&
      (typeof module.exports === 'object' || typeof module.exports === 'function')) {
    module.exports.coreV090 = __restaurantCoreV090;
    module.exports.simulateV090Day = __restaurantCoreV090.simulateDay;
    module.exports.simulateV090Days = __restaurantCoreV090.simulateDays;
  }
} catch (error) {
  console.error('[V0.9.x core] legacy compatibility export failed', error);
}
// V090_CORE_COMPAT_EXPORT_END
`;
  appendOnce(relative, marker, block);
  log(`已在 ${relative} 暴露 V0.9.x 兼容接口。`);
}

function findFunctionRange(source, functionName) {
  const needle = `function ${functionName}(`;
  const start = source.indexOf(needle);
  if (start < 0) return null;
  const brace = source.indexOf('{', start);
  if (brace < 0) return null;
  let depth = 0;
  let quote = null;
  let escaped = false;
  let lineComment = false;
  let blockComment = false;

  for (let i = brace; i < source.length; i++) {
    const ch = source[i];
    const next = source[i + 1];

    if (lineComment) {
      if (ch === '\n') lineComment = false;
      continue;
    }
    if (blockComment) {
      if (ch === '*' && next === '/') { blockComment = false; i++; }
      continue;
    }
    if (quote) {
      if (escaped) { escaped = false; continue; }
      if (ch === '\\') { escaped = true; continue; }
      if (ch === quote) quote = null;
      continue;
    }
    if (ch === '/' && next === '/') { lineComment = true; i++; continue; }
    if (ch === '/' && next === '*') { blockComment = true; i++; continue; }
    if (ch === '"' || ch === "'" || ch === '`') { quote = ch; continue; }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return { start, end: i + 1 };
    }
  }
  return null;
}

function patchMainLoop() {
  const relative = 'src/main.js';
  const full = mustExist(relative);
  let source = fs.readFileSync(full, 'utf8');

  if (source.includes('V091_FRAME_PACING_BEGIN')) {
    log('src/main.js 已存在 V0.9.1 frame pacing，跳过重复修改。');
    return;
  }

  // Newer builds have changed whitespace/formatting several times.
  // Locate the timeSystem require semantically instead of requiring one exact text layout.
  const timeRequireRe = /const\s+timeSystem\s*=\s*require\(\s*['"]\.\/core\/timeSystem\.js['"]\s*\)\s*;?/m;
  const timeMatch = source.match(timeRequireRe);
  if (!timeMatch) {
    throw new Error('无法定位 timeSystem require；请确认 src/main.js 仍使用 ./core/timeSystem.js。');
  }

  source = source.replace(
    timeRequireRe,
    `${timeMatch[0]}\n\n// V091_FRAME_PACING_BEGIN\nconst framePacing = require('./core/framePacing.js');\n// V091_FRAME_PACING_END`
  );

  // Accept let/var and optional initial semicolon/spacing used by later patches.
  const lastFrameRe = /(?:let|var)\s+lastFrameTime\s*=\s*null\s*;?/m;
  const lastFrameMatch = source.match(lastFrameRe);
  if (!lastFrameMatch) {
    throw new Error('无法定位 lastFrameTime；倍速补丁未修改主循环。');
  }

  source = source.replace(
    lastFrameRe,
    `${lastFrameMatch[0]}\n\n// V091_FRAME_PACING_STATE_BEGIN\nlet lastRenderTime = 0;\nlet simulationAccumulatorMs = 0;\nlet pendingFrameDirty = true;\n// V091_FRAME_PACING_STATE_END`
  );

  const range = findFunctionRange(source, 'gameLoop');
  if (!range) throw new Error('无法定位 gameLoop()；拒绝盲目覆盖主循环。');

  const oldFunction = source.slice(range.start, range.end);
  const requiredLoopTokens = ['timeSystem', 'scheduleNextFrame', 'animationManager'];
  const missingLoopTokens = requiredLoopTokens.filter(token => !oldFunction.includes(token));
  if (missingLoopTokens.length) {
    throw new Error(
      'gameLoop() 结构与预期不一致，缺少：' + missingLoopTokens.join(', ') +
      '；为避免破坏新版主循环，未进行替换。'
    );
  }

  const newFunction = `function gameLoop(\n  timestamp\n) {\n  const now =\n    typeof timestamp ===\n      'number'\n      ? timestamp\n      : Date.now();\n\n  if (\n    lastFrameTime ===\n      null\n  ) {\n    lastFrameTime =\n      now;\n\n    lastRenderTime =\n      now;\n  }\n\n  const rawDeltaMs =\n    Math.max(\n      0,\n      now -\n      lastFrameTime\n    );\n\n  lastFrameTime =\n    now;\n\n  // V0.9.1: never let a background/resume spike force a huge one-frame catch-up.\n  const deltaMs =\n    framePacing\n      .clampFrameDelta(\n        rawDeltaMs\n      );\n\n  const paused =\n    timeSystem\n      .isPaused();\n\n  const speed =\n    timeSystem\n      .getSpeed();\n\n  simulationAccumulatorMs +=\n    deltaMs;\n\n  let advancedMinutes =\n    0;\n\n  if (\n    framePacing\n      .shouldRunSimulation(\n        simulationAccumulatorMs,\n        speed,\n        paused\n      )\n  ) {\n    const simulationDelta =\n      simulationAccumulatorMs;\n\n    simulationAccumulatorMs =\n      0;\n\n    // Preserve the old ordering: scene observes the previous clock first,\n    // then the clock advances. The next bounded tick sees the new date/time.\n    sceneManager\n      .update(\n        simulationDelta\n      );\n\n    advancedMinutes =\n      timeSystem\n        .update(\n          simulationDelta\n        );\n  }\n\n  const animationChanged =\n    animationManager\n      .update(\n        deltaMs\n      );\n\n  if (\n    advancedMinutes >\n      0 ||\n    animationChanged ||\n    needsResize\n  ) {\n    pendingFrameDirty =\n      true;\n  }\n\n  if (\n    pendingFrameDirty &&\n    framePacing\n      .shouldRender(\n        now -\n          lastRenderTime,\n        speed,\n        paused,\n        animationChanged,\n        needsResize\n      )\n  ) {\n    render();\n\n    lastRenderTime =\n      now;\n\n    pendingFrameDirty =\n      false;\n  }\n\n  scheduleNextFrame(\n    gameLoop\n  );\n}`;

  source = source.slice(0, range.start) + newFunction + source.slice(range.end);

  const anchorRe = /scheduleNextFrame\(\s*gameLoop\s*\)\s*;?/g;
  const anchorMatches = Array.from(source.matchAll(anchorRe));
  if (anchorMatches.length && !source.includes('V091_VISIBILITY_RESET_BEGIN')) {
    const visibilityBlock = `// V091_VISIBILITY_RESET_BEGIN
if (
  typeof document !==
    'undefined' &&
  document.addEventListener
) {
  document.addEventListener(
    'visibilitychange',
    function () {
      lastFrameTime =
        null;

      simulationAccumulatorMs =
        0;

      pendingFrameDirty =
        true;

      if (
        timeSystem &&
        typeof timeSystem.resetAccumulator ===
          'function'
      ) {
        timeSystem
          .resetAccumulator();
      }
    }
  );
}
// V091_VISIBILITY_RESET_END

`;
    const anchorMatch = anchorMatches[anchorMatches.length - 1];
    const anchorText = anchorMatch[0];
    const anchorIndex = anchorMatch.index;
    source = source.slice(0, anchorIndex) + visibilityBlock + anchorText + source.slice(anchorIndex + anchorText.length);
  }


  fs.writeFileSync(full, source, 'utf8');
  log('src/main.js 已增量接入自适应帧率、模拟节流与后台恢复保护。');
}

function syntaxCheck() {
  const targets = [
    'src/core/framePacing.js',
    'src/simulation/v090/restaurantCore.js',
    'src/simulation/v090/legacyAdapter.js',
    'src/simulation/v090/spaceModel.js',
    'src/simulation/v090/tableModel.js',
    'src/simulation/v090/staffModel.js',
    'src/simulation/v090/dishModel.js',
    'src/simulation/v090/inventoryModel.js',
    'src/simulation/v090/supplyModel.js',
    'src/simulation/v090/kitchenModel.js',
    'src/simulation/v090/competitorModel.js',
    'src/simulation/v090/districtMarketModel.js',
    'src/simulation/v090/customerJourney.js',
    'src/simulation/v090/financeModel.js',
    'src/simulation/v090/dailyReport.js',
    'src/simulation/v090/saveMigration.js',
    'tests/v090_core_rework.test.js',
    'tests/v091_speed_performance.test.js',
    'scripts/v090-diagnostics.js',
    'src/main.js'
  ];
  for (const relative of targets) {
    mustExist(relative);
    const result = cp.spawnSync(process.execPath, ['--check', relative], { cwd: ROOT, encoding: 'utf8' });
    if (result.status !== 0) {
      process.stderr.write(result.stdout || '');
      process.stderr.write(result.stderr || '');
      throw new Error(`syntax check failed: ${relative}`);
    }
  }
  log('核心模块、倍速模块与主循环语法检查全部通过。');
}

function runSelfTest(file) {
  const result = cp.spawnSync(process.execPath, [file], { cwd: ROOT, encoding: 'utf8' });
  process.stdout.write(result.stdout || '');
  process.stderr.write(result.stderr || '');
  if (result.status !== 0) throw new Error(`${file} failed before npm test`);
}

function main() {
  mustExist('src/simulation/v090/restaurantCore.js');
  mustExist('src/core/framePacing.js');
  patchPackageJson();
  installAndroidBridge();
  exposeFromNewestLegacySimulation();
  patchMainLoop();
  syntaxCheck();
  runSelfTest('tests/v090_core_rework.test.js');
  runSelfTest('tests/v091_speed_performance.test.js');
  log('安装完成：V0.9.0 经营核心 + V0.9.1 倍速性能优化已整合。');
}

main();
