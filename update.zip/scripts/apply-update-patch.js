'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.21';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.21 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function replaceSection(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  if (
    source.includes(
      replacement
    )
  ) {
    return source;
  }

  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V0.8.21 section start missing: ' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
      startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V0.8.21 section end missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    '\n\n' +
    source.slice(
      end
    )
  );
}

function insertBefore(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      anchor
    );

  if (index < 0) {
    throw new Error(
      'V0.8.21 insertion anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    addition +
    source.slice(
      index
    )
  );
}

function cleanupLegacyRootWorkflow() {
  const rel =
    'apply-update.yml';

  if (
    fs.existsSync(
      abs(rel)
    )
  ) {
    fs.unlinkSync(
      abs(rel)
    );

    console.log(
      '[V0.8.21] removed stray root apply-update.yml'
    );
  }
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      '0.8.20' &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.21 requires formal V0.8.20 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateCustomerEngine() {
  const rel =
    'src/customer/customerEngineV10.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const P=require('./customerPackV10.js');
const R=require('./customerRulesV10.js');`,
`const P=require('./customerPackV10.js');
const R=require('./customerRulesV10.js');
const database=require('./customerRandomDatabaseV0821.js');`,
      'customer database import'
    );

  const replacement =
`function createSegmentProfile(rng,opts={}){
  let segment=opts.segmentId?R.byId(P.SEGMENTS,opts.segmentId):null;
  if(!segment){
    const weights=R.districtSegmentWeights(opts.districtId||'');segment=pick(rng,weights,x=>x.weight)?.segment||pick(rng,P.SEGMENTS,x=>x.weight);
  }
  const income=opts.incomeBandId?R.byId(P.INCOME_BANDS,opts.incomeBandId):pick(rng,P.INCOME_BANDS,x=>Math.max(1,10-Math.abs((x.budgetMultiplier||1)-(segment.budgetIndex||1))*7));
  const household=opts.householdTypeId?R.byId(P.HOUSEHOLD_TYPES,opts.householdTypeId):pick(rng,P.HOUSEHOLD_TYPES,()=>1);
  return database.normalizeProfile({
    id:opts.id||id(rng,'custseg'),segmentId:segment.id,name:segment.name,incomeBandId:income.id,householdTypeId:household.id,
    occupationId:pick(rng,P.OCCUPATIONS)?.id,motiveIds:[pick(rng,P.DINING_MOTIVES)?.id,pick(rng,P.DINING_MOTIVES)?.id].filter((x,i,a)=>x&&a.indexOf(x)===i),
    tasteIds:[pick(rng,P.TASTE_PROFILES)?.id,pick(rng,P.TASTE_PROFILES)?.id,pick(rng,P.TASTE_PROFILES)?.id].filter((x,i,a)=>x&&a.indexOf(x)===i),
    channelHabitId:pick(rng,P.CHANNEL_HABITS)?.id,timePatternId:pick(rng,P.TIME_PATTERNS)?.id,decisionBiasIds:[pick(rng,P.DECISION_BIASES)?.id,pick(rng,P.DECISION_BIASES)?.id].filter((x,i,a)=>x&&a.indexOf(x)===i),
    reviewStyleId:pick(rng,P.REVIEW_STYLES)?.id,socialInfluenceId:pick(rng,P.SOCIAL_INFLUENCE_TYPES)?.id,dietaryPreferenceId:pick(rng,P.DIETARY_PREFERENCES)?.id,
    traits:{priceSensitivity:R.clamp((segment.priceSensitivity+income.priceSensitivity)/2),qualitySensitivity:segment.qualitySensitivity,distanceSensitivity:segment.distanceSensitivity,queueTolerance:segment.queueTolerance,noveltySeeking:segment.noveltySeeking,loyalty:segment.loyalty,socialInfluence:segment.socialInfluence,reviewPropensity:segment.reviewPropensity,deliveryAffinity:segment.deliveryAffinity},
    memory:{historicalPrice:null,lastPaidPrice:null,visitedStores:{},favoriteStoreIds:[],dislikedStoreIds:[]}
  });
}`;

  source =
    replaceSection(
      source,
      'function createSegmentProfile(rng,opts={}){',
      'function generateVisit(',
      replacement,
      'createSegmentProfile'
    );

  source =
    replaceOnce(
      source,
`module.exports={createSegmentProfile,generateVisit,storeUtility,chooseStore,queueDecision,chooseDish,evaluateExperience,postVisit,buildDistrictPopulation,aggregateDemand};`,
`module.exports={
  createSegmentProfile,
  generateVisit,
  storeUtility,
  chooseStore,
  queueDecision,
  chooseDish,
  evaluateExperience,
  postVisit,
  buildDistrictPopulation,
  aggregateDemand,
  normalizeProfile:
    database.normalizeProfile,
  customerInsights:
    database.aggregateProfiles
};`,
      'customer engine exports'
    );

  write(
    rel,
    source
  );
}

function updateCustomerIndex() {
  write(
    'src/customer/index.js',
`'use strict';

module.exports = {
  pack:
    require('./customerPackV10.js'),
  rules:
    require('./customerRulesV10.js'),
  database:
    require('./customerRandomDatabaseV0821.js'),
  engine:
    require('./customerEngineV10.js')
};
`
  );
}

function updateOperationsStore() {
  const rel =
    'src/operations/operationsStoreV080.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const runtimeEngine =
  require('./restaurantRuntimeV10.js');`,
`const runtimeEngine =
  require('./restaurantRuntimeV10.js');

const customerRandomDatabase =
  require('../customer/customerRandomDatabaseV0821.js');`,
      'operations customer database import'
    );

  source =
    replaceOnce(
      source,
`  normalizeLegacyCalendar(
    runtime
  );

  procurementEngine`,
`  runtime.customers =
    customerRandomDatabase
      .normalizeCustomerMap(
        runtime.customers
      );

  normalizeLegacyCalendar(
    runtime
  );

  procurementEngine`,
      'legacy customer normalization'
    );

  const customerApis =
`function generateCustomer(
  shopId,
  options
) {
  return mutate(
    shopId,
    runtime => {
      const customer =
        runtimeEngine
          .customerProfile(
            runtime,
            options ||
            {}
          );

      return {
        ok:true,
        customer:
          customerRandomDatabase
            .resolvedProfile(
              customer
            )
      };
    }
  );
}

function customerRows(
  shopId,
  filters
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return [];
  }

  return (
    customerRandomDatabase
      .queryProfiles(
        runtime.customers,
        filters ||
        {}
      )
  );
}

function customerInsights(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return null;
  }

  return (
    customerRandomDatabase
      .aggregateProfiles(
        runtime.customers
      )
  );
}

`;

  source =
    insertBefore(
      source,
      'function supplierCatalog(\n  shopId,',
      customerApis,
      'function generateCustomer(',
      'customer operation APIs'
    );

  source =
    replaceOnce(
      source,
`  inventoryLotRows,
  inventoryHealth,
  supplierCatalog,`,
`  inventoryLotRows,
  inventoryHealth,
  generateCustomer,
  customerRows,
  customerInsights,
  supplierCatalog,`,
      'operations customer exports'
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0821.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/supplierProcurementDatabaseV0820.test.js',
    'tests/procurementLogisticsIntegrationV0820.test.js',
    'tests/updateInfrastructureV0820.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/supplierProcurementDatabaseV0820.test.js',
    'tests/procurementLogisticsIntegrationV0820.test.js',
    'tests/updateInfrastructureV0820.test.js',
    'tests/customerRandomDatabaseV0821.test.js',
    'tests/customerEngineIntegrationV0821.test.js',
    'tests/customerOperationsIntegrationV0821.test.js',
    'tests/updateInfrastructureV0821.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0821'
    );

  write(
    rel,
    source
  );
}

function updateMainLabel() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.20 供应商采购物流数据库版启动成功',
      '城市餐饮经营小游戏 V0.8.21 顾客随机数据库版启动成功'
    );

  write(
    rel,
    source
  );
}

// setup-android@v3 compatibility for the ephemeral GitHub runner only.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const latestBin =
    path.join(
      latestDir,
      'bin',
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      latestBin
    )
  ) {
    console.log(
      '[V0.8.21] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const versionedDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      '16.0'
    );

  try {
    if (
      fs.existsSync(
        versionedDir
      )
    ) {
      fs.rmSync(
        versionedDir,
        {
          recursive:true,
          force:true
        }
      );
    }

    fs.symlinkSync(
      latestDir,
      versionedDir,
      'dir'
    );
  } catch (error) {
    console.log(
      '[V0.8.21] Android SDK runner compatibility symlink skipped: ' +
      error.message
    );
  }

  const candidates = [
    latestBin,
    path.join(
      versionedDir,
      'bin',
      'sdkmanager'
    )
  ];

  for (
    const sdkmanager
    of candidates
  ) {
    if (
      !fs.existsSync(
        sdkmanager
      )
    ) {
      continue;
    }

    const binDir =
      path.dirname(
        sdkmanager
      );

    const real =
      path.join(
        binDir,
        'sdkmanager.v0821-real'
      );

    if (
      !fs.existsSync(
        real
      )
    ) {
      fs.renameSync(
        sdkmanager,
        real
      );
    }

    const wrapper = [
      '#!/usr/bin/env bash',
      'set -e',
      'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0821-real"',
      'ARGS=()',
      'for ARG in "$@"; do',
      '  if [ "$ARG" = "tools" ]; then',
      '    continue',
      '  fi',
      '  ARGS+=("$ARG")',
      'done',
      'if [ "${#ARGS[@]}" -eq 0 ]; then',
      '  exit 0',
      'fi',
      'exec "$REAL" "${ARGS[@]}"',
      ''
    ].join(
      '\n'
    );

    fs.writeFileSync(
      sdkmanager,
      wrapper,
      'utf8'
    );

    fs.chmodSync(
      sdkmanager,
      0o755
    );
  }

  console.log(
    '[V0.8.21] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.21 package version finalize failed'
    );
  }

  if (
    fs.existsSync(
      abs(
        'apply-update.yml'
      )
    )
  ) {
    throw new Error(
      'V0.8.21 root apply-update.yml cleanup failed'
    );
  }

  const requiredFiles = [
    'src/customer/customerRandomDatabaseV0821.js',
    'tests/customerRandomDatabaseV0821.test.js',
    'tests/customerEngineIntegrationV0821.test.js',
    'tests/customerOperationsIntegrationV0821.test.js',
    'tests/updateInfrastructureV0821.test.js'
  ];

  for (
    const file
    of requiredFiles
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.21 required file missing: ' +
        file
      );
    }
  }

  const engine =
    read(
      'src/customer/customerEngineV10.js'
    );

  for (
    const marker
    of [
      'customerRandomDatabaseV0821.js',
      'database.normalizeProfile',
      'customerInsights:'
    ]
  ) {
    if (
      !engine.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.21 customer engine validation missing ' +
        marker
      );
    }
  }

  const operations =
    read(
      'src/operations/operationsStoreV080.js'
    );

  for (
    const marker
    of [
      'customerRandomDatabaseV0821.js',
      'normalizeCustomerMap(',
      'function generateCustomer(',
      'function customerRows(',
      'function customerInsights('
    ]
  ) {
    if (
      !operations.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.21 operations validation missing ' +
        marker
      );
    }
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/customerRandomDatabaseV0821.test.js',
      'tests/customerEngineIntegrationV0821.test.js',
      'tests/customerOperationsIntegrationV0821.test.js',
      'tests/updateInfrastructureV0821.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.21 runner validation missing ' +
        marker
      );
    }
  }
}

cleanupLegacyRootWorkflow();
updatePackage();
updatePackageLock();
updateCustomerEngine();
updateCustomerIndex();
updateOperationsStore();
updateRunner();
updateMainLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.21] PASS：顾客随机数据库统一完成'
);
