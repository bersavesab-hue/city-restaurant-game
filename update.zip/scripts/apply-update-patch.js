'use strict';

// V0866_PRESTIGE_INCREMENTAL_PATCH
// Applied by .github/workflows/apply-update.yml after update.zip is unpacked.
// The script intentionally patches only stable anchors and aborts on mismatch.

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

function file(rel) {
  return path.join(root, rel);
}

function read(rel) {
  const p = file(rel);
  if (!fs.existsSync(p)) throw new Error('缺少目标文件: ' + rel);
  return fs.readFileSync(p, 'utf8');
}

function write(rel, content) {
  fs.writeFileSync(file(rel), content, 'utf8');
}

function insertAfterOnce(content, anchor, addition, label) {
  if (content.includes(addition.trim())) return content;
  const index = content.indexOf(anchor);
  if (index < 0) throw new Error('补丁锚点不存在: ' + label);
  const at = index + anchor.length;
  return content.slice(0, at) + addition + content.slice(at);
}

function replaceOnce(content, before, after, label) {
  if (content.includes(after)) return content;
  const first = content.indexOf(before);
  if (first < 0) throw new Error('补丁锚点不存在: ' + label);
  if (content.indexOf(before, first + before.length) >= 0) {
    throw new Error('补丁锚点不唯一: ' + label);
  }
  return content.slice(0, first) + after + content.slice(first + before.length);
}

function patchMain() {
  let s = read('src/main.js');

  s = insertAfterOnce(
    s,
    "const financialSystem = require('./finance/financialSystemV103.js');",
    "\nconst restaurantPrestigeSystem = require('./reputation/restaurantPrestigeSystemV105.js');\nconst rankingScene = require('./scenes/rankingSceneV105.js');\nconst honorScene = require('./scenes/honorSceneV105.js');",
    'main imports'
  );

  s = insertAfterOnce(
    s,
    "runtime.financialSystem =\n  financialSystem;",
    "\n\nruntime.restaurantPrestige =\n  restaurantPrestigeSystem;",
    'runtime prestige export'
  );

  s = insertAfterOnce(
    s,
    "sceneManager.register(\n  'financeCenter',\n  financeCenterScene\n);",
    "\n\nsceneManager.register(\n  'ranking',\n  rankingScene\n);\n\nsceneManager.register(\n  'honors',\n  honorScene\n);",
    'prestige scene registration'
  );

  s = replaceOnce(
    s,
    "if (\n      toolId ===\n      'news'\n    ) {",
    "if (\n      toolId ===\n      'rank'\n    ) {\n      trafficMode =\n        false;\n\n      sceneManager\n        .switchTo(\n          'ranking'\n        );\n\n      render();\n    } else if (\n      toolId ===\n      'news'\n    ) {",
    'city rank tool route'
  );

  s = s.replace(/城市餐饮经营小游戏 V0\.8\.65/g, '城市餐饮经营小游戏 V0.8.66');
  write('src/main.js', s);
}

function patchMoreScene() {
  let s = read('src/scenes/moreScene.js');

  s = insertAfterOnce(
    s,
    "const gameState = require('../core/gameState.js');",
    "\nconst citySystem = require('../city/citySystem.js');\nconst demandSystem = require('../city/demandSystem.js');\nconst prestige = require('../reputation/restaurantPrestigeSystemV105.js');",
    'more scene prestige imports'
  );

  s = insertAfterOnce(
    s,
    "    const shop = this.currentShop();",
    "\n    const prestigeReport = shop\n      ? prestige.sync({ gameState, citySystem, demandSystem })\n      : null;",
    'more scene prestige report'
  );

  const oldBody = `    ui.sectionTitle(ctx, '经营扩展', 94, shop ? ('当前门店：' + (shop.name || '门店')) : '开店后解锁更多经营能力', 390);\n    this.drawEntry(ctx, 'go:advancedManagement', 10, 110, 180, '经营中心', '营销 · 会员 · 主动采购 · 成长', 'gold');\n    this.drawEntry(ctx, 'go:license', 200, 110, 180, '证照许可', '营业 · 食品 · 消防等低频手续', 'neutral');\n\n    ui.sectionTitle(ctx, '市场与扩张', 218, '', 390);\n    this.drawEntry(ctx, 'go:dynamicWorld', 10, 234, 180, '城市动态', '事件 · 政策 · 人物 · 市场变化', 'blue');\n    this.drawEntry(ctx, 'go:propertyMarket', 200, 234, 180, '扩店找铺', '房源市场 · 看铺 · 谈判 · 签约', 'green');\n\n    ui.sectionTitle(ctx, '系统与管理', 342, '', 390);\n    this.drawEntry(ctx, 'go:system', 10, 358, 180, '系统设置', '存档 · 新游戏 · 模拟设置', 'neutral');\n    this.drawEntry(ctx, 'go:financeCenter', 200, 358, 180, '金融中心', '授信 · 贷款 · 还款 · 信用', 'gold');\n\n    ui.rect(ctx, 10, 470, 370, 112, { fill: ui.COLORS.panel, stroke: ui.COLORS.line });\n    ui.text(ctx, '分流规则', 24, 491, 8.5, ui.COLORS.text, '700');\n    ui.text(ctx, '门店：员工 / 排班 / 装修 / 设备 / 财务', 24, 520, 7, ui.COLORS.text, '600');\n    ui.text(ctx, '菜单：菜品研发与菜品经营数据', 24, 544, 7, ui.COLORS.text, '600');\n    ui.text(ctx, '供应链：采购 / 库存 / 损耗 / 供应商', 24, 568, 7, ui.COLORS.text, '600');`;

  const newBody = `    const rankText = prestigeReport && prestigeReport.cityRank\n      ? ('城市第' + prestigeReport.cityRank.playerRank + ' · 评级' + prestigeReport.dimensions.grade + ' ' + ui.number(prestigeReport.dimensions.operating, 1))\n      : '开店后进入动态城市排名';\n    const honorText = prestigeReport\n      ? (prestigeReport.certificationLabel + ' · 已获' + prestigeReport.awards.length + '项荣誉')\n      : '金牌认证 · 行业奖项 · 荣誉履历';\n\n    ui.sectionTitle(ctx, '行业评价', 94, shop ? ('当前门店：' + (shop.name || '门店')) : '开店后进入行业竞争', 390);\n    this.drawEntry(ctx, 'go:ranking', 10, 110, 180, '餐饮排行榜', rankText, 'blue');\n    this.drawEntry(ctx, 'go:honors', 200, 110, 180, '荣誉与金牌', honorText, 'gold');\n\n    ui.sectionTitle(ctx, '经营扩展', 218, '', 390);\n    this.drawEntry(ctx, 'go:advancedManagement', 10, 234, 180, '经营中心', '营销 · 会员 · 主动采购 · 成长', 'gold');\n    this.drawEntry(ctx, 'go:license', 200, 234, 180, '证照许可', '营业 · 食品 · 消防等低频手续', 'neutral');\n\n    ui.sectionTitle(ctx, '市场与扩张', 342, '', 390);\n    this.drawEntry(ctx, 'go:dynamicWorld', 10, 358, 180, '城市动态', '事件 · 政策 · 人物 · 市场变化', 'blue');\n    this.drawEntry(ctx, 'go:propertyMarket', 200, 358, 180, '扩店找铺', '房源市场 · 看铺 · 谈判 · 签约', 'green');\n\n    ui.sectionTitle(ctx, '系统与管理', 466, '', 390);\n    this.drawEntry(ctx, 'go:system', 10, 482, 180, '系统设置', '存档 · 新游戏 · 模拟设置', 'neutral');\n    this.drawEntry(ctx, 'go:financeCenter', 200, 482, 180, '金融中心', '授信 · 贷款 · 还款 · 信用', 'gold');`;

  s = replaceOnce(s, oldBody, newBody, 'more scene information architecture');
  write('src/scenes/moreScene.js', s);
}

function patchStoreDetail() {
  let s = read('src/scenes/storeDetailScene.js');

  s = insertAfterOnce(
    s,
    "const analytics = require('../analytics/businessDataHub.js');",
    "\nconst prestige = require('../reputation/restaurantPrestigeSystemV105.js');",
    'store detail prestige import'
  );

  s = insertAfterOnce(
    s,
    "    const player = typeof gameState.getPlayer === 'function' ? gameState.getPlayer() : {};",
    "\n    const prestigeReport = store ? prestige.sync(this.context()) : null;",
    'store detail prestige report'
  );

  s = replaceOnce(
    s,
    "    ui.header(ctx, store.name + ' · 门店详情', (store.address || '当前门店') + ' · 数据用于解释今天为什么赚/亏', 390, ui.money(player && player.cash));",
    "    const prestigeSummary = prestigeReport\n      ? (prestigeReport.certificationLabel + ' · 评级' + prestigeReport.dimensions.grade + ' ' + ui.number(prestigeReport.dimensions.operating, 1) + ' · 城市第' + (prestigeReport.cityRank && prestigeReport.cityRank.playerRank || '—'))\n      : '行业评价待生成';\n    ui.header(ctx, store.name + ' · 门店详情', (store.address || '当前门店') + ' · ' + prestigeSummary, 390, ui.money(player && player.cash));",
    'store detail prestige summary'
  );

  const oldButtons = `    const buttons = [\n      ['action:city', '‹ 城市', 10, 72, '#EDE6DC', ui.COLORS.navy],\n      ['action:district', '商圈', 90, 82, '#E7EDF0', ui.COLORS.navy],\n      ['action:property', '房源', 180, 82, ui.COLORS.navy, ui.COLORS.white],\n      ['action:data', '完整数据', 270, 110, ui.COLORS.gold, '#26343B']\n    ];`;

  const newButtons = `    const buttons = [\n      ['action:city', '城市', 10, 62, '#EDE6DC', ui.COLORS.navy],\n      ['action:district', '商圈', 78, 66, '#E7EDF0', ui.COLORS.navy],\n      ['action:property', '房源', 150, 66, ui.COLORS.navy, ui.COLORS.white],\n      ['action:data', '完整数据', 222, 78, ui.COLORS.gold, '#26343B'],\n      ['action:honors', '荣誉', 306, 74, ui.COLORS.paleGold, ui.COLORS.navy]\n    ];`;

  s = replaceOnce(s, oldButtons, newButtons, 'store detail action buttons');

  s = insertAfterOnce(
    s,
    "    if (hit.id === 'action:data') return sceneManager.switchTo('business');",
    "\n    if (hit.id === 'action:honors') return sceneManager.switchTo('honors');",
    'store detail honors route'
  );

  write('src/scenes/storeDetailScene.js', s);
}

function patchTestRunner() {
  let s = read('scripts/run-ci-tests-v060.js');
  if (!s.includes("'tests/restaurantPrestigeV105.test.js'")) {
    const anchor = "    'tests/financialSystemV103.test.js',";
    const index = s.indexOf(anchor);
    if (index < 0) throw new Error('补丁锚点不存在: test runner financialSystem');
    s = s.slice(0, index) + "    'tests/restaurantPrestigeV105.test.js',\n" + s.slice(index);
  }
  write('scripts/run-ci-tests-v060.js', s);
}

function patchPackageVersion() {
  const rel = 'package.json';
  const pkg = JSON.parse(read(rel));
  pkg.version = '0.8.66';
  write(rel, JSON.stringify(pkg, null, 2) + '\n');
}

patchMain();
patchMoreScene();
patchStoreDetail();
patchTestRunner();
patchPackageVersion();

console.log('[V0.8.66] 餐饮行业评价系统增量接线完成');
