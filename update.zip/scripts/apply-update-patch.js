'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const BASE = '0.8.65';
const TARGET = '0.8.66';

function p(rel){ return path.join(ROOT, rel); }
function read(rel){ return fs.readFileSync(p(rel),'utf8'); }
function write(rel,content){ fs.writeFileSync(p(rel),content,'utf8'); }
function replaceOnce(rel,from,to,label){
  let s=read(rel);
  const count=s.split(from).length-1;
  if(count!==1) throw new Error(`[V0866] ${label||rel} anchor count=${count}`);
  s=s.replace(from,to);write(rel,s);
}
function replaceRegex(rel,re,to,label){
  let s=read(rel);
  const m=s.match(re);
  if(!m) throw new Error(`[V0866] ${label||rel} regex anchor missing`);
  s=s.replace(re,to);write(rel,s);
}

const pkg=JSON.parse(read('package.json'));
if(pkg.version!==BASE) throw new Error(`[V0866] base version mismatch: expected ${BASE}, got ${pkg.version}`);
pkg.version=TARGET;
write('package.json',JSON.stringify(pkg,null,2)+'\n');

const lock=JSON.parse(read('package-lock.json'));
lock.version=TARGET;
if(lock.packages&&lock.packages['']) lock.packages[''].version=TARGET;
write('package-lock.json',JSON.stringify(lock,null,2)+'\n');

replaceOnce(
  'android/app/build.gradle',
  "        versionCode 865\n        versionName '0.8.65'",
  "        versionCode 866\n        versionName '0.8.66'",
  'android version'
);

// ---------- main / immersive renovation ----------
replaceOnce(
  'src/main.js',
  "'newGame'\n  ) {\n    drawBottomNav();",
  "'newGame' &&\n    sceneManager\n      .getCurrentId() !==\n    'renovation'\n  ) {\n    // V0866_IMMERSIVE_RENOVATION_NAV\n    drawBottomNav();",
  'hide bottom nav in renovation'
);
replaceOnce(
  'src/main.js',
  '城市餐饮经营小游戏 V0.8.65 启动热修复版启动成功',
  '城市餐饮经营小游戏 V0.8.66 经营主链与自由装修整合版启动成功',
  'startup version'
);

// ---------- mature starter shop ----------
replaceOnce(
  'src/core/newGameFlowV0814.js',
  "const shopLifecycleModule =\n  require('./shopLifecycleV0816.js');",
  "const shopLifecycleModule =\n  require('./shopLifecycleV0816.js');\n\nconst starterShopV0866 =\n  require('./starterShopV0866.js');",
  'starter import'
);
replaceOnce(
  'src/core/newGameFlowV0814.js',
  "const VERSION = '0.8.16';",
  "const VERSION = '0.8.66';",
  'new game version'
);
replaceOnce(
  'src/core/newGameFlowV0814.js',
  "    openingPrepSystem:\n      opts.openingPrepSystem ||\n      openingPrepSystem\n  };",
  "    openingPrepSystem:\n      opts.openingPrepSystem ||\n      openingPrepSystem,\n    starterShop:\n      opts.starterShop ||\n      starterShopV0866\n  };",
  'new game deps'
);
replaceOnce(
  'src/core/newGameFlowV0814.js',
  "  function confirmCityName(name) {\n    const state =\n      ensureState();",
  "  function confirmCityName(name) {\n    const state =\n      ensureState();\n\n    const wasFresh =\n      state.mode === 'fresh';",
  'remember fresh state'
);
replaceOnce(
  'src/core/newGameFlowV0814.js',
  "    state.startedAt =\n      state.startedAt ||\n      now();\n\n    const stage =\n      syncStage(",
  "    state.startedAt =\n      state.startedAt ||\n      now();\n\n    // V0866_MATURE_STARTER_SHOP: first-time players start from an\n    // already-operating 42㎡ small restaurant. Property search becomes an\n    // expansion loop instead of a tutorial wall before the core gameplay.\n    if (\n      wasFresh &&\n      deps.starterShop &&\n      typeof deps.starterShop.ensureStarterShop === 'function'\n    ) {\n      deps.starterShop.ensureStarterShop({\n        gameState: deps.gameState\n      });\n    }\n\n    const stage =\n      syncStage(",
  'create starter shop'
);

// New-game copy: player starts operating, not property hunting.
replaceRegex(
  'src/scenes/newGameSceneV0814.js',
  /const steps = \[[\s\S]*?\n    \];/,
  `const steps = [
      ['1','接手成熟小店','42㎡小店已经营业，16个真实座位、基础员工和6道菜单'],
      ['2','先看经营问题','午餐容易满座、晚餐偏弱，还有一道菜毛利偏低'],
      ['3','马上做第一次调整','桌位、菜单、价格和备货变化会直接进入真实客流与订单'],
      ['4','再扩第二家店','熟悉经营后再完整体验找房、谈租、装修、办证与招聘']
    ];`,
  'new game steps'
);
replaceOnce(
  'src/scenes/newGameSceneV0814.js',
  '进入城市 · 开始选址  ›',
  '接手小店 · 立即营业  ›',
  'new game CTA'
);
replaceOnce(
  'src/scenes/newGameSceneV0814.js',
  '从第一家小餐馆起步，靠选址和经营判断把生意做起来',
  '先接手一间正在营业的小店，马上看懂客流、桌位、菜单与利润',
  'new game subtitle'
);

// ---------- store operating model ----------
replaceOnce(
  'src/opening/openingPrepSystem.js',
  "const renovationSystem =\n  require('../renovation/renovationSystem.js');",
  "const renovationSystem =\n  require('../renovation/renovationSystem.js');\n\nconst storeOperatingModel =\n  require('../operations/storeOperatingModelV0866.js');",
  'opening model import'
);

replaceRegex(
  'src/opening/openingPrepSystem.js',
  /  getSeats\(shopId\) \{[\s\S]*?\n  \}\n\n  ensureEquipment\(shopId\) \{/,
  `  getSeats(shopId) {
    const shop =
      this.getShop(
        shopId
      );

    if (!shop) {
      return 0;
    }

    return Math.max(
      0,
      Number(
        storeOperatingModel
          .planningSeatCapacity(
            shop
          )
      ) || 0
    );
  }

  ensureEquipment(shopId) {`,
  'opening real seats'
);

replaceRegex(
  'src/opening/openingPrepSystem.js',
  /  getRequiredStaff\(shopId\) \{[\s\S]*?\n  \}\n\n  generateCandidate\(/,
  `  getRequiredStaff(shopId) {
    const shop =
      this.getShop(
        shopId
      );

    if (!shop) {
      return {
        manager:0,
        chef:0,
        server:0,
        cashier:0
      };
    }

    return storeOperatingModel
      .requiredStaff(
        shop
      );
  }

  generateCandidate(`,
  'format-aware required staff'
);

// ---------- customer traffic respects actual seats ----------
replaceOnce(
  'src/city/customerTrafficSystem.js',
  "function estimateSeatCapacity(store, rule, usableArea, dineInAllowed) {\n  if (!dineInAllowed || !rule.dineIn) return 0;",
  "function estimateSeatCapacity(store, rule, usableArea, dineInAllowed) {\n  if (!dineInAllowed || !rule.dineIn) return 0;\n\n  if (\n    store &&\n    store.actualSeatCapacity !== undefined &&\n    store.actualSeatCapacity !== null\n  ) {\n    return Math.max(\n      0,\n      Math.min(\n        rule.maxSeats,\n        Math.floor(\n          Number(store.actualSeatCapacity) || 0\n        )\n      )\n    );\n  }",
  'actual seat capacity'
);
replaceOnce(
  'src/city/customerTrafficSystem.js',
  "  if (usableArea < 25) {\n    dineInAllowed = false;\n    warnings.push('面积不足25㎡，默认仅支持窗口、打包或外卖经营');\n  }",
  "  if (usableArea < 25) {\n    dineInAllowed = false;\n    warnings.push('面积不足25㎡，默认仅支持窗口、打包或外卖经营');\n  }\n\n  const frontageWidth =\n    firstPositive(\n      [input.frontage, input.frontageWidth],\n      0\n    );\n\n  if (\n    frontageWidth > 0 &&\n    frontageWidth < 2.4\n  ) {\n    dineInAllowed = false;\n    warnings.push('门面宽度不足2.4m，不建议设置正式堂食');\n  }",
  'frontage dine-in rule'
);

replaceOnce(
  'src/city/customerTrafficSystem.js',
  "  const serviceModes = rule.modes.filter(mode => (\n    mode !== 'dinein' || dineInAllowed\n  ));",
  "  if (\n    input.actualSeatCapacity !== undefined &&\n    input.actualSeatCapacity !== null &&\n    seatCapacity <= 0\n  ) {\n    dineInAllowed = false;\n  }\n\n  const serviceModes = rule.modes.filter(mode => (\n    mode !== 'dinein' || dineInAllowed\n  ));",
  'zero-seat no dine-in'
);

// ---------- property pre-lease seat estimate ----------
replaceRegex(
  'src/property/propertySystem.js',
  /    const seatEstimate = Math\.max\([\s\S]*?\n    \);/,
  `    const seatEstimate =
      usableArea < 25 ||
      propertyType.id === "foodcourt_stall" ||
      propertyType.id === "park_canteen"
        ? 0
        : Math.max(
            4,
            Math.floor(
              (diningSuggestedArea * layoutType.seatsFactor) / 1.55
            )
          );`,
  'property seat estimate'
);

// ---------- real traffic is the only arrival source ----------
replaceOnce(
  'src/operations/restaurantSimulationV081.js',
  "const floorSimulation =\n  require('./floorSimulationV082.js');",
  "const floorSimulation =\n  require('./floorSimulationV082.js');\n\nconst storeOperatingModel =\n  require('./storeOperatingModelV0866.js');",
  'simulation model import'
);

replaceRegex(
  'src/operations/restaurantSimulationV081.js',
  /function expectedArrivalsPerMinute\([\s\S]*?\n}\n\nfunction chooseCustomer\(/,
  `function expectedArrivalsPerMinute(
  shop,
  runtime
) {
  const time =
    gameState.getTime();

  if (
    !shop ||
    !runtime ||
    !isWithinBusinessHours(
      shop,
      time
    )
  ) {
    return 0;
  }

  const period =
    mealPeriod(
      Number(
        time.hour
      ) || 0
    );

  const traffic =
    storeOperatingModel
      .attemptedArrivalsPerMinute(
        shop,
        runtime,
        period
      );

  runtime.simulation =
    runtime.simulation ||
    {};

  runtime.simulation
    .trafficFunnel =
    traffic.snapshot
      ? {
          version:'0.8.66',
          mealPeriod:period,
          funnel:
            traffic.snapshot.funnel,
          rates:
            traffic.snapshot.rates,
          queue:
            traffic.snapshot.queue,
          losses:
            traffic.snapshot.losses,
          format:
            traffic.snapshot.format,
          bottleneck:
            traffic.snapshot.bottleneck
        }
      : null;

  // V0866_UNIFIED_TRAFFIC_MODIFIERS
  // The physical traffic funnel is the base arrival source, but all existing
  // world / marketing / staffing modifiers must remain part of the same loop.
  const worldModifiers =
    dynamicWorldSystem
      .getModifiers({
        districtId:
          shop.districtId,
        shopId:
          shop.id
      });

  const rawMarketingFactor =
    marketingEngine
      .demandMultiplier(
        runtime.campaigns || []
      );

  // Keep the historical modifier name because policies/events already expose
  // it and older saves/tests depend on this integration contract.
  const marketingEfficiencyMultiplier =
    clamp(
      Number(
        worldModifiers
          .marketingEfficiencyMultiplier
      ) || 1,
      0.45,
      1.75
    );

  // The new funnel already uses marketing as part of store attraction. Apply
  // only a moderated residual multiplier here to avoid double-counting.
  const marketingFactor =
    1 +
    (
      rawMarketingFactor -
      1
    ) *
    marketingEfficiencyMultiplier *
    0.35;

  const dynamicDemandFactor =
    clamp(
      Number(
        worldModifiers
          .demandMultiplier
      ) || 1,
      0.45,
      1.75
    );

  const competitiveMarket =
    liveWorldSystem
      .getDistrictDashboard(
        shop.districtId
      );

  const competitionFactor =
    clamp(
      Number(
        competitiveMarket
          .playerDemandMultiplier
      ) || 1,
      0.45,
      1.40
    );

  const nightFactor =
    period === 'night'
      ? clamp(
          Number(
            worldModifiers
              .nightDemandMultiplier
          ) || 1,
          0.45,
          1.75
        )
      : 1;

  const coverage =
    staffCoverage(
      shop
    );

  const staffingFactor =
    0.85 +
    clamp(
      coverage,
      0.08,
      1.2
    ) *
    0.15;

  const peakDemandFactor =
    staffWorkloadSystem
      .getDemandMultiplier(
        time
      );

  const trialFactor =
    shop.status ===
      'trial_opening'
      ? 0.78
      : 1;

  const externalDemandFactor =
    marketingFactor *
    dynamicDemandFactor *
    competitionFactor *
    nightFactor *
    staffingFactor *
    peakDemandFactor *
    trialFactor;

  if (
    runtime.simulation
      .trafficFunnel &&
    runtime.simulation
      .trafficFunnel.rates
  ) {
    runtime.simulation
      .trafficFunnel.rates = {
        ...runtime.simulation
          .trafficFunnel.rates,
        marketingFactor,
        marketingEfficiencyMultiplier,
        dynamicDemandFactor,
        competitionFactor,
        nightFactor,
        staffingFactor,
        peakDemandFactor,
        trialFactor,
        externalDemandFactor
      };
  }

  return Math.max(
    0,
    Number(
      traffic.rate
    ) *
    externalDemandFactor
  );
}

function chooseCustomer(`,
  'replace arrival generator'
);

replaceOnce(
  'src/operations/restaurantSimulationV081.js',
  "  const rate =\n    expectedArrivalsPerMinute(\n      shop,\n      runtime\n    );",
  "  const capacityState =\n    storeOperatingModel\n      .syncRuntimeCapacity(\n        runtime,\n        shop\n      );\n\n  const rate =\n    expectedArrivalsPerMinute(\n      shop,\n      runtime\n    );",
  'sync actual capacity'
);

replaceRegex(
  'src/operations/restaurantSimulationV081.js',
  /          seats:\n            Number\(\n              shop\.seatEstimate \|\|\n              shop\.seats \|\|\n              36\n            \)/,
  `          seats:
            capacityState
              ? capacityState.seats
              : 0,
          tableCounts:
            capacityState
              ? capacityState.tableCounts
              : {
                  two:0,
                  four:0,
                  six:0,
                  eight:0
                },
          allowedChannels:
            capacityState
              ? capacityState.channels
              : ['pickup']`,
  'actual floor capacity'
);

// ---------- floor simulation no longer manufactures 8/36 seats ----------
replaceRegex(
  'src/operations/floorSimulationV082.js',
  /function desiredTableCounts\([\s\S]*?\n}\n\nfunction profileById\(/,
  `function desiredTableCounts(
  seats
) {
  let remaining =
    Math.max(
      0,
      Math.round(
        Number(
          seats
        ) || 0
      )
    );

  const counts = {
    two:0,
    four:0,
    six:0,
    eight:0
  };

  while (
    remaining >= 4
  ) {
    counts.four += 1;
    remaining -= 4;
  }

  if (
    remaining > 0
  ) {
    counts.two += 1;
  }

  return counts;
}

function syncTables(
  runtime,
  seats,
  explicitCounts
) {
  const room =
    runtime.diningRoom;

  const occupied =
    (
      room.tables ||
      []
    ).some(
      table =>
        table.status !==
        'free'
    );

  const target =
    Math.max(
      0,
      Math.round(
        Number(
          seats
        ) || 0
      )
    );

  const normalizedCounts =
    explicitCounts &&
    typeof explicitCounts ===
      'object'
      ? {
          two:
            Math.max(
              0,
              Number(
                explicitCounts.two
              ) || 0
            ),
          four:
            Math.max(
              0,
              Number(
                explicitCounts.four
              ) || 0
            ),
          six:
            Math.max(
              0,
              Number(
                explicitCounts.six
              ) || 0
            ),
          eight:
            Math.max(
              0,
              Number(
                explicitCounts.eight
              ) || 0
            )
        }
      : desiredTableCounts(
          target
        );

  const desiredSeats =
    normalizedCounts.two * 2 +
    normalizedCounts.four * 4 +
    normalizedCounts.six * 6 +
    normalizedCounts.eight * 8;

  const current =
    totalSeats(
      room
    );

  const drift =
    Math.abs(
      current -
      desiredSeats
    );

  if (
    !occupied &&
    (
      !room.tables ||
      drift > 0
    )
  ) {
    runtime.diningRoom =
      serviceEngine
        .createDiningRoom({
          tableCounts:
            normalizedCounts
        });
  }

  return runtime.diningRoom;
}

function profileById(`,
  'rewrite table sync'
);

// Enforce service channels from store format before queueing.
replaceOnce(
  'src/operations/floorSimulationV082.js',
  "  const partyCount =\n    Math.max(",
  "  const allowedChannels =\n    Array.isArray(\n      ctx.allowedChannels\n    ) &&\n    ctx.allowedChannels.length\n      ? ctx.allowedChannels\n      : ['dine_in','pickup','delivery'];\n\n  if (\n    allowedChannels\n      .indexOf(\n        visit.channel\n      ) < 0\n  ) {\n    visit.channel =\n      allowedChannels\n        .indexOf(\n          'pickup'\n        ) >= 0\n        ? 'pickup'\n        : allowedChannels[0];\n  }\n\n  const partyCount =\n    Math.max(",
  'channel restrictions'
);

replaceRegex(
  'src/operations/floorSimulationV082.js',
  /  syncTables\(\n    runtime,\n    ctx\.seats \|\|\n    shop\.seatEstimate \|\|\n    shop\.seats \|\|\n    36\n  \);/,
  `  syncTables(
    runtime,
    ctx.seats != null
      ? ctx.seats
      : 0,
    ctx.tableCounts
  );`,
  'advance real tables'
);

// ---------- renovation free-build core ----------
replaceOnce(
  'src/renovation/renovationSystem.js',
  "// V0864_SPATIAL_VALIDATION_INTEGRATION\nconst renovationSpatial =\n  require('./renovationSpatialV0864.js');",
  "// V0866_FREE_BUILD_SPATIAL_INTEGRATION\nconst renovationSpatial =\n  require('./renovationFreeBuildV0866.js');",
  'renovation spatial import'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  "      editorPlacements: [],\n      privateRooms: []",
  "      freeBuildVersion: 1,\n      editorWalls: [],\n      editorDoors: [],\n      editorPlacements: [],\n      privateRooms: []",
  'new floor freebuild fields'
);

// Every existing plan is migrated to free-build data shape on access.
replaceOnce(
  'src/renovation/renovationSystem.js',
  "    // Old saves could carry rounded or stale per-floor areas. The property",
  "    store[shopId].freeBuildVersion = 1;\n\n    for (\n      const floor\n      of store[shopId].floors || []\n    ) {\n      floor.freeBuildVersion = 1;\n      floor.editorWalls =\n        Array.isArray(floor.editorWalls)\n          ? floor.editorWalls\n          : [];\n      floor.editorDoors =\n        Array.isArray(floor.editorDoors)\n          ? floor.editorDoors\n          : [];\n      floor.editorPlacements =\n        Array.isArray(floor.editorPlacements)\n          ? floor.editorPlacements\n          : [];\n    }\n\n    // Old saves could carry rounded or stale per-floor areas. The property",
  'migrate plans to freebuild'
);

replaceRegex(
  'src/renovation/renovationSystem.js',
  /  calculateFloorArea\(\n    shop,[\s\S]*?\n  \}\n\n  cycleAisle\(/,
  `  calculateFloorArea(
    shop,
    plan,
    floor,
    floorIndex
  ) {
    const aisle =
      config.aisleModes[
        floor.aisleMode
      ] ||
      config.aisleModes
        .standard;

    const geometry =
      floorGeometrySystem
        .getFloorGeometry(
          shop,
          floorIndex,
          floor.area,
          plan.floors.length
        );

    const freeBuild =
      Number(
        floor.freeBuildVersion
      ) >= 1 ||
      Number(
        plan.freeBuildVersion
      ) >= 1;

    const kitchenArea =
      freeBuild
        ? 0
        : floor.area *
          floor.kitchenRatio;

    const storageArea =
      freeBuild
        ? 0
        : floor.area *
          floor.storageRatio;

    const serviceArea =
      freeBuild
        ? 0
        : floor.area *
          floor.serviceRatio;

    const diningArea =
      freeBuild
        ? floor.area
        : Math.max(
            0,
            floor.area -
            kitchenArea -
            storageArea -
            serviceArea
          );

    const structuralReservedArea =
      this.getStructuralReservedArea(
        geometry,
        floor
      );

    const usableDiningSlots =
      freeBuild
        ? []
        : this.getUsableDiningSlots(
            geometry,
            floor
          );

    const effectiveDiningArea =
      Math.max(
        0,
        diningArea -
        structuralReservedArea
      ) *
      Math.min(
        1,
        geometry.efficiency
          .dining
      );

    let tableArea = 0;
    let tableSeats = 0;

    Object.keys(
      floor.tables
    ).forEach(key => {
      const count =
        Math.max(
          0,
          Number(
            floor.tables[key]
          ) || 0
        );

      tableArea +=
        count *
        config.tableFootprint[
          key
        ] *
        aisle.areaFactor;

      tableSeats +=
        count *
        Number(key);
    });

    let privateRoomArea = 0;
    let privateRoomSeats = 0;

    for (
      const room
      of floor.privateRooms || []
    ) {
      privateRoomArea +=
        7 +
        room.seats *
        1.55;

      privateRoomSeats +=
        room.seats;
    }

    const occupiedArea =
      tableArea +
      privateRoomArea;

    const remainingArea =
      effectiveDiningArea -
      occupiedArea;

    const minimumDining =
      freeBuild
        ? 0
        : Math.max(
            config.zoneRules
              .minDiningAreaM2,
            floor.area *
            config.zoneRules
              .minDiningRatio
          );

    const warnings = [];

    if (
      !freeBuild &&
      diningArea + 0.01 <
      minimumDining
    ) {
      warnings.push(
        '堂食区低于最小面积'
      );
    }

    if (
      !freeBuild &&
      remainingArea < -0.01
    ) {
      warnings.push(
        '家具与包厢超出可摆面积'
      );
    }

    if (
      !freeBuild &&
      tableArea > 0 &&
      usableDiningSlots.length <
      Object.keys(
        floor.tables
      ).reduce(
        (sum,key) =>
          sum +
          Number(
            floor.tables[key]
          ),
        0
      )
    ) {
      warnings.push(
        '可落位餐桌点不足'
      );
    }

    return {
      aisle,
      geometry,
      usableDiningSlots,
      kitchenArea,
      storageArea,
      serviceArea,
      diningArea,
      structuralReservedArea,
      effectiveDiningArea,
      tableArea,
      tableSeats,
      privateRoomArea,
      privateRoomSeats,
      occupiedArea,
      remainingArea,
      zoneTotal:
        floor.area,
      minimumDining,
      areaUtilization:
        effectiveDiningArea > 0
          ? occupiedArea /
            effectiveDiningArea
          : 0,
      warnings,
      valid:
        warnings.length === 0
    };
  }

  cycleAisle(`,
  'freebuild area calculation'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  "      const zoneRatio =\n        floor.kitchenRatio +\n        floor.storageRatio +\n        floor.serviceRatio;\n\n      const diningArea =\n        Math.max(\n          0,\n          floor.area *\n          (\n            1 -\n            zoneRatio\n          )\n        );",
  "      const freeBuild =\n        Number(\n          floor.freeBuildVersion\n        ) >= 1 ||\n        Number(\n          plan.freeBuildVersion\n        ) >= 1;\n\n      const zoneRatio =\n        floor.kitchenRatio +\n        floor.storageRatio +\n        floor.serviceRatio;\n\n      const diningArea =\n        freeBuild\n          ? floor.area\n          : Math.max(\n              0,\n              floor.area *\n              (\n                1 -\n                zoneRatio\n              )\n            );",
  'metrics freebuild dining'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  "      kitchenArea +=\n        floor.area *\n        floor.kitchenRatio;\n\n      storageArea +=\n        floor.area *\n        floor.storageRatio;\n\n      serviceArea +=\n        floor.area *\n        floor.serviceRatio;",
  "      if (freeBuild) {\n        for (\n          const placement\n          of floor.editorPlacements || []\n        ) {\n          const spec =\n            renovationSpatial\n              .specFor(\n                placement.kind\n              ) || {};\n\n          const area =\n            Number(\n              spec.floorArea\n            ) || 0;\n\n          if (spec.kitchen) {\n            kitchenArea += area;\n          }\n\n          if (spec.storage) {\n            storageArea += area;\n          }\n\n          if (spec.reception) {\n            serviceArea += area;\n          }\n        }\n      } else {\n        kitchenArea +=\n          floor.area *\n          floor.kitchenRatio;\n\n        storageArea +=\n          floor.area *\n          floor.storageRatio;\n\n        serviceArea +=\n          floor.area *\n          floor.serviceRatio;\n      }",
  'derive functional areas from equipment'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  "    const kitchenLoad =\n      totalSeats /\n      Math.max(\n        1,\n        kitchenArea *\n          2.65\n      );",
  "    const freeBuildKitchenCapacity =\n      plan.floors\n        .reduce(\n          (sum,floor) =>\n            sum +\n            (floor.editorPlacements || [])\n              .reduce(\n                (inner,item) => {\n                  if (item.kind === 'stove') return inner + 28;\n                  if (item.kind === 'prep') return inner + 16;\n                  if (item.kind === 'sink') return inner + 10;\n                  if (item.kind === 'fridge') return inner + 8;\n                  return inner;\n                },\n                0\n              ),\n          0\n        );\n\n    const freeBuildPlan =\n      Number(\n        plan.freeBuildVersion\n      ) >= 1;\n\n    const kitchenLoad =\n      freeBuildPlan\n        ? totalSeats /\n          Math.max(\n            8,\n            freeBuildKitchenCapacity\n          )\n        : totalSeats /\n          Math.max(\n            1,\n            kitchenArea *\n              2.65\n          );",
  'equipment kitchen load'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  "    const totalCost =\n      Math.round(\n        constructionBase +\n        lightingCost +\n        furnitureCost +\n        roomCost +\n        kitchenComplexity +\n        decorCost\n      );",
  "    const partitionCost =\n      plan.floors\n        .reduce(\n          (sum,floor) =>\n            sum +\n            (floor.editorWalls || [])\n              .reduce(\n                (inner,wall) =>\n                  inner +\n                  renovationSpatial\n                    .wallLength(\n                      wall\n                    ) *\n                  280,\n                0\n              ) +\n            (floor.editorDoors || [])\n              .length *\n              980,\n          0\n        );\n\n    const totalCost =\n      Math.round(\n        constructionBase +\n        lightingCost +\n        furnitureCost +\n        roomCost +\n        kitchenComplexity +\n        decorCost +\n        partitionCost\n      );",
  'wall door cost'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  "      decorCost:\n        Math.round(\n          decorCost\n        ),",
  "      decorCost:\n        Math.round(\n          decorCost\n        ),\n\n      partitionCost:\n        Math.round(\n          partitionCost\n        ),",
  'partition cost output'
);

// ---------- install immersive free-build editor ----------
replaceOnce(
  'src/scenes/renovationScene.js',
  "require('../renovation/renovationEditorV0864.js').install({\n  RenovationScene,\n  renovationSystem,\n  renovationConfig,\n  floorGeometrySystem,\n  saveSystem,\n  gameState,\n  ui,\n  COLORS\n});\n\nmodule.exports =",
  "require('../renovation/renovationEditorV0864.js').install({\n  RenovationScene,\n  renovationSystem,\n  renovationConfig,\n  floorGeometrySystem,\n  saveSystem,\n  gameState,\n  ui,\n  COLORS\n});\n\n// V0866_IMMERSIVE_FREE_BUILD_EDITOR_INSTALL\nrequire('../renovation/renovationEditorV0866.js').install({\n  RenovationScene,\n  renovationSystem,\n  renovationConfig,\n  floorGeometrySystem,\n  saveSystem,\n  gameState,\n  ui,\n  COLORS\n});\n\nmodule.exports =",
  'install freebuild editor'
);

// ---------- add V0.8.66 behavior tests while retaining historical test paths ----------
{
  const rel='scripts/run-ci-tests-v060.js';
  let s=read(rel);
  const anchor="    'tests/preparationCommandCenterV0861.test.js',";
  if(!s.includes(anchor)) throw new Error('[V0866] test runner anchor missing');
  if(!s.includes("'tests/renovationFreeBuildV0866.test.js'")) {
    s=s.replace(
      anchor,
      "    'tests/renovationFreeBuildV0866.test.js',\n    'tests/unifiedStoreFlowV0866.test.js',\n"+anchor
    );
  }
  write(rel,s);
}

// ---------- post-patch integration guard ----------
{
  const sim = read('src/operations/restaurantSimulationV081.js');
  if (!sim.includes('peakDemandFactor')) {
    throw new Error('[V0866] real traffic patch lost staff peakDemandFactor');
  }
  if (!sim.includes('marketingEfficiencyMultiplier')) {
    throw new Error('[V0866] real traffic patch lost marketingEfficiencyMultiplier');
  }
  if (!sim.includes('dynamicDemandFactor') || !sim.includes('competitionFactor')) {
    throw new Error('[V0866] real traffic patch lost dynamic demand or competition factors');
  }
  if (!sim.includes('workloadTick.overtimeCost')) {
    throw new Error('[V0866] overtime cost bridge missing after patch');
  }
  if (sim.includes("shop.seatEstimate ||\n              shop.seats ||\n              36")) {
    throw new Error('[V0866] legacy default 36-seat fallback still present');
  }

  const floor = read('src/operations/floorSimulationV082.js');
  if (!floor.includes('ctx.tableCounts')) {
    throw new Error('[V0866] floor simulation is not using physical table counts');
  }
}

console.log('[V0866] integrated operating loop + free-build renovation patch applied');
