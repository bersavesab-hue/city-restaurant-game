'use strict';

const fs = require('fs');
const cp = require('child_process');

const paths = {
  demand: 'src/city/demandSystem.js',
  shop: 'src/scenes/shopScene.js',
  main: 'src/main.js',
  traffic: 'src/city/customerTrafficSystem.js',
  trafficScene: 'src/scenes/trafficDataScene.js'
};

const MARK = {
  demand: 'V104_TRAFFIC_API_START',
  shop: 'V104_SHOP_BRIDGE_START',
  main: 'V104_TRAFFIC_SCENE'
};

function exists(path) {
  return fs.existsSync(path);
}

function read(path) {
  return fs.readFileSync(path, 'utf8');
}

function write(path, value) {
  fs.writeFileSync(path, value, 'utf8');
}

function syntax(path) {
  const r = cp.spawnSync(process.execPath, ['--check', path], { encoding: 'utf8' });
  if (r.status !== 0) {
    process.stderr.write(r.stdout || '');
    process.stderr.write(r.stderr || '');
    throw new Error('Syntax check failed: ' + path);
  }
}

function withRollback(path, mutate) {
  const before = read(path);
  let after;
  try {
    after = mutate(before);
    if (typeof after !== 'string' || !after.length) {
      throw new Error('patch returned empty content: ' + path);
    }
    write(path, after);
    syntax(path);
  } catch (error) {
    write(path, before);
    throw error;
  }
}

if (!exists(paths.traffic) || !exists(paths.trafficScene)) {
  throw new Error('V1.0.4 core files missing from update.zip');
}
if (!exists(paths.demand) || !exists(paths.main)) {
  throw new Error('V1.0.4 incompatible repository: demandSystem/main.js missing');
}

// 1) demandSystem：不再依赖 class 尾部固定锚点，直接在模块末尾增强实例。
withRollback(paths.demand, source => {
  if (source.includes(MARK.demand)) return source;

  const bridge = `

/* ${MARK.demand} */
const __v104Traffic = require('./customerTrafficSystem.js');

demandSystem.getStoreFormat = function getStoreFormatV104(store) {
  return __v104Traffic.classifyStore(store || {});
};

demandSystem.getTrafficFunnel = function getTrafficFunnelV104(districtId, store, options) {
  const pool = this.createDemandPool(districtId);
  if (!pool) return null;

  const result = __v104Traffic.simulate({
    district: citySystem.getDistrict(districtId),
    demandPool: pool,
    store: store || {},
    customerTypes: CUSTOMER_TYPES,
    weatherModifier: this.getWeatherModifier(),
    mealPeriod: pool.mealPeriod,
    ...(options || {})
  });

  // 本次返回的是经营快照；不直接永久扣减全局商圈需求，避免每次打开数据页就“吃掉客流”。
  result.demandPool = pool;
  return result;
};
/* V104_TRAFFIC_API_END */
`;

  return source + bridge;
});

// 2) 找铺页：仅做实例增强，不破坏现有页面结构。
if (exists(paths.shop)) {
  withRollback(paths.shop, source => {
    if (source.includes(MARK.shop)) return source;

    const bridge = `

/* ${MARK.shop} */
const __v104TrafficShop = require('../city/customerTrafficSystem.js');
const __v104ShopScene = module.exports;

if (__v104ShopScene && !__v104ShopScene.__v104TrafficBridge) {
  __v104ShopScene.__v104TrafficBridge = true;

  if (typeof __v104ShopScene.makeLiveListing === 'function') {
    const __oldMakeLiveListingV104 = __v104ShopScene.makeLiveListing;
    __v104ShopScene.makeLiveListing = function makeLiveListingV104(item) {
      const live = __oldMakeLiveListingV104.call(this, item);
      const format = __v104TrafficShop.classifyStore(live || item || {});
      return {
        ...live,
        businessFormat: format,
        businessFormatId: format.id,
        businessFormatName: format.name,
        dineInAllowed: format.dineInAllowed,
        seatCapacityByFormat: format.seatCapacity,
        hotKitchenReady: format.hotKitchenReady
      };
    };
  }

  // 房源详情标题直接告诉玩家“这个铺位适合干什么”，不额外挤一个大页面。
  if (typeof __v104ShopScene.drawHeader === 'function') {
    const __oldDrawHeaderV104 = __v104ShopScene.drawHeader;
    __v104ShopScene.drawHeader = function drawHeaderV104(ctx, title, subtitle, backId) {
      let nextSubtitle = subtitle;
      if (title === '房源详情' && typeof this.getSelectedListing === 'function') {
        const item = this.getSelectedListing();
        if (item) {
          const format = item.businessFormat || __v104TrafficShop.classifyStore(item);
          nextSubtitle = (item.address || '当前铺位') + ' · ' + format.name + (format.dineInAllowed ? ' · ' + format.seatCapacity + '座' : ' · 非堂食');
        }
      }
      return __oldDrawHeaderV104.call(this, ctx, title, nextSubtitle, backId);
    };
  }
}
/* V104_SHOP_BRIDGE_END */
`;

    return source + bridge;
  });
}

// 3) 数据入口：兼容多种换行/空格格式，只替换 businessScene 的 require 路径。
withRollback(paths.main, source => {
  if (source.includes(MARK.main) || source.includes("require('./scenes/trafficDataScene.js')")) {
    return source;
  }

  const patterns = [
    /require\(\s*['"]\.\/scenes\/businessScene\.js['"]\s*\)/,
    /require\(\s*['"]\.\/scenes\/businessScene['"]\s*\)/
  ];

  let changed = false;
  for (const pattern of patterns) {
    if (pattern.test(source)) {
      source = source.replace(pattern, "require('./scenes/trafficDataScene.js')");
      changed = true;
      break;
    }
  }

  if (!changed) {
    // 若当前版本已经重构了 require 区，则尝试替换 business 注册对象。
    const reg = /(sceneManager\.register\(\s*['"]business['"]\s*,\s*)([A-Za-z_$][\w$]*)(\s*\))/m;
    const m = source.match(reg);
    if (m) {
      const insertAt = m.index;
      const declaration = "const trafficDataSceneV104 = require('./scenes/trafficDataScene.js');\n\n";
      source = source.slice(0, insertAt) + declaration + source.slice(insertAt);
      source = source.replace(reg, '$1trafficDataSceneV104$3');
      changed = true;
    }
  }

  if (!changed) {
    throw new Error('V1.0.4 could not locate the 数据/business scene entry in src/main.js');
  }

  return source + '\n/* ' + MARK.main + ' */\n';
});

// 4) 新模块自身检查。
syntax(paths.traffic);
syntax(paths.trafficScene);

// 5) 纯逻辑 smoke test。
const traffic = require('../src/city/customerTrafficSystem.js');
const stall = traffic.classifyStore({ usableArea: 10, drainage: true, fireSprinkler: true });
if (stall.id !== 'stall' || stall.dineInAllowed || stall.seatCapacity !== 0) {
  throw new Error('V1.0.4 smoke failed: stall classification');
}

const small = traffic.classifyStore({
  usableArea: 48,
  exhaust: true,
  drainage: true,
  greaseTrap: true,
  fireSprinkler: true,
  threePhase: true
});
if (small.id !== 'small_restaurant' || !small.dineInAllowed || small.seatCapacity < 12) {
  throw new Error('V1.0.4 smoke failed: small restaurant classification');
}

const funnel = traffic.simulate({
  mealPeriod: 'lunch',
  district: { saturation: 72, baseDemand: 1600 },
  demandPool: {
    mealPeriod: 'lunch',
    totalDemand: 420,
    remainingDemand: 420,
    customerGroups: {
      office: { demand: 260 },
      resident: { demand: 160 }
    }
  },
  customerTypes: {
    office: { speedSensitivity: 0.92 },
    resident: { speedSensitivity: 0.48 }
  },
  store: {
    usableArea: 42,
    footfall: 7600,
    visibility: 82,
    frontage: 4.3,
    rating: 3.8,
    reputation: 47,
    priceFit: 68,
    menuAppeal: 63,
    exhaust: true,
    drainage: true,
    greaseTrap: true,
    fireSprinkler: true,
    threePhase: true,
    staffCount: 3
  }
});

if (!funnel || funnel.funnel.actualCustomers < 0 || funnel.funnel.actualCustomers > funnel.funnel.attempted) {
  throw new Error('V1.0.4 smoke failed: traffic funnel');
}

console.log('[V1.0.4] robust traffic + format + data distribution patch PASS');
