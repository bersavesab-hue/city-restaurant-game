'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.62';
const TARGET_VERSION = '0.8.63';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0863] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0863] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* =========================================================
   A. 主动经营策略：分析 -> 可执行动作 -> 次日反馈
   ========================================================= */

replaceExact(
  'src/operations/operationsStoreV080.js',
`function dashboard(
  shopId
) {`,
`function strategyMenuRows(
  shopId,
  runtime
) {
  return (
    runtime.menu ||
    []
  )
    .filter(
      item =>
        item &&
        item.active !==
          false
    )
    .map(
      item => {
        const stats =
          item.stats ||
          {};

        const orders =
          Math.max(
            0,
            Number(
              stats.orders
            ) ||
            0
          );

        const revenue =
          Number(
            stats.revenue
          ) ||
          0;

        const variableCost =
          Number(
            stats.variableCost
          ) ||
          0;

        const estimatedCost =
          Math.max(
            0,
            estimateMenuItemCost(
              shopId,
              item
            )
          );

        const contribution =
          orders >
            0
            ? (
                revenue -
                variableCost
              ) /
              orders
            : (
                Number(
                  item.listPrice
                ) ||
                0
              ) -
              estimatedCost;

        const ratingCount =
          Math.max(
            0,
            Number(
              stats.ratingCount
            ) ||
            0
          );

        const rating =
          ratingCount >
            0
            ? (
                Number(
                  stats.ratingSum
                ) ||
                0
              ) /
              ratingCount
            : 0;

        return {
          item,
          orders,
          revenue,
          variableCost,
          estimatedCost,
          contribution,
          rating
        };
      }
    );
}

function operatingStrategyRecommendation(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return {
      id:'runtime_missing',
      executable:false,
      label:'门店运行数据不存在',
      detail:'等待门店运行时初始化'
    };
  }

  runtime.simulation =
    runtime.simulation ||
    {};

  if (
    Number(
      runtime
        .simulation
        .lastStrategyDay
    ) ===
      Number(
        runtime.day
      )
  ) {
    return {
      id:'strategy_wait',
      executable:false,
      label:'今日策略已执行，等待日结评估',
      detail:
        runtime
          .simulation
          .lastStrategyLabel ||
        '等待下一营业日重新诊断'
    };
  }

  const cycle =
    dailyOperatingCycle
      .brief(
        shopId
      );

  const latest =
    cycle &&
    cycle.latestClosed;

  const signals =
    latest &&
    latest.extra &&
    latest.extra
      .operatingSignals &&
    typeof latest.extra
      .operatingSignals ===
      'object'
      ? latest.extra
          .operatingSignals
      : {};

  const rows =
    strategyMenuRows(
      shopId,
      runtime
    );

  if (!rows.length) {
    return {
      id:'menu_missing',
      executable:false,
      label:'当前没有可经营菜品',
      detail:'先恢复至少一道在售菜品'
    };
  }

  const bestSeller =
    rows
      .slice()
      .sort(
        (a,b) =>
          b.orders -
            a.orders ||
          b.rating -
            a.rating ||
          b.contribution -
            a.contribution
      )[0];

  const featured =
    rows.find(
      row =>
        row.item.featured
    ) ||
    null;

  const lowestSeller =
    rows
      .filter(
        row =>
          !bestSeller ||
          row.item.id !==
            bestSeller.item.id
      )
      .slice()
      .sort(
        (a,b) =>
          a.orders -
            b.orders ||
          a.contribution -
            b.contribution
      )[0] ||
    null;

  const financial =
    latest &&
    latest.financial ||
    {};

  const waste =
    Math.max(
      0,
      Number(
        signals.expiredWasteValue
      ) ||
      0
    );

  const wasteHigh =
    waste >
    Math.max(
      30,
      (
        Number(
          financial.revenue
        ) ||
        0
      ) *
      0.02
    );

  if (
    wasteHigh &&
    rows.length >
      1 &&
    lowestSeller
  ) {
    return {
      id:'reduce_waste',
      action:'deactivate_low_seller',
      executable:true,
      menuItemId:
        lowestSeller
          .item.id,
      label:
        '暂时下架低销菜「' +
        lowestSeller
          .item.name +
        '」',
      detail:
        '上次过期损耗' +
        Math.round(
          waste
        ) +
        '元，先收窄菜单减少备货分散',
      successMessage:
        '已暂时下架低销菜，下一营业日观察损耗变化'
    };
  }

  if (
    Number(
      signals.stockouts
    ) >
      0 &&
    !wasteHigh
  ) {
    return {
      id:'repair_stockout',
      action:'restock',
      executable:true,
      label:'按当前菜单补齐缺货食材',
      detail:
        '上次有' +
        Number(
          signals.stockouts
        ) +
        '次缺货流失',
      successMessage:
        '已执行库存补充，下一营业日观察缺货与利润'
    };
  }

  if (
    Number(
      signals.priceWalkaways
    ) >
    0
  ) {
    const priceCandidate =
      rows
        .slice()
        .sort(
          (a,b) => {
            const aRatio =
              (
                Number(
                  a.item.listPrice
                ) ||
                0
              ) /
              Math.max(
                1,
                a.estimatedCost
              );

            const bRatio =
              (
                Number(
                  b.item.listPrice
                ) ||
                0
              ) /
              Math.max(
                1,
                b.estimatedCost
              );

            return (
              bRatio -
                aRatio ||
              b.item.listPrice -
                a.item.listPrice ||
              a.orders -
                b.orders
            );
          }
        )
        .find(
          row => {
            const price =
              Number(
                row.item.listPrice
              ) ||
              0;

            const floor =
              Math.max(
                3,
                row.estimatedCost *
                  1.6
              );

            return (
              price -
              Math.max(
                floor,
                price *
                  0.92
              )
            ) >=
              0.5;
          }
        );

    if (priceCandidate) {
      const price =
        Number(
          priceCandidate
            .item
            .listPrice
        ) ||
        0;

      const floor =
        Math.max(
          3,
          priceCandidate
            .estimatedCost *
            1.6
        );

      const target =
        Math.max(
          floor,
          price *
            0.92
        );

      const delta =
        Math.round(
          (
            target -
            price
          ) *
          10
        ) /
        10;

      return {
        id:'repair_price',
        action:'price_cut',
        executable:true,
        menuItemId:
          priceCandidate
            .item.id,
        delta,
        label:
          '小幅下调「' +
          priceCandidate
            .item.name +
          '」售价',
        detail:
          '上次有' +
          Number(
            signals.priceWalkaways
          ) +
          '位顾客因价格超预算离开',
        successMessage:
          '已小幅调价，下一营业日观察客流、客单和利润'
      };
    }
  }

  const repeatWeak =
    (
      Number(
        signals.repeatGuests
      ) +
      Number(
        signals.newGuests
      )
    ) >=
      8 &&
    Number(
      signals.avgRepeatIntent
    ) >
      0 &&
    Number(
      signals.avgRepeatIntent
    ) <
      0.38;

  if (
    bestSeller &&
    (
      repeatWeak ||
      !featured ||
      featured.item.id !==
        bestSeller.item.id
    )
  ) {
    return {
      id:
        repeatWeak
          ? 'repair_repeat'
          : 'feature_best_seller',
      action:'feature_dish',
      executable:true,
      menuItemId:
        bestSeller
          .item.id,
      label:
        '设「' +
        bestSeller
          .item.name +
        '」为招牌菜',
      detail:
        repeatWeak
          ? '复购意向偏弱，先集中稳定最受欢迎菜品'
          : '把真实热销菜强化为门店记忆点',
      successMessage:
        '招牌菜已调整，下一营业日观察点单与复购变化'
    };
  }

  return {
    id:'observe',
    executable:false,
    label:'当前经营结构稳定，继续观察1个营业日',
    detail:'暂时不建议为了操作而操作'
  };
}

function applyOperatingStrategy(
  shopId
) {
  const recommendation =
    operatingStrategyRecommendation(
      shopId
    );

  if (
    !recommendation ||
    !recommendation.executable
  ) {
    return {
      ok:false,
      reason:
        recommendation &&
        recommendation.label ||
        '当前没有可执行策略',
      recommendation
    };
  }

  const baseline =
    decisionContextSnapshot(
      shopId
    );

  let result =
    null;

  if (
    recommendation.action ===
      'restock'
  ) {
    result =
      autoRestock(
        shopId
      );

    if (
      result &&
      result.ok
    ) {
      recordTrackedDecision(
        shopId,
        'strategy_restock',
        {
          orders:
            Number(
              result.orders
            ) ||
            0,
          spent:
            Number(
              result.spent
            ) ||
            0,
          source:'active_strategy'
        },
        baseline
      );
    }
  } else if (
    recommendation.action ===
      'price_cut'
  ) {
    result =
      adjustMenuPrice(
        shopId,
        recommendation
          .menuItemId,
        recommendation.delta
      );
  } else if (
    recommendation.action ===
      'feature_dish'
  ) {
    result =
      setMenuFeatured(
        shopId,
        recommendation
          .menuItemId
      );
  } else if (
    recommendation.action ===
      'deactivate_low_seller'
  ) {
    result =
      setMenuActive(
        shopId,
        recommendation
          .menuItemId,
        false
      );

    if (
      result &&
      result.ok
    ) {
      recordTrackedDecision(
        shopId,
        'menu_focus',
        {
          menuItemId:
            recommendation
              .menuItemId,
          name:
            result.item &&
            result.item.name ||
            null,
          action:'deactivate',
          source:'active_strategy'
        },
        baseline
      );
    }
  } else {
    return {
      ok:false,
      reason:'策略动作暂不支持',
      recommendation
    };
  }

  if (
    !result ||
    result.ok ===
      false
  ) {
    return {
      ok:false,
      reason:
        result &&
        (
          result.reason ||
          result.message
        ) ||
        '策略执行失败',
      recommendation,
      result
    };
  }

  const runtime =
    getRuntime(
      shopId
    );

  if (runtime) {
    runtime.simulation =
      runtime.simulation ||
      {};

    runtime
      .simulation
      .lastStrategyDay =
      Number(
        runtime.day
      ) ||
      currentDay();

    runtime
      .simulation
      .lastStrategyAction =
      recommendation.id;

    runtime
      .simulation
      .lastStrategyLabel =
      recommendation.label;

    persist(
      shopId
    );
  }

  return {
    ok:true,
    message:
      recommendation
        .successMessage ||
      '经营策略已执行',
    recommendation,
    result
  };
}

function dashboard(
  shopId
) {`,
  'active strategy functions'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
`  autoRestock,
  dashboard
};`,
`  autoRestock,
  operatingStrategyRecommendation,
  applyOperatingStrategy,
  dashboard
};`,
  'active strategy exports'
);

/* =========================================================
   B. 经营页：首要策略 + 一键执行
   ========================================================= */

replaceExact(
  'src/scenes/businessScene.js',
`    const latestSignals =
      latest &&
      latest.extra &&
      latest.extra
        .operatingSignals
        ? latest.extra
            .operatingSignals
        : null;

    this.sectionCard(`,
`    const latestSignals =
      latest &&
      latest.extra &&
      latest.extra
        .operatingSignals
        ? latest.extra
            .operatingSignals
        : null;

    const strategy =
      operations
        .operatingStrategyRecommendation(
          shop.id
        );

    this.sectionCard(`,
  'strategy UI data'
);

replaceExact(
  'src/scenes/businessScene.js',
`    ui.text(
      ctx,
      nextAction
        ? '明日建议：' +
          nextAction.message
        : '明日建议：等待首次完整日结',
      28,
      620,
      6.5,
      nextAction
        ? '#C08824'
        : '#71858F',
      '700'
    );

    if (
      nextAction &&
      nextAction.routeId
    ) {
      opUi.button(
        ctx,
        nextAction.routeId ===
          'shop'
          ? '回门店'
          : '去处理',
        272,
        632,
        90,
        32,
        'gold'
      );

      this.addButton(
        'day:improve:' +
          nextAction.routeId,
        264,
        626,
        106,
        44
      );
    }

`,
`    ui.text(
      ctx,
      strategy
        ? '首要策略：' +
          strategy.label
        : nextAction
          ? '明日建议：' +
            nextAction.message
          : '明日建议：等待首次完整日结',
      28,
      620,
      6.5,
      strategy &&
      strategy.executable
        ? '#C08824'
        : nextAction
          ? '#C08824'
          : '#71858F',
      '700'
    );

    if (
      strategy &&
      strategy.executable
    ) {
      opUi.button(
        ctx,
        '执行策略',
        272,
        632,
        90,
        32,
        'gold'
      );

      this.addButton(
        'day:strategy',
        264,
        626,
        106,
        44
      );
    } else if (
      nextAction &&
      nextAction.routeId
    ) {
      opUi.button(
        ctx,
        nextAction.routeId ===
          'shop'
          ? '回门店'
          : '去处理',
        272,
        632,
        90,
        32,
        'gold'
      );

      this.addButton(
        'day:improve:' +
          nextAction.routeId,
        264,
        626,
        106,
        44
      );
    }

`,
  'strategy UI button'
);

replaceExact(
  'src/scenes/businessScene.js',
`        return true;
      }

      if (
        target.id.indexOf(
          'day:improve:'
        ) ===
        0
      ) {`,
`        return true;
      }

      if (
        target.id ===
        'day:strategy'
      ) {
        const result =
          operations
            .applyOperatingStrategy(
              shop.id
            );

        if (
          result &&
          result.ok
        ) {
          saveSystem
            .autoSave(true);
        }

        opUi.toast(
          result &&
          (
            result.message ||
            result.reason
          ) ||
          '策略执行失败'
        );

        return true;
      }

      if (
        target.id.indexOf(
          'day:improve:'
        ) ===
        0
      ) {`,
  'strategy click handler'
);

/* =========================================================
   C. 回归测试
   ========================================================= */

replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`const calibration=operations.runOperatingBalanceCalibration(100,{seed:20260915});
assert.ok(calibration.pass);
assert.equal(calibration.total,100);`,
`const calibration=operations.runOperatingBalanceCalibration(100,{seed:20260915});
assert.ok(calibration.pass);
assert.equal(calibration.total,100);

/*
 * 策略执行会登记为下一营业日决策，
 * 因而可能创建下一营业日 active。
 * 必须放在所有“上一营业日仍为closed”的兼容断言之后测试。
 */
for (
  const item
  of runtime.menu
) {
  item.featured =
    false;
}

const strategy =
  operations
    .operatingStrategyRecommendation(
      'shop_v0843_integration'
    );

assert.ok(
  strategy &&
  typeof strategy.label ===
    'string',
  '日结后必须生成首要经营策略'
);

assert.ok(
  strategy.executable,
  '测试门店必须获得一条可执行策略'
);

const appliedStrategy =
  operations
    .applyOperatingStrategy(
      'shop_v0843_integration'
    );

assert.ok(
  appliedStrategy.ok,
  '一键经营策略必须真正执行到底层系统'
);

const postStrategyCycle =
  operations
    .operatingDaySnapshot(
      'shop_v0843_integration'
    );

assert.equal(
  postStrategyCycle.status,
  'open',
  '执行日结后策略应登记到下一营业日，而不是篡改已结算营业日'
);

assert.ok(
  postStrategyCycle.latestClosed &&
  postStrategyCycle.latestClosed.financial,
  '创建下一营业日后必须继续保留上一完整日结'
);

const repeatedStrategy =
  operations
    .applyOperatingStrategy(
      'shop_v0843_integration'
    );

assert.equal(
  repeatedStrategy.ok,
  false,
  '同一营业日不能无限重复执行一键策略'
);

assert.ok(
  String(
    repeatedStrategy.reason ||
    ''
  ).includes(
    '等待日结评估'
  ),
  '执行一次策略后必须等待下一营业日评估'
);`,
  'strategy integration test after closed-state compatibility assertions'
);

replaceExact(
  'tests/businessDayUiV0844.test.js',
`    '热销菜：'
  ) &&`,
`    '热销菜：'
  ) &&
  businessSource.includes(
    '首要策略：'
  ) &&
  businessSource.includes(
    "'day:strategy'"
  ) &&
  businessSource.includes(
    '.applyOperatingStrategy('
  ) &&`,
  'strategy UI source assertions'
);

/* =========================================================
   D. 版本与仓库卫生
   ========================================================= */

updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 862
        versionName '0.8.62'`,
`        versionCode 863
        versionName '0.8.63'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.62 装修专业编辑器版启动成功'",
  "'城市餐饮经营小游戏 V0.8.63 主动经营决策版启动成功'",
  'startup banner'
);

/*
 * 清理历史误上传的大ZIP。
 * 当前真正用于更新的update.zip由工作流在提交前统一删除。
 */
for (
  const staleZip
  of [
    'city-restaurant-v0853-core-content-update.zip'
  ]
) {
  const full =
    fp(
      staleZip
    );

  if (
    fs.existsSync(
      full
    )
  ) {
    fs.rmSync(
      full,
      {
        force:true
      }
    );
  }
}

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0863] 主动经营决策完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
