'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function read(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

function write(rel, content) {
  fs.writeFileSync(path.join(ROOT, rel), content, 'utf8');
}

function must(condition, message) {
  if (!condition) throw new Error('[V1.0.2 IA] ' + message);
}

function replaceOnce(content, before, after, label) {
  if (content.includes(after)) return content;
  const first = content.indexOf(before);
  must(first >= 0, '找不到替换锚点：' + label);
  const second = content.indexOf(before, first + 1);
  must(second < 0, '替换锚点不唯一：' + label);
  return content.replace(before, after);
}

function replaceSection(content, startToken, endToken, replacement, label) {
  const start = content.indexOf(startToken);
  must(start >= 0, '找不到区块起点：' + label);
  const end = content.indexOf(endToken, start + startToken.length);
  must(end > start, '找不到区块终点：' + label);
  return content.slice(0, start) + replacement + content.slice(end);
}

function patchMain() {
  const rel = 'src/main.js';
  let c = read(rel);

  if (!c.includes("const moreScene = require('./scenes/moreScene.js');")) {
    c = replaceOnce(
      c,
      "const businessDataScene = require('./scenes/businessDataScene.js');",
      "const businessDataScene = require('./scenes/businessDataScene.js');\nconst moreScene = require('./scenes/moreScene.js');",
      'main require moreScene'
    );
  }

  if (!c.includes("sceneManager.register(\n  'more',\n  moreScene\n);")) {
    const anchor = "sceneManager.register(\n  'storeDetail',\n  storeDetailScene\n);";
    c = replaceOnce(
      c,
      anchor,
      anchor + "\n\nsceneManager.register(\n  'more',\n  moreScene\n);",
      'main register more'
    );
  }

  const oldRoute = `    // DATA_HUB_NAV_ROUTE_V1\n    const routedSceneId =\n      sceneId === 'shop'\n        ? (businessDataHub.hasStore({ gameState, citySystem, demandSystem }) ? 'storeDetail' : 'property')\n        : sceneId;`;
  const newRoute = `    // IA_ROUTING_V102：一级“门店”永远回到原门店总控，不再被数据页劫持。\n    const routedSceneId = sceneId;`;
  if (c.includes(oldRoute)) c = c.replace(oldRoute, newRoute);
  must(!c.includes("? (businessDataHub.hasStore({ gameState, citySystem, demandSystem }) ? 'storeDetail' : 'property')"), '门店路由仍被 storeDetail 劫持');

  const navStart = "const V33_NAV_ITEMS = [";
  const navEnd = "const v33PreviousLoadResources";
  const navReplacement = `const V33_NAV_ITEMS = [\n  { id: 'city', label: '城市', scene: 'city', normal: 'v33_nav_city', active: 'v33_nav_city_active' },\n  { id: 'shop', label: '门店', scene: 'shop', normal: 'v33_nav_store', active: 'v33_nav_store_active' },\n  { id: 'traffic', label: '客流', scene: 'traffic', normal: 'v33_nav_data', active: 'v33_nav_data_active' },\n  { id: 'research', label: '菜单', scene: 'research', normal: 'v33_nav_menu', active: 'v33_nav_menu_active' },\n  { id: 'supply', label: '供应链', scene: 'supply', normal: 'v33_nav_supply', active: 'v33_nav_supply_active' },\n  { id: 'more', label: '更多', scene: 'more', normal: 'v33_nav_system', active: 'v33_nav_system_active' }\n];\n\n`;
  c = replaceSection(c, navStart, navEnd, navReplacement, 'V33 primary nav');

  const activeStart = 'function v33ActiveNavId() {';
  const activeEnd = 'function v33DrawNavIconImage';
  const activeReplacement = `function v33ActiveNavId() {\n  const current = sceneManager.getCurrentId();\n\n  if (current === 'city') return trafficMode ? 'traffic' : 'city';\n\n  if (\n    current === 'shop' ||\n    current === 'propertyMarket' ||\n    current === 'storeDetail' ||\n    current === 'renovation' ||\n    current === 'equipment' ||\n    current === 'license' ||\n    current === 'staff' ||\n    current === 'schedule' ||\n    current === 'business'\n  ) {\n    return 'shop';\n  }\n\n  if (current === 'research') return 'research';\n  if (current === 'supply') return 'supply';\n\n  if (\n    current === 'more' ||\n    current === 'advancedManagement' ||\n    current === 'dynamicWorld' ||\n    current === 'system' ||\n    current === 'businessLegacy'\n  ) {\n    return 'more';\n  }\n\n  if (current === 'district' || current === 'districtDetail') return 'city';\n  return 'more';\n}\n\n`;
  c = replaceSection(c, activeStart, activeEnd, activeReplacement, 'V33 active nav');

  must(c.includes("{ id: 'traffic', label: '客流', scene: 'traffic'"), '客流未进入一级导航');
  must(c.includes("{ id: 'more', label: '更多', scene: 'more'"), '更多未进入一级导航');
  must(!c.includes("{ id: 'business', label: '数据', scene: 'business'"), '数据仍占一级导航');
  must(!c.includes("{ id: 'renovation', label: '装修', scene: 'renovation'"), '装修仍占一级导航');

  write(rel, c);
}

function patchStore() {
  const rel = 'src/scenes/storeScene.js';
  let c = read(rel);

  const funcsStart = '    const funcs = [';
  const funcsEnd = '    for (\n      let i = 0;\n      i < 5;';
  const start = c.indexOf(funcsStart, c.indexOf('renderOperating('));
  must(start >= 0, '找不到营业门店二级入口');
  const end = c.indexOf(funcsEnd, start);
  must(end > start, '找不到营业门店入口结束位置');
  const newFuncs = `    const funcs = [\n      [\n        'staff',\n        '员工',\n        'broker'\n      ],\n      [\n        'schedule',\n        '排班',\n        'route'\n      ],\n      [\n        'renovation-dynamic',\n        '装修',\n        'layout'\n      ],\n      [\n        'equipment',\n        '设备',\n        'lease'\n      ],\n      [\n        'finance',\n        '财务',\n        'rent'\n      ]\n    ];\n\n`;
  c = c.slice(0, start) + newFuncs + c.slice(end);

  const oldSceneMap = `    const sceneMap = {\n      renovation:\n          'renovation',\n      equipment:\n          'equipment',\n      license:\n          'license',\n      staff:\n          'staff',\n      research:\n          'research',\n      supply:\n          'supply',\n      day:\n          'business',\n      business:\n          'business'\n    };`;
  const newSceneMap = `    const sceneMap = {\n      renovation:\n          'renovation',\n      equipment:\n          'equipment',\n      license:\n          'license',\n      staff:\n          'staff',\n      schedule:\n          'schedule',\n      research:\n          'research',\n      supply:\n          'supply',\n      finance:\n          'business',\n      day:\n          'business',\n      business:\n          'business'\n    };`;
  c = replaceOnce(c, oldSceneMap, newSceneMap, 'store sceneMap');

  c = c.replace("'品牌升级',\n        'module:business'", "'经营报表',\n        'module:business'");

  must(c.includes("'finance',\n        '财务'"), '门店财务二级入口未生成');
  must(c.includes("schedule:\n          'schedule'"), '门店排班二级入口未接线');
  write(rel, c);
}

function patchDistrictDetail() {
  const rel = 'src/scenes/districtDetailScene.js';
  let c = read(rel);
  c = c.replace(
    "if (analytics.hasStore(this.context())) return sceneManager.switchTo('storeDetail', { districtId: this.districtId });",
    "if (analytics.hasStore(this.context())) return sceneManager.switchTo('shop', { districtId: this.districtId });"
  );
  must(!c.includes("return sceneManager.switchTo('storeDetail'"), '商圈详情仍跳转重复门店详情页');
  write(rel, c);
}

function patchBusinessReport() {
  const rel = 'src/scenes/businessDataScene.js';
  let c = read(rel);

  const overviewStart = '  drawOverview(ctx, d) {';
  const overviewEnd = '  drawPnl(ctx, d) {';
  const overviewReplacement = `  drawOverview(ctx, d) {\n    const c7 = d.compare7 || {};\n    const p = d.pnl || {};\n    const f = d.funnel || {};\n    const today = d.today || {};\n    const avgTicket = Math.max(0, Number(today.avgTicket) || 0);\n    const grossMargin = Math.max(0, Number(p.grossMargin) || 0);\n    const potentialLoss = Math.round((Number(f.lost) || 0) * avgTicket * grossMargin);\n    const variableRate = Number(p.revenue) > 0 ? Math.max(0, Math.min(0.95, Number(p.cogs) / Number(p.revenue))) : 0.35;\n    const contributionRate = Math.max(0.05, 1 - variableRate);\n    const fixedCost = Math.max(0, (Number(p.wages)||0) + (Number(p.utilities)||0) + (Number(p.rent)||0) + (Number(p.marketing)||0) + (Number(p.maintenance)||0) + (Number(p.other)||0));\n    const breakEvenRevenue = Math.round(fixedCost / contributionRate);\n    const breakEvenOrders = avgTicket > 0 ? Math.ceil(breakEvenRevenue / avgTicket) : 0;\n\n    ui.metricCompareCard(ctx, 10, 116, 116, 76, '近7日营业额', ui.money(d.last7.revenue), c7.revenue && c7.revenue.delta, '对比前7日');\n    ui.metricCompareCard(ctx, 137, 116, 116, 76, '近7日利润', ui.money(d.last7.profit), c7.profit && c7.profit.delta, '对比前7日', { valueColor: d.last7.profit < 0 ? ui.COLORS.red : ui.COLORS.green });\n    ui.metricCard(ctx, 264, 116, 116, 76, '今日流失', ui.number(f.lost) + '单', '潜在毛利 -' + ui.money(potentialLoss), { valueColor: f.lost > 0 ? ui.COLORS.red : ui.COLORS.green });\n\n    ui.sectionTitle(ctx, '今天真正要看什么', 220, '只保留能指导决策的数据', 390);\n    ui.rect(ctx, 10, 234, 370, 150, { fill: ui.COLORS.panel, stroke: ui.COLORS.line });\n    ui.row(ctx, 24, 260, 334, '今日营业额', ui.money(today.revenue));\n    ui.divider(ctx, 24, 276, 334);\n    ui.row(ctx, 24, 300, 334, '保本营业额', ui.money(breakEvenRevenue), today.revenue >= breakEvenRevenue ? ui.COLORS.green : ui.COLORS.red);\n    ui.divider(ctx, 24, 316, 334);\n    ui.row(ctx, 24, 340, 334, '保本订单', ui.number(breakEvenOrders) + '单');\n    ui.divider(ctx, 24, 356, 334);\n    ui.row(ctx, 24, 376, 334, '潜在毛利损失', ui.money(potentialLoss), potentialLoss > 0 ? ui.COLORS.red : ui.COLORS.green);\n\n    ui.sectionTitle(ctx, '最值得处理的问题', 414, '', 390);\n    const alerts = d.alerts || [];\n    if (!alerts.length) {\n      ui.alertBox(ctx, 10, 428, 370, { level:'info', title:'经营暂时稳定', detail:'没有高优先级异常；继续观察趋势，不需要为了数据而调整。' });\n    } else {\n      alerts.slice(0, 2).forEach((a, i) => ui.alertBox(ctx, 10, 428 + i * 62, 370, a));\n    }\n  }\n\n`;
  c = replaceSection(c, overviewStart, overviewEnd, overviewReplacement, 'business overview');

  if (!c.includes('  drawTrafficReport(ctx, d) {')) {
    const insertAt = c.indexOf('  drawActions(ctx) {');
    must(insertAt >= 0, '找不到经营报表动作区');
    const methods = `  drawTrafficReport(ctx, d) {\n    const f = d.funnel || {};\n    const today = d.today || {};\n    const p = d.pnl || {};\n    const potentialLoss = Math.round((Number(f.lost)||0) * (Number(today.avgTicket)||0) * Math.max(0, Number(p.grossMargin)||0));\n\n    ui.sectionTitle(ctx, '客流转化', 116, '只看客人在哪一步真正流失', 390);\n    ui.metricCard(ctx, 10, 130, 116, 73, '潜在订单', ui.number(f.potential) + '单', '被门店吸引');\n    ui.metricCard(ctx, 137, 130, 116, 73, '实际订单', ui.number(f.actual) + '单', ui.percent(f.conversionRate) + '转化');\n    ui.metricCard(ctx, 264, 130, 116, 73, '流失订单', ui.number(f.lost) + '单', '约损失' + ui.money(potentialLoss), { valueColor: f.lost > 0 ? ui.COLORS.red : ui.COLORS.green });\n\n    ui.sectionTitle(ctx, '流失原因', 230, '先处理最大的那一项', 390);\n    ui.rect(ctx, 10, 244, 370, 214, { fill: ui.COLORS.panel, stroke: ui.COLORS.line });\n    const reasons = f.reasons || {};\n    const rows = [\n      ['缺货', Number(reasons.stock)||0],\n      ['厨房产能', Number(reasons.kitchen)||0],\n      ['餐位不足', Number(reasons.seats)||0],\n      ['等待过久', Number(reasons.wait)||0],\n      ['价格不匹配', Number(reasons.price)||0],\n      ['品质/口碑', Number(reasons.quality)||0]\n    ].sort((a,b)=>b[1]-a[1]);\n    const max = Math.max(1, ...rows.map(x=>x[1]));\n    rows.forEach((r, i) => {\n      const y = 273 + i * 30;\n      ui.text(ctx, r[0], 24, y, 7.1, ui.COLORS.text, '600');\n      ui.progress(ctx, 126, y - 4, 170, r[1] / max, { fill: r[1] > 0 ? ui.COLORS.red : '#D8D2CA', height: 8 });\n      ui.text(ctx, ui.number(r[1]) + '单', 354, y, 7, r[1] > 0 ? ui.COLORS.red : ui.COLORS.muted, '700', 'right');\n    });\n\n    ui.rect(ctx, 10, 482, 370, 94, { fill: ui.COLORS.paleBlue, stroke: '#BCD3DE' });\n    ui.text(ctx, '阅读方式', 24, 502, 8, ui.COLORS.text, '700');\n    ui.text(ctx, '商圈总需求只作背景；玩家真正要处理的是潜在订单到实际订单之间的流失。', 24, 529, 6.4, ui.COLORS.text, '600');\n    ui.text(ctx, '菜品、库存、员工和装修的详细原因回各自页面处理。', 24, 554, 6.4, ui.COLORS.muted, '500');\n  }\n\n  drawTrendReport(ctx, d) {\n    const c7 = d.compare7 || {};\n    ui.sectionTitle(ctx, '经营趋势', 116, '跨期变化放在报表，门店首页只看今天', 390);\n    ui.metricCompareCard(ctx, 10, 130, 116, 76, '7日营业额', ui.money(d.last7.revenue), c7.revenue && c7.revenue.delta, '对比前7日');\n    ui.metricCompareCard(ctx, 137, 130, 116, 76, '7日订单', ui.number(d.last7.orders), c7.orders && c7.orders.delta, '对比前7日');\n    ui.metricCompareCard(ctx, 264, 130, 116, 76, '7日利润', ui.money(d.last7.profit), c7.profit && c7.profit.delta, '对比前7日', { valueColor: d.last7.profit >= 0 ? ui.COLORS.green : ui.COLORS.red });\n\n    ui.rect(ctx, 10, 230, 370, 180, { fill: ui.COLORS.panel, stroke: ui.COLORS.line });\n    ui.text(ctx, '营业额趋势', 24, 252, 7, ui.COLORS.muted, '600');\n    ui.sparkline(ctx, 24, 272, 342, 48, d.trend || [], 'revenue', ui.COLORS.blue);\n    ui.text(ctx, '利润趋势', 24, 344, 7, ui.COLORS.muted, '600');\n    ui.sparkline(ctx, 24, 364, 342, 34, d.trend || [], 'profit', ui.COLORS.green);\n\n    ui.rect(ctx, 10, 436, 370, 116, { fill: ui.COLORS.paleGold, stroke: '#E5C98D' });\n    ui.text(ctx, '为什么趋势单独放二级报表', 24, 458, 8, ui.COLORS.text, '700');\n    ui.text(ctx, '单日波动适合门店现场决策；7日与更长周期适合判断经营方向。', 24, 486, 6.5, ui.COLORS.text, '600');\n    ui.text(ctx, '以后30日、同星期对比、门店间对标都继续扩在这里，不再占一级页面。', 24, 516, 6.2, ui.COLORS.muted, '500');\n  }\n\n`;
    c = c.slice(0, insertAt) + methods + c.slice(insertAt);
  }

  const oldRender = `    ui.header(ctx, '经营数据中枢', d.store ? d.store.name + ' · 所有页面共用同一套数据口径' : '尚未开店 · 市场数据仍可查看', 390, ui.money(player && player.cash));\n    ui.tabBar(ctx, [{label:'总览'}, {label:'损益'}, {label:'菜品'}, {label:'库存人效'}, {label:'产能现金'}], this.tab, 75, this.addButton.bind(this), 390);\n    if (!d.store) {\n      ui.rect(ctx, 12, 130, 366, 170, { fill:ui.COLORS.panel, stroke:ui.COLORS.line });\n      ui.text(ctx, '开店后这里会自动形成日 / 7日 / 30日经营账。', 195, 185, 9, ui.COLORS.text, '700', 'center');\n      ui.text(ctx, '当前可先从城市与商圈详情查看人口、需求、客群、租金和竞争。', 195, 221, 7, ui.COLORS.muted, '500', 'center');\n    } else if (this.tab === 0) this.drawOverview(ctx, d);\n    else if (this.tab === 1) this.drawPnl(ctx, d);\n    else if (this.tab === 2) this.drawDishes(ctx, d);\n    else if (this.tab === 3) this.drawSupplyStaff(ctx, d);\n    else this.drawCapacityCash(ctx, d);`;
  const newRender = `    ui.header(ctx, '经营报表', d.store ? d.store.name + ' · 深度复盘，不占门店首页' : '尚未开店 · 报表将在营业后形成', 390, ui.money(player && player.cash));\n    ui.tabBar(ctx, [{label:'总览'}, {label:'财务'}, {label:'客流'}, {label:'趋势'}], this.tab, 75, this.addButton.bind(this), 390);\n    if (!d.store) {\n      ui.rect(ctx, 12, 130, 366, 170, { fill:ui.COLORS.panel, stroke:ui.COLORS.line });\n      ui.text(ctx, '开店后这里形成跨期经营报表。', 195, 185, 9, ui.COLORS.text, '700', 'center');\n      ui.text(ctx, '菜品、库存、员工、装修等详细数据回各自模块查看。', 195, 221, 7, ui.COLORS.muted, '500', 'center');\n    } else if (this.tab === 0) this.drawOverview(ctx, d);\n    else if (this.tab === 1) this.drawPnl(ctx, d);\n    else if (this.tab === 2) this.drawTrafficReport(ctx, d);\n    else this.drawTrendReport(ctx, d);`;
  c = replaceOnce(c, oldRender, newRender, 'business render tabs');

  c = c.replace(
    "if (hit.id === 'action:store') return sceneManager.switchTo('storeDetail', { districtId });",
    "if (hit.id === 'action:store') return sceneManager.switchTo('shop', { districtId });"
  );

  must(c.includes("ui.header(ctx, '经营报表'"), '经营数据中枢没有降级为经营报表');
  must(c.includes("{label:'客流'}"), '经营报表缺少客流标签');
  must(!c.includes("ui.tabBar(ctx, [{label:'总览'}, {label:'损益'}, {label:'菜品'}"), '旧复杂报表标签仍在使用');
  write(rel, c);
}

function validateSyntax(rel) {
  const content = read(rel);
  must(content.trim().length > 20, rel + ' 内容异常为空');
}

patchMain();
patchStore();
patchDistrictDetail();
patchBusinessReport();

[
  'src/main.js',
  'src/scenes/storeScene.js',
  'src/scenes/districtDetailScene.js',
  'src/scenes/businessDataScene.js',
  'src/scenes/moreScene.js'
].forEach(validateSyntax);

console.log('[V1.0.2 IA] 分流架构安装完成');
console.log('[V1.0.2 IA] 一级：城市 / 门店 / 客流 / 菜单 / 供应链 / 更多');
console.log('[V1.0.2 IA] 门店：员工 / 排班 / 装修 / 设备 / 财务');
console.log('[V1.0.2 IA] 经营数据中枢已降级为二级经营报表');
