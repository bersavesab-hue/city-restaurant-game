'use strict';

const fs = require('fs');
const cp = require('child_process');

const pkgPath='package.json';
if(!fs.existsSync(pkgPath)) throw new Error('package.json not found');

// Run one conservative cleanup pass first. Do NOT run npm test/build here;
// the existing GitHub workflow does that immediately after this patch.
const r=cp.spawnSync(process.execPath,['scripts/project-cleaner.js','--apply'],{
  cwd:process.cwd(),encoding:'utf8',stdio:'inherit'
});
if(r.status!==0) process.exit(r.status||1);

const pkg=JSON.parse(fs.readFileSync(pkgPath,'utf8'));
pkg.scripts=pkg.scripts||{};
pkg.scripts['cleanup:scan']='node scripts/project-cleaner.js';
pkg.scripts['cleanup:apply']='node scripts/project-cleaner.js --apply';

// Only remove broken legacy pretest segments whose referenced script is ALREADY missing.
// Active legacy hooks remain until their behavior is baked into current source code.
if(typeof pkg.scripts.pretest==='string'){
  const parts=pkg.scripts.pretest.split(/\s*&&\s*/).filter(Boolean);
  const kept=[];
  for(const cmd of parts){
    const m=cmd.match(/^node\s+([^\s]+\.js)(?:\s|$)/i);
    if(m && !fs.existsSync(m[1])){
      console.log('[cleanup-bot-v2] remove broken pretest hook:',cmd);
      continue;
    }
    kept.push(cmd);
  }
  if(kept.length) pkg.scripts.pretest=kept.join(' && ');
  else delete pkg.scripts.pretest;
}

fs.writeFileSync(pkgPath,JSON.stringify(pkg,null,2)+'\n','utf8');
console.log('[cleanup-bot-v2] installed cleanup scripts; CI will now run normal test/build validation.');
