'use strict';

/**
 * City Restaurant operating systems V1.0.6 installer
 *
 * 修复 V1.0.5 的根本问题：不再正则改 src/main.js / demandSystem.js / package.json。
 * 只在 Android 固定入口末尾加载经营中枢；其余接线全部在运行时完成。
 */

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const root = process.cwd();
const VERSION = '1.0.6';
const MARKER = 'CITY_RESTAURANT_OPERATING_V106';

function full(rel) { return path.join(root, rel); }
function exists(rel) { return fs.existsSync(full(rel)); }
function read(rel) { return fs.readFileSync(full(rel), 'utf8'); }
function assert(ok, msg) { if (!ok) throw new Error('[V1.0.6 installer] ' + msg); }
function count(s, needle) { return s.split(needle).length - 1; }

const required = [
  'src/operating/eventCatalogV106.js',
  'src/operating/businessOperatingSystemV106.js',
  'src/operating/operatingRuntimeBridgeV106.js',
  'tests/operatingSystemsV106.test.js',
  'scripts/audit-operating-v106.js',
  'android/entry.js',
  'src/core/gameState.js',
  'src/core/timeSystem.js',
  'src/city/demandSystem.js',
  'package.json'
];
for (const rel of required) assert(exists(rel), '缺少文件：' + rel);

const pkg = JSON.parse(read('package.json'));
assert(pkg && pkg.scripts && typeof pkg.scripts.test === 'string', 'package.json scripts.test 不存在');
assert(typeof pkg.scripts['build:android-js'] === 'string', 'package.json build:android-js 不存在');

let entry = read('android/entry.js');
assert(/GameRuntime/.test(entry), 'android/entry.js 不是当前游戏运行入口，拒绝误改');
assert(/src\/main\.js/.test(entry), 'android/entry.js 未发现主游戏加载语句，拒绝误改');

const bridgeNeedle = "require('../src/operating/operatingRuntimeBridgeV106.js')";
if (!entry.includes(bridgeNeedle)) {
  entry = entry.replace(/\s*$/, '') + `\n\n/* ${MARKER} */\n${bridgeNeedle};\n`;
}
assert(count(entry, bridgeNeedle) === 1, '经营中枢入口重复');

// 只写 Android 入口；不碰 main.js、demandSystem.js、package.json。
fs.writeFileSync(full('android/entry.js'), entry, 'utf8');

const syntaxTargets = [
  'android/entry.js',
  'src/operating/eventCatalogV106.js',
  'src/operating/businessOperatingSystemV106.js',
  'src/operating/operatingRuntimeBridgeV106.js',
  'tests/operatingSystemsV106.test.js',
  'scripts/audit-operating-v106.js'
];
for (const rel of syntaxTargets) {
  const result = cp.spawnSync(process.execPath, ['--check', full(rel)], { encoding: 'utf8' });
  if (result.status !== 0) {
    process.stderr.write(result.stdout || '');
    process.stderr.write(result.stderr || '');
    throw new Error('[V1.0.6 installer] 语法检查失败：' + rel);
  }
}

let result = cp.spawnSync(process.execPath, [full('tests/operatingSystemsV106.test.js')], {
  encoding: 'utf8', cwd: root
});
process.stdout.write(result.stdout || '');
process.stderr.write(result.stderr || '');
assert(result.status === 0, '经营中枢功能测试失败');

result = cp.spawnSync(process.execPath, [full('scripts/audit-operating-v106.js')], {
  encoding: 'utf8', cwd: root
});
process.stdout.write(result.stdout || '');
process.stderr.write(result.stderr || '');
assert(result.status === 0, '经营中枢接线审计失败');

console.log('[V1.0.6 installer] PASS — 无侵入接入完成。');
console.log('[V1.0.6 installer] untouched: src/main.js / src/city/demandSystem.js / package.json');
