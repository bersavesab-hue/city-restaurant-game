'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.51';
const TARGET_VERSION = '0.8.52';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0852] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0852] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* 1) 把每日目标连胜接入现有成就目录，不新造平行奖励系统。 */
replaceExact(
  'src/progress/growthAchievementSystemV0833.js',
`    {id:'easter_3',name:'彩蛋收藏家',metric:'easterEvents',target:3,points:35},
    {id:'achievement_20',name:'经营收藏家',metric:'achievementCount',target:20,points:120}`,
`    {id:'easter_3',name:'彩蛋收藏家',metric:'easterEvents',target:3,points:35},
    {id:'goal_streak_3',name:'三日稳进',metric:'bestGoalStreak',target:3,points:0},
    {id:'goal_streak_7',name:'七日连稳',metric:'bestGoalStreak',target:7,points:0},
    {id:'goal_streak_14',name:'十四日节奏',metric:'bestGoalStreak',target:14,points:0},
    {id:'goal_streak_30',name:'三十日掌控',metric:'bestGoalStreak',target:30,points:0},
    {id:'achievement_20',name:'经营收藏家',metric:'achievementCount',target:20,points:120}`,
  'goal streak achievement catalog'
);

replaceExact(
  'src/progress/growthAchievementSystemV0833.js',
`        storeCount:1,
        achievementCount:0
      },`,
`        storeCount:1,
        achievementCount:0,
        goalsCompleted:0,
        goalsMissed:0,
        goalStreak:0,
        bestGoalStreak:0
      },`,
  'growth goal metrics defaults'
);

/* 2) 专用同步接口：只更新目标相关指标，不覆盖其他成长数据。 */
replaceExact(
  'src/progress/growthAchievementSystemV0833.js',
`function addClue(
  hiddenId,
  clue
) {`,
`function syncGoalProgress(
  shopId,
  input
) {
  const state =
    ensureShop(shopId);

  const source =
    input &&
    typeof input ===
      'object'
      ? input
      : {};

  const currentStreak =
    Math.max(
      0,
      Number(
        source.goalStreak
      ) ||
      0
    );

  state.metrics
    .goalStreak =
    currentStreak;

  state.metrics
    .bestGoalStreak =
    Math.max(
      Number(
        state.metrics
          .bestGoalStreak
      ) ||
      0,
      Number(
        source.bestGoalStreak
      ) ||
      0,
      currentStreak
    );

  state.metrics
    .goalsCompleted =
    Math.max(
      Number(
        state.metrics
          .goalsCompleted
      ) ||
      0,
      Number(
        source.goalsCompleted
      ) ||
      0
    );

  state.metrics
    .goalsMissed =
    Math.max(
      Number(
        state.metrics
          .goalsMissed
      ) ||
      0,
      Number(
        source.goalsMissed
      ) ||
      0
    );

  const achievements =
    evaluateAchievements(
      shopId
    );

  const features =
    evaluateUnlocks(
      shopId
    );

  const unlocks =
    achievements.concat(
      features
    );

  state.recentUnlocks =
    unlocks.concat(
      state.recentUnlocks
    ).slice(
      0,
      40
    );

  return {
    version:VERSION,
    unlocked:
      clone(
        unlocks
      ),
    metrics:
      clone(
        state.metrics
      ),
    achievementPoints:
      getRoot()
        .global
        .achievementPoints
  };
}

function addClue(
  hiddenId,
  clue
) {`,
  'sync goal progress'
);

replaceExact(
  'src/progress/growthAchievementSystemV0833.js',
`  evaluate,
  addClue,`,
`  evaluate,
  syncGoalProgress,
  addClue,`,
  'export goal progress sync'
);

/* 3) 日结后把目标连胜同步进成长系统，并把里程碑解锁结果返回给UI。 */
replaceExact(
  'src/operations/operationsStoreV080.js',
`        result.dailyBrief =
          daily &&
          daily.brief ||
          null;

        result.decisionFeedback =`,
`        result.dailyBrief =
          daily &&
          daily.brief ||
          null;

        const goalCycle =
          dailyOperatingCycle
            .brief(
              shopId
            );

        result.goalGrowth =
          growthAchievementSystem
            .syncGoalProgress(
              shopId,
              goalCycle &&
              goalCycle.metrics ||
              {}
            );

        result.decisionFeedback =`,
  'sync goal milestones after daily close'
);

/* 4) 营业页显示距离下一连胜里程碑还有几天。 */
replaceExact(
  'src/scenes/businessScene.js',
`    const goalLine =
      active &&
      active.goal
        ? '今日目标：' +
          active.goal.label +
          (
            goalStreak >
              0
              ? ' · 连续' +
                goalStreak +
                '天'
              : ''
          )
        : latest &&`,
`    const goalMilestones =
      [
        3,
        7,
        14,
        30
      ];

    const nextGoalMilestone =
      goalMilestones.find(
        target =>
          goalStreak <
          target
      ) ||
      null;

    const goalMilestoneText =
      (
        active &&
        active.goal
      ) ||
      (
        latest &&
        latest.goalResult
      )
        ? nextGoalMilestone
          ? ' · 连续' +
            goalStreak +
            '天/距' +
            nextGoalMilestone +
            '日还' +
            (
              nextGoalMilestone -
              goalStreak
            ) +
            '天'
          : ' · 30日里程碑已达成'
        : '';

    const goalLine =
      active &&
      active.goal
        ? '今日目标：' +
          active.goal.label
        : latest &&`,
  'goal milestone progress text'
);

replaceExact(
  'src/scenes/businessScene.js',
`      goalLine,
      28,
      207,`,
`      goalLine +
      goalMilestoneText,
      28,
      207,`,
  'render milestone progress'
);

/* 5) 达成里程碑时，日结Toast优先显示新成就。 */
replaceExact(
  'src/scenes/businessScene.js',
`          opUi.toast(
            result.ok
              ? result.dailyBrief &&
                result.dailyBrief
                  .goalResult
                ? result.dailyBrief
                    .goalResult
                    .completed
                  ? '日结完成 · 今日目标达成'
                  : '日结完成 · 今日目标未达成'
                : '日结完成，经营复盘已生成'
              : result.reason ||
                '无法完成日结'
          );`,
`          const milestone =
            result.ok &&
            result.goalGrowth &&
            Array.isArray(
              result.goalGrowth
                .unlocked
            )
              ? result.goalGrowth
                  .unlocked
                  .find(
                    item =>
                      item &&
                      item.type ===
                        'achievement' &&
                      item.metric ===
                        'bestGoalStreak'
                  )
              : null;

          opUi.toast(
            result.ok
              ? milestone
                ? '里程碑达成 · ' +
                  milestone.name
                : result.dailyBrief &&
                  result.dailyBrief
                    .goalResult
                  ? result.dailyBrief
                      .goalResult
                      .completed
                    ? '日结完成 · 今日目标达成'
                    : '日结完成 · 今日目标未达成'
                  : '日结完成，经营复盘已生成'
              : result.reason ||
                '无法完成日结'
          );`,
  'milestone toast'
);

/* 6) 既有成长测试验证四档目标里程碑。 */
replaceExact(
  'tests/growthAchievementSystemV0833.test.js',
`assert.equal(overview.achievementCatalog.length,32);`,
`assert.equal(overview.achievementCatalog.length,36);`,
  'achievement catalog size'
);

replaceExact(
  'tests/growthAchievementSystemV0833.test.js',
`assert.ok(overview.unlockedFeatures.length>=5);

const firstHidden =`,
`assert.ok(overview.unlockedFeatures.length>=5);

const goalSync =
  growth
    .syncGoalProgress(
      'shop_growth_v0833',
      {
        goalsCompleted:7,
        goalsMissed:1,
        goalStreak:7,
        bestGoalStreak:7
      }
    );

assert.ok(
  goalSync.unlocked.some(
    item =>
      item.id ===
      'goal_streak_3'
  )
);

assert.ok(
  goalSync.unlocked.some(
    item =>
      item.id ===
      'goal_streak_7'
  )
);

assert.ok(
  !goalSync.unlocked.some(
    item =>
      item.id ===
      'goal_streak_14'
  )
);

assert.equal(
  goalSync.metrics.bestGoalStreak,
  7
);

const firstHidden =`,
  'goal milestone growth tests'
);

/* 7) 营业日集成测试验证目标进度确实进入成长系统。 */
replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`assert.ok(Array.isArray(closed.decisionFeedback));`,
`assert.ok(
  closed.goalGrowth,
  '日结后必须同步目标进度到成长系统'
);
assert.ok(
  closed.goalGrowth.metrics.bestGoalStreak >=
    1,
  '成长系统必须记录目标最佳连胜'
);
assert.ok(Array.isArray(closed.decisionFeedback));`,
  'goal growth integration'
);

/* 8) UI源码回归，确保里程碑进度和达成提示不被后续改丢。 */
replaceExact(
  'tests/businessDayUiV0844.test.js',
`    'goalStreak'
  ),`,
`    'goalStreak'
  ) &&
  businessSource.includes(
    '日里程碑'
  ) &&
  businessSource.includes(
    'goalGrowth'
  ) &&
  businessSource.includes(
    '里程碑达成'
  ),`,
  'goal milestone UI assertions'
);

/* 9) 版本同步。 */
updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 851
        versionName '0.8.51'`,
`        versionCode 852
        versionName '0.8.52'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.51 每日经营目标版启动成功'",
  "'城市餐饮经营小游戏 V0.8.52 经营里程碑版启动成功'",
  'startup banner'
);

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0852] 经营里程碑补丁完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
