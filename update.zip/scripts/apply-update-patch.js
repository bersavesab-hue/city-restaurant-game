'use strict';

const fs = require('fs');
const cp = require('child_process');

const DEMAND_TARGET = 'src/city/demandSystem.js';
const SHOP_TARGET = 'src/scenes/shopScene.js';
const TRAFFIC_TARGET = 'src/city/customerTrafficSystem.js';

function mustExist(path) {
  if (!fs.existsSync(path)) {
    throw new Error('V1.0.3 patch target missing: ' + path);
  }
}

function checkSyntax(path) {
  const result = cp.spawnSync(process.execPath, ['--check', path], {
    encoding: 'utf8'
  });

  if (result.status !== 0) {
    process.stderr.write(result.stdout || '');
    process.stderr.write(result.stderr || '');
    throw new Error('Syntax check failed: ' + path);
  }
}

mustExist(DEMAND_TARGET);
mustExist(TRAFFIC_TARGET);

let demand = fs.readFileSync(DEMAND_TARGET, 'utf8');

if (!demand.includes("require('./customerTrafficSystem.js')")) {
  const anchor = "const gameState =\n  require('../core/gameState.js');";

  if (!demand.includes(anchor)) {
    throw new Error('V1.0.3 demandSystem require anchor not found');
  }

  demand = demand.replace(
    anchor,
    anchor +
      "\n\nconst customerTrafficSystem =\n" +
      "  require('./customerTrafficSystem.js');"
  );
}

if (!demand.includes('getTrafficFunnel(')) {
  const classEnd = '\n}\n\nconst demandSystem =\n  new DemandSystem();';

  if (!demand.includes(classEnd)) {
    throw new Error('V1.0.3 demandSystem class end anchor not found');
  }

  const methods = `

  // V1.0.3：店铺面积/硬件经营形态判定
  getStoreFormat(store) {
    return customerTrafficSystem.classifyStore(
      store || {}
    );
  }

  // V1.0.3：商圈需求 -> 门前客流 -> 进店 -> 排队 -> 成交 -> 流失
  getTrafficFunnel(
    districtId,
    store,
    options
  ) {
    const pool =
      this.createDemandPool(
        districtId
      );

    if (!pool) {
      return null;
    }

    const result =
      customerTrafficSystem.simulate({
        district:
          citySystem.getDistrict(
            districtId
          ),
        demandPool:
          pool,
        store:
          store || {},
        customerTypes:
          CUSTOMER_TYPES,
        weatherModifier:
          this.getWeatherModifier(),
        mealPeriod:
          pool.mealPeriod,
        ...(options || {})
      });

    // 当前 pool 是本次快照，消费后保留剩余需求，
    // 后续玩家店/NPC店可继续共同使用同一需求池实现竞争。
    this.consumeDemand(
      pool,
      result.funnel.actualCustomers
    );

    result.demandPool = pool;

    return result;
  }
`;

  demand = demand.replace(
    classEnd,
    methods + classEnd
  );
}

fs.writeFileSync(DEMAND_TARGET, demand, 'utf8');

// 找铺页只做“数据接入”，不改变当前稳定UI布局。
// 这样后续二级详情页可以直接读取 businessFormat，避免再次重复面积判断。
if (fs.existsSync(SHOP_TARGET)) {
  let shop = fs.readFileSync(SHOP_TARGET, 'utf8');

  if (!shop.includes("require('../city/customerTrafficSystem.js')")) {
    const anchor = "const citySystem =\n  require('../city/citySystem.js');";

    if (!shop.includes(anchor)) {
      throw new Error('V1.0.3 shopScene require anchor not found');
    }

    shop = shop.replace(
      anchor,
      anchor +
        "\n\nconst customerTrafficSystem =\n" +
        "  require('../city/customerTrafficSystem.js');"
    );
  }

  if (!shop.includes('businessFormat:')) {
    const returnAnchor = `    return {
      ...item,

      competitorCount:`;

    if (!shop.includes(returnAnchor)) {
      throw new Error('V1.0.3 shopScene live listing anchor not found');
    }

    shop = shop.replace(
      returnAnchor,
      `    const businessFormat =
      customerTrafficSystem
        .classifyStore(
          item
        );

    return {
      ...item,

      businessFormat,
      businessFormatId:
        businessFormat.id,
      businessFormatName:
        businessFormat.name,
      dineInAllowed:
        businessFormat.dineInAllowed,
      seatCapacityByFormat:
        businessFormat.seatCapacity,
      hotKitchenReady:
        businessFormat.hotKitchenReady,

      competitorCount:`
    );
  }

  fs.writeFileSync(SHOP_TARGET, shop, 'utf8');
  checkSyntax(SHOP_TARGET);
}

checkSyntax(TRAFFIC_TARGET);
checkSyntax(DEMAND_TARGET);

// 独立 smoke test：不依赖完整游戏运行时。
const traffic = require('../src/city/customerTrafficSystem.js');

const stall = traffic.classifyStore({
  usableArea: 10,
  exhaust: true,
  drainage: true,
  fireSprinkler: true
});

if (stall.id !== 'stall' || stall.dineInAllowed || stall.seatCapacity !== 0) {
  throw new Error('V1.0.3 smoke failed: 10㎡ stall classification');
}

const small = traffic.classifyStore({
  usableArea: 48,
  exhaust: true,
  drainage: true,
  greaseTrap: true,
  fireSprinkler: true,
  threePhase: true
});

if (small.id !== 'small_restaurant' || !small.dineInAllowed || small.seatCapacity < 12) {
  throw new Error('V1.0.3 smoke failed: small restaurant classification');
}

const funnel = traffic.simulate({
  mealPeriod: 'lunch',
  district: {
    saturation: 72,
    baseDemand: 1600
  },
  demandPool: {
    mealPeriod: 'lunch',
    totalDemand: 420,
    remainingDemand: 420,
    customerGroups: {
      office: { demand: 260 },
      resident: { demand: 160 }
    }
  },
  customerTypes: {
    office: { speedSensitivity: 0.92 },
    resident: { speedSensitivity: 0.48 }
  },
  store: {
    usableArea: 32,
    footfall: 7600,
    visibility: 82,
    frontage: 4.3,
    rating: 3.8,
    reputation: 47,
    priceFit: 68,
    menuAppeal: 63,
    exhaust: true,
    drainage: true,
    greaseTrap: true,
    fireSprinkler: true,
    threePhase: true,
    staffCount: 2
  }
});

if (
  !funnel ||
  funnel.funnel.periodPassers <= 0 ||
  funnel.funnel.actualCustomers < 0 ||
  funnel.funnel.actualCustomers > funnel.funnel.attempted ||
  funnel.funnel.lostCustomers !==
    funnel.funnel.attempted - funnel.funnel.actualCustomers
) {
  throw new Error('V1.0.3 smoke failed: traffic funnel invariant');
}

console.log('[V1.0.3] customer traffic + store format patch PASS');
