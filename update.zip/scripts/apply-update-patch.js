'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const TARGET_VERSION = '0.8.61';
const TARGET_CODE = 861;

function file(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(file(rel), 'utf8');
}

function write(rel, content) {
  const abs = file(rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, content, 'utf8');
}

function must(condition, message) {
  if (!condition) {
    throw new Error('[V0861] ' + message);
  }
}

function replaceOnce(source, search, replacement, label) {
  if (typeof search === 'string') {
    must(source.includes(search), '找不到补丁锚点：' + label);
    return source.replace(search, replacement);
  }

  must(search.test(source), '找不到补丁锚点：' + label);
  search.lastIndex = 0;
  return source.replace(search, replacement);
}

const storePath = 'src/scenes/storeScene.js';
const prepPath = 'src/opening/openingPrepSystem.js';
const runnerPath = 'scripts/run-ci-tests-v060.js';
const testPath = 'tests/preparationCommandCenterV0861.test.js';
const manifestPath = 'PATCH_MANIFEST_V0861.json';

let prep = read(prepPath);

if (!prep.includes('V0861_PREPARATION_COMMAND_CENTER_SYSTEM')) {
  prep = replaceOnce(
    prep,
    '// V084_PERSON_CANDIDATES',
    '// V084_PERSON_CANDIDATES\n// V0861_PREPARATION_COMMAND_CENTER_SYSTEM',
    'openingPrep system marker'
  );

  const method = String.raw`
  getPreparationBoard(
    shopId,
    readinessInput
  ) {
    const readiness =
      readinessInput ||
      this.getReadiness(
        shopId
      );

    const day =
      this.getCurrentDay();

    const cash =
      Number(
        gameState
          .getPlayer()
          .cash
      ) || 0;

    const renovation =
      renovationSystem
        .ensurePlan(
          shopId
        );

    const equipment =
      readiness.equipment ||
      this.ensureEquipment(
        shopId
      );

    const permits =
      readiness.permits ||
      this.getPermitOverview(
        shopId
      );

    const staffing =
      readiness.staffing ||
      this.getStaffOverview(
        shopId
      );

    const permitRows =
      Array.isArray(
        permits &&
        permits.rows
      )
        ? permits.rows
        : [];

    const applyingRows =
      permitRows.filter(
        row =>
          row.status ===
          'applying'
      );

    const actionableRows =
      permitRows.filter(
        row =>
          row.status ===
            'not_applied' &&
          row.ready
      );

    const fixableRows =
      permitRows.filter(
        row =>
          row.remediable &&
          (
            row.status ===
              'needs_fix' ||
            !row.ready
          )
      );

    const blockedPermitRows =
      permitRows.filter(
        row =>
          row.status ===
            'not_applied' &&
          !row.ready &&
          !row.remediable
      );

    const requiredTotal =
      staffing &&
      staffing.required
        ? Object.values(
            staffing.required
          ).reduce(
            (sum, value) =>
              sum +
              Math.max(
                0,
                Number(value) || 0
              ),
            0
          )
        : 0;

    const hiredCount =
      staffing &&
      Array.isArray(
        staffing.hired
      )
        ? staffing.hired.length
        : 0;

    const candidates =
      staffing &&
      Array.isArray(
        staffing.candidates
      )
        ? staffing.candidates
        : [];

    const bestCandidate =
      candidates
        .slice()
        .sort(
          (a, b) =>
            Number(b.score || 0) -
            Number(a.score || 0)
        )[0] ||
      null;

    const equipmentQuote =
      equipment.status ===
        'planning'
        ? this.getEquipmentQuote(
            shopId
          )
        : equipment.quote ||
          null;

    const equipmentEta =
      equipment.status ===
        'ordered'
        ? Math.max(
            0,
            Number(
              equipment.deliveryDay
            ) -
            day
          )
        : 0;

    const permitEta =
      applyingRows.length
        ? Math.max(
            0,
            Math.min(
              ...applyingRows.map(
                row =>
                  Number(
                    row.finishDay
                  ) ||
                  day
              )
            ) -
            day
          )
        : 0;

    const staffingCoverage =
      clamp(
        Number(
          staffing &&
          staffing.coverage
        ) || 0,
        0,
        1
      );

    const permitProgress =
      permits &&
      Number(permits.total) > 0
        ? clamp(
            (
              Number(
                permits.approved
              ) || 0
            ) /
            Number(
              permits.total
            ),
            0,
            1
          )
        : 0;

    let renovationProgress =
      readiness.renovationReady
        ? 1
        : 0;

    if (
      !readiness.renovationReady &&
      typeof renovationSystem
        .getConstructionProgress ===
        'function'
    ) {
      try {
        const construction =
          renovationSystem
            .getConstructionProgress(
              shopId
            );

        renovationProgress =
          clamp(
            Number(
              construction &&
              construction.progress
            ) || 0,
            0,
            1
          );
      } catch (error) {
        renovationProgress = 0;
      }
    }

    const equipmentProgress =
      readiness.equipmentReady
        ? 1
        : equipment.status ===
            'ordered'
          ? 0.62
          : 0;

    const equipmentState =
      readiness.equipmentReady
        ? 'done'
        : equipment.status ===
            'ordered'
          ? 'waiting'
          : 'available';

    const permitState =
      readiness.permitsReady
        ? 'done'
        : actionableRows.length ||
          fixableRows.length
          ? 'available'
          : applyingRows.length
            ? 'waiting'
            : 'blocked';

    const workstreams = [
      {
        id:'renovation',
        title:'装修',
        state:
          readiness.renovationReady
            ? 'done'
            : 'available',
        progress:
          renovationProgress,
        statusText:
          readiness.renovationReady
            ? '已完成'
            : '可立即推进',
        detail:
          readiness.renovationReady
            ? '空间方案已具备开业条件'
            : '餐位、动线和许可条件仍需推进',
        action:'进入装修',
        priority:95,
        estimatedCost:0,
        blockingOpening:
          !readiness.renovationReady
      },
      {
        id:'equipment',
        title:'设备',
        state:
          equipmentState,
        progress:
          equipmentProgress,
        statusText:
          readiness.equipmentReady
            ? '已安装'
            : equipment.status ===
                'ordered'
              ? '等待到货 · ' +
                equipmentEta +
                '天'
              : '可提前采购',
        detail:
          readiness.equipmentReady
            ? '后厨与前厅设备已经到位'
            : equipment.status ===
                'ordered'
              ? '订单已锁定，等待到货安装'
              : '现在下单可与装修同步等待交期',
        action:
          equipment.status ===
            'planning'
            ? '配置设备'
            : '查看设备',
        priority:
          equipment.status ===
            'planning' &&
          equipmentQuote &&
          Number(
            equipmentQuote.installDays
          ) >= 3
            ? 98
            : 90,
        estimatedCost:
          equipment.status ===
            'planning' &&
          equipmentQuote
            ? Number(
                equipmentQuote.total
              ) || 0
            : 0,
        etaDays:
          equipmentEta,
        blockingOpening:
          !readiness.equipmentReady
      },
      {
        id:'license',
        title:'证照',
        state:
          permitState,
        progress:
          permitProgress,
        statusText:
          readiness.permitsReady
            ? '已齐全'
            : applyingRows.length
              ? '审核中 ' +
                applyingRows.length +
                '项'
              : actionableRows.length
                ? '可提交 ' +
                  actionableRows.length +
                  '项'
                : fixableRows.length
                  ? '可整改 ' +
                    fixableRows.length +
                    '项'
                  : '等待前置条件',
        detail:
          readiness.permitsReady
            ? '全部开业证照已完成'
            : actionableRows.length
              ? '已有证照可先办理，不必等全部筹备完成'
              : fixableRows.length
                ? '先完成整改即可继续办理'
                : applyingRows.length
                  ? '审批进行中，可同时处理其他事项'
                  : blockedPermitRows[0] &&
                    blockedPermitRows[0]
                      .reasons &&
                    blockedPermitRows[0]
                      .reasons[0] ||
                    '等待装修或设备条件',
        action:'办理证照',
        priority:88,
        estimatedCost:
          actionableRows.reduce(
            (sum, row) =>
              sum +
              Math.max(
                0,
                Number(row.fee) || 0
              ),
            0
          ) +
          (
            fixableRows[0]
              ? Math.max(
                  0,
                  Number(
                    fixableRows[0]
                      .remediationCost
                  ) || 0
                )
              : 0
          ),
        etaDays:
          permitEta,
        blockingOpening:
          !readiness.permitsReady
      },
      {
        id:'staff',
        title:'招聘',
        state:
          readiness.staffingReady
            ? 'done'
            : 'available',
        progress:
          staffingCoverage,
        statusText:
          readiness.staffingReady
            ? '班组齐备'
            : '到岗 ' +
              hiredCount +
              '/' +
              requiredTotal,
        detail:
          readiness.staffingReady
            ? '基础班组覆盖已达标'
            : candidates.length
              ? '今日有' +
                candidates.length +
                '名候选，可提前锁定核心岗位'
              : '等待人才市场刷新',
        action:'去招聘',
        priority:82,
        estimatedCost:
          bestCandidate
            ? Math.round(
                Number(
                  bestCandidate.wage
                ) *
                0.18
              )
            : 0,
        blockingOpening:
          !readiness.staffingReady
      }
    ];

    const available =
      workstreams
        .filter(
          row =>
            row.state ===
            'available'
        )
        .sort(
          (a, b) =>
            b.priority -
            a.priority
        );

    const waiting = [];

    if (
      equipment.status ===
      'ordered'
    ) {
      waiting.push({
        id:'equipment',
        moduleId:'equipment',
        title:'设备到货',
        days:equipmentEta,
        detail:
          equipmentEta > 0
            ? '设备还有' +
              equipmentEta +
              '天到货，可同时推进装修/招聘/证照'
            : '设备今天到货，进入设备页查看安装状态'
      });
    }

    if (applyingRows.length) {
      waiting.push({
        id:'license',
        moduleId:'license',
        title:'证照审核',
        days:permitEta,
        detail:
          applyingRows.length +
          '项证照审核中' +
          (
            permitEta > 0
              ? '，最快' +
                permitEta +
                '天出结果'
              : '，今天可能出结果'
          )
      });
    }

    const blockers =
      workstreams
        .filter(
          row =>
            row.blockingOpening
        )
        .map(
          row => ({
            id:row.id,
            title:row.title,
            detail:
              row.title +
              '未完成：' +
              row.statusText
          })
        );

    const immediateCost =
      available.reduce(
        (sum, row) =>
          sum +
          Math.max(
            0,
            Number(
              row.estimatedCost
            ) || 0
          ),
        0
      );

    const affordable =
      available.filter(
        row =>
          Number(
            row.estimatedCost
          ) <= cash
      );

    const selected =
      (
        affordable.length
          ? affordable
          : available
      )[0] ||
      null;

    let focus = null;

    if (readiness.ready) {
      focus = {
        id:'trial',
        title:'可以开始试营业',
        detail:'四项基础条件已经齐全，用3天真实经营验证方案',
        action:'开始试营业',
        state:'ready'
      };
    } else if (selected) {
      const focusTitle = {
        equipment:'先锁设备交期',
        renovation:'推进装修方案',
        license:'先办可提交证照',
        staff:'提前锁定班组'
      }[selected.id] ||
      '继续筹备';

      focus = {
        id:selected.id,
        title:focusTitle,
        detail:selected.detail,
        action:selected.action,
        state:selected.state,
        estimatedCost:
          selected.estimatedCost
      };
    } else if (waiting.length) {
      const first =
        waiting[0];

      focus = {
        id:first.moduleId,
        title:'等待期间别空转',
        detail:first.detail,
        action:'查看进度',
        state:'waiting'
      };
    } else {
      focus = {
        id:'renovation',
        title:'继续完善开店条件',
        detail:'仍有开业条件未完成',
        action:'进入装修',
        state:'blocked'
      };
    }

    const signals = [];

    if (
      equipment.status ===
      'planning'
    ) {
      signals.push(
        '设备现在即可提前下单，与装修并行等待交期'
      );
    }

    if (
      actionableRows.length
    ) {
      signals.push(
        '已有' +
        actionableRows.length +
        '项证照可以提前提交'
      );
    }

    if (
      bestCandidate &&
      !readiness.staffingReady
    ) {
      signals.push(
        '今日优质候选：' +
        bestCandidate.name +
        ' · ' +
        bestCandidate.roleName +
        ' · 综合' +
        bestCandidate.score
      );
    }

    return {
      version:'0.8.61',
      day,
      cash,
      readinessPercent:
        Math.round(
          (
            renovationProgress +
            equipmentProgress +
            permitProgress +
            staffingCoverage
          ) /
          4 *
          100
        ),
      ready:
        !!readiness.ready,
      workstreams,
      focus,
      waiting,
      blockers,
      signals,
      actionableCount:
        available.length,
      parallelCount:
        available.length,
      immediateCost,
      immediateCashGap:
        Math.max(
          0,
          immediateCost -
          cash
        )
    };
  }
`;

  prep = replaceOnce(
    prep,
    '\n  startTrialOpening(shopId) {',
    '\n' + method + '\n  startTrialOpening(shopId) {',
    'insert getPreparationBoard'
  );
}

write(prepPath, prep);

let store = read(storePath);

if (!store.includes('V0861_PREPARATION_COMMAND_CENTER_UI')) {
  store = replaceOnce(
    store,
    '// V44_STORE_VISUAL_REPAIR',
    '// V44_STORE_VISUAL_REPAIR\n// V0861_PREPARATION_COMMAND_CENTER_UI',
    'store scene marker'
  );

  const progressAnchor = `    const renovationProgress =\n      this.getRenovationProgress(\n        shop.id\n      );\n`;

  store = replaceOnce(
    store,
    progressAnchor,
    progressAnchor + `\n    const preparationBoard =\n      openingPrepSystem\n        .getPreparationBoard(\n          shop.id,\n          readiness\n        );\n\n    const renovationLine =\n      preparationBoard &&\n      Array.isArray(\n        preparationBoard.workstreams\n      )\n        ? preparationBoard\n            .workstreams\n            .find(\n              row =>\n                row.id ===\n                'renovation'\n            )\n        : null;\n\n    if (\n      renovationLine &&\n      !readiness.renovationReady\n    ) {\n      renovationLine.progress =\n        renovationProgress;\n\n      renovationLine.statusText =\n        renovationProgress > 0\n          ? '推进中 ' +\n            Math.round(\n              renovationProgress *\n              100\n            ) +\n            '%'\n          : '可立即推进';\n    }\n`,
    'preparation board in state'
  );

  const returnAnchor = `    return {\n      readiness,\n      metrics,\n      finance,\n      plan,\n      renovationProgress,\n      permitApproved,`;

  const override = `    if (\n      shop.status !==\n        'trial_complete' &&\n      preparationBoard &&\n      preparationBoard.focus\n    ) {\n      recommendation = {\n        id:\n          preparationBoard\n            .focus.id,\n        title:\n          preparationBoard\n            .focus.title,\n        detail:\n          preparationBoard\n            .focus.detail,\n        action:\n          preparationBoard\n            .focus.action\n      };\n    }\n\n`;

  store = replaceOnce(
    store,
    returnAnchor,
    override + `    return {\n      readiness,\n      metrics,\n      finance,\n      plan,\n      renovationProgress,\n      preparationBoard,\n      permitApproved,`,
    'preparation state return'
  );

  const renderFunction = String.raw`  renderPreparing(
    ctx,
    shop
  ) {
    const state =
      this.getPreparationState(
        shop
      );

    const board =
      state.preparationBoard ||
      openingPrepSystem
        .getPreparationBoard(
          shop.id,
          state.readiness
        );

    const district =
      citySystem.getDistrict(
        shop.districtId
      );

    const compact =
      this.contentBottom <
      650;

    this.drawHeader(
      ctx,
      {
        subtitle:
          '门店筹备中心 · 四线并行'
      }
    );

    const heroY = 91;
    const heroH =
      compact
        ? 112
        : 132;

    ui.card(
      ctx,
      10,
      heroY,
      370,
      heroH,
      {
        radius:15,
        fill:'#FFFCF7',
        stroke:'#DED5C8'
      }
    );

    ui.coverImage(
      ctx,
      resourceManager.getImage(
        'lib_store_hero'
      ) ||
      visualAssetSystem.get(
        'premium_store_hero'
      ),
      18,
      heroY + 8,
      354,
      compact
        ? 55
        : 73,
      11,
      'rgba(2,28,42,0.30)'
    );

    storeText(
      ctx,
      shortText(
        shop.name ||
        '筹备中的门店',
        13
      ),
      28,
      heroY + 29,
      12.5,
      COLORS.white,
      '800'
    );

    storeText(
      ctx,
      (
        district
          ? district.name
          : ''
      ) +
      ' · ' +
      shortText(
        shop.address ||
        '已签约门店',
        16
      ),
      28,
      heroY +
        (
          compact
            ? 50
            : 56
        ),
      5.0,
      '#EEF6F8',
      '700'
    );

    const heroMetrics = [
      [
        '面积',
        Math.round(
          Number(
            shop.usableArea ||
            shop.grossArea ||
            0
          )
        ) + '㎡'
      ],
      [
        '餐位',
        Math.round(
          Number(
            state.metrics
              ? state.metrics.totalSeats
              : shop.seatEstimate
          ) || 0
        ) + '个'
      ],
      [
        '月租',
        compactMoney(
          shop.monthlyRent || 0
        )
      ],
      [
        '准备度',
        Math.round(
          Number(
            board.readinessPercent
          ) || 0
        ) + '%'
      ]
    ];

    const metricY =
      heroY +
      heroH -
      30;

    for (
      let i = 0;
      i < 4;
      i++
    ) {
      const x =
        28 +
        i * 86;

      storeText(
        ctx,
        heroMetrics[i][0],
        x,
        metricY,
        4.4,
        COLORS.muted,
        '700'
      );

      storeText(
        ctx,
        heroMetrics[i][1],
        x,
        metricY + 17,
        6.0,
        COLORS.text,
        '800'
      );
    }

    const workY =
      heroY +
      heroH +
      8;

    const rowH =
      compact
        ? 52
        : 60;

    const rowGap = 6;
    const cardW = 182;

    const iconMap = {
      renovation:'layout',
      equipment:'rider',
      license:'lease',
      staff:'broker'
    };

    const stateTone = {
      done:COLORS.green,
      waiting:COLORS.blue,
      available:COLORS.goldDeep,
      blocked:COLORS.red
    };

    const stateFill = {
      done:'#E9F7EF',
      waiting:'#EAF4F8',
      available:'#FFF7DE',
      blocked:'#FFF0EA'
    };

    for (
      let i = 0;
      i < board.workstreams.length;
      i++
    ) {
      const line =
        board.workstreams[i];

      const col =
        i % 2;

      const row =
        Math.floor(
          i / 2
        );

      const x =
        10 +
        col * 188;

      const y =
        workY +
        row *
        (
          rowH +
          rowGap
        );

      ui.card(
        ctx,
        x,
        y,
        cardW,
        rowH,
        {
          radius:12,
          fill:
            stateFill[
              line.state
            ] ||
            '#FFFCF7',
          stroke:'#DED5C8',
          shadow:false
        }
      );

      this.drawPropertyIcon(
        ctx,
        iconMap[
          line.id
        ] ||
        'layout',
        x + 8,
        y + 10,
        20,
        line.state ===
          'done'
          ? '✓'
          : '',
        '#EEF4F6'
      );

      storeText(
        ctx,
        line.title,
        x + 36,
        y + 15,
        5.9,
        COLORS.text,
        '800'
      );

      storeText(
        ctx,
        shortText(
          line.statusText,
          12
        ),
        x + cardW - 9,
        y + 15,
        4.5,
        stateTone[
          line.state
        ] ||
        COLORS.muted,
        '800',
        'right'
      );

      storeText(
        ctx,
        shortText(
          line.detail,
          compact
            ? 18
            : 22
        ),
        x + 36,
        y + 32,
        4.3,
        COLORS.muted,
        '600'
      );

      ui.card(
        ctx,
        x + 10,
        y + rowH - 9,
        cardW - 20,
        4,
        {
          radius:2,
          fill:'#E4E0D9',
          stroke:false,
          shadow:false
        }
      );

      ui.card(
        ctx,
        x + 10,
        y + rowH - 9,
        Math.max(
          3,
          (
            cardW - 20
          ) *
          clamp(
            Number(
              line.progress
            ) || 0,
            0,
            1
          )
        ),
        4,
        {
          radius:2,
          fill:
            stateTone[
              line.state
            ] ||
            COLORS.blue,
          stroke:false,
          shadow:false
        }
      );

      this.addButton(
        'module:' +
          line.id,
        x,
        y,
        cardW,
        rowH
      );
    }

    const readyY =
      workY +
      rowH * 2 +
      rowGap +
      8;

    const readyH =
      compact
        ? 44
        : 50;

    ui.card(
      ctx,
      10,
      readyY,
      370,
      readyH,
      {
        radius:13,
        fill:'#FFFCF7',
        stroke:'#DED5C8',
        shadow:false
      }
    );

    storeText(
      ctx,
      '开店进度 · 开业准备度',
      22,
      readyY + 15,
      6.6,
      COLORS.text,
      '800'
    );

    storeText(
      ctx,
      Math.round(
        Number(
          board.readinessPercent
        ) || 0
      ) + '%',
      367,
      readyY + 15,
      7.3,
      board.ready
        ? COLORS.green
        : COLORS.orange,
      '800',
      'right'
    );

    ui.card(
      ctx,
      22,
      readyY + 24,
      346,
      6,
      {
        radius:3,
        fill:'#E6E1DA',
        stroke:false,
        shadow:false
      }
    );

    ui.card(
      ctx,
      22,
      readyY + 24,
      346 *
        clamp(
          Number(
            board.readinessPercent
          ) / 100,
          0,
          1
        ),
      6,
      {
        radius:3,
        fill:
          board.ready
            ? COLORS.green
            : COLORS.gold,
        stroke:false,
        shadow:false
      }
    );

    storeText(
      ctx,
      board.parallelCount > 0
        ? '可并行推进 ' +
          board.parallelCount +
          ' 项 · 不必逐项等待'
        : board.waiting.length
          ? '当前有 ' +
            board.waiting.length +
            ' 项等待中，可检查其他筹备线'
          : '基础筹备条件正在收口',
      22,
      readyY +
        readyH -
        7,
      4.4,
      COLORS.muted,
      '700'
    );

    const focusY =
      readyY +
      readyH +
      8;

    const focusH =
      compact
        ? 78
        : 96;

    ui.card(
      ctx,
      10,
      focusY,
      232,
      focusH,
      {
        radius:13,
        fill:'#FFF9E9',
        stroke:'#E3D2A4',
        shadow:false
      }
    );

    const rec =
      state.recommendation;

    storeText(
      ctx,
      '今日重点 · 下一步建议',
      22,
      focusY + 17,
      6.7,
      COLORS.text,
      '800'
    );

    storeText(
      ctx,
      rec.title,
      22,
      focusY + 37,
      6.2,
      COLORS.orange,
      '800'
    );

    storeText(
      ctx,
      shortText(
        rec.detail,
        compact
          ? 24
          : 29
      ),
      22,
      focusY + 54,
      4.5,
      COLORS.muted,
      '600'
    );

    this.drawActionButton(
      ctx,
      'module:' +
        rec.id,
      '继续筹备',
      22,
      focusY +
        focusH -
        29,
      202,
      23,
      'gold'
    );

    ui.card(
      ctx,
      250,
      focusY,
      130,
      focusH,
      {
        radius:13,
        fill:'#FFFCF7',
        stroke:'#DED5C8',
        shadow:false
      }
    );

    const gap =
      state.finance
        ? Number(
            state.finance.gap
          ) || 0
        : 0;

    const need =
      state.finance &&
      state.finance.need
        ? state.finance.need
        : null;

    storeText(
      ctx,
      '筹备资金',
      262,
      focusY + 17,
      6.4,
      COLORS.text,
      '800'
    );

    storeText(
      ctx,
      '预计投入',
      262,
      focusY + 38,
      4.3,
      COLORS.muted,
      '600'
    );

    storeText(
      ctx,
      compactMoney(
        need
          ? need.totalNeed
          : (
              state.metrics
                ? state.metrics.totalCost
                : 0
            )
      ),
      369,
      focusY + 38,
      5.3,
      COLORS.text,
      '800',
      'right'
    );

    storeText(
      ctx,
      gap > 0
        ? '缺口 ' +
          compactMoney(gap)
        : '现金 ' +
          compactMoney(
            gameState
              .getPlayer()
              .cash
          ),
      262,
      focusY + 58,
      4.8,
      gap > 0
        ? COLORS.red
        : COLORS.green,
      '800'
    );

    if (gap > 0) {
      this.drawActionButton(
        ctx,
        'module:finance',
        '申请周转',
        261,
        focusY +
          focusH -
          29,
        107,
        23,
        'blue'
      );
    } else {
      storeText(
        ctx,
        board.immediateCashGap > 0
          ? '可执行项仍差 ' +
            compactMoney(
              board.immediateCashGap
            )
          : '当前可执行项资金可覆盖',
        262,
        focusY +
          focusH -
          14,
        4.1,
        COLORS.muted,
        '600'
      );
    }

    const bottomY =
      focusY +
      focusH +
      8;

    const bottomH =
      Math.max(
        44,
        this.contentBottom -
        bottomY -
        8
      );

    ui.card(
      ctx,
      10,
      bottomY,
      370,
      bottomH,
      {
        radius:13,
        fill:'#F6F8F7',
        stroke:'#D8DFDD',
        shadow:false
      }
    );

    const waitingText =
      board.waiting.length
        ? board.waiting[0]
            .detail
        : '暂无必须等待的项目，可以继续主动推进';

    const blockerText =
      board.blockers.length
        ? board.blockers
            .slice(0, 2)
            .map(
              row =>
                row.title
            )
            .join('、') +
          '仍会阻塞试营业'
        : '基础条件已齐，可进入试营业';

    storeText(
      ctx,
      '等待中',
      22,
      bottomY + 16,
      5.7,
      COLORS.blue,
      '800'
    );

    storeText(
      ctx,
      shortText(
        waitingText,
        compact
          ? 20
          : 30
      ),
      70,
      bottomY + 16,
      4.3,
      COLORS.muted,
      '600'
    );

    storeText(
      ctx,
      '阻塞开业',
      208,
      bottomY + 16,
      5.7,
      board.blockers.length
        ? COLORS.red
        : COLORS.green,
      '800'
    );

    storeText(
      ctx,
      shortText(
        blockerText,
        20
      ),
      366,
      bottomY + 16,
      4.2,
      COLORS.muted,
      '600',
      'right'
    );

    if (
      !compact &&
      bottomH >= 68
    ) {
      const signal =
        board.signals[0] ||
        (
          district
            ? district.name +
              '仍有可考察铺面'
            : '筹备状态正常推进'
        );

      storeText(
        ctx,
        '筹备动态 · ' +
          shortText(
            signal,
            42
          ),
        22,
        bottomY + 41,
        4.7,
        COLORS.text,
        '700'
      );

      storeText(
        ctx,
        '当前可并行 ' +
          board.parallelCount +
          ' 项 · 等待 ' +
          board.waiting.length +
          ' 项',
        22,
        bottomY + 60,
        4.4,
        COLORS.muted,
        '600'
      );

      this.drawActionButton(
        ctx,
        'go-property',
        '继续看商圈',
        292,
        bottomY + 34,
        76,
        25,
        'blue'
      );
    }
  }
`;

  const renderPattern = /  renderPreparing\(\n    ctx,\n    shop\n  \) \{[\s\S]*?\n  \}\n\n  showShopDetail\(/;

  store = replaceOnce(
    store,
    renderPattern,
    renderFunction + '\n\n  showShopDetail(',
    'replace renderPreparing'
  );
}

write(storePath, store);

const testSource = `'use strict';\n\nconst assert = require('assert');\nconst fs = require('fs');\nconst path = require('path');\n\nconst ROOT = path.resolve(__dirname, '..');\nconst storeSource = fs.readFileSync(path.join(ROOT, 'src/scenes/storeScene.js'), 'utf8');\nconst prepSource = fs.readFileSync(path.join(ROOT, 'src/opening/openingPrepSystem.js'), 'utf8');\n\nfor (const token of [\n  'V0861_PREPARATION_COMMAND_CENTER_UI',\n  '门店筹备中心 · 四线并行',\n  '开店进度 · 开业准备度',\n  '今日重点 · 下一步建议',\n  '可并行推进 ',\n  '等待中',\n  '阻塞开业',\n  '筹备资金'\n]) {\n  assert.ok(storeSource.includes(token), '筹备中心UI缺失：' + token);\n}\n\nfor (const token of [\n  'V0861_PREPARATION_COMMAND_CENTER_SYSTEM',\n  'getPreparationBoard(',\n  "state:'waiting'",\n  'parallelCount:',\n  'immediateCashGap:',\n  'actionableRows'\n]) {\n  assert.ok(prepSource.includes(token), '筹备指挥系统缺失：' + token);\n}\n\nassert.ok(!storeSource.includes("'module:renovation'"), '不能破坏动态装修路由规则');\n\nglobalThis.GameRuntime = {\n  api:{\n    getSystemInfoSync(){ return { windowWidth:390, windowHeight:780 }; },\n    showToast(){},\n    setStorageSync(){},\n    getStorageSync(){ return null; }\n  },\n  requestRender(){}\n};\n\nconst gameState = require('../src/core/gameState.js');\nconst renovationSystem = require('../src/renovation/renovationSystem.js');\nconst prep = require('../src/opening/openingPrepSystem.js');\n\ngameState.reset();\ngameState.setCash(1000000);\ngameState.addShop({\n  id:'v0861_parallel_shop',\n  name:'并行筹备测试店',\n  districtId:'university',\n  streetId:'parallel_test',\n  address:'学府路61号',\n  status:'leased_pending_renovation',\n  grossArea:138,\n  usableArea:118,\n  seatEstimate:36,\n  floor:'1层',\n  electricCapacityKw:40,\n  greaseTrap:true,\n  fireSprinkler:true,\n  monthlyRent:9800,\n  freeRentDays:10,\n  depositMonths:2,\n  paymentMonths:3,\n  leaseYears:5,\n  transferFee:0,\n  brokerFee:0,\n  upfrontPaid:30000\n});\n\nrenovationSystem.ensurePlan('v0861_parallel_shop');\n\nlet board = prep.getPreparationBoard('v0861_parallel_shop');\nassert.equal(board.version, '0.8.61');\nassert.equal(board.workstreams.length, 4);\nassert.ok(board.parallelCount >= 3, '签约后至少装修、设备、招聘应可并行推进');\nassert.ok(board.workstreams.some(row => row.id === 'equipment' && row.state === 'available'));\nassert.ok(board.workstreams.some(row => row.id === 'staff' && row.state === 'available'));\nassert.ok(board.workstreams.some(row => row.id === 'license' && row.state === 'available'), '主体登记/招牌备案应允许提前办理');\n\nconst earlyPermit = prep.applyPermit('v0861_parallel_shop', 'business');\nassert.ok(earlyPermit.ok, '主体登记应可在装修完成前提前提交');\n\nconst equipmentOrder = prep.orderEquipment('v0861_parallel_shop');\nassert.ok(equipmentOrder.ok, '设备应可在装修完成前提前下单');\n\nconst staffBefore = prep.getStaffOverview('v0861_parallel_shop');\nconst candidate = staffBefore.candidates[0];\nassert.ok(candidate, '筹备阶段应有招聘候选人');\nassert.ok(prep.hireCandidate('v0861_parallel_shop', candidate.id).ok, '装修完成前应可提前招聘');\n\nboard = prep.getPreparationBoard('v0861_parallel_shop');\nassert.ok(board.waiting.some(row => row.id === 'equipment'), '设备下单后应进入等待事项');\nassert.ok(board.waiting.some(row => row.id === 'license'), '证照提交后应进入等待事项');\nassert.ok(board.blockers.length > 0, '未完成装修时必须明确显示开业阻塞项');\nassert.ok(board.focus && board.focus.id, '每天必须给出明确今日重点');\n\nconsole.log('V0.8.61 preparation command center tests passed');\n`;

write(testPath, testSource);

let runner = read(runnerPath);
if (!runner.includes(testPath)) {
  runner = replaceOnce(
    runner,
    "    'tests/renovationFinalFixV0850.test.js',\n",
    "    'tests/renovationFinalFixV0850.test.js',\n    'tests/preparationCommandCenterV0861.test.js',\n",
    'register V0861 test'
  );
  write(runnerPath, runner);
}

const manifest = {
  id:'V0861_PREPARATION_COMMAND_CENTER',
  baseVersion:'0.8.60',
  targetVersion:TARGET_VERSION,
  category:'开店筹备中心重构',
  features:[
    '装修、设备、证照、招聘四条筹备线同屏并行',
    '今日重点根据交期、可执行性和资金自动排序',
    '设备允许装修期间提前下单并显示到货倒计时',
    '主体登记等可提前证照直接显示可办理状态',
    '招聘可在装修完成前提前锁定核心岗位',
    '显示开业准备度、等待事项、阻塞开业条件',
    '显示当前可并行项目数和即时资金压力',
    '保留原四态门店页与历史动态装修路由兼容'
  ],
  workflowSafe:true,
  modifiesPackageViaPatch:true,
  containsWorkflowFiles:false
};
write(manifestPath, JSON.stringify(manifest, null, 2) + '\n');

const pkg = JSON.parse(read('package.json'));
pkg.version = TARGET_VERSION;
write('package.json', JSON.stringify(pkg, null, 2) + '\n');

const lock = JSON.parse(read('package-lock.json'));
lock.version = TARGET_VERSION;
if (lock.packages && lock.packages['']) {
  lock.packages[''].version = TARGET_VERSION;
}
write('package-lock.json', JSON.stringify(lock, null, 2) + '\n');

let gradle = read('android/app/build.gradle');
gradle = gradle.replace(/versionCode\s+\d+/, 'versionCode ' + TARGET_CODE);
gradle = gradle.replace(/versionName\s+'[^']+'/, "versionName '" + TARGET_VERSION + "'");
write('android/app/build.gradle', gradle);

const finalStore = read(storePath);
const finalPrep = read(prepPath);
for (const token of [
  'V0861_PREPARATION_COMMAND_CENTER_UI',
  '今日重点 · 下一步建议',
  '开店进度 · 开业准备度',
  '等待中',
  '阻塞开业',
  '继续筹备'
]) {
  must(finalStore.includes(token), '最终UI兼容检查失败：' + token);
}
for (const token of [
  'V0861_PREPARATION_COMMAND_CENTER_SYSTEM',
  'getPreparationBoard(',
  'parallelCount:',
  'immediateCashGap:'
]) {
  must(finalPrep.includes(token), '最终系统检查失败：' + token);
}
must(!finalStore.includes("'module:renovation'"), '检测到被禁止的硬编码装修路由');

console.log('V0.8.61 preparation command center patch applied');
