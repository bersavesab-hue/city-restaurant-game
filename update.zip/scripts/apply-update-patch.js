'use strict';

const fs = require('fs');
const cp = require('child_process');

function read(file) {
  return fs.readFileSync(file, 'utf8');
}

function write(file, content) {
  fs.writeFileSync(file, content, 'utf8');
}

function mustContain(source, token, label) {
  if (!source.includes(token)) {
    throw new Error('[FINANCE V1.0.3] 无法定位 ' + label);
  }
}

function checkJs(file) {
  const result = cp.spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) {
    process.stderr.write(result.stdout || '');
    process.stderr.write(result.stderr || '');
    throw new Error('[FINANCE V1.0.3] JS语法检查失败：' + file);
  }
}

function patchMain() {
  const file = 'src/main.js';
  let source = read(file);

  if (!source.includes("require('./finance/financialSystemV103.js')")) {
    const anchor = "const moreScene = require('./scenes/moreScene.js');";
    mustContain(source, anchor, 'main.js moreScene require');
    source = source.replace(
      anchor,
      anchor + "\nconst financeCenterScene = require('./scenes/financeCenterSceneV103.js');\nconst financialSystem = require('./finance/financialSystemV103.js');"
    );
  }

  if (!source.includes("sceneManager.register(\n  'financeCenter',")) {
    const anchor = "sceneManager.register(\n  'more',\n  moreScene\n);";
    mustContain(source, anchor, 'main.js more scene registration');
    source = source.replace(
      anchor,
      anchor + "\n\nsceneManager.register(\n  'financeCenter',\n  financeCenterScene\n);"
    );
  }

  if (!source.includes('runtime.financialSystem =')) {
    const anchor = 'runtime.economyBalance =\n  economyBalanceGuard;';
    mustContain(source, anchor, 'main.js runtime economyBalance');
    source = source.replace(
      anchor,
      anchor + "\n\nruntime.financialSystem =\n  financialSystem;"
    );
  }

  if (!source.includes('let financialChanged =')) {
    const anchor = '  let staffCareerChanged =\n    false;';
    mustContain(source, anchor, 'main.js gameLoop change flags');
    source = source.replace(
      anchor,
      anchor + "\n\n  let financialChanged =\n    false;"
    );
  }

  if (!source.includes('financialSystem\n              .update()')) {
    const anchor = `          if (\n            staffCareer\n              .update()\n          ) {\n            staffCareerChanged =\n              true;\n          }`;
    mustContain(source, anchor, 'main.js staffCareer runtime update');
    source = source.replace(
      anchor,
      anchor + `\n\n          if (\n            financialSystem\n              .update()\n          ) {\n            financialChanged =\n              true;\n          }`
    );
  }

  if (!source.includes('staffCareerChanged,\n      financialChanged')) {
    const anchor = '      lifecycleChanged,\n      staffCareerChanged\n    });';
    mustContain(source, anchor, 'main.js state bus flags');
    source = source.replace(
      anchor,
      '      lifecycleChanged,\n      staffCareerChanged,\n      financialChanged\n    });'
    );
  }

  if (!source.includes('staffCareerChanged ||\n    financialChanged\n  ) {')) {
    const anchor = '    lifecycleChanged ||\n    staffCareerChanged\n  ) {';
    mustContain(source, anchor, 'main.js autosave finance flag');
    source = source.replace(
      anchor,
      '    lifecycleChanged ||\n    staffCareerChanged ||\n    financialChanged\n  ) {'
    );
  }

  if (!source.includes('staffCareerChanged ||\n    financialChanged ||\n    animationChanged')) {
    const anchor = '    lifecycleChanged ||\n    staffCareerChanged ||\n    animationChanged ||';
    mustContain(source, anchor, 'main.js render finance flag');
    source = source.replace(
      anchor,
      '    lifecycleChanged ||\n    staffCareerChanged ||\n    financialChanged ||\n    animationChanged ||'
    );
  }

  if (!source.includes('FINANCIAL_SYSTEM_V103_WIRING')) {
    source += '\n\n/* FINANCIAL_SYSTEM_V103_WIRING */\n';
  }

  write(file, source);
  checkJs(file);
}

function patchStoreScene() {
  const file = 'src/scenes/storeScene.js';
  let source = read(file);
  if (!source.includes("finance:\n          'financeCenter',")) {
    const anchor = "finance:\n          'business',";
    mustContain(source, anchor, 'storeScene finance route');
    source = source.replace(anchor, "finance:\n          'financeCenter',");
  }
  if (!source.includes('FINANCE_CENTER_V103_ROUTE')) {
    source += '\n\n// FINANCE_CENTER_V103_ROUTE\n';
  }
  write(file, source);
  checkJs(file);
}

function patchMoreScene() {
  const file = 'src/scenes/moreScene.js';
  if (!fs.existsSync(file)) return;
  let source = read(file);
  if (!source.includes("'go:financeCenter'")) {
    const oldLine = "    this.drawEntry(ctx, 'go:shop', 200, 358, 180, '返回门店', '回到门店经营总控中心', 'gold');";
    mustContain(source, oldLine, 'moreScene 返回门店入口');
    source = source.replace(
      oldLine,
      "    this.drawEntry(ctx, 'go:financeCenter', 200, 358, 180, '金融中心', '授信 · 贷款 · 还款 · 信用', 'gold');"
    );
  }
  write(file, source);
  checkJs(file);
}

function patchTestRunner() {
  const file = 'scripts/run-ci-tests-v060.js';
  let source = read(file);

  if (!source.includes('tests/financialSystemV103.test.js')) {
    const anchor = "    'tests/v60CleanBase.test.js'";
    mustContain(source, anchor, '主测试入口 v60CleanBase');
    source = source.replace(
      anchor,
      "    'tests/financialSystemV103.test.js',\n" + anchor
    );
  }

  // 兼容此前数据/客流补丁：该测试存在时运行，不存在时跳过，同时满足DevKit覆盖发现。
  if (!source.includes('tests/customerTrafficSystemV103.test.js')) {
    const anchor = "    'tests/propertyDeal.test.js',";
    mustContain(source, anchor, '可选测试入口 propertyDeal');
    source = source.replace(
      anchor,
      "    'tests/customerTrafficSystemV103.test.js',\n" + anchor
    );
  }

  write(file, source);
  checkJs(file);
}

patchMain();
patchStoreScene();
patchMoreScene();
patchTestRunner();

for (const file of [
  'src/finance/financialSystemV103.js',
  'src/scenes/financeCenterSceneV103.js',
  'tests/financialSystemV103.test.js'
]) {
  checkJs(file);
}

console.log('[FINANCE V1.0.3] 金融系统安装完成');
console.log('[FINANCE V1.0.3] 资金账户 / 融资贷款 / 信用授信 / 还款流水');
console.log('[FINANCE V1.0.3] 门店财务入口已改为金融中心，经营报表继续负责损益分析');
