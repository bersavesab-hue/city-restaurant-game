'use strict';

const fs = require('fs');
const path = require('path');

console.log('[V0864-R3-UNIQUE] correct operating tradeoff patch loaded');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.63';
const TARGET_VERSION = '0.8.64';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), {recursive:true});
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0864] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0864] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* =========================================================
   A. 菜单策略真正产生“效率 vs 选择”的取舍
   ========================================================= */

replaceExact(
  'src/operations/floorSimulationV082.js',
`    churnRiskVisitsToday:0,
    dishOrdersToday:{},`,
`    churnRiskVisitsToday:0,
    varietyWalkawaysToday:0,
    signatureWalkawaysToday:0,
    dishOrdersToday:{},`,
  'tradeoff metrics'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`function buildOrder(
  runtime,
  floor,
  shop,
  profile,
  visit,
  minute,
  tableId,
  waitMinutes,
  ctx
) {
  const chosen =`,
`function menuComplexityFactor(
  activeMenuCount
) {
  const count =
    Math.max(
      0,
      Number(
        activeMenuCount
      ) ||
      0
    );

  if (count <= 2) {
    return 0.88;
  }

  if (count === 3) {
    return 0.91;
  }

  if (count === 4) {
    return 0.95;
  }

  if (count <= 7) {
    return 1;
  }

  if (count <= 10) {
    return 1.05;
  }

  return 1.10;
}

function menuVarietyWalkawayProbability(
  profile,
  activeMenuCount
) {
  const count =
    Math.max(
      0,
      Number(
        activeMenuCount
      ) ||
      0
    );

  if (count >= 5) {
    return 0;
  }

  const base =
    count <= 1
      ? 0.18
      : count === 2
        ? 0.10
        : count === 3
          ? 0.06
          : 0.025;

  const novelty =
    clamp(
      Number(
        profile &&
        profile.traits &&
        profile.traits
          .noveltySeeking
      ) ||
      50,
      0,
      100
    ) /
    100;

  return clamp(
    base *
    (
      0.65 +
      novelty *
      0.70
    ),
    0,
    0.30
  );
}

function signatureShortageWalkawayProbability(
  profile,
  signatureDish
) {
  if (
    !signatureDish ||
    !signatureDish.signature ||
    signatureDish.available
  ) {
    return 0;
  }

  const loyalty =
    clamp(
      Number(
        profile &&
        profile.traits &&
        profile.traits.loyalty
      ) ||
      50,
      0,
      100
    ) /
    100;

  const popularity =
    clamp(
      Number(
        signatureDish.popularity
      ) ||
      50,
      0,
      100
    ) /
    100;

  return clamp(
    0.08 +
    loyalty *
      0.10 +
    popularity *
      0.12,
    0.08,
    0.32
  );
}

function buildOrder(
  runtime,
  floor,
  shop,
  profile,
  visit,
  minute,
  tableId,
  waitMinutes,
  ctx
) {
  const choices =
    menuChoices(
      runtime
    );

  const activeChoices =
    choices.filter(
      item =>
        item &&
        item.menuItem &&
        item.menuItem.active !==
          false
    );

  const availableChoices =
    activeChoices.filter(
      item =>
        item.available
    );

  if (
    availableChoices.length >
    0
  ) {
    const signature =
      activeChoices.find(
        item =>
          item.signature
      ) ||
      null;

    const signatureRisk =
      signatureShortageWalkawayProbability(
        profile,
        signature
      );

    if (
      signatureRisk >
        0 &&
      runtime.rng.next() <
        signatureRisk
    ) {
      const lost =
        Math.max(
          1,
          Number(
            visit.partySize
          ) ||
          1
        );

      floor.metrics
        .signatureWalkawaysToday +=
        lost;

      floor.history.unshift({
        minute,
        type:'signature_stockout_walkaway',
        profileId:
          profile.id,
        visitId:
          visit.id,
        menuItemId:
          signature &&
          signature.menuItem &&
          signature.menuItem.id ||
          null,
        probability:
          signatureRisk
      });

      return {
        ok:false,
        reason:'招牌菜缺货'
      };
    }

    const varietyRisk =
      menuVarietyWalkawayProbability(
        profile,
        activeChoices.length
      );

    if (
      varietyRisk >
        0 &&
      runtime.rng.next() <
        varietyRisk
    ) {
      const lost =
        Math.max(
          1,
          Number(
            visit.partySize
          ) ||
          1
        );

      floor.metrics
        .varietyWalkawaysToday +=
        lost;

      floor.history.unshift({
        minute,
        type:'menu_variety_walkaway',
        profileId:
          profile.id,
        visitId:
          visit.id,
        activeMenuCount:
          activeChoices.length,
        probability:
          varietyRisk
      });

      return {
        ok:false,
        reason:'菜单选择太少'
      };
    }
  }

  const chosen =`,
  'menu tradeoff helpers and order prechecks'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`  const ticket =
    kitchenEngine
      .createTicket(
        runtime.kitchen,
        order,
        minute
      );

  floor.orders[`,
`  const ticket =
    kitchenEngine
      .createTicket(
        runtime.kitchen,
        order,
        minute
      );

  const activeMenuCount =
    (
      runtime.menu ||
      []
    ).filter(
      item =>
        item &&
        item.active !==
          false
    ).length;

  const complexityFactor =
    menuComplexityFactor(
      activeMenuCount
    );

  for (
    const line
    of ticket.lines ||
      []
  ) {
    line.estimatedMinutes =
      Math.max(
        1,
        Math.round(
          Number(
            line.estimatedMinutes
          ) *
          complexityFactor
        )
      );
  }

  order.meta
    .menuComplexityFactor =
    complexityFactor;

  floor.orders[`,
  'menu complexity changes kitchen speed'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`    priceWalkawaysToday:
      floor.metrics
        .priceWalkawaysToday,
    repeatRate:`,
`    priceWalkawaysToday:
      floor.metrics
        .priceWalkawaysToday,
    varietyWalkawaysToday:
      floor.metrics
        .varietyWalkawaysToday,
    signatureWalkawaysToday:
      floor.metrics
        .signatureWalkawaysToday,
    repeatRate:`,
  'tradeoff snapshot metrics'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`  customerReturnScore,
  priceRejectProbability
};`,
`  customerReturnScore,
  priceRejectProbability,
  menuComplexityFactor,
  menuVarietyWalkawayProbability,
  signatureShortageWalkawayProbability
};`,
  'export tradeoff helpers'
);

/* =========================================================
   B. 招牌菜收益增强，但缺货有真实代价
   ========================================================= */

replaceExact(
  'src/customer/customerEngineV10.js',
  'if(d.signature)score+=5;',
  'if(d.signature)score+=9;',
  'signature benefit'
);

/* =========================================================
   C. 日结保存经营取舍结果
   ========================================================= */

replaceExact(
  'src/operations/operationsStoreV080.js',
`    priceWalkaways:
      Math.max(
        0,
        Number(
          floor.priceWalkawaysToday
        ) ||
        0
      ),
    stockouts:`,
`    priceWalkaways:
      Math.max(
        0,
        Number(
          floor.priceWalkawaysToday
        ) ||
        0
      ),
    varietyWalkaways:
      Math.max(
        0,
        Number(
          floor.varietyWalkawaysToday
        ) ||
        0
      ),
    signatureWalkaways:
      Math.max(
        0,
        Number(
          floor.signatureWalkawaysToday
        ) ||
        0
      ),
    stockouts:`,
  'store tradeoff walkaways'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
`    avgWaitMinutes:
      Number(
        floor.avgWaitMinutes
      ) ||
      0,
    expiredWasteValue:`,
`    avgWaitMinutes:
      Number(
        floor.avgWaitMinutes
      ) ||
      0,
    avgCookMinutes:
      Number(
        floor.avgCookMinutes
      ) ||
      0,
    activeMenuCount:
      runtime &&
      Array.isArray(
        runtime.menu
      )
        ? runtime.menu
            .filter(
              item =>
                item &&
                item.active !==
                  false
            )
            .length
        : 0,
    expiredWasteValue:`,
  'store menu count and kitchen speed'
);

/* =========================================================
   D. 策略建议增加可逆性：菜单太窄时会主动恢复菜品
   ========================================================= */

replaceExact(
  'src/operations/operationsStoreV080.js',
`  const rows =
    strategyMenuRows(
      shopId,
      runtime
    );

  if (!rows.length) {`,
`  const rows =
    strategyMenuRows(
      shopId,
      runtime
    );

  const inactiveMenu =
    (
      runtime.menu ||
      []
    ).filter(
      item =>
        item &&
        item.active ===
          false
    );

  if (
    Number(
      signals.varietyWalkaways
    ) >
      0 &&
    inactiveMenu.length
  ) {
    const restore =
      inactiveMenu
        .slice()
        .sort(
          (a,b) =>
            (
              Number(
                b.stats &&
                b.stats.orders
              ) ||
              0
            ) -
            (
              Number(
                a.stats &&
                a.stats.orders
              ) ||
              0
            )
        )[0];

    return {
      id:'restore_variety',
      action:'reactivate_dish',
      executable:true,
      menuItemId:
        restore.id,
      label:
        '恢复「' +
        restore.name +
        '」丰富菜单',
      detail:
        '上次有' +
        Number(
          signals.varietyWalkaways
        ) +
        '位顾客因选择太少离开',
      successMessage:
        '已恢复一道菜，下一营业日观察选择流失和出餐速度'
    };
  }

  if (!rows.length) {`,
  'strategy can reverse excessive menu focus'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
`  if (
    Number(
      signals.stockouts
    ) >
      0 &&
    !wasteHigh
  ) {`,
`  if (
    Number(
      signals.signatureWalkaways
    ) >
      0 &&
    !wasteHigh
  ) {
    return {
      id:'repair_signature_stock',
      action:'restock',
      executable:true,
      label:'优先保障招牌菜原料',
      detail:
        '上次有' +
        Number(
          signals.signatureWalkaways
        ) +
        '位顾客因招牌菜缺货离开',
      successMessage:
        '已补充库存，下一营业日重点观察招牌菜缺货流失'
    };
  }

  if (
    Number(
      signals.stockouts
    ) >
      0 &&
    !wasteHigh
  ) {`,
  'signature stockout strategy'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
`function applyOperatingStrategy(
  shopId
) {
  const recommendation =
    operatingStrategyRecommendation(
      shopId
    );`,
`function enrichStrategyTradeoff(
  recommendation
) {
  if (
    !recommendation ||
    typeof recommendation !==
      'object'
  ) {
    return recommendation;
  }

  let benefit =
    '减少经营波动';

  let risk =
    '需要观察下一营业日数据';

  if (
    recommendation.action ===
      'price_cut'
  ) {
    benefit =
      '降低价格流失，提高成交概率';

    risk =
      '客单价和单份毛利会下降';
  } else if (
    recommendation.action ===
      'restock'
  ) {
    benefit =
      '减少缺货，保住可成交订单';

    risk =
      '补货过量会转化为过期损耗';
  } else if (
    recommendation.action ===
      'deactivate_low_seller'
  ) {
    benefit =
      '备货更集中，厨房出餐更快';

    risk =
      '菜单选择变少，求新顾客可能离开';
  } else if (
    recommendation.action ===
      'reactivate_dish'
  ) {
    benefit =
      '增加选择，减少菜单过窄流失';

    risk =
      '备货复杂度和厨房压力会回升';
  } else if (
    recommendation.action ===
      'feature_dish'
  ) {
    benefit =
      '点单更集中，招牌记忆更强';

    risk =
      '招牌菜缺货时顾客失望会更明显';
  } else if (
    recommendation.id ===
      'observe'
  ) {
    benefit =
      '避免无意义调整造成经营震荡';

    risk =
      '短期不会主动追求更高增长';
  }

  return {
    ...recommendation,
    benefit,
    risk
  };
}

function operatingStrategyDecision(
  shopId
) {
  return enrichStrategyTradeoff(
    operatingStrategyRecommendation(
      shopId
    )
  );
}

function applyOperatingStrategy(
  shopId
) {
  const recommendation =
    operatingStrategyDecision(
      shopId
    );`,
  'tradeoff-enriched strategy decision'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
`  } else if (
    recommendation.action ===
      'feature_dish'
  ) {
    result =
      setMenuFeatured(
        shopId,
        recommendation
          .menuItemId
      );
  } else if (
    recommendation.action ===
      'deactivate_low_seller'
  ) {`,
`  } else if (
    recommendation.action ===
      'feature_dish'
  ) {
    result =
      setMenuFeatured(
        shopId,
        recommendation
          .menuItemId
      );
  } else if (
    recommendation.action ===
      'reactivate_dish'
  ) {
    result =
      setMenuActive(
        shopId,
        recommendation
          .menuItemId,
        true
      );

    if (
      result &&
      result.ok
    ) {
      recordTrackedDecision(
        shopId,
        'menu_focus',
        {
          menuItemId:
            recommendation
              .menuItemId,
          name:
            result.item &&
            result.item.name ||
            null,
          action:'reactivate',
          source:'active_strategy'
        },
        baseline
      );
    }
  } else if (
    recommendation.action ===
      'deactivate_low_seller'
  ) {`,
  'reactivate menu action'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
`  operatingStrategyRecommendation,
  applyOperatingStrategy,`,
`  operatingStrategyRecommendation,
  operatingStrategyDecision,
  applyOperatingStrategy,`,
  'export strategy decision'
);

/* =========================================================
   E. 日结诊断识别菜单过窄与招牌菜缺货
   ========================================================= */

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  if (
    extra &&
    extra.regulatory &&`,
`  if (
    Number(
      signals.varietyWalkaways
    ) >
    0
  ) {
    reasons.push({
      code:'MENU_TOO_NARROW',
      severity:'warning',
      message:
        '菜单选择过少导致 ' +
        Number(
          signals.varietyWalkaways
        ) +
        ' 位顾客离开'
    });
  }

  if (
    Number(
      signals.signatureWalkaways
    ) >
    0
  ) {
    reasons.push({
      code:'SIGNATURE_STOCKOUT',
      severity:'warning',
      message:
        '招牌菜缺货导致 ' +
        Number(
          signals.signatureWalkaways
        ) +
        ' 位顾客放弃消费'
    });
  }

  if (
    extra &&
    extra.regulatory &&`,
  'tradeoff reasons'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  if (
    reasons.some(
      item =>
        item.code ===
        'REPEAT_WEAK'
    )
  ) {`,
`  if (
    reasons.some(
      item =>
        item.code ===
        'MENU_TOO_NARROW'
    )
  ) {
    actions.push({
      id:'restore_menu_variety',
      routeId:'research',
      message:'恢复一道匹配客群的菜，避免菜单过窄'
    });
  }

  if (
    reasons.some(
      item =>
        item.code ===
        'SIGNATURE_STOCKOUT'
    )
  ) {
    actions.push({
      id:'protect_signature_stock',
      routeId:'supply',
      message:'优先保障招牌菜关键原料'
    });
  }

  if (
    reasons.some(
      item =>
        item.code ===
        'REPEAT_WEAK'
    )
  ) {`,
  'tradeoff next actions'
);

/* =========================================================
   F. UI明确告诉玩家“收益/风险”
   ========================================================= */

replaceExact(
  'src/scenes/businessScene.js',
`      operations
        .operatingStrategyRecommendation(
          shop.id
        );`,
`      operations
        .operatingStrategyDecision(
          shop.id
        );`,
  'use enriched strategy in UI'
);

replaceExact(
  'src/scenes/businessScene.js',
`      latestSignals &&
      latestSignals.topDish
        ? '热销菜：' +
          latestSignals
            .topDish
            .name +
          ' · ' +
          latestSignals
            .topDish
            .qty +
          '份 · 复购意向' +
          Math.round(
            Number(
              latestSignals
                .avgRepeatIntent
            ) *
            100
          ) +
          '%'
        : '经营因果：价格、库存、复购数据将在日结后形成',`,
`      strategy &&
      strategy.benefit
        ? '取舍：' +
          strategy.benefit +
          '；风险：' +
          strategy.risk
        : latestSignals &&
          latestSignals.topDish
          ? '热销菜：' +
            latestSignals
              .topDish
              .name +
            ' · ' +
            latestSignals
              .topDish
              .qty +
            '份 · 复购意向' +
            Math.round(
              Number(
                latestSignals
                  .avgRepeatIntent
              ) *
              100
            ) +
            '%'
          : '经营因果：价格、库存、复购数据将在日结后形成',`,
  'show strategy tradeoff'
);

/* =========================================================
   G. 回归测试
   ========================================================= */

replaceExact(
  'tests/operationCoreV070.test.js',
`assert.ok(
  expensiveReject >
  0.5,
  '明显超预算菜价必须产生真实流失风险'
);`,
`assert.ok(
  expensiveReject >
  0.5,
  '明显超预算菜价必须产生真实流失风险'
);

assert.ok(
  floorSimulation
    .menuComplexityFactor(
      3
    ) <
  floorSimulation
    .menuComplexityFactor(
      8
    ),
  '精简菜单必须真实降低厨房复杂度'
);

const lowNoveltyVarietyRisk =
  floorSimulation
    .menuVarietyWalkawayProbability(
      {
        traits:{
          noveltySeeking:20
        }
      },
      2
    );

const highNoveltyVarietyRisk =
  floorSimulation
    .menuVarietyWalkawayProbability(
      {
        traits:{
          noveltySeeking:90
        }
      },
      2
    );

assert.ok(
  highNoveltyVarietyRisk >
  lowNoveltyVarietyRisk,
  '菜单过窄时求新型顾客必须更容易流失'
);

assert.equal(
  floorSimulation
    .menuVarietyWalkawayProbability(
      {
        traits:{
          noveltySeeking:90
        }
      },
      6
    ),
  0,
  '菜单足够丰富时不能平白制造选择不足流失'
);

assert.ok(
  floorSimulation
    .signatureShortageWalkawayProbability(
      {
        traits:{
          loyalty:80
        }
      },
      {
        signature:true,
        available:false,
        popularity:90
      }
    ) >
  0,
  '招牌菜缺货必须产生额外失望流失风险'
);`,
  'deterministic tradeoff tests'
);

replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`const strategy =
  operations
    .operatingStrategyRecommendation(`,
`const strategy =
  operations
    .operatingStrategyDecision(`,
  'integration uses enriched strategy'
);

replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`assert.ok(
  strategy &&
  typeof strategy.label ===
    'string',
  '日结后必须生成首要经营策略'
);`,
`assert.ok(
  strategy &&
  typeof strategy.label ===
    'string',
  '日结后必须生成首要经营策略'
);

assert.ok(
  typeof strategy.benefit ===
    'string' &&
  typeof strategy.risk ===
    'string',
  '经营策略必须同时告诉玩家收益与风险'
);`,
  'integration checks tradeoff'
);

replaceExact(
  'tests/businessDayUiV0844.test.js',
`    '.applyOperatingStrategy('
  ) &&`,
`    '.applyOperatingStrategy('
  ) &&
  businessSource.includes(
    '.operatingStrategyDecision('
  ) &&
  businessSource.includes(
    '取舍：'
  ) &&
  businessSource.includes(
    '风险：'
  ) &&`,
  'UI tradeoff assertions'
);

/* =========================================================
   H. 版本同步
   ========================================================= */

updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 863
        versionName '0.8.63'`,
`        versionCode 864
        versionName '0.8.64'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.63 主动经营决策版启动成功'",
  "'城市餐饮经营小游戏 V0.8.64 经营取舍深化版启动成功'",
  'startup banner'
);

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0864] 经营取舍深化完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
