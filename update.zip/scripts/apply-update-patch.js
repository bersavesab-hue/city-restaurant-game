'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const perf = require('./v094-perf-lib.js');

const ROOT = process.cwd();
const MAIN_REL = 'src/main.js';
const MAIN_BACKUP_REL = '.v094-backup/main.js';
const PACKAGE_BACKUP_REL = '.v094-backup/package.json';
const STATE_REL = 'scripts/.v094-test-state.json';
const RUNNER_CMD = 'node scripts/v094-adaptive-test-runner.js';

function say(msg) {
  process.stdout.write(`[V0.9.4 installer] ${msg}\n`);
}

function must(relative) {
  const full = path.join(ROOT, relative);
  if (!fs.existsSync(full)) throw new Error(`required file missing: ${relative}`);
  return full;
}

function restoreOnFailure(mainPath, pkgPath, mainBytes, pkgBytes) {
  try { fs.writeFileSync(mainPath, mainBytes); } catch (_) {}
  try { fs.writeFileSync(pkgPath, pkgBytes); } catch (_) {}
}

function main() {
  const mainPath = must(MAIN_REL);
  const pkgPath = must('package.json');
  must('scripts/v094-perf-lib.js');
  must('scripts/v094-adaptive-test-runner.js');

  const originalMainBytes = fs.readFileSync(mainPath);
  const originalPackageBytes = fs.readFileSync(pkgPath);
  const baseSource = originalMainBytes.toString('utf8');
  const pkg = JSON.parse(originalPackageBytes.toString('utf8'));

  if (!pkg.scripts || typeof pkg.scripts.test !== 'string' || !pkg.scripts.test.trim()) {
    throw new Error('package.json scripts.test missing; refusing to bypass repository tests');
  }
  if (pkg.scripts.test.includes('v094-adaptive-test-runner')) {
    throw new Error('V0.9.4 adaptive runner already installed unexpectedly');
  }

  const state = {
    version: '0.9.4',
    mainPath: MAIN_REL,
    mainBackupPath: MAIN_BACKUP_REL,
    packageBackupPath: PACKAGE_BACKUP_REL,
    originalPretest: typeof pkg.scripts.pretest === 'string' ? pkg.scripts.pretest : '',
    originalTest: pkg.scripts.test,
    originalPosttest: typeof pkg.scripts.posttest === 'string' ? pkg.scripts.posttest : ''
  };

  const backupDir = path.join(ROOT, '.v094-backup');
  fs.mkdirSync(backupDir, { recursive: true });
  fs.writeFileSync(path.join(ROOT, MAIN_BACKUP_REL), originalMainBytes);
  fs.writeFileSync(path.join(ROOT, PACKAGE_BACKUP_REL), originalPackageBytes);

  try {
    const candidate = perf.applyVariant(baseSource, 'full');
    fs.writeFileSync(mainPath, candidate, 'utf8');

    const syntax = cp.spawnSync(process.execPath, ['--check', MAIN_REL], {
      cwd: ROOT,
      encoding: 'utf8'
    });
    if (syntax.status !== 0) {
      throw new Error(
        `candidate main.js syntax failed\n${syntax.stdout || ''}${syntax.stderr || ''}`
      );
    }

    fs.writeFileSync(
      path.join(ROOT, STATE_REL),
      JSON.stringify(state, null, 2) + '\n',
      'utf8'
    );

    // 关键修复：父级 npm test 会自动先执行 pretest。
    // V0.9.3 只替换 test，导致旧 pretest 能在自适应 runner 启动前先把流程打断。
    // 这里临时移除 pretest/posttest，由 runner 按原顺序逐一执行原命令。
    delete pkg.scripts.pretest;
    delete pkg.scripts.posttest;
    pkg.scripts.test = RUNNER_CMD;
    fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
  } catch (error) {
    restoreOnFailure(mainPath, pkgPath, originalMainBytes, originalPackageBytes);
    throw error;
  }

  say('已安装生命周期安全的自适应倍速优化。');
  say('父 npm test 不再提前执行旧 pretest；runner 会亲自按 pretest -> test -> posttest 验证。');
  say('full -> throttle -> resolution -> baseline 自动回退。');
}

main();
