'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.48';
const TARGET_VERSION = '0.8.49';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0849] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0849] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* 1) 增加营业日目标生成与结算。 */
replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`function buildReasons(
  financial,
  active,
  endSnapshot,
  extra
) {`,
`function buildDailyGoal(
  state,
  baseline
) {
  const previous =
    state.history.find(
      item =>
        item &&
        item.status ===
          'closed' &&
        item.financial
    );

  if (!previous) {
    return {
      id:'first_order',
      kind:'orders_at_least',
      label:'拿下今天第一单',
      target:1,
      sourceDay:null,
      status:'active'
    };
  }

  const financial =
    previous.financial ||
    {};

  const end =
    previous.endSnapshot ||
    baseline ||
    {};

  if (
    Number(
      financial.orders
    ) <=
    0
  ) {
    return {
      id:'recover_orders',
      kind:'orders_at_least',
      label:'今天至少完成1笔有效订单',
      target:1,
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      end.tensionScore
    ) >=
    90
  ) {
    return {
      id:'cash_relief',
      kind:'tension_at_most',
      label:'把现金压力降到90以下',
      target:89,
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      end.inventoryAlerts
    ) >
    0
  ) {
    return {
      id:'clear_inventory_alerts',
      kind:'inventory_alerts_at_most',
      label:'把库存预警清零',
      target:0,
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      financial.foodCostRate
    ) >
    42
  ) {
    return {
      id:'food_cost_control',
      kind:'food_cost_at_most',
      label:'把食材成本率压到42%以内',
      target:42,
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      financial.profit
    ) <=
    0
  ) {
    return {
      id:'profit_turnaround',
      kind:'profit_at_least',
      label:'让今天净利润转正',
      target:0,
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      end.rating
    ) >
      0 &&
    Number(
      end.rating
    ) <
      3.8
  ) {
    return {
      id:'rating_recovery',
      kind:'rating_at_least',
      label:'把门店评分提升到3.8以上',
      target:3.8,
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  return {
    id:'profit_growth',
    kind:'profit_at_least',
    label:'今天净利润比昨日提升5%',
    target:
      Math.max(
        1,
        round(
          Number(
            financial.profit
          ) *
          1.05
        )
      ),
    baselineValue:
      round(
        financial.profit
      ),
    sourceDay:
      previous.day,
    status:'active'
  };
}

function evaluateDailyGoal(
  goal,
  financial,
  endSnapshot
) {
  if (!goal) {
    return null;
  }

  let actual = 0;
  let completed = false;

  if (
    goal.kind ===
    'orders_at_least'
  ) {
    actual =
      Number(
        financial.orders
      ) ||
      0;

    completed =
      actual >=
      Number(
        goal.target
      );
  } else if (
    goal.kind ===
    'profit_at_least'
  ) {
    actual =
      round(
        financial.profit
      );

    completed =
      actual >=
      Number(
        goal.target
      );
  } else if (
    goal.kind ===
    'food_cost_at_most'
  ) {
    actual =
      round(
        financial.foodCostRate
      );

    completed =
      Number(
        financial.orders
      ) >
        0 &&
      actual <=
        Number(
          goal.target
        );
  } else if (
    goal.kind ===
    'inventory_alerts_at_most'
  ) {
    actual =
      Math.max(
        0,
        Number(
          endSnapshot.inventoryAlerts
        ) ||
        0
      );

    completed =
      actual <=
        Number(
          goal.target
        );
  } else if (
    goal.kind ===
    'tension_at_most'
  ) {
    actual =
      round(
        endSnapshot.tensionScore
      );

    completed =
      actual <=
        Number(
          goal.target
        );
  } else if (
    goal.kind ===
    'rating_at_least'
  ) {
    actual =
      round(
        endSnapshot.rating
      );

    completed =
      actual >=
        Number(
          goal.target
        );
  }

  return {
    ...clone(
      goal
    ),
    status:
      completed
        ? 'completed'
        : 'missed',
    completed,
    actual,
    message:
      completed
        ? '今日目标完成'
        : '今日目标未完成'
  };
}

function buildReasons(
  financial,
  active,
  endSnapshot,
  extra
) {`,
  'daily goal functions'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  state.active = {`,
`  const normalizedBaseline =
    normalizeSnapshot(
      baseline
    );

  const goal =
    buildDailyGoal(
      state,
      normalizedBaseline
    );

  state.active = {`,
  'goal creation before active day'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`    baseline:
      normalizeSnapshot(
        baseline
      ),
    visits:{`,
`    baseline:
      clone(
        normalizedBaseline
      ),
    goal:
      clone(
        goal
      ),
    visits:{`,
  'goal stored on active day'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  const reasons =
    buildReasons(
      financial,
      active,
      endSnapshot,
      extra
    );

  const brief = {`,
`  const reasons =
    buildReasons(
      financial,
      active,
      endSnapshot,
      extra
    );

  const goalResult =
    evaluateDailyGoal(
      active.goal,
      financial,
      endSnapshot
    );

  const brief = {`,
  'goal evaluation at close'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`    financial,
    deltas:{`,
`    financial,
    goal:
      clone(
        active.goal
      ),
    goalResult:
      clone(
        goalResult
      ),
    deltas:{`,
  'goal result in daily brief'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  state.metrics.totalRevenue =
    round(`,
`  if (goalResult) {
    const metricKey =
      goalResult.completed
        ? 'goalsCompleted'
        : 'goalsMissed';

    state.metrics[
      metricKey
    ] =
      (
        Number(
          state.metrics[
            metricKey
          ]
        ) ||
        0
      ) +
      1;
  }

  state.metrics.totalRevenue =
    round(`,
  'goal metrics'
);

/* 2) 营业日页面显示当天目标和昨日目标结果。 */
replaceExact(
  'src/scenes/businessScene.js',
`    ui.text(
      ctx,
      shop.status ===
        'trial_opening'
        ? '试营业中 · 顾客订单、营业额和成本会实时计入今日经营'
        : shop.status ===
            'open'
          ? '营业数据、决策和诊断会在日结时统一结算'
          : '完成开店筹备后即可进入试营业',
      28,
      207,
      6.5,
      '#71858F',
      '600'
    );`,
`    const goalLine =
      active &&
      active.goal
        ? '今日目标：' +
          active.goal.label
        : latest &&
          latest.goalResult
          ? (
              latest
                .goalResult
                .completed
                ? '昨日目标已完成：'
                : '昨日目标未完成：'
            ) +
            latest
              .goalResult
              .label
          : shop.status ===
              'trial_opening'
            ? '试营业中 · 顾客订单、营业额和成本会实时计入今日经营'
            : shop.status ===
                'open'
              ? '营业数据、决策和诊断会在日结时统一结算'
              : '完成开店筹备后即可进入试营业';

    ui.text(
      ctx,
      goalLine,
      28,
      207,
      6.5,
      active &&
      active.goal
        ? '#C08824'
        : latest &&
          latest.goalResult
          ? latest
              .goalResult
              .completed
              ? '#248B63'
              : '#C85242'
          : '#71858F',
      active &&
      active.goal
        ? '800'
        : '600'
    );`,
  'goal line in operating header'
);

/* 3) 开始营业时直接告诉玩家今天追什么。 */
replaceExact(
  'src/scenes/businessScene.js',
`        opUi.toast(
          result.ok
            ? result.existing
              ? '本营业日已经开始'
              : '营业日已开始'
            : result.reason ||
              '无法开始营业日'
        );`,
`        opUi.toast(
          result.ok
            ? result.existing
              ? '本营业日已经开始'
              : result.day &&
                result.day.goal
                ? '营业日已开始 · ' +
                  result.day
                    .goal
                    .label
                : '营业日已开始'
            : result.reason ||
              '无法开始营业日'
        );`,
  'start day goal toast'
);

/* 4) 日结时立刻给目标成败反馈。 */
replaceExact(
  'src/scenes/businessScene.js',
`          opUi.toast(
            result.ok
              ? '日结完成，经营复盘已生成'
              : result.reason ||
                '无法完成日结'
          );`,
`          opUi.toast(
            result.ok
              ? result.dailyBrief &&
                result.dailyBrief
                  .goalResult
                ? result.dailyBrief
                    .goalResult
                    .completed
                  ? '日结完成 · 今日目标达成'
                  : '日结完成 · 今日目标未达成'
                : '日结完成，经营复盘已生成'
              : result.reason ||
                '无法完成日结'
          );`,
  'close day goal result toast'
);

/* 5) 现有营业日集成测试加入目标闭环验证。 */
replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`const opened=operations.startOperatingDay('shop_v0843_integration');
assert.ok(opened.ok);`,
`const opened=operations.startOperatingDay('shop_v0843_integration');
assert.ok(opened.ok);
assert.ok(opened.day && opened.day.goal,'营业日开始时必须生成今日目标');
assert.equal(opened.day.goal.id,'first_order');`,
  'operating goal start assertion'
);

replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`assert.ok(closed.dailyBrief,'日结必须返回统一复盘');`,
`assert.ok(closed.dailyBrief,'日结必须返回统一复盘');
assert.ok(closed.dailyBrief.goalResult,'日结必须结算今日目标');
assert.equal(closed.dailyBrief.goalResult.completed,true,'完成首单后首日目标必须达成');`,
  'operating goal close assertion'
);

/* 6) UI接线测试保证目标信息不会被后续改丢。 */
replaceExact(
  'tests/businessDayUiV0844.test.js',
`    '.operatingDayHistory('
  ),`,
`    '.operatingDayHistory('
  ) &&
  businessSource.includes(
    '今日目标：'
  ) &&
  businessSource.includes(
    'goalResult'
  ),`,
  'goal UI assertions'
);

/* 7) 版本同步。 */
updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 848
        versionName '0.8.48'`,
`        versionCode 849
        versionName '0.8.49'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.48 连续经营正反馈版启动成功'",
  "'城市餐饮经营小游戏 V0.8.49 每日经营目标版启动成功'",
  'startup banner'
);

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0849] 每日经营目标补丁完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
