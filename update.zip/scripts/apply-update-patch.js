'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = process.cwd();

function log(message) {
  process.stdout.write(`[V0.9.2 stable] ${message}\n`);
}

function mustExist(relative) {
  const full = path.join(ROOT, relative);
  if (!fs.existsSync(full)) throw new Error(`required file missing after unzip: ${relative}`);
  return full;
}

function appendOnce(relative, marker, block) {
  const full = path.join(ROOT, relative);
  if (!fs.existsSync(full)) return false;
  let source = fs.readFileSync(full, 'utf8');
  if (source.includes(marker)) return true;
  source += `\n${block.trim()}\n`;
  fs.writeFileSync(full, source, 'utf8');
  return true;
}

function installAndroidBridge() {
  const relative = 'android/entry.js';
  const marker = 'V090_CORE_BRIDGE_BEGIN';
  const block = `
// V090_CORE_BRIDGE_BEGIN
// Backend-only integration. This does not draw or modify any UI.
try {
  const v090Bridge = require('../src/simulation/v090/bridge.js');
  v090Bridge.install(globalThis);
} catch (error) {
  console.error('[V0.9.x core] bridge install failed', error);
  throw error;
}
// V090_CORE_BRIDGE_END
`;
  if (appendOnce(relative, marker, block)) {
    log('android/entry.js 已注册经营核心桥接。');
  } else {
    log('未找到 android/entry.js；跳过全局桥接。');
  }
}

function exposeFromNewestLegacySimulation() {
  const dir = path.join(ROOT, 'src', 'operations');
  if (!fs.existsSync(dir)) return;
  const candidates = fs.readdirSync(dir)
    .filter(name => /^restaurantSimulationV.*\.js$/i.test(name))
    .sort();
  if (!candidates.length) return;
  const newest = candidates[candidates.length - 1];
  const relative = path.posix.join('src/operations', newest);
  const marker = 'V090_CORE_COMPAT_EXPORT_BEGIN';
  const block = `
// V090_CORE_COMPAT_EXPORT_BEGIN
try {
  const __restaurantCoreV090 = require('../simulation/v090/restaurantCore.js');
  if (typeof module !== 'undefined' && module.exports &&
      (typeof module.exports === 'object' || typeof module.exports === 'function')) {
    module.exports.coreV090 = __restaurantCoreV090;
    module.exports.simulateV090Day = __restaurantCoreV090.simulateDay;
    module.exports.simulateV090Days = __restaurantCoreV090.simulateDays;
  }
} catch (error) {
  console.error('[V0.9.x core] legacy compatibility export failed', error);
}
// V090_CORE_COMPAT_EXPORT_END
`;
  appendOnce(relative, marker, block);
  log(`已在 ${relative} 暴露 V0.9.x 兼容接口。`);
}

function patchMainRenderOnly() {
  const relative = 'src/main.js';
  const full = mustExist(relative);
  let source = fs.readFileSync(full, 'utf8');

  if (source.includes('V092_RENDER_PACING_BEGIN')) {
    log('src/main.js 已存在 V0.9.2 渲染节流，跳过重复修改。');
    return;
  }

  // If an earlier failed/manual V0.9.1 replacement somehow exists locally,
  // do not stack another governor on top of it.
  if (source.includes('V091_FRAME_PACING_STATE_BEGIN') || source.includes('shouldRunSimulation(')) {
    throw new Error('检测到旧 V0.9.1 模拟节流代码。请先恢复仓库主分支版本后再应用本包，避免叠加修改。');
  }

  const timeRequireRe = /const\s+timeSystem\s*=\s*require\(\s*['"]\.\/core\/timeSystem\.js['"]\s*\)\s*;?/m;
  const timeMatch = source.match(timeRequireRe);
  if (!timeMatch) throw new Error('无法定位 timeSystem require；未修改 src/main.js。');

  source = source.replace(
    timeRequireRe,
    `${timeMatch[0]}\n\n// V092_RENDER_PACING_BEGIN\nconst framePacing = require('./core/framePacing.js');\n// V092_RENDER_PACING_END`
  );

  const lastFrameRe = /(?:let|var)\s+lastFrameTime\s*=\s*null\s*;?/m;
  const lastFrameMatch = source.match(lastFrameRe);
  if (!lastFrameMatch) throw new Error('无法定位 lastFrameTime；未修改 src/main.js。');

  source = source.replace(
    lastFrameRe,
    `${lastFrameMatch[0]}\n\n// V092_RENDER_PACING_STATE_BEGIN\nlet lastUiRenderTime = 0;\nlet pendingUiRender = true;\n// V092_RENDER_PACING_STATE_END`
  );

  // Keep the original simulation loop untouched. Only replace the tiny redraw block.
  const renderBlockRe = /if\s*\(\s*advancedMinutes\s*>\s*0\s*\|\|\s*animationChanged\s*\|\|\s*needsResize\s*\)\s*\{\s*render\(\s*\)\s*;?\s*\}/m;
  const renderBlockMatch = source.match(renderBlockRe);
  if (!renderBlockMatch) {
    throw new Error('无法定位原有 render 条件块；为避免破坏主循环，本包拒绝盲改。');
  }

  const replacement = `// V092_RENDER_PACING_LOGIC_BEGIN
  if (
    advancedMinutes > 0 ||
    animationChanged ||
    needsResize
  ) {
    pendingUiRender = true;
  }

  if (pendingUiRender) {
    const __uiSpeed =
      typeof timeSystem.getSpeed === 'function'
        ? timeSystem.getSpeed()
        : 1;

    const __uiPaused =
      typeof timeSystem.isPaused === 'function'
        ? timeSystem.isPaused()
        : false;

    if (
      framePacing.shouldRender(
        now - lastUiRenderTime,
        __uiSpeed,
        __uiPaused,
        animationChanged,
        needsResize
      )
    ) {
      render();
      lastUiRenderTime = now;
      pendingUiRender = false;
    }
  }
  // V092_RENDER_PACING_LOGIC_END`;

  source = source.replace(renderBlockRe, replacement);

  // Reset only frame bookkeeping after returning from background. This does not
  // alter the simulation engine, event order, or timeSystem update cadence.
  if (!source.includes('V092_VISIBILITY_RESET_BEGIN')) {
    const scheduleRe = /scheduleNextFrame\(\s*gameLoop\s*\)\s*;?/g;
    const matches = Array.from(source.matchAll(scheduleRe));
    if (matches.length) {
      const last = matches[matches.length - 1];
      const idx = last.index;
      const text = last[0];
      const block = `// V092_VISIBILITY_RESET_BEGIN
if (typeof document !== 'undefined' && document.addEventListener) {
  document.addEventListener('visibilitychange', function () {
    lastFrameTime = null;
    lastUiRenderTime = 0;
    pendingUiRender = true;
    if (timeSystem && typeof timeSystem.resetAccumulator === 'function') {
      timeSystem.resetAccumulator();
    }
  });
}
// V092_VISIBILITY_RESET_END

`;
      source = source.slice(0, idx) + block + text + source.slice(idx + text.length);
    }
  }

  fs.writeFileSync(full, source, 'utf8');
  log('src/main.js 已仅做 UI 渲染节流；scene/time 模拟更新频率保持原样。');
}

function syntaxCheck() {
  const targets = [
    'src/core/framePacing.js',
    'src/simulation/v090/restaurantCore.js',
    'tests/v090_core_rework.test.js',
    'tests/v091_speed_performance.test.js',
    'scripts/v090-diagnostics.js',
    'src/main.js'
  ];
  for (const relative of targets) {
    mustExist(relative);
    const result = cp.spawnSync(process.execPath, ['--check', relative], { cwd: ROOT, encoding: 'utf8' });
    if (result.status !== 0) {
      process.stderr.write(result.stdout || '');
      process.stderr.write(result.stderr || '');
      throw new Error(`syntax check failed: ${relative}`);
    }
  }
  log('语法检查通过。');
}

function runSelfTest(file) {
  const result = cp.spawnSync(process.execPath, [file], { cwd: ROOT, encoding: 'utf8' });
  process.stdout.write(result.stdout || '');
  process.stderr.write(result.stderr || '');
  if (result.status !== 0) throw new Error(`${file} failed`);
}

function main() {
  mustExist('src/simulation/v090/restaurantCore.js');
  mustExist('src/core/framePacing.js');

  // Intentionally DO NOT modify package.json or npm test.
  // The repository's existing test suite remains exactly as-is.
  installAndroidBridge();
  exposeFromNewestLegacySimulation();
  patchMainRenderOnly();
  syntaxCheck();
  runSelfTest('tests/v090_core_rework.test.js');
  runSelfTest('tests/v091_speed_performance.test.js');
  log('安装完成：经营核心 + V0.9.2 稳定版倍速渲染优化。');
}

main();
