'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const BASE_VERSION =
  '0.8.43';

const TARGET_VERSION =
  '0.8.44';

function readJson(relative) {
  return JSON.parse(
    fs.readFileSync(
      path.join(
        ROOT,
        relative
      ),
      'utf8'
    )
  );
}

function writeJson(
  relative,
  value
) {
  fs.writeFileSync(
    path.join(
      ROOT,
      relative
    ),
    JSON.stringify(
      value,
      null,
      2
    ) +
    '\n',
    'utf8'
  );
}

function requireFile(relative) {
  const absolute =
    path.join(
      ROOT,
      relative
    );

  if (!fs.existsSync(absolute)) {
    throw new Error(
      'V0.8.44补丁缺少文件：' +
      relative
    );
  }

  return fs.readFileSync(
    absolute,
    'utf8'
  );
}

const pkg =
  readJson(
    'package.json'
  );

if (
  pkg.version !==
    BASE_VERSION &&
  pkg.version !==
    TARGET_VERSION
) {
  throw new Error(
    'V0.8.44补丁基线不匹配：当前为 ' +
    pkg.version +
    '，要求 ' +
    BASE_VERSION
  );
}

const businessSource =
  requireFile(
    'src/scenes/businessScene.js'
  );

const storeSource =
  requireFile(
    'src/scenes/storeScene.js'
  );

const requiredTokens = [
  [
    businessSource,
    'renderOperatingDay',
    '营业日页面未正确接入'
  ],
  [
    businessSource,
    "'day:close'",
    '安全日结按钮未正确接入'
  ],
  [
    storeSource,
    "'module:day'",
    '门店主页缺少营业日直达入口'
  ],
  [
    requireFile(
      'tools/devkit/dependency-audit.js'
    ),
    'stripJsComments',
    '依赖检测误报修复未安装'
  ]
];

for (
  const row
  of requiredTokens
) {
  if (!row[0].includes(row[1])) {
    throw new Error(
      row[2]
    );
  }
}

pkg.version =
  TARGET_VERSION;

pkg.scripts =
  pkg.scripts ||
  {};

const safety =
  'node scripts/patch-safety-v089.js';

const gate =
  'node scripts/quality-gate-v089.js';

const existingPretest =
  String(
    pkg.scripts.pretest ||
    ''
  )
    .split('&&')
    .map(
      item =>
        item.trim()
    )
    .filter(Boolean)
    .filter(
      item =>
        item !== safety &&
        item !== gate
    );

pkg.scripts.pretest =
  [
    safety,
    gate,
    ...existingPretest
  ].join(
    ' && '
  );

writeJson(
  'package.json',
  pkg
);

const lock =
  readJson(
    'package-lock.json'
  );

lock.version =
  TARGET_VERSION;

if (
  lock.packages &&
  lock.packages['']
) {
  lock.packages[''].version =
    TARGET_VERSION;
}

writeJson(
  'package-lock.json',
  lock
);

console.log(
  'V0.8.44稳定接线修复安装完成'
);
