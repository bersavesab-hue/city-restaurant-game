'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const TARGET_VERSION = '0.8.14';

function abs(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(abs(rel), 'utf8');
}

function write(rel, content) {
  fs.writeFileSync(abs(rel), content, 'utf8');
}

function replaceOnce(source, from, to, label) {
  if (source.includes(to)) return source;
  const index = source.indexOf(from);
  if (index < 0) {
    throw new Error('V0.8.14 patch anchor missing: ' + label);
  }
  return source.slice(0, index) + to + source.slice(index + from.length);
}

function insertAfter(source, anchor, addition, marker, label) {
  if (marker && source.includes(marker)) return source;
  const index = source.indexOf(anchor);
  if (index < 0) {
    throw new Error('V0.8.14 insert anchor missing: ' + label);
  }
  const end = index + anchor.length;
  return source.slice(0, end) + addition + source.slice(end);
}

function replaceSection(source, startMarker, endMarker, replacement, label) {
  if (source.includes(replacement)) return source;
  const start = source.indexOf(startMarker);
  if (start < 0) {
    throw new Error('V0.8.14 section start missing: ' + label);
  }
  const end = source.indexOf(endMarker, start + startMarker.length);
  if (end < 0) {
    throw new Error('V0.8.14 section end missing: ' + label);
  }
  return source.slice(0, start) + replacement + '\n\n' + source.slice(end);
}

function updatePackage() {
  const pkg = JSON.parse(read('package.json'));
  if (
    pkg.version !== '0.8.13' &&
    pkg.version !== TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.14 requires formal V0.8.13 baseline; current=' + pkg.version
    );
  }
  pkg.version = TARGET_VERSION;
  write('package.json', JSON.stringify(pkg, null, 2) + '\n');
}

function updatePackageLock() {
  const rel = 'package-lock.json';
  if (!fs.existsSync(abs(rel))) return;
  const lock = JSON.parse(read(rel));
  lock.version = TARGET_VERSION;
  if (lock.packages && lock.packages['']) {
    lock.packages[''].version = TARGET_VERSION;
  }
  write(rel, JSON.stringify(lock, null, 2) + '\n');
}

function updateMain() {
  const rel = 'src/main.js';
  let source = read(rel);

  source = insertAfter(
    source,
`const timeScheduleCoordinator =
  require('./core/timeScheduleCoordinatorV0812.js');`,
`

const newGameFlow =
  require('./core/newGameFlowV0814.js');`,
    "require('./core/newGameFlowV0814.js')",
    'main new game flow require'
  );

  source = insertAfter(
    source,
`const featureHubScene =
  require('./scenes/featureHubSceneV0810.js');`,
`

const newGameScene =
  require('./scenes/newGameSceneV0814.js');`,
    "require('./scenes/newGameSceneV0814.js')",
    'main new game scene require'
  );

  source = insertAfter(
    source,
`sceneManager.register(
  'featureHub',
  featureHubScene
);`,
`

sceneManager.register(
  'newGame',
  newGameScene
);`,
    "'newGame',\n  newGameScene",
    'main new game scene registration'
  );

  source = insertAfter(
    source,
`// V0812_TIME_SCHEDULE_BOOT
timeScheduleCoordinator.install();
runtime.timeSchedule =
  timeScheduleCoordinator;`,
`

// V0814_NEW_GAME_FLOW_BOOT
runtime.newGameFlow =
  newGameFlow;`,
    'V0814_NEW_GAME_FLOW_BOOT',
    'main opening flow boot'
  );

  const oldRender =
`  sceneManager
    .render(
      ctx
    );

  drawBottomNav();`;

  const newRender =
`  sceneManager
    .render(
      ctx
    );

  if (
    sceneManager
      .getCurrentId() !==
    'newGame'
  ) {
    drawBottomNav();
  }`;

  source = replaceOnce(
    source,
    oldRender,
    newRender,
    'hide global nav during onboarding'
  );

  const startupReplacement =
`const restoredFromSave =
  saveSystem.load();

newGameFlow
  .initialize({
    fresh:
      !restoredFromSave,
    restoredFromSave
  });

simulationSystem
  .initialize();

if (
  !restoredFromSave
) {
  saveSystem.save();
}

if (
  api &&
  typeof api.onHide ===
    'function'
) {
  api.onHide(
    function () {
      saveSystem.save();
    }
  );
}

const startupRoute =
  newGameFlow
    .getStartupRoute();

sceneManager
  .switchTo(
    startupRoute.routeId,
    startupRoute.params
  );`;

  source = replaceSection(
    source,
    'const restoredFromSave =',
    'render();',
    startupReplacement,
    'startup route selection'
  );

  source = source.replace(
    '城市餐饮经营小游戏 V0.8.12 时间与营业日程统一版启动成功',
    '城市餐饮经营小游戏 V0.8.14 完整开局流程版启动成功'
  );

  write(rel, source);
}

function updateSystemScene() {
  const rel = 'src/scenes/systemSceneV086.js';
  let source = read(rel);

  source = insertAfter(
    source,
`const simulationSystem =
  require('../core/simulationSystem.js');`,
`

const newGameFlow =
  require('../core/newGameFlowV0814.js');`,
    "require('../core/newGameFlowV0814.js')",
    'system new game flow require'
  );

  const replacement =
`    if (
      button.id ===
      'new-game'
    ) {
      const run =
        () => {
          newGameFlow
            .restart();

          sceneManager
            .switchTo(
              'newGame'
            );

          this.toast(
            '已建立全新存档'
          );
        };

      if (
        api &&
        typeof api.showModal ===
          'function'
      ) {
        api.showModal({
          title:'重新开局',
          content:
            '当前主存档和备份都会被清除，然后进入完整开局流程。',
          confirmText:'重新开始',
          cancelText:'取消',
          success:result => {
            if (
              result &&
              result.confirm
            ) {
              run();
            }
          }
        });
      } else {
        run();
      }

      return true;
    }`;

  source = replaceSection(
    source,
`    if (
      button.id ===
      'new-game'
    ) {`,
    '    return false;',
    replacement,
    'system restart flow'
  );

  write(rel, source);
}

function updateRunner() {
  const rel = 'scripts/run-ci-tests-v060.js';
  let source = read(rel);

  if (source.includes('tests/updateInfrastructureV0814.test.js')) {
    return;
  }

  const anchor =
`    'tests/saveMigrationV0813.test.js',
    'tests/seedManagerV0813.test.js',
    'tests/updateInfrastructureV0813.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/saveMigrationV0813.test.js',
    'tests/seedManagerV0813.test.js',
    'tests/updateInfrastructureV0813.test.js',
    'tests/newGameFlowV0814.test.js',
    'tests/newGameCompatibilityV0814.test.js',
    'tests/updateInfrastructureV0814.test.js',
    'tests/v60CleanBase.test.js'`;

  source = replaceOnce(
    source,
    anchor,
    replacement,
    'permanent CI runner V0814'
  );

  write(rel, source);
}

// GitHub's setup-android@v3 may still request removed legacy SDK package "tools".
// Patch only the ephemeral runner filesystem. Nothing here is committed.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir = path.join(sdkRoot, 'cmdline-tools', 'latest');
  const sourceProperties = path.join(latestDir, 'source.properties');
  const binDir = path.join(latestDir, 'bin');
  const sdkmanager = path.join(binDir, 'sdkmanager');

  if (!fs.existsSync(sourceProperties) || !fs.existsSync(sdkmanager)) {
    console.log('[V0.8.14] Android SDK runner compatibility: preinstalled sdkmanager not found, skip');
    return;
  }

  let properties = fs.readFileSync(sourceProperties, 'utf8');
  properties = properties
    .replace(/^Pkg\.Revision=.*$/m, 'Pkg.Revision=16.0')
    .replace(/^Pkg\.Path=.*$/m, 'Pkg.Path=cmdline-tools;16.0');
  fs.writeFileSync(sourceProperties, properties, 'utf8');

  const realSdkmanager = path.join(binDir, 'sdkmanager.v0814-real');
  if (!fs.existsSync(realSdkmanager)) {
    fs.renameSync(sdkmanager, realSdkmanager);
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0814-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join('\n');

  fs.writeFileSync(sdkmanager, wrapper, 'utf8');
  fs.chmodSync(sdkmanager, 0o755);
  console.log('[V0.8.14] Android SDK runner compatibility enabled');
}

function validate() {
  const pkg = JSON.parse(read('package.json'));
  if (pkg.version !== TARGET_VERSION) {
    throw new Error('V0.8.14 package version finalize failed');
  }

  const checks = [
    [
      'src/main.js',
      [
        "require('./core/newGameFlowV0814.js')",
        "require('./scenes/newGameSceneV0814.js')",
        "'newGame',\n  newGameScene",
        'V0814_NEW_GAME_FLOW_BOOT',
        'const restoredFromSave =',
        '.getStartupRoute()'
      ]
    ],
    [
      'src/scenes/systemSceneV086.js',
      [
        "require('../core/newGameFlowV0814.js')",
        '.restart();',
        "'newGame'"
      ]
    ],
    [
      'scripts/run-ci-tests-v060.js',
      [
        'tests/newGameFlowV0814.test.js',
        'tests/newGameCompatibilityV0814.test.js',
        'tests/updateInfrastructureV0814.test.js'
      ]
    ]
  ];

  for (const [file, markers] of checks) {
    const source = read(file);
    for (const marker of markers) {
      if (!source.includes(marker)) {
        throw new Error('V0.8.14 validation missing ' + marker + ' in ' + file);
      }
    }
  }

  for (const file of [
    'src/core/newGameFlowV0814.js',
    'src/scenes/newGameSceneV0814.js',
    'tests/newGameFlowV0814.test.js',
    'tests/newGameCompatibilityV0814.test.js',
    'tests/updateInfrastructureV0814.test.js'
  ]) {
    if (!fs.existsSync(abs(file))) {
      throw new Error('V0.8.14 required file missing: ' + file);
    }
  }
}

updatePackage();
updatePackageLock();
updateMain();
updateSystemScene();
updateRunner();
patchAndroidRunnerCompatibility();
validate();

console.log('[V0.8.14] PASS：新游戏与完整开局流程增量安装完成');
