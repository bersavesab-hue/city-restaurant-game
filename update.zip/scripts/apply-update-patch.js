'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = process.cwd();
const PATCH_MARK = 'DATA_HUB_V1_20260916';

function read(file) { return fs.readFileSync(file, 'utf8'); }
function write(file, text) { fs.writeFileSync(file, text, 'utf8'); }
function exists(rel) { return fs.existsSync(path.join(ROOT, rel)); }

function walk(dir, out) {
  if (!fs.existsSync(dir)) return out;
  for (const name of fs.readdirSync(dir)) {
    const full = path.join(dir, name);
    const st = fs.statSync(full);
    if (st.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

function findMain() {
  const preferred = ['src/main.js', 'main.js'];
  for (const rel of preferred) {
    const f = path.join(ROOT, rel);
    if (fs.existsSync(f)) {
      const s = read(f);
      if (s.includes('sceneManager') && s.includes('register')) return f;
    }
  }
  const all = walk(path.join(ROOT, 'src'), []);
  for (const f of all) {
    if (!/\.js$/i.test(f)) continue;
    const s = read(f);
    if (s.includes('sceneManager.register') && s.includes('district:enter')) return f;
  }
  throw new Error('无法定位主场景入口 main.js；未修改项目。');
}

function requirePathFrom(mainFile, targetRel) {
  let rel = path.relative(path.dirname(mainFile), path.join(ROOT, targetRel)).replace(/\\/g, '/');
  if (!rel.startsWith('.')) rel = './' + rel;
  return rel;
}

function insertRequires(source, mainFile) {
  if (source.includes(PATCH_MARK)) return source;
  const req = [
    '',
    `// ${PATCH_MARK}`,
    `const businessDataHub = require('${requirePathFrom(mainFile, 'src/analytics/businessDataHub.js')}');`,
    `const districtDetailScene = require('${requirePathFrom(mainFile, 'src/scenes/districtDetailScene.js')}');`,
    `const storeDetailScene = require('${requirePathFrom(mainFile, 'src/scenes/storeDetailScene.js')}');`,
    `const businessDataScene = require('${requirePathFrom(mainFile, 'src/scenes/businessDataScene.js')}');`,
    ''
  ].join('\n');

  const preferred = /\/\*\s*=+\s*\n\s*手机自适应基础[\s\S]*?\*\//;
  const m = source.match(preferred);
  if (m) return source.replace(m[0], req + m[0]);

  const marker = 'const businessScene';
  const idx = source.indexOf(marker);
  if (idx >= 0) {
    const semi = source.indexOf(';', idx);
    if (semi >= 0) return source.slice(0, semi + 1) + req + source.slice(semi + 1);
  }
  return req + source;
}

function replaceRegistration(source, id, oldVar, replacement) {
  const re = new RegExp(`sceneManager\\s*\\.register\\s*\\(\\s*['\"]${id}['\"]\\s*,\\s*${oldVar}\\s*\\)\\s*;`, 'm');
  if (re.test(source)) return source.replace(re, replacement);
  return source;
}

function hasSceneRegistration(source, id) {
  const re = new RegExp(`sceneManager\\s*\\.register\\s*\\(\\s*['\"]${id}['\"]`, 'm');
  return re.test(source);
}

function insertBeforeRender(source, block) {
  const renderMarker = source.indexOf('function render(');
  if (renderMarker >= 0) return source.slice(0, renderMarker) + block + source.slice(renderMarker);
  const hit = source.indexOf('/* =========================\n   总渲染');
  if (hit >= 0) return source.slice(0, hit) + block + source.slice(hit);
  return source + block;
}

function insertSceneRegistrations(source) {
  // 找铺页不覆盖：只给旧 shopScene 增加 property 别名。
  if (!hasSceneRegistration(source, 'property')) {
    const block = "\nsceneManager.register(\n  'property',\n  shopScene\n);\n\n";
    source = insertBeforeRender(source, block);
  }

  if (!hasSceneRegistration(source, 'districtDetail')) {
    source = insertBeforeRender(source, "\nsceneManager.register(\n  'districtDetail',\n  districtDetailScene\n);\n\n");
  }

  if (!hasSceneRegistration(source, 'storeDetail')) {
    source = insertBeforeRender(source, "\nsceneManager.register(\n  'storeDetail',\n  storeDetailScene\n);\n\n");
  }

  // 数据入口需要统一口径；旧 business 场景保留为 businessLegacy。
  if (!source.includes("'business',\n  businessDataScene") && !source.includes("'business', businessDataScene")) {
    const genericBusiness = /sceneManager\s*\.register\s*\(\s*['\"]business['\"]\s*,\s*([A-Za-z_$][\w$]*)\s*\)\s*;/m;
    const m = source.match(genericBusiness);
    if (m && m[1] !== 'businessDataScene') {
      const legacyVar = m[1];
      const replacement = hasSceneRegistration(source, 'businessLegacy')
        ? "sceneManager.register(\n  'business',\n  businessDataScene\n);"
        : "sceneManager.register(\n  'businessLegacy',\n  " + legacyVar + "\n);\n\nsceneManager.register(\n  'business',\n  businessDataScene\n);";
      source = source.replace(genericBusiness, replacement);
    } else if (!m) {
      source = insertBeforeRender(source, "\nsceneManager.register(\n  'business',\n  businessDataScene\n);\n\n");
    }
  }

  return source;
}

function patchDistrictEnter(source) {
  const marker = "target.id ===\n    'district:enter'";
  let idx = source.indexOf(marker);
  if (idx < 0) idx = source.indexOf("target.id === 'district:enter'");
  if (idx < 0) idx = source.indexOf('district:enter');
  if (idx < 0) return source;

  const end = source.indexOf("target.id.indexOf", idx + 1);
  const stop = end >= 0 ? end : Math.min(source.length, idx + 1800);
  const head = source.slice(0, idx);
  let chunk = source.slice(idx, stop);

  // 只改该点击分支中的目标 scene，避免误伤底部导航配置。
  chunk = chunk.replace(/\.switchTo\(\s*['\"]shop['\"]\s*,/m, ".switchTo(\n            'districtDetail',");
  return head + chunk + source.slice(stop);
}

function patchNavRouting(source) {
  if (source.includes('DATA_HUB_NAV_ROUTE_V1')) return source;
  const needle = /const sceneId\s*=\s*target\.id\s*\.split\(\s*['\"]:['\"]\s*\)\[1\];/m;
  const m = source.match(needle);
  if (!m) return source;
  const replacement = m[0] + `\n\n    // DATA_HUB_NAV_ROUTE_V1\n    const routedSceneId =\n      sceneId === 'shop'\n        ? (businessDataHub.hasStore({ gameState, citySystem, demandSystem }) ? 'storeDetail' : 'property')\n        : sceneId;`;
  source = source.replace(m[0], replacement);

  // 仅在导航分支后半段把 switchTo(sceneId) 改为 routedSceneId。
  const start = source.indexOf('DATA_HUB_NAV_ROUTE_V1');
  const end = source.indexOf('const scene =', start);
  if (start >= 0) {
    const stop = end >= 0 ? end : Math.min(source.length, start + 1600);
    let chunk = source.slice(start, stop);
    chunk = chunk.replace(/\.switchTo\(\s*sceneId\s*\)/m, '.switchTo(\n          routedSceneId\n        )');
    source = source.slice(0, start) + chunk + source.slice(stop);
  }
  return source;
}

function patchAutoSync(source) {
  if (source.includes('DATA_HUB_AUTO_SYNC_V1')) return source;
  const re = /(const\s+advancedMinutes\s*=\s*timeSystem[\s\S]{0,220}?\.update\(\s*deltaMs\s*\)\s*;)/m;
  const m = source.match(re);
  if (!m) return source;
  const extra = `${m[0]}\n\n  // DATA_HUB_AUTO_SYNC_V1\n  if (advancedMinutes > 0) {\n    businessDataHub.syncFromGame({ gameState, citySystem, demandSystem, timeSystem });\n  }`;
  return source.replace(m[0], extra);
}

function patchPackageTest() {
  const file = path.join(ROOT, 'package.json');
  if (!fs.existsSync(file)) return;
  const pkg = JSON.parse(read(file));
  pkg.scripts = pkg.scripts || {};

  // 重要：旧干净基线 scripts/v60-audit.js 会严格校验 scripts.test。
  // 数据中枢不得修改它，只能把自己的安装桥和自检追加到 pretest。
  const originalTest = pkg.scripts.test;
  const requiredBaseTest = 'node scripts/run-ci-tests-v060.js';
  if (originalTest && originalTest !== requiredBaseTest) {
    console.log('[经营数据中枢] 保留现有 scripts.test：' + originalTest);
  }

  const commands = [
    'node scripts/install-business-data-bridge.js',
    'node tests/businessDataHub.test.js'
  ];

  let pretest = String(pkg.scripts.pretest || '').trim();
  for (const cmd of commands) {
    if (!pretest.includes(cmd)) {
      pretest = pretest ? pretest + ' && ' + cmd : cmd;
    }
  }
  pkg.scripts.pretest = pretest;

  if (pkg.scripts.test !== originalTest) {
    throw new Error('数据中枢禁止修改 scripts.test');
  }

  write(file, JSON.stringify(pkg, null, 2) + '\n');
}

function syntaxCheck(file) {
  const r = cp.spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (r.status !== 0) {
    process.stderr.write(r.stdout || '');
    process.stderr.write(r.stderr || '');
    throw new Error('语法检查失败：' + path.relative(ROOT, file));
  }
}

function main() {
  const required = [
    'src/analytics/businessDataHub.js',
    'src/analytics/pageDataContract.js',
    'src/ui/dataWidgets.js',
    'src/scenes/dataSceneBase.js',
    'src/scenes/districtDetailScene.js',
    'src/scenes/storeDetailScene.js',
    'src/scenes/businessDataScene.js',
    'tests/businessDataHub.test.js',
    'scripts/install-business-data-bridge.js'
  ];
  for (const rel of required) {
    if (!exists(rel)) throw new Error('补丁文件缺失：' + rel);
  }

  const mainFile = findMain();
  let source = read(mainFile);
  source = insertRequires(source, mainFile);
  source = insertSceneRegistrations(source);
  source = patchDistrictEnter(source);
  source = patchNavRouting(source);
  source = patchAutoSync(source);
  write(mainFile, source);
  patchPackageTest();

  syntaxCheck(mainFile);
  required.filter(x => /\.js$/i.test(x)).forEach(rel => syntaxCheck(path.join(ROOT, rel)));

  console.log('[经营数据中枢] 安装完成');
  console.log('[经营数据中枢] 主入口：' + path.relative(ROOT, mainFile));
  console.log('[经营数据中枢] 商圈详情 / 门店详情 / 数据中枢 已接入');
}

main();
