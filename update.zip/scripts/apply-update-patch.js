'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.49';
const TARGET_VERSION = '0.8.50';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0850-R2] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0850-R2] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* A. 修复旧存档 interrupted 历史导致经营页运行时异常。 */
replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`function brief(shopId) {
  const state =
    ensureShop(shopId);

  if (state.active) {
    return {
      version:VERSION,
      shopId:
        String(shopId),
      status:'open',
      active:
        clone(
          state.active
        ),
      latestClosed:
        state.history[0]
          ? clone(
              state.history[0]
            )
          : null
    };
  }

  return {
    version:VERSION,
    shopId:
      String(shopId),
    status:
      state.history.length
        ? 'closed'
        : 'idle',
    active:null,
    latestClosed:
      state.history[0]
        ? clone(
            state.history[0]
          )
        : null
  };
}`,
`function brief(shopId) {
  const state =
    ensureShop(shopId);

  const latestClosed =
    state.history.find(
      item =>
        item &&
        item.status ===
          'closed' &&
        item.financial &&
        typeof item.financial ===
          'object'
    ) ||
    null;

  if (state.active) {
    return {
      version:VERSION,
      shopId:
        String(shopId),
      status:'open',
      active:
        clone(
          state.active
        ),
      latestClosed:
        latestClosed
          ? clone(
              latestClosed
            )
          : null
    };
  }

  return {
    version:VERSION,
    shopId:
      String(shopId),
    status:
      latestClosed
        ? 'closed'
        : 'idle',
    active:null,
    latestClosed:
      latestClosed
        ? clone(
            latestClosed
          )
        : null
  };
}`,
  'latestClosed old-save compatibility'
);

replaceExact(
  'src/scenes/businessScene.js',
`    const dayHistory =
      operations
        .operatingDayHistory(
          shop.id,
          2
        );

    const previous =
      dayHistory &&
      dayHistory.length >
        1
        ? dayHistory[1]
        : null;`,
`    const dayHistory =
      operations
        .operatingDayHistory(
          shop.id,
          120
        );

    const closedHistory =
      Array.isArray(
        dayHistory
      )
        ? dayHistory
            .filter(
              item =>
                item &&
                item.status ===
                  'closed' &&
                item.financial &&
                typeof item.financial ===
                  'object'
            )
        : [];

    const previous =
      closedHistory.length >
        1
        ? closedHistory[1]
        : null;`,
  'closed day trend filtering'
);

/* B. 加入旧存档回归测试。 */
replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`const after=operations.operatingDaySnapshot('shop_v0843_integration');
assert.equal(after.status,'closed');
assert.ok(after.latestClosed);
assert.ok(after.latestClosed.financial.orders>=1);`,
`const after=operations.operatingDaySnapshot('shop_v0843_integration');
assert.equal(after.status,'closed');
assert.ok(after.latestClosed);
assert.ok(after.latestClosed.financial.orders>=1);

const cycleRoot=
  gameState
    .getBusiness()
    .dailyOperatingCycle;

const cycleShop=
  cycleRoot
    .shops[
      'shop_v0843_integration'
    ];

cycleShop.history.unshift({
  id:'legacy_interrupted_day',
  version:'0.8.40',
  shopId:'shop_v0843_integration',
  day:11,
  status:'interrupted',
  baseline:{},
  visits:{},
  decisionRefs:[],
  events:[]
});

const legacySafe=
  operations
    .operatingDaySnapshot(
      'shop_v0843_integration'
    );

assert.equal(
  legacySafe.status,
  'closed',
  '中断记录不能把已日结门店误判为未完成'
);

assert.ok(
  legacySafe.latestClosed &&
  legacySafe.latestClosed.status ===
    'closed' &&
  legacySafe.latestClosed.financial,
  '旧存档存在 interrupted 历史时必须跳过并返回最近完整日结'
);`,
  'legacy interrupted history regression'
);

replaceExact(
  'tests/businessDayUiV0844.test.js',
`    '.operatingDayHistory('
  ),`,
`    '.operatingDayHistory('
  ) &&
  businessSource.includes(
    "item.status ==="
  ) &&
  businessSource.includes(
    "'closed'"
  ) &&
  businessSource.includes(
    'item.financial'
  ) &&
  businessSource.includes(
    'closedHistory'
  ),`,
  'business trend safety assertions'
);

/* C. 修复 V0.8.49 基础设施测试写死版本号的问题。 */
replaceExact(
  'tests/updateInfrastructureV0849.test.js',
`assert.strictEqual(pkg.version, '0.8.49');
assert.strictEqual(lock.version, '0.8.49');
assert.strictEqual(lock.packages[''].version, '0.8.49');`,
`const versionParts =
  String(pkg.version)
    .split('.')
    .map(Number);

const versionNumber =
  versionParts[0] * 10000 +
  versionParts[1] * 100 +
  versionParts[2];

assert.ok(
  versionNumber >= 849,
  '项目版本不得低于0.8.49'
);

assert.strictEqual(
  lock.version,
  pkg.version
);

assert.strictEqual(
  lock.packages[''].version,
  pkg.version
);`,
  'future-proof V0849 package assertions'
);

replaceExact(
  'tests/updateInfrastructureV0849.test.js',
`assert.ok(gradle.includes('versionCode 849'));
assert.ok(gradle.includes("versionName '0.8.49'"));`,
`const codeMatch =
  gradle.match(
    /versionCode\\s+(\\d+)/
  );

const nameMatch =
  gradle.match(
    /versionName\\s+'([^']+)'/
  );

assert.ok(
  codeMatch &&
  Number(codeMatch[1]) >= 849,
  'Android versionCode不得低于849'
);

assert.ok(
  nameMatch &&
  nameMatch[1] === pkg.version,
  'Android versionName必须与package.json一致'
);`,
  'future-proof V0849 android assertions'
);

/* D. 安卓错误框展示真实异常信息。 */
replaceExact(
  'android/app/src/main/assets/index.html',
`        box.textContent =
          '游戏启动错误：\\n' +
          event.message +
          '\\n\\n' +
          (
            event.filename ||
            ''
          ) +
          ':' +
          (
            event.lineno ||
            ''
          );`,
`        const detail =
          event &&
          event.error &&
          (
            event.error.stack ||
            event.error.message
          ) ||
          event.message ||
          '未知脚本异常';

        box.textContent =
          '游戏运行错误：\\n' +
          detail +
          '\\n\\n' +
          (
            event.filename ||
            ''
          ) +
          ':' +
          (
            event.lineno ||
            ''
          );`,
  'android error diagnostics'
);

/* E. 版本同步。 */
updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 849
        versionName '0.8.49'`,
`        versionCode 850
        versionName '0.8.50'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.49 装修面积修复版启动成功'",
  "'城市餐饮经营小游戏 V0.8.50 旧存档运行时修复版启动成功'",
  'startup banner'
);

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (fs.existsSync(genericManifest)) {
  fs.rmSync(
    genericManifest,
    { force:true }
  );
}

console.log(
  '[V0850-R2] 旧存档运行时修复 + 版本测试兼容完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
