'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.60';
const TARGET_VERSION = '0.8.61';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0861] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0861] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* =========================================================
   A. 顾客复购、价格流失、菜品热度进入真实模拟
   ========================================================= */

replaceExact(
  'src/operations/floorSimulationV082.js',
`    cookMinutesTotal:0,
    cookSamples:0`,
`    cookMinutesTotal:0,
    cookSamples:0,
    repeatGuestsToday:0,
    newGuestsToday:0,
    priceWalkawaysToday:0,
    repeatIntentTotalToday:0,
    repeatIntentSamplesToday:0,
    repeatLikelyVisitsToday:0,
    churnRiskVisitsToday:0,
    dishOrdersToday:{},
    dishRevenueToday:{}`,
  'floor causal metrics'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`function createCustomer(
  runtime,
  districtId
) {
  const existing =
    Object.values(
      runtime.customers ||
      {}
    );

  if (
    existing.length &&
    runtime.rng.next() <
      0.34
  ) {
    return existing[
      runtime.rng.int(
        0,
        existing.length -
          1
      )
    ];
  }

  const profile =
    customerEngine
      .createSegmentProfile(
        runtime.rng,
        {
          districtId
        }
      );

  runtime.customers[
    profile.id
  ] =
    profile;

  const ids =
    Object.keys(
      runtime.customers
    );

  if (
    ids.length >
    300
  ) {
    delete runtime
      .customers[
        ids[0]
      ];
  }

  return profile;
}`,
`function customerReturnScore(
  profile,
  shopId
) {
  const memory =
    profile &&
    profile.memory &&
    typeof profile.memory ===
      'object'
      ? profile.memory
      : {};

  const row =
    memory.visitedStores &&
    memory.visitedStores[
      shopId
    ];

  const visits =
    Math.max(
      0,
      Number(
        row &&
        row.visits
      ) ||
      0
    );

  if (
    visits <=
    0
  ) {
    return 0;
  }

  const satisfaction =
    clamp(
      Number(
        row.avgSatisfaction
      ) ||
      50,
      0,
      100
    ) /
    100;

  const loyalty =
    clamp(
      Number(
        profile &&
        profile.traits &&
        profile.traits.loyalty
      ) ||
      50,
      0,
      100
    ) /
    100;

  const favorite =
    Array.isArray(
      memory.favoriteStoreIds
    ) &&
    memory.favoriteStoreIds
      .includes(
        shopId
      );

  const disliked =
    Array.isArray(
      memory.dislikedStoreIds
    ) &&
    memory.dislikedStoreIds
      .includes(
        shopId
      );

  return clamp(
    0.08 +
    satisfaction *
      0.50 +
    loyalty *
      0.22 +
    Math.min(
      5,
      visits
    ) *
      0.04 +
    (
      favorite
        ? 0.15
        : 0
    ) -
    (
      disliked
        ? 0.45
        : 0
    ),
    0,
    1
  );
}

function createCustomer(
  runtime,
  districtId,
  shop
) {
  const existing =
    Object.values(
      runtime.customers ||
      {}
    );

  const shopId =
    shop &&
    shop.id;

  const candidates =
    shopId
      ? existing
          .map(
            profile => ({
              profile,
              score:
                customerReturnScore(
                  profile,
                  shopId
                )
            })
          )
          .filter(
            item =>
              item.score >
              0.02
          )
          .sort(
            (a,b) =>
              b.score -
              a.score
          )
      : [];

  if (
    candidates.length
  ) {
    const sample =
      candidates.slice(
        0,
        12
      );

    const avgStrength =
      sample.reduce(
        (
          total,
          item
        ) =>
          total +
          item.score,
        0
      ) /
      Math.max(
        1,
        sample.length
      );

    const ratingBoost =
      Math.max(
        0,
        (
          Number(
            runtime.shop &&
            runtime.shop.rating
          ) ||
          4
        ) -
        4
      ) *
      0.08;

    const wordBoost =
      Math.max(
        0,
        Number(
          runtime.shop &&
          runtime.shop.wordOfMouth
        ) ||
        0
      ) *
      0.12;

    const repeatChance =
      clamp(
        0.06 +
        avgStrength *
          0.52 +
        ratingBoost +
        wordBoost,
        0.05,
        0.68
      );

    if (
      runtime.rng.next() <
      repeatChance
    ) {
      const totalWeight =
        sample.reduce(
          (
            total,
            item
          ) =>
            total +
            Math.max(
              0.01,
              item.score
            ),
          0
        );

      let roll =
        runtime.rng.next() *
        totalWeight;

      for (
        const item
        of sample
      ) {
        roll -=
          Math.max(
            0.01,
            item.score
          );

        if (
          roll <=
          0
        ) {
          return item.profile;
        }
      }

      return sample[0]
        .profile;
    }
  }

  const profile =
    customerEngine
      .createSegmentProfile(
        runtime.rng,
        {
          districtId
        }
      );

  runtime.customers[
    profile.id
  ] =
    profile;

  const ids =
    Object.keys(
      runtime.customers
    );

  if (
    ids.length >
    300
  ) {
    delete runtime
      .customers[
        ids[0]
      ];
  }

  return profile;
}`,
  'real repeat customer selection'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`        qualityScore:
          64 +
          Math.min(
            20,
            Number(
              item.avgRating ||
              0
            ) *
              3
          ),
        popularity:
          Math.min(
            100,
            42 +
            Math.log10(
              Math.max(
                1,
                Number(
                  item.salesQty ||
                  1
                )
              )
            ) *
              18
          ),`,
`        qualityScore:
          64 +
          Math.min(
            20,
            (
              item.stats &&
              Number(
                item.stats
                  .ratingCount
              ) >
                0
                ? Number(
                    item.stats
                      .ratingSum
                  ) /
                  Number(
                    item.stats
                      .ratingCount
                  )
                : 0
            ) *
              3
          ),
        popularity:
          Math.min(
            100,
            42 +
            Math.log10(
              Math.max(
                1,
                Number(
                  item.stats &&
                  item.stats.orders
                ) ||
                1
              )
            ) *
              18
          ),`,
  'menu popularity uses real stats'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`function buildOrder(
  runtime,
  floor,
  shop,
  profile,
  visit,
  minute,
  tableId,
  waitMinutes,
  ctx
) {`,
`function priceRejectProbability(
  profile,
  visit,
  menuItem
) {
  const budget =
    Math.max(
      1,
      Number(
        visit &&
        visit.budget
      ) ||
      1
    );

  const price =
    Math.max(
      0,
      Number(
        menuItem &&
        menuItem.listPrice
      ) ||
      0
    );

  const ratio =
    price /
    budget;

  if (
    ratio <=
    1.02
  ) {
    return 0;
  }

  const sensitivity =
    clamp(
      Number(
        profile &&
        profile.traits &&
        profile.traits
          .priceSensitivity
      ) ||
      50,
      0,
      100
    ) /
    100;

  const overBudget =
    Math.max(
      0,
      ratio -
      1
    );

  return clamp(
    overBudget *
      0.70 +
    sensitivity *
      0.18 +
    Math.max(
      0,
      ratio -
      1.35
    ) *
      0.60,
    0,
    0.85
  );
}

function buildOrder(
  runtime,
  floor,
  shop,
  profile,
  visit,
  minute,
  tableId,
  waitMinutes,
  ctx
) {`,
  'price rejection helper'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`    return {
      ok:false,
      reason:'缺货'
    };
  }

  floor.sequence +=
    1;`,
`    return {
      ok:false,
      reason:'缺货'
    };
  }

  const rejectProbability =
    priceRejectProbability(
      profile,
      visit,
      chosen.dish.menuItem
    );

  if (
    rejectProbability >
      0 &&
    runtime.rng.next() <
      rejectProbability
  ) {
    const lost =
      Math.max(
        1,
        Number(
          visit.partySize
        ) ||
        1
      );

    floor.metrics
      .priceWalkawaysToday +=
      lost;

    floor.history.unshift({
      minute,
      type:'price_walkaway',
      profileId:
        profile.id,
      visitId:
        visit.id,
      menuItemId:
        chosen.dish
          .menuItem
          .id,
      price:
        Number(
          chosen.dish
            .menuItem
            .listPrice
        ) ||
        0,
      budget:
        Number(
          visit.budget
        ) ||
        0,
      rejectProbability
    });

    return {
      ok:false,
      reason:'价格超预算'
    };
  }

  floor.sequence +=
    1;`,
  'price causes real lost sales'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`  const profile =
    createCustomer(
      runtime,
      shop.districtId
    );`,
`  const profile =
    createCustomer(
      runtime,
      shop.districtId,
      shop
    );`,
  'repeat customer selector call'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`  const visit =
    customerEngine
      .generateVisit(
        profile,
        runtime.rng,
        {
          hour,
          day:
            runtime.day,
          rain:
            ctx.weather ===
              'rain' ||
            ctx.weather ===
              'heavyRain'
        }
      );

  // V083_DYNAMIC_MODIFIERS`,
`  const previousVisits =
    Math.max(
      0,
      Number(
        profile &&
        profile.memory &&
        profile.memory
          .visitedStores &&
        profile.memory
          .visitedStores[
            shop.id
          ] &&
        profile.memory
          .visitedStores[
            shop.id
          ].visits
      ) ||
      0
    );

  const visit =
    customerEngine
      .generateVisit(
        profile,
        runtime.rng,
        {
          hour,
          day:
            runtime.day,
          rain:
            ctx.weather ===
              'rain' ||
            ctx.weather ===
              'heavyRain'
        }
      );

  const partyCount =
    Math.max(
      1,
      Number(
        visit.partySize
      ) ||
      1
    );

  if (
    previousVisits >
    0
  ) {
    floor.metrics
      .repeatGuestsToday +=
      partyCount;
  } else {
    floor.metrics
      .newGuestsToday +=
      partyCount;
  }

  // V083_DYNAMIC_MODIFIERS`,
  'track new and repeat guests'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`    const reputationMultiplier =
      clamp(`,
`    const repeatProbability =
      clamp(
        Number(
          retention &&
          retention.repeatProbability
        ) ||
        0,
        0,
        1
      );

    floor.metrics
      .repeatIntentTotalToday +=
      repeatProbability;

    floor.metrics
      .repeatIntentSamplesToday +=
      1;

    if (
      repeatProbability >=
      0.52
    ) {
      floor.metrics
        .repeatLikelyVisitsToday +=
        1;
    } else if (
      repeatProbability <
      0.30
    ) {
      floor.metrics
        .churnRiskVisitsToday +=
        1;
    }

    const reputationMultiplier =
      clamp(`,
  'retention becomes daily metric'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`  if (menuItem) {
    menuEngine
      .recordSale(
        menuItem,
        {
          qty:
            order.items.reduce(
              (
                sum,
                item
              ) =>
                sum +
                item.qty,
              0
            ),
          paid:
            order.total,
          variableCost:
            order.meta
              .foodCost,
          rating:
            retention &&
            retention.reviewStars
        }
      );
  }`,
`  if (menuItem) {
    const soldQty =
      order.items.reduce(
        (
          sum,
          item
        ) =>
          sum +
          item.qty,
        0
      );

    menuEngine
      .recordSale(
        menuItem,
        {
          qty:
            soldQty,
          paid:
            order.total,
          variableCost:
            order.meta
              .foodCost,
          rating:
            retention &&
            retention.reviewStars
        }
      );

    floor.metrics
      .dishOrdersToday[
        menuItem.id
      ] =
      (
        Number(
          floor.metrics
            .dishOrdersToday[
              menuItem.id
            ]
        ) ||
        0
      ) +
      soldQty;

    floor.metrics
      .dishRevenueToday[
        menuItem.id
      ] =
      Math.round(
        (
          (
            Number(
              floor.metrics
                .dishRevenueToday[
                  menuItem.id
                ]
            ) ||
            0
          ) +
          Number(
            settled.revenue
          )
        ) *
        100
      ) /
      100;
  }`,
  'daily dish performance'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`    completedOrdersToday:
      floor.metrics
        .completedOrdersToday,
    peakQueueToday:`,
`    completedOrdersToday:
      floor.metrics
        .completedOrdersToday,
    repeatGuestsToday:
      floor.metrics
        .repeatGuestsToday,
    newGuestsToday:
      floor.metrics
        .newGuestsToday,
    priceWalkawaysToday:
      floor.metrics
        .priceWalkawaysToday,
    repeatRate:
      (
        floor.metrics
          .repeatGuestsToday +
        floor.metrics
          .newGuestsToday
      ) >
        0
        ? Math.round(
            floor.metrics
              .repeatGuestsToday /
            (
              floor.metrics
                .repeatGuestsToday +
              floor.metrics
                .newGuestsToday
            ) *
            1000
          ) /
          1000
        : 0,
    avgRepeatIntent:
      floor.metrics
        .repeatIntentSamplesToday >
        0
        ? Math.round(
            floor.metrics
              .repeatIntentTotalToday /
            floor.metrics
              .repeatIntentSamplesToday *
            1000
          ) /
          1000
        : 0,
    repeatLikelyVisitsToday:
      floor.metrics
        .repeatLikelyVisitsToday,
    churnRiskVisitsToday:
      floor.metrics
        .churnRiskVisitsToday,
    dishOrdersToday:{
      ...floor.metrics
        .dishOrdersToday
    },
    dishRevenueToday:{
      ...floor.metrics
        .dishRevenueToday
    },
    peakQueueToday:`,
  'snapshot causal metrics'
);

replaceExact(
  'src/operations/floorSimulationV082.js',
`  closeDay,
  kitchenQueueCount
};`,
`  closeDay,
  kitchenQueueCount,
  customerReturnScore,
  priceRejectProbability
};`,
  'export causal helpers'
);

/* =========================================================
   B. 只有真实评价才改变公开评分
   ========================================================= */

replaceExact(
  'src/operations/retentionEngineV10.js',
`function updateShopReputation(shop,result){
  const old=Number(shop.rating||4);const stars=result.reviewStars||result.reviewScore?.stars||old;
  const count=Math.max(0,Number(shop.reviewCount||0));shop.rating=Math.round(((old*count+stars)/(count+1))*100)/100;shop.reviewCount=count+1;
  shop.wordOfMouth=Math.max(-1,Math.min(1,(Number(shop.wordOfMouth)||0)*.9+Number(result.wordOfMouth||0)*.1));return shop;
}`,
`function updateShopReputation(shop,result){
  const old=Number(shop.rating||4);
  const count=Math.max(0,Number(shop.reviewCount||0));
  const stars=result&&result.reviewStars!=null?Number(result.reviewStars):null;

  if(stars!=null&&Number.isFinite(stars)){
    shop.rating=Math.round(((old*count+stars)/(count+1))*100)/100;
    shop.reviewCount=count+1;
  }else{
    shop.rating=old;
    shop.reviewCount=count;
  }

  shop.wordOfMouth=Math.max(
    -1,
    Math.min(
      1,
      (Number(shop.wordOfMouth)||0)*.9+
      Number(result&&result.wordOfMouth||0)*.1
    )
  );

  return shop;
}`,
  'only actual reviews change public rating'
);

/* =========================================================
   C. 过期食材真实进入损耗与利润
   ========================================================= */

replaceExact(
  'src/operations/restaurantRuntimeV10.js',
`function closeDay(runtime,ctx={}){
  const daily=settlement.summary(runtime.ledger);brandGrowth.applyDailyResult(runtime.brand,{profit:daily.profit,rating:runtime.shop.rating,customers:daily.customers});
  inventoryEngine.advanceDay(runtime.inventory,runtime.day+1,{shrinkRate:ctx.shrinkRate??.002});runtime.day++;
  for(const c of runtime.campaigns)marketing.tickCampaign(c);
  const result={day:runtime.day-1,financial:daily,shopRating:runtime.shop.rating,brand:{level:runtime.brand.level,xp:runtime.brand.xp}};
  runtime.history.push({type:'day_close',...result});runtime.ledger=settlement.createLedger();return result;
}`,
`function closeDay(runtime,ctx={}){
  const inventoryLoss=
    inventoryEngine.advanceDay(
      runtime.inventory,
      runtime.day+1,
      {shrinkRate:ctx.shrinkRate??.002}
    );

  if(
    inventoryLoss&&
    Number(inventoryLoss.expiredValue)>0
  ){
    settlement.addFixedCosts(
      runtime.ledger,
      {waste:Number(inventoryLoss.expiredValue)||0}
    );
  }

  const daily=settlement.summary(runtime.ledger);
  brandGrowth.applyDailyResult(runtime.brand,{profit:daily.profit,rating:runtime.shop.rating,customers:daily.customers});
  runtime.day++;

  for(const c of runtime.campaigns)marketing.tickCampaign(c);

  const result={
    day:runtime.day-1,
    financial:daily,
    inventoryLoss:{
      expiredGrams:Number(inventoryLoss&&inventoryLoss.expiredGrams)||0,
      expiredValue:Number(inventoryLoss&&inventoryLoss.expiredValue)||0
    },
    shopRating:runtime.shop.rating,
    brand:{level:runtime.brand.level,xp:runtime.brand.xp}
  };

  runtime.history.push({type:'day_close',...result});
  runtime.ledger=settlement.createLedger();
  return result;
}`,
  'expired stock affects profit'
);

/* =========================================================
   D. 兼容手动/测试关闭路径也带楼面指标
   ========================================================= */

replaceExact(
  'src/operations/liveOperationsCoordinatorV0824.js',
`const runtimeEngine =
  require('./restaurantRuntimeV10.js');`,
`const runtimeEngine =
  require('./restaurantRuntimeV10.js');

const floorSimulation =
  require('./floorSimulationV082.js');`,
  'live close imports floor simulation'
);

replaceExact(
  'src/operations/liveOperationsCoordinatorV0824.js',
`  const result =
    runtimeEngine
      .closeDay(
        r,
        options ||
        {}
      );

  r.simulation`,
`  const result =
    runtimeEngine
      .closeDay(
        r,
        options ||
        {}
      );

  result.floor =
    floorSimulation
      .closeDay(
        r
      );

  r.simulation`,
  'manual close carries floor metrics'
);

/* =========================================================
   E. 日结保存经营因果信号
   ========================================================= */

replaceExact(
  'src/operations/operationsStoreV080.js',
`function finalizeClosedOperatingDay(shopId,runtime,closeResult,options) {`,
`function buildOperatingSignals(
  runtime,
  closed
) {
  const floor =
    closed &&
    closed.floor &&
    typeof closed.floor ===
      'object'
      ? closed.floor
      : {};

  const repeatGuests =
    Math.max(
      0,
      Number(
        floor.repeatGuestsToday
      ) ||
      0
    );

  const newGuests =
    Math.max(
      0,
      Number(
        floor.newGuestsToday
      ) ||
      0
    );

  const knownGuests =
    repeatGuests +
    newGuests;

  const dishOrders =
    floor.dishOrdersToday &&
    typeof floor.dishOrdersToday ===
      'object'
      ? floor.dishOrdersToday
      : {};

  let topDishId =
    null;

  let topDishQty =
    0;

  for (
    const [
      id,
      qty
    ]
    of Object.entries(
      dishOrders
    )
  ) {
    if (
      Number(qty) >
      topDishQty
    ) {
      topDishId =
        id;

      topDishQty =
        Number(qty) ||
        0;
    }
  }

  const topDish =
    topDishId &&
    runtime &&
    Array.isArray(
      runtime.menu
    )
      ? runtime.menu.find(
          item =>
            item.id ===
            topDishId
        )
      : null;

  return {
    repeatGuests,
    newGuests,
    repeatRate:
      knownGuests >
        0
        ? Math.round(
            repeatGuests /
            knownGuests *
            1000
          ) /
          1000
        : Number(
            floor.repeatRate
          ) ||
          0,
    avgRepeatIntent:
      Number(
        floor.avgRepeatIntent
      ) ||
      0,
    repeatLikelyVisits:
      Math.max(
        0,
        Number(
          floor.repeatLikelyVisitsToday
        ) ||
        0
      ),
    churnRiskVisits:
      Math.max(
        0,
        Number(
          floor.churnRiskVisitsToday
        ) ||
        0
      ),
    priceWalkaways:
      Math.max(
        0,
        Number(
          floor.priceWalkawaysToday
        ) ||
        0
      ),
    stockouts:
      Math.max(
        0,
        Number(
          floor.stockoutsToday
        ) ||
        0
      ),
    queueWalkaways:
      Math.max(
        0,
        Number(
          floor.walkawaysToday
        ) ||
        0
      ),
    mistakes:
      Math.max(
        0,
        Number(
          floor.mistakesToday
        ) ||
        0
      ),
    avgWaitMinutes:
      Number(
        floor.avgWaitMinutes
      ) ||
      0,
    expiredWasteValue:
      Math.max(
        0,
        Number(
          closed &&
          closed.inventoryLoss &&
          closed.inventoryLoss
            .expiredValue
        ) ||
        0
      ),
    expiredWasteGrams:
      Math.max(
        0,
        Number(
          closed &&
          closed.inventoryLoss &&
          closed.inventoryLoss
            .expiredGrams
        ) ||
        0
      ),
    topDish:
      topDish
        ? {
            id:
              topDish.id,
            name:
              topDish.name,
            qty:
              topDishQty,
            revenue:
              Number(
                floor.dishRevenueToday &&
                floor.dishRevenueToday[
                  topDish.id
                ]
              ) ||
              0
          }
        : null
  };
}

function finalizeClosedOperatingDay(shopId,runtime,closeResult,options) {`,
  'operating signal builder'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
`  const endSnapshot=decisionContextSnapshot(shopId,runtime,closed.financial);
  const balanceV2=operatingBalanceTuner.assessDay(closed.financial,{tensionScore:endSnapshot.tensionScore});`,
`  const operatingSignals=
    buildOperatingSignals(
      runtime,
      closed
    );

  const endSnapshot=decisionContextSnapshot(shopId,runtime,closed.financial);
  const balanceV2=operatingBalanceTuner.assessDay(closed.financial,{tensionScore:endSnapshot.tensionScore});`,
  'build signals before daily close'
);

replaceExact(
  'src/operations/operationsStoreV080.js',
`    source:options&&options.source||'unified',
    regulatory:{openViolations:regulatoryView&&Array.isArray(regulatoryView.openViolations)?regulatoryView.openViolations.length:0}`,
`    source:options&&options.source||'unified',
    operatingSignals,
    regulatory:{openViolations:regulatoryView&&Array.isArray(regulatoryView.openViolations)?regulatoryView.openViolations.length:0}`,
  'persist operating signals'
);

/* =========================================================
   F. 日结诊断真正识别价格/缺货/损耗/复购
   ========================================================= */

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  if (
    extra &&
    extra.regulatory &&
    Number(
      extra.regulatory
        .openViolations
    ) >
    0
  ) {
    reasons.push({
      code:'OPEN_VIOLATION',
      severity:'critical',
      message:'仍有未完成的监管整改'
    });
  }

  return reasons;`,
`  const signals =
    extra &&
    extra.operatingSignals &&
    typeof extra.operatingSignals ===
      'object'
      ? extra.operatingSignals
      : {};

  if (
    Number(
      signals.stockouts
    ) >
    0
  ) {
    reasons.push({
      code:'STOCKOUT_LOSS',
      severity:'warning',
      message:
        '缺货导致 ' +
        Number(
          signals.stockouts
        ) +
        ' 次订单流失'
    });
  }

  if (
    Number(
      signals.priceWalkaways
    ) >
    0
  ) {
    reasons.push({
      code:'PRICE_RESISTANCE',
      severity:'warning',
      message:
        '有 ' +
        Number(
          signals.priceWalkaways
        ) +
        ' 位顾客因价格超预算离开'
    });
  }

  if (
    Number(
      signals.expiredWasteValue
    ) >
    Math.max(
      30,
      Number(
        financial.revenue
      ) *
      0.02
    )
  ) {
    reasons.push({
      code:'WASTE_HIGH',
      severity:'warning',
      message:
        '过期食材损耗 ' +
        Number(
          signals.expiredWasteValue
        ).toFixed(
          2
        )
    });
  }

  if (
    (
      Number(
        signals.repeatGuests
      ) +
      Number(
        signals.newGuests
      )
    ) >=
      12 &&
    Number(
      signals.avgRepeatIntent
    ) >
      0 &&
    Number(
      signals.avgRepeatIntent
    ) <
      0.35
  ) {
    reasons.push({
      code:'REPEAT_WEAK',
      severity:'warning',
      message:'顾客复购意向偏弱'
    });
  }

  if (
    extra &&
    extra.regulatory &&
    Number(
      extra.regulatory
        .openViolations
    ) >
    0
  ) {
    reasons.push({
      code:'OPEN_VIOLATION',
      severity:'critical',
      message:'仍有未完成的监管整改'
    });
  }

  return reasons;`,
  'causal daily reasons'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  const actions = [];

  if (
    reasons.some(
      item =>
        item.code ===
        'INVENTORY_ALERTS'
    )
  ) {`,
`  const actions = [];

  if (
    reasons.some(
      item =>
        item.code ===
          'STOCKOUT_LOSS' ||
        item.code ===
          'WASTE_HIGH'
    )
  ) {
    actions.push({
      id:'fix_supply_balance',
      routeId:'supply',
      message:'调整补货量，兼顾缺货与过期损耗'
    });
  }

  if (
    reasons.some(
      item =>
        item.code ===
        'PRICE_RESISTANCE'
    )
  ) {
    actions.push({
      id:'fix_price_resistance',
      routeId:'research',
      message:'检查高价菜和顾客预算匹配'
    });
  }

  if (
    reasons.some(
      item =>
        item.code ===
        'REPEAT_WEAK'
    )
  ) {
    actions.push({
      id:'fix_repeat_intent',
      routeId:'business',
      message:'优先改善菜品、速度和服务体验'
    });
  }

  if (
    reasons.some(
      item =>
        item.code ===
        'INVENTORY_ALERTS'
    )
  ) {`,
  'causal next actions'
);

/* =========================================================
   G. 经营页把因果直接展示给玩家
   ========================================================= */

replaceExact(
  'src/scenes/businessScene.js',
`    const balance =
      showingCurrent
        ? liveBalance
        : latest &&
          latest.extra &&
          latest.extra.balance
          ? latest.extra.balance
          : liveBalance;

    this.sectionCard(`,
`    const balance =
      showingCurrent
        ? liveBalance
        : latest &&
          latest.extra &&
          latest.extra.balance
          ? latest.extra.balance
          : liveBalance;

    const latestSignals =
      latest &&
      latest.extra &&
      latest.extra
        .operatingSignals
        ? latest.extra
            .operatingSignals
        : null;

    this.sectionCard(`,
  'read operating signals in UI'
);

replaceExact(
  'src/scenes/businessScene.js',
`    ui.text(
      ctx,
      balance
        ? '数值平衡 ' +
          balance.score +
          ' · ' +
          balance.grade
        : '数值平衡：等待营业数据',
      28,
      466,
      7,
      '#3A5665',
      '700'
    );

    opUi.button(`,
`    ui.text(
      ctx,
      balance
        ? '数值平衡 ' +
          balance.score +
          ' · ' +
          balance.grade
        : '数值平衡：等待营业数据',
      28,
      466,
      7,
      '#3A5665',
      '700'
    );

    ui.text(
      ctx,
      latestSignals
        ? '上次经营：回头客' +
          Math.round(
            Number(
              latestSignals
                .repeatRate
            ) *
            100
          ) +
          '% · 价流' +
          Number(
            latestSignals
              .priceWalkaways
          ) +
          ' · 缺货' +
          Number(
            latestSignals
              .stockouts
          ) +
          ' · 损耗' +
          opUi.money(
            latestSignals
              .expiredWasteValue
          )
        : '经营因果：等待首次完整日结',
      28,
      488,
      5.7,
      '#71858F',
      '700'
    );

    opUi.button(`,
  'causal summary in health card'
);

replaceExact(
  'src/scenes/businessScene.js',
`    ui.text(
      ctx,
      '待评估决策 ' +
      (
        feedback &&
        feedback.pending
          ? feedback.pending.length
          : 0
      ) +
      ' 项 · 已反馈 ' +
      (
        feedback &&
        feedback.metrics
          ? feedback.metrics.resolved ||
            0
          : 0
      ) +
      ' 项',
      28,
      680,
      6.1,
      '#71858F',
      '600'
    );`,
`    ui.text(
      ctx,
      latestSignals &&
      latestSignals.topDish
        ? '热销菜：' +
          latestSignals
            .topDish
            .name +
          ' · ' +
          latestSignals
            .topDish
            .qty +
          '份 · 复购意向' +
          Math.round(
            Number(
              latestSignals
                .avgRepeatIntent
            ) *
            100
          ) +
          '%'
        : '经营因果：价格、库存、复购数据将在日结后形成',
      28,
      680,
      6.1,
      '#71858F',
      '600'
    );`,
  'top dish and repeat intent UI'
);

/* =========================================================
   H. 回归测试
   ========================================================= */

replaceExact(
  'tests/operationCoreV070.test.js',
`const runtimeEngine=require('../src/operations/restaurantRuntimeV10.js');`,
`const runtimeEngine=require('../src/operations/restaurantRuntimeV10.js');
const floorSimulation=require('../src/operations/floorSimulationV082.js');`,
  'core imports floor simulation'
);

replaceExact(
  'tests/operationCoreV070.test.js',
`assert.equal(events.EVENT_TEMPLATES.length,60);`,
`assert.equal(events.EVENT_TEMPLATES.length,60);

const highReturnScore=
  floorSimulation
    .customerReturnScore(
      {
        traits:{loyalty:80},
        memory:{
          visitedStores:{
            shop1:{
              visits:3,
              avgSatisfaction:90
            }
          },
          favoriteStoreIds:['shop1'],
          dislikedStoreIds:[]
        }
      },
      'shop1'
    );

const lowReturnScore=
  floorSimulation
    .customerReturnScore(
      {
        traits:{loyalty:40},
        memory:{
          visitedStores:{
            shop1:{
              visits:1,
              avgSatisfaction:30
            }
          },
          favoriteStoreIds:[],
          dislikedStoreIds:['shop1']
        }
      },
      'shop1'
    );

assert.ok(
  highReturnScore >
  lowReturnScore,
  '高满意老客必须比低满意顾客更容易回店'
);

const affordableReject=
  floorSimulation
    .priceRejectProbability(
      {traits:{priceSensitivity:80}},
      {budget:30},
      {listPrice:25}
    );

const expensiveReject=
  floorSimulation
    .priceRejectProbability(
      {traits:{priceSensitivity:80}},
      {budget:30},
      {listPrice:55}
    );

assert.equal(
  affordableReject,
  0,
  '预算内菜价不应制造额外价格流失'
);

assert.ok(
  expensiveReject >
  0.5,
  '明显超预算菜价必须产生真实流失风险'
);

const noReviewShop={
  rating:4,
  reviewCount:0,
  wordOfMouth:0
};

retention.updateShopReputation(
  noReviewShop,
  {
    reviewStars:null,
    wordOfMouth:0.3
  }
);

assert.equal(
  noReviewShop.reviewCount,
  0,
  '未发表评价的顾客不能虚增公开评价数'
);

retention.updateShopReputation(
  noReviewShop,
  {
    reviewStars:5,
    wordOfMouth:0.3
  }
);

assert.equal(
  noReviewShop.reviewCount,
  1,
  '真实评价才允许进入公开评分'
);`,
  'causality deterministic tests'
);

replaceExact(
  'tests/operationCoreV070.test.js',
`const close=runtimeEngine.closeDay(runtime);
assert.ok(close.financial.revenue>0);`,
`runtime.inventory.lots.push({
  id:'waste_probe',
  batchNo:'waste_probe',
  ingredientId:
    ingredient.id,
  grams:500,
  receivedDay:0,
  expiryDay:0,
  unitCostPerKg:20,
  quality:50,
  storage:'ambient'
});

const close=runtimeEngine.closeDay(runtime);
assert.ok(close.financial.revenue>0);
assert.ok(
  close.inventoryLoss &&
  close.inventoryLoss.expiredValue >
    0,
  '过期库存必须形成真实损耗'
);
assert.ok(
  close.financial.waste >
    0,
  '过期库存损耗必须进入当日利润表'
);`,
  'waste accounting test'
);

replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`assert.ok(closed.playtestHealth);`,
`assert.ok(closed.playtestHealth);
assert.ok(
  closed.dailyBrief.extra &&
  closed.dailyBrief.extra
    .operatingSignals,
  '统一日结必须保存经营因果信号'
);`,
  'operating signals integration'
);

replaceExact(
  'tests/businessDayUiV0844.test.js',
`    'stabilityLevel'
  ) &&`,
`    'stabilityLevel'
  ) &&
  businessSource.includes(
    'operatingSignals'
  ) &&
  businessSource.includes(
    '上次经营：回头客'
  ) &&
  businessSource.includes(
    '热销菜：'
  ) &&`,
  'causal UI assertions'
);

/* =========================================================
   I. 版本同步
   ========================================================= */

updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 860
        versionName '0.8.60'`,
`        versionCode 861
        versionName '0.8.61'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.60 经营核心整合修复版启动成功'",
  "'城市餐饮经营小游戏 V0.8.61 经营因果闭环版启动成功'",
  'startup banner'
);

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0861] 经营因果闭环完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
