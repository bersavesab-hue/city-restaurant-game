'use strict';

/**
 * City Restaurant all-in-one operating systems installer V1.0.5
 * 设计目标：
 * 1) 先验证所有目标/锚点，再一次性写入；
 * 2) 幂等，可重复上传同一包；
 * 3) 不覆盖 package.json，只做精确增量修改；
 * 4) 写入后立即语法检查 + 功能测试 + 接线审计；
 * 5) 任一步失败，GitHub Action 不会进入 commit，避免“半安装”。
 */

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const root = process.cwd();
const VERSION = '1.0.5';
const MARKER = 'CITY_RESTAURANT_OPERATING_V105';

function full(rel) { return path.join(root, rel); }
function exists(rel) { return fs.existsSync(full(rel)); }
function read(rel) { return fs.readFileSync(full(rel), 'utf8'); }
function assert(condition, message) { if (!condition) throw new Error('[V1.0.5 installer] ' + message); }
function count(source, needle) { return source.split(needle).length - 1; }

const requiredStatic = [
  'src/operating/eventCatalogV105.js',
  'src/operating/businessOperatingSystemV105.js',
  'src/operating/operatingRuntimeBridgeV105.js',
  'tests/operatingSystemsV105.test.js',
  'scripts/audit-operating-v105.js'
];
for (const rel of requiredStatic) assert(exists(rel), '更新包缺少 ' + rel);
assert(exists('src/main.js'), '仓库缺少 src/main.js，拒绝猜测式安装');
assert(exists('src/city/demandSystem.js'), '仓库缺少 src/city/demandSystem.js，拒绝猜测式安装');
assert(exists('package.json'), '仓库缺少 package.json');

let main = read('src/main.js');
let demand = read('src/city/demandSystem.js');
const pkg = JSON.parse(read('package.json'));
assert(pkg && pkg.scripts && typeof pkg.scripts.test === 'string', 'package.json scripts.test 不存在');
assert(typeof pkg.scripts['build:android-js'] === 'string', 'package.json build:android-js 不存在');

// ---------- 1. main.js：经营中枢 require ----------
const bridgeRequire = "const operatingRuntimeBridgeV105 =\n  require('./operating/operatingRuntimeBridgeV105.js');";
if (!main.includes("require('./operating/operatingRuntimeBridgeV105.js')")) {
  const demandRequirePattern = /const\s+demandSystem\s*=\s*\n?\s*require\([\"']\.\/city\/demandSystem\.js[\"']\);/;
  assert(demandRequirePattern.test(main), 'main.js 找不到 demandSystem require 锚点');
  main = main.replace(demandRequirePattern, match => match + '\n\n/* ' + MARKER + ' */\n' + bridgeRequire);
}

// ---------- 2. main.js：事件/消息按钮 ----------
if (!main.includes('operatingRuntimeBridgeV105.openEventCenter')) {
  const toolIdPattern = /const\s+toolId\s*=\s*target\.id\s*\.split\(\s*[\"']:[\"']\s*\)\s*\[1\]\s*;/;
  assert(toolIdPattern.test(main), 'main.js 找不到 toolId 声明锚点，无法安全接入事件按钮');
  main = main.replace(toolIdPattern, match => match + `

    if (
      toolId ===
      'event'
    ) {
      operatingRuntimeBridgeV105.openEventCenter();

      return;
    }

    if (
      toolId ===
      'dynamic'
    ) {
      operatingRuntimeBridgeV105.openMessageCenter();

      return;
    }`);
}

// ---------- 3. main.js：系统入口（只替换明确的旧占位，不覆盖已有真实系统页） ----------
if (main.includes('系统设置将在下一阶段接入') && !main.includes('operatingRuntimeBridgeV105.openControlCenter')) {
  const systemBlock = /if\s*\(\s*sceneId\s*===\s*['"]system['"]\s*\)\s*\{[\s\S]{0,300}?系统设置将在下一阶段接入[\s\S]{0,250}?return;\s*\}/;
  assert(systemBlock.test(main), '检测到系统占位文字，但无法定位其完整代码块');
  main = main.replace(systemBlock,
`if (
      sceneId ===
      'system'
    ) {
      operatingRuntimeBridgeV105.openControlCenter('operations');

      return;
    }`);
}

// ---------- 4. demandSystem：事件对真实需求生效（包装现有方法，不侵入原计算公式） ----------
if (!demand.includes('RestaurantOperatingV105.getDemandMultiplier')) {
  const exportPattern = /module\.exports\s*=\s*demandSystem\s*;/;
  assert(exportPattern.test(demand), 'demandSystem.js 找不到 module.exports = demandSystem 锚点');
  const hook = `
/* ${MARKER}: demand multiplier bridge */
const __operatingV105BaseGetTotalDemand =
  demandSystem.getTotalDemand.bind(demandSystem);

demandSystem.getTotalDemand = function operatingV105GetTotalDemand(districtId) {
  const baseDemand = __operatingV105BaseGetTotalDemand(districtId);
  const multiplier =
    globalThis.RestaurantOperatingV105 &&
    typeof globalThis.RestaurantOperatingV105.getDemandMultiplier === 'function'
      ? globalThis.RestaurantOperatingV105.getDemandMultiplier(districtId)
      : 1;

  return Math.max(0, Math.floor(baseDemand * multiplier));
};

`;
  demand = demand.replace(exportPattern, hook + '$&');
}

// ---------- 5. package.json：只增量追加测试，不覆盖原脚本 ----------
const operatingTest = 'node tests/operatingSystemsV105.test.js';
const auditTest = 'node scripts/audit-operating-v105.js';
if (!pkg.scripts.test.includes(operatingTest)) pkg.scripts.test += ' && ' + operatingTest;
if (!pkg.scripts.test.includes(auditTest)) pkg.scripts.test += ' && ' + auditTest;
pkg.cityRestaurantOperatingVersion = VERSION;
pkg.cityRestaurantOperatingFeatures = [
  'event-engine', 'forced-event-modal', 'event-queue', 'event-cooldown', 'event-chain',
  'notifications', 'finance-credit-loans', 'daily-weekly-monthly-settlement', 'traffic-funnel',
  'staff-health', 'dish-improvement-api', 'rating', 'ranking', 'awards', 'guide', 'save-restore'
];

// ---------- 6. 写入前做重复/结构检查 ----------
assert(count(main, "require('./operating/operatingRuntimeBridgeV105.js')") === 1, '经营中枢 require 重复');
assert(count(main, 'operatingRuntimeBridgeV105.openEventCenter') === 1, '事件入口数量异常');
assert(count(demand, 'RestaurantOperatingV105.getDemandMultiplier') >= 1 && count(demand, 'RestaurantOperatingV105.getDemandMultiplier') <= 3, '需求倍率接线数量异常');

// ---------- 7. 一次性落盘 ----------
fs.writeFileSync(full('src/main.js'), main, 'utf8');
fs.writeFileSync(full('src/city/demandSystem.js'), demand, 'utf8');
fs.writeFileSync(full('package.json'), JSON.stringify(pkg, null, 2) + '\n', 'utf8');

// ---------- 8. 安装后即时验证 ----------
const syntaxTargets = [
  'src/main.js',
  'src/city/demandSystem.js',
  'src/operating/eventCatalogV105.js',
  'src/operating/businessOperatingSystemV105.js',
  'src/operating/operatingRuntimeBridgeV105.js',
  'tests/operatingSystemsV105.test.js',
  'scripts/audit-operating-v105.js'
];
for (const rel of syntaxTargets) {
  const result = cp.spawnSync(process.execPath, ['--check', full(rel)], { encoding: 'utf8' });
  if (result.status !== 0) {
    process.stderr.write(result.stdout || '');
    process.stderr.write(result.stderr || '');
    throw new Error('[V1.0.5 installer] 语法检查失败：' + rel);
  }
}

let result = cp.spawnSync(process.execPath, [full('tests/operatingSystemsV105.test.js')], { encoding: 'utf8' });
process.stdout.write(result.stdout || '');
process.stderr.write(result.stderr || '');
assert(result.status === 0, '经营中枢功能测试失败');

result = cp.spawnSync(process.execPath, [full('scripts/audit-operating-v105.js')], { encoding: 'utf8', cwd: root });
process.stdout.write(result.stdout || '');
process.stderr.write(result.stderr || '');
assert(result.status === 0, '经营中枢接线审计失败');

console.log('[V1.0.5 installer] PASS — 所有文件与接线一次性验证完成。');
