'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.16';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.16 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function insertAfter(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      anchor
    );

  if (index < 0) {
    throw new Error(
      'V0.8.16 insert anchor missing: ' +
      label
    );
  }

  const end =
    index +
    anchor.length;

  return (
    source.slice(
      0,
      end
    ) +
    addition +
    source.slice(
      end
    )
  );
}

function replaceSection(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  if (
    source.includes(
      replacement
    )
  ) {
    return source;
  }

  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V0.8.16 section start missing: ' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
      startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V0.8.16 section end missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    '\n\n' +
    source.slice(
      end
    )
  );
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      '0.8.15' &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.16 requires formal V0.8.15 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateBusinessLifecycle() {
  const rel =
    'src/core/businessLifecycleV086.js';

  let source =
    read(rel);

  source =
    insertAfter(
      source,
`const timeScheduleCoordinator =
  require('./timeScheduleCoordinatorV0812.js');`,
`

const shopLifecycle =
  require('./shopLifecycleV0816.js');`,
      "require('./shopLifecycleV0816.js')",
      'business lifecycle require'
    );

  const deriveReplacement =
`function lifecycleEvidence(
  shop
) {
  if (!shop) {
    return {};
  }

  const leaseFound =
    findLease(
      shop.id
    );

  const leaseStatus =
    leaseFound
      ? (
          leaseFound
            .lease
            .lifecycle &&
          leaseFound
            .lease
            .lifecycle
            .status ||
          'active'
        )
      : null;

  if (
    [
      'closed',
      'paused',
      'open',
      'trial_opening',
      'trial_complete'
    ].includes(
      shop.status
    )
  ) {
    return {
      leaseStatus
    };
  }

  const plan =
    renovationSystem
      .ensurePlan(
        shop.id
      );

  const equipment =
    openingPrepSystem
      .ensureEquipment(
        shop.id
      );

  const permits =
    openingPrepSystem
      .getPermitOverview(
        shop.id
      );

  const staffing =
    openingPrepSystem
      .getStaffOverview(
        shop.id
      );

  return {
    renovationStatus:
      plan &&
      plan.status ||
      null,
    equipmentStatus:
      equipment &&
      equipment.status ||
      null,
    permitTotal:
      Number(
        permits &&
        permits.total
      ) ||
      0,
    permitsApproved:
      Number(
        permits &&
        permits.approved
      ) ||
      0,
    permitsApplying:
      !!(
        permits &&
        Array.isArray(
          permits.rows
        ) &&
        permits.rows.some(
          row =>
            row.status ===
              'applying'
        )
      ),
    staffCoverage:
      Number(
        staffing &&
        staffing.coverage
      ) ||
      0,
    leaseStatus
  };
}

function deriveStage(
  shop
) {
  return (
    shopLifecycle
      .deriveStage(
        shop,
        lifecycleEvidence(
          shop
        )
      )
  );
}`;

  source =
    replaceSection(
      source,
      'function deriveStage(\n  shop\n) {',
      'function refreshStage(',
      deriveReplacement,
      'business deriveStage'
    );

  const refreshReplacement =
`function refreshStage(
  shop,
  day
) {
  const result =
    shopLifecycle
      .syncShop(
        shop,
        lifecycleEvidence(
          shop
        ),
        {
          day,
          reason:
            'business-lifecycle-refresh'
        }
      );

  return !!(
    result &&
    result.changed
  );
}`;

  source =
    replaceSection(
      source,
      'function refreshStage(',
      'function processDay(',
      refreshReplacement,
      'business refreshStage'
    );

  const startTrialAnchor =
`  const day =
    currentDay();

  shop.status =
    'trial_opening';`;

  const startTrialReplacement =
`  const lifecycleStage =
    shopLifecycle
      .deriveStage(
        shop,
        lifecycleEvidence(
          shop
        )
      );

  if (
    lifecycleStage !==
      'ready_for_trial'
  ) {
    return {
      ok:false,
      message:
        lifecycleStage ===
          'closed'
          ? '门店已经关闭，不能重新开始试营业'
          : lifecycleStage ===
              'paused'
            ? '门店处于暂停营业状态'
            : '当前门店尚未进入待试营业状态'
    };
  }

  const day =
    currentDay();

  shop.status =
    'trial_opening';`;

  source =
    replaceOnce(
      source,
      startTrialAnchor,
      startTrialReplacement,
      'business start trial guard'
    );

  const pauseBlock =
`function pauseShop(
  shopId,
  reason
) {
  return (
    shopLifecycle
      .pauseShop(
        shopId,
        reason
      )
  );
}

function resumeShop(
  shopId
) {
  return (
    shopLifecycle
      .resumeShop(
        shopId
      )
  );
}

`;

  source =
    insertAfter(
      source,
`function getTrialReport(
  shopId
) {`,
      '',
      'function pauseShop(',
      'pause functions precheck'
    );

  if (
    !source.includes(
      'function pauseShop('
    )
  ) {
    const marker =
      'function getTrialReport(\n  shopId\n) {';

    const index =
      source.indexOf(
        marker
      );

    if (index < 0) {
      throw new Error(
        'V0.8.16 pause/resume insertion anchor missing'
      );
    }

    source =
      source.slice(
        0,
        index
      ) +
      pauseBlock +
      source.slice(
        index
      );
  }

  const overviewAnchor =
`    stage:
      shop.lifecycleStage,
    loan:`;

  const overviewReplacement =
`    stage:
      shop.lifecycleStage,
    lifecycle:
      shopLifecycle
        .getOverview(
          shop,
          lifecycleEvidence(
            shop
          )
        ),
    loan:`;

  source =
    replaceOnce(
      source,
      overviewAnchor,
      overviewReplacement,
      'shop overview lifecycle'
    );

  const exportAnchor =
`  startTrialOpening,
  formalOpen,
  getTrialReport,`;

  const exportReplacement =
`  startTrialOpening,
  formalOpen,
  pauseShop,
  resumeShop,
  getTrialReport,`;

  source =
    replaceOnce(
      source,
      exportAnchor,
      exportReplacement,
      'business lifecycle exports'
    );

  write(
    rel,
    source
  );
}

function updateRenovation() {
  const rel =
    'src/renovation/renovationSystem.js';

  let source =
    read(rel);

  source =
    insertAfter(
      source,
`const simulationSystem =
  require('../core/simulationSystem.js');`,
`

const shopLifecycle =
  require('../core/shopLifecycleV0816.js');`,
      "require('../core/shopLifecycleV0816.js')",
      'renovation lifecycle require'
    );

  const planAnchor =
`    const plan =
      this.getStore()[shopId];

    const quotes =`;

  const planReplacement =
`    const plan =
      this.getStore()[shopId];

    if (
      !shopLifecycle
        .canAction(
          shop,
          'start_renovation',
          {
            renovationStatus:
              plan &&
              plan.status
          }
        )
    ) {
      return {
        ok:false,
        message:
          shop &&
          shop.status ===
            'closed'
            ? '门店已经关闭，不能开始装修'
            : '当前门店状态不能重复开始装修'
      };
    }

    const quotes =`;

  source =
    replaceOnce(
      source,
      planAnchor,
      planReplacement,
      'renovation start guard'
    );

  const renovatingAnchor =
`    shop.status =
      'renovating';

    shop.renovationCost =`;

  const renovatingReplacement =
`    shop.status =
      'renovating';

    shopLifecycle
      .syncShop(
        shop,
        {
          renovationStatus:
            'constructing'
        },
        {
          reason:
            'renovation-started'
        }
      );

    shop.renovationCost =`;

  source =
    replaceOnce(
      source,
      renovatingAnchor,
      renovatingReplacement,
      'renovation start sync'
    );

  const completedAnchor =
`    shop.status =
      'renovated_pending_license';

    shop.layoutMetrics =`;

  const completedReplacement =
`    shop.status =
      'renovated_pending_license';

    shopLifecycle
      .syncShop(
        shop,
        {
          renovationStatus:
            'completed'
        },
        {
          reason:
            'renovation-completed'
        }
      );

    shop.layoutMetrics =`;

  source =
    replaceOnce(
      source,
      completedAnchor,
      completedReplacement,
      'renovation complete sync'
    );

  write(
    rel,
    source
  );
}

function updateOpeningPrep() {
  const rel =
    'src/opening/openingPrepSystem.js';

  let source =
    read(rel);

  source =
    insertAfter(
      source,
`const renovationSystem =
  require('../renovation/renovationSystem.js');`,
`

const shopLifecycle =
  require('../core/shopLifecycleV0816.js');`,
      "require('../core/shopLifecycleV0816.js')",
      'opening lifecycle require'
    );

  const readyCondition =
`    if (
      shop &&
      ready &&
      shop.status !==
        'open' &&
      shop.status !==
        'trial_opening' &&
      shop.status !==
        'trial_complete'
    ) {
      shop.status =
        'ready_for_trial';
    }

    return {`;

  const readyReplacement =
`    if (
      shop &&
      ready &&
      shop.status !==
        'open' &&
      shop.status !==
        'trial_opening' &&
      shop.status !==
        'trial_complete' &&
      shop.status !==
        'closed' &&
      shop.status !==
        'paused'
    ) {
      shop.status =
        'ready_for_trial';
    }

    if (shop) {
      shopLifecycle
        .syncShop(
          shop,
          {
            renovationStatus:
              renovation &&
              renovation.status ||
              null,
            equipmentStatus:
              equipment &&
              equipment.status ||
              null,
            permitTotal:
              Number(
                permits.total
              ) ||
              0,
            permitsApproved:
              Number(
                permits.approved
              ) ||
              0,
            permitsApplying:
              !!(
                Array.isArray(
                  permits.rows
                ) &&
                permits.rows.some(
                  row =>
                    row.status ===
                      'applying'
                )
              ),
            staffCoverage:
              Number(
                staffing.coverage
              ) ||
              0
          },
          {
            reason:
              'opening-readiness'
          }
        );
    }

    return {`;

  source =
    replaceOnce(
      source,
      readyCondition,
      readyReplacement,
      'opening ready terminal protection'
    );

  const trialStatusAnchor =
`    shop.status =
      'trial_opening';

    shop.trialOpenedDay =`;

  const trialStatusReplacement =
`    const lifecycleStage =
      shopLifecycle
        .deriveStage(
          shop,
          {
            renovationStatus:
              readiness
                .renovationReady
                ? 'completed'
                : null,
            equipmentStatus:
              readiness
                .equipmentReady
                ? 'installed'
                : null,
            permitTotal:
              Number(
                readiness
                  .permits &&
                readiness
                  .permits
                  .total
              ) ||
              0,
            permitsApproved:
              Number(
                readiness
                  .permits &&
                readiness
                  .permits
                  .approved
              ) ||
              0,
            staffCoverage:
              Number(
                readiness
                  .staffing &&
                readiness
                  .staffing
                  .coverage
              ) ||
              0
          }
        );

    if (
      lifecycleStage !==
        'ready_for_trial'
    ) {
      return {
        ok:false,
        message:
          lifecycleStage ===
            'closed'
            ? '门店已经关闭，不能开始试营业'
            : lifecycleStage ===
                'paused'
              ? '门店处于暂停营业状态'
              : '当前门店状态不能开始试营业'
      };
    }

    shop.status =
      'trial_opening';

    shop.trialOpenedDay =`;

  source =
    replaceOnce(
      source,
      trialStatusAnchor,
      trialStatusReplacement,
      'opening start trial guard'
    );

  const trialReturnAnchor =
`    shop.trialReport =
      null;

    return {`;

  const trialReturnReplacement =
`    shop.trialReport =
      null;

    shopLifecycle
      .syncShop(
        shop,
        null,
        {
          reason:
            'opening-trial-started'
        }
      );

    return {`;

  source =
    replaceOnce(
      source,
      trialReturnAnchor,
      trialReturnReplacement,
      'opening trial sync'
    );

  write(
    rel,
    source
  );
}

function updateNegotiation() {
  const rel =
    'src/property/propertyNegotiationSystem.js';

  let source =
    read(rel);

  source =
    insertAfter(
      source,
`const simulationSystem =
  require('../core/simulationSystem.js');`,
`

const shopLifecycle =
  require('../core/shopLifecycleV0816.js');`,
      "require('../core/shopLifecycleV0816.js')",
      'negotiation lifecycle require'
    );

  const addAnchor =
`    gameState
      .addShop(
        shop
      );

    session.status =`;

  const addReplacement =
`    gameState
      .addShop(
        shop
      );

    shopLifecycle
      .syncShop(
        shop,
        {
          renovationStatus:
            null
        },
        {
          day,
          reason:
            'lease-signed'
        }
      );

    session.status =`;

  source =
    replaceOnce(
      source,
      addAnchor,
      addReplacement,
      'lease signed lifecycle sync'
    );

  write(
    rel,
    source
  );
}

function updateNewGameFlow() {
  const rel =
    'src/core/newGameFlowV0814.js';

  let source =
    read(rel);

  source =
    insertAfter(
      source,
`const openingPrepSystem =
  require('../opening/openingPrepSystem.js');`,
`

const shopLifecycleModule =
  require('./shopLifecycleV0816.js');`,
      "require('./shopLifecycleV0816.js')",
      'new game lifecycle require'
    );

  source =
    source.replace(
      "const VERSION = '0.8.14';",
      "const VERSION = '0.8.16';"
    );

  const currentShopReplacement =
`  function getCurrentShop() {
    const business =
      getBusiness();

    const shops =
      Array.isArray(
        business.shops
      )
        ? business.shops
        : [];

    const current =
      shops.find(
        shop =>
          shop.id ===
            business.currentShopId &&
          shop.status !==
            'closed'
      );

    return (
      current ||
      shops.find(
        shop =>
          shop.status !==
            'closed'
      ) ||
      null
    );
  }`;

  source =
    replaceSection(
      source,
      '  function getCurrentShop() {',
      '  function hasApprovedPermits(',
      currentShopReplacement,
      'new game current shop'
    );

  const nowAnchor =
`  function now() {
    return typeof opts.now === 'function'
      ? Number(opts.now()) || 0
      : Date.now();
  }`;

  const lifecycleSetup =
`

  const lifecycle =
    opts.shopLifecycle ||
    shopLifecycleModule
      .createLifecycle({
        gameState:
          deps.gameState,
        bus:
          deps.bus,
        now,
        inspect(shop) {
          const renovations =
            deps.gameState
              .getRenovations();

          const prep =
            deps.gameState
              .getOpeningPrep();

          const renovation =
            renovations &&
            renovations[
              shop.id
            ];

          const equipment =
            prep &&
            prep.equipment &&
            prep.equipment[
              shop.id
            ];

          const permits =
            prep &&
            prep.permits &&
            prep.permits[
              shop.id
            ];

          const permitItems =
            permits &&
            permits.items &&
            typeof permits.items ===
              'object'
              ? Object.values(
                  permits.items
                )
              : [];

          const approved =
            permitItems.filter(
              item => {
                const status =
                  String(
                    item &&
                    item.status ||
                    ''
                  );

                return (
                  status ===
                    'approved' ||
                  status.indexOf(
                    'approved_'
                  ) ===
                    0
                );
              }
            ).length;

          let coverage =
            0;

          try {
            const overview =
              deps.openingPrepSystem &&
              typeof deps
                .openingPrepSystem
                .getStaffOverview ===
                'function'
                ? deps.openingPrepSystem
                    .getStaffOverview(
                      shop.id
                    )
                : null;

            coverage =
              Number(
                overview &&
                overview.coverage
              ) ||
              0;
          } catch (error) {
            coverage =
              0;
          }

          return {
            renovationStatus:
              renovation &&
              renovation.status ||
              null,
            equipmentStatus:
              equipment &&
              equipment.status ||
              null,
            permitTotal:
              permitItems.length,
            permitsApproved:
              approved,
            permitsApplying:
              permitItems.some(
                item =>
                  String(
                    item &&
                    item.status ||
                    ''
                  ) ===
                  'applying'
              ),
            staffCoverage:
              coverage
          };
        }
      });`;

  source =
    insertAfter(
      source,
      nowAnchor,
      lifecycleSetup,
      'const lifecycle =',
      'new game lifecycle setup'
    );

  const deriveReplacement =
`  function deriveStage() {
    const state =
      ensureState();

    const business =
      getBusiness();

    if (
      state.mode === 'fresh' &&
      !state.cityConfirmed
    ) {
      return 'city_setup';
    }

    const shop =
      getCurrentShop();

    if (
      !business.hasShop ||
      !shop
    ) {
      return 'property_search';
    }

    const stage =
      lifecycle
        .deriveStage(
          shop
        );

    if (
      stage ===
        'awaiting_renovation' ||
      stage ===
        'renovating'
    ) {
      return 'renovation';
    }

    if (
      stage ===
        'awaiting_equipment' ||
      stage ===
        'equipment_installing'
    ) {
      return 'equipment';
    }

    if (
      stage ===
        'awaiting_permits' ||
      stage ===
        'permits_reviewing'
    ) {
      return 'license';
    }

    if (
      stage ===
        'awaiting_staff'
    ) {
      return 'staff';
    }

    if (
      stage ===
        'ready_for_trial' ||
      stage ===
        'trial_opening'
    ) {
      return 'trial';
    }

    if (
      stage ===
        'trial_complete'
    ) {
      return 'formal_open';
    }

    if (
      stage ===
        'formal_open' ||
      stage ===
        'paused'
    ) {
      return 'complete';
    }

    if (
      stage ===
        'closed'
    ) {
      return 'property_search';
    }

    return 'property_search';
  }`;

  source =
    replaceSection(
      source,
      '  function deriveStage() {',
      '  function routeForStage(stage) {',
      deriveReplacement,
      'new game derive stage bridge'
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0816.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/cityPropertyDatabaseV0815.test.js',
    'tests/propertyMarketDatabaseV0815.test.js',
    'tests/updateInfrastructureV0815.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/cityPropertyDatabaseV0815.test.js',
    'tests/propertyMarketDatabaseV0815.test.js',
    'tests/updateInfrastructureV0815.test.js',
    'tests/shopLifecycleV0816.test.js',
    'tests/shopLifecycleIntegrationV0816.test.js',
    'tests/updateInfrastructureV0816.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0816'
    );

  write(
    rel,
    source
  );
}

function updateMainVersionLabel() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.12 时间与营业日程统一版启动成功',
      '城市餐饮经营小游戏 V0.8.16 门店生命周期统一版启动成功'
    );

  write(
    rel,
    source
  );
}

// GitHub setup-android@v3 may still request removed legacy SDK package "tools".
// This shim only touches the ephemeral GitHub runner.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const binDir =
    path.join(
      latestDir,
      'bin'
    );

  const sdkmanager =
    path.join(
      binDir,
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.16] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const realSdkmanager =
    path.join(
      binDir,
      'sdkmanager.v0816-real'
    );

  if (
    !fs.existsSync(
      realSdkmanager
    )
  ) {
    fs.renameSync(
      sdkmanager,
      realSdkmanager
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0816-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.16] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.16 package version finalize failed'
    );
  }

  const requiredFiles = [
    'src/core/shopLifecycleV0816.js',
    'tests/shopLifecycleV0816.test.js',
    'tests/shopLifecycleIntegrationV0816.test.js',
    'tests/updateInfrastructureV0816.test.js'
  ];

  for (
    const file
    of requiredFiles
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.16 required file missing: ' +
        file
      );
    }
  }

  const business =
    read(
      'src/core/businessLifecycleV086.js'
    );

  for (
    const marker
    of [
      'shopLifecycleV0816.js',
      'lifecycleEvidence',
      '.deriveStage(',
      'pauseShop',
      'resumeShop'
    ]
  ) {
    if (
      !business.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.16 business lifecycle validation missing ' +
        marker
      );
    }
  }

  const opening =
    read(
      'src/opening/openingPrepSystem.js'
    );

  if (
    !opening.includes(
      "'closed'"
    ) ||
    !opening.includes(
      "'paused'"
    ) ||
    !opening.includes(
      'shopLifecycleV0816.js'
    )
  ) {
    throw new Error(
      'V0.8.16 opening terminal-state protection missing'
    );
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/shopLifecycleV0816.test.js',
      'tests/shopLifecycleIntegrationV0816.test.js',
      'tests/updateInfrastructureV0816.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.16 runner validation missing ' +
        marker
      );
    }
  }
}

updatePackage();
updatePackageLock();
updateBusinessLifecycle();
updateRenovation();
updateOpeningPrep();
updateNegotiation();
updateNewGameFlow();
updateRunner();
updateMainVersionLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.16] PASS：门店生命周期状态机统一完成'
);
