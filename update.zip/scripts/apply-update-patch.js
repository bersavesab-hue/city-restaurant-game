'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.15';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.15 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function insertAfter(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      anchor
    );

  if (index < 0) {
    throw new Error(
      'V0.8.15 insert anchor missing: ' +
      label
    );
  }

  const end =
    index +
    anchor.length;

  return (
    source.slice(
      0,
      end
    ) +
    addition +
    source.slice(
      end
    )
  );
}

function replaceSection(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  if (
    source.includes(
      replacement
    )
  ) {
    return source;
  }

  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V0.8.15 section start missing: ' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
      startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V0.8.15 section end missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    '\n\n' +
    source.slice(
      end
    )
  );
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      '0.8.14' &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.15 requires formal V0.8.14 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updatePropertyMarket() {
  const rel =
    'src/property/propertyMarketSystem.js';

  let source =
    read(rel);

  source =
    insertAfter(
      source,
`const propertySystem = require("./propertySystem.js");`,
`

const cityPropertyDatabase =
  require("./cityPropertyDatabaseV0815.js");`,
      'cityPropertyDatabaseV0815.js',
      'property market database require'
    );

  const replacement =
`      const merged =
        cityPropertyDatabase
          .enrichDynamicListing(
            {
              ...base,

              marketKey: item.key,

              askingMonthlyRent:
                item.askingMonthlyRent,

              askingTransferFee:
                item.askingTransferFee,

              daysOnMarket:
                item.daysOnMarket,

              watchers:
                item.watchers,

              competingTenants:
                clone(
                  item.competingTenants
                ),

              marketStatus:
                item.status,

              listedDay:
                item.listedDay,

              priceChangeCount:
                item.priceChangeCount,

              priceChangeRate:
                Number(
                  (
                    (
                      item.askingMonthlyRent -
                      item.initialAskingMonthlyRent
                    ) /
                    Math.max(
                      1,
                      item.initialAskingMonthlyRent
                    )
                  ).toFixed(
                    4
                  )
                )
            },
            {
              currentDay:
                this.state.currentDay,
              districtId:
                item.districtId
            }
          );`;

  source =
    replaceSection(
      source,
      '      const merged = {',
      '      if (f.minArea != null',
      replacement,
      'dynamic listing enrichment'
    );

  const typeFilter =
`      if (f.propertyTypeId && merged.propertyTypeId !== f.propertyTypeId) {
        continue;
      }`;

  const subtypeFilter =
`      if (f.propertyTypeId && merged.propertyTypeId !== f.propertyTypeId) {
        continue;
      }

      if (
        f.propertySubtypeId &&
        merged.propertySubtypeId !==
          f.propertySubtypeId
      ) {
        continue;
      }`;

  source =
    replaceOnce(
      source,
      typeFilter,
      subtypeFilter,
      'property subtype filter'
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0815.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/newGameFlowV0814.test.js',
    'tests/newGameCompatibilityV0814.test.js',
    'tests/updateInfrastructureV0814.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/newGameFlowV0814.test.js',
    'tests/newGameCompatibilityV0814.test.js',
    'tests/updateInfrastructureV0814.test.js',
    'tests/cityPropertyDatabaseV0815.test.js',
    'tests/propertyMarketDatabaseV0815.test.js',
    'tests/updateInfrastructureV0815.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0815'
    );

  write(
    rel,
    source
  );
}

// GitHub setup-android@v3 may still request removed legacy SDK package "tools".
// This compatibility shim only modifies the ephemeral GitHub runner.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const binDir =
    path.join(
      latestDir,
      'bin'
    );

  const sdkmanager =
    path.join(
      binDir,
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.15] Android SDK runner compatibility: preinstalled sdkmanager not found, skip'
    );

    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const realSdkmanager =
    path.join(
      binDir,
      'sdkmanager.v0815-real'
    );

  if (
    !fs.existsSync(
      realSdkmanager
    )
  ) {
    fs.renameSync(
      sdkmanager,
      realSdkmanager
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0815-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.15] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.15 package version finalize failed'
    );
  }

  const market =
    read(
      'src/property/propertyMarketSystem.js'
    );

  for (
    const marker
    of [
      'cityPropertyDatabaseV0815.js',
      '.enrichDynamicListing(',
      'f.propertySubtypeId'
    ]
  ) {
    if (
      !market.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.15 property market validation missing ' +
        marker
      );
    }
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/cityPropertyDatabaseV0815.test.js',
      'tests/propertyMarketDatabaseV0815.test.js',
      'tests/updateInfrastructureV0815.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.15 runner validation missing ' +
        marker
      );
    }
  }

  for (
    const file
    of [
      'src/property/cityPropertyDatabaseV0815.js',
      'tests/cityPropertyDatabaseV0815.test.js',
      'tests/propertyMarketDatabaseV0815.test.js',
      'tests/updateInfrastructureV0815.test.js'
    ]
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.15 required file missing: ' +
        file
      );
    }
  }
}

updatePackage();
updatePackageLock();
updatePropertyMarket();
updateRunner();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.15] PASS：城市 / 商圈 / 房源数据库统一完成'
);
