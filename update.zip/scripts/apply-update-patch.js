'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.46';
const TARGET_VERSION = '0.8.47';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0847] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0847] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* 1) 经营页接入统一入口路由。 */
replaceExact(
  'src/scenes/businessScene.js',
`const saveSystem =
  require('../core/saveSystem.js');`,
`const saveSystem =
  require('../core/saveSystem.js');

const entryRouter =
  require('../core/entryRouterV0810.js');`,
  'entry router import'
);

/* 2) 日结结果不仅给建议，还明确首要问题。 */
replaceExact(
  'src/scenes/businessScene.js',
`    const nextAction =
      latest &&
      latest.nextActions &&
      latest.nextActions[0];`,
`    const nextAction =
      latest &&
      latest.nextActions &&
      latest.nextActions[0];

    const primaryReason =
      latest &&
      latest.reasons &&
      latest.reasons[0];`,
  'primary reason source'
);

replaceExact(
  'src/scenes/businessScene.js',
`    this.sectionCard(
      ctx,
      14,
      510,
      362,
      112,
      '日结复盘与决策反馈'
    );`,
`    this.sectionCard(
      ctx,
      14,
      510,
      362,
      150,
      '日结复盘与第一次改善'
    );`,
  'day review section size'
);

replaceExact(
  'src/scenes/businessScene.js',
`    ui.text(
      ctx,
      recent &&
      recent.impact
        ? recent.impact.explanation
        : '完成菜单、招聘、采购或营销决策后，日结会生成效果反馈。',
      28,
      550,
      6.7,
      '#3A5665',
      '700'
    );

    ui.text(
      ctx,
      nextAction
        ? '明日建议：' +
          nextAction.message
        : '明日建议：等待首次完整日结',
      28,
      582,
      6.7,
      nextAction
        ? '#C08824'
        : '#71858F',
      '700'
    );

    ui.text(
      ctx,
      '待评估决策 ' +`,
`    ui.text(
      ctx,
      primaryReason
        ? '首要问题：' +
          primaryReason.message
        : '首要问题：暂未发现明显经营短板',
      28,
      548,
      6.7,
      primaryReason &&
      primaryReason.severity ===
        'critical'
        ? '#C85242'
        : primaryReason
          ? '#C08824'
          : '#248B63',
      '800'
    );

    ui.text(
      ctx,
      recent &&
      recent.impact
        ? '上次调整：' +
          recent.impact.explanation
        : '上次调整：尚无已完成的经营决策反馈',
      28,
      572,
      6.3,
      '#3A5665',
      '700'
    );

    ui.text(
      ctx,
      nextAction
        ? '明日建议：' +
          nextAction.message
        : '明日建议：等待首次完整日结',
      28,
      596,
      6.5,
      nextAction
        ? '#C08824'
        : '#71858F',
      '700'
    );

    if (
      nextAction &&
      nextAction.routeId
    ) {
      opUi.button(
        ctx,
        nextAction.routeId ===
          'shop'
          ? '回门店'
          : '去处理',
        272,
        608,
        90,
        32,
        'gold'
      );

      this.addButton(
        'day:improve:' +
          nextAction.routeId,
        264,
        602,
        106,
        44
      );
    }

    ui.text(
      ctx,
      '待评估决策 ' +`,
  'actionable day review'
);

replaceExact(
  'src/scenes/businessScene.js',
`      28,
      608,
      6.3,
      '#71858F',
      '600'
    );`,
`      28,
      638,
      6.1,
      '#71858F',
      '600'
    );`,
  'day review metrics position'
);

/* 3) 点击“去处理”直达对应改善入口。 */
replaceExact(
  'src/scenes/businessScene.js',
`      if (
        target.id ===
        'day:close'
      ) {`,
`      if (
        target.id.indexOf(
          'day:improve:'
        ) ===
        0
      ) {
        const routeId =
          target.id.slice(
            'day:improve:'.length
          );

        if (
          routeId ===
          'business'
        ) {
          this.tab =
            'overview';

          opUi.toast(
            '已打开经营结构，请先检查成本与现金流'
          );

          return true;
        }

        const ok =
          entryRouter
            .open(
              routeId,
              {
                shopId:
                  shop.id,
                source:
                  'daily_review'
              }
            );

        if (!ok) {
          const error =
            entryRouter
              .getLastError();

          opUi.toast(
            error &&
            error.reason ||
            '改善入口暂不可用'
          );
        }

        return true;
      }

      if (
        target.id ===
        'day:close'
      ) {`,
  'day improvement navigation'
);

/* 4) 既有回归测试纳入“第一次改善”接线检查。 */
replaceExact(
  'tests/businessDayUiV0844.test.js',
`    '.dashboard('
  ),
  '试营业必须能进入营业日，并读取真实运行时经营数据'
);`,
`    '.dashboard('
  ) &&
  businessSource.includes(
    "'day:improve:'"
  ) &&
  businessSource.includes(
    'entryRouter'
  ) &&
  businessSource.includes(
    '首要问题：'
  ),
  '试营业必须能进入营业日、读取真实经营数据，并从日结直达第一次经营改善'
);`,
  'business UI improvement assertion'
);

/* 5) 版本同步。 */
updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 846
        versionName '0.8.46'`,
`        versionCode 847
        versionName '0.8.47'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.46 首店真实营业优化版启动成功'",
  "'城市餐饮经营小游戏 V0.8.47 第一次经营改善闭环版启动成功'",
  'startup banner'
);

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0847] 第一次经营改善闭环补丁完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
