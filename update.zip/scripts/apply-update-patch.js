'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');

function read(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

function write(rel, content) {
  fs.writeFileSync(path.join(ROOT, rel), content, 'utf8');
}

function mustContain(source, needle, label) {
  if (!source.includes(needle)) {
    throw new Error('[V0.8.10] anchor missing: ' + label);
  }
}

function versionAtLeast(a, b) {
  const aa = String(a || '0').split('.').map(Number);
  const bb = String(b || '0').split('.').map(Number);
  const n = Math.max(aa.length, bb.length);
  for (let i = 0; i < n; i++) {
    const av = aa[i] || 0;
    const bv = bb[i] || 0;
    if (av > bv) return true;
    if (av < bv) return false;
  }
  return true;
}

function patchPackage() {
  const rel = 'package.json';
  const pkg = JSON.parse(read(rel));

  if (!versionAtLeast(pkg.version, '0.8.9')) {
    throw new Error('[V0.8.10] base version must be at least 0.8.9, got ' + pkg.version);
  }

  pkg.version = '0.8.10';
  write(rel, JSON.stringify(pkg, null, 2) + '\n');

  const lockRel = 'package-lock.json';
  if (fs.existsSync(path.join(ROOT, lockRel))) {
    const lock = JSON.parse(read(lockRel));
    lock.version = '0.8.10';
    if (lock.packages && lock.packages['']) {
      lock.packages[''].version = '0.8.10';
    }
    write(lockRel, JSON.stringify(lock, null, 2) + '\n');
  }
}

function patchMain() {
  const rel = 'src/main.js';
  let source = read(rel);

  if (!source.includes('V0810_ENTRY_ROUTER_BOOT')) {
    const sceneAnchor =
      "const sceneManager =\n  require('./core/sceneManager.js');\n";

    mustContain(source, sceneAnchor, 'main sceneManager import');

    source = source.replace(
      sceneAnchor,
      sceneAnchor +
      "\nconst entryRouter =\n  require('./core/entryRouterV0810.js');\n"
    );

    const systemAnchor =
      "const systemScene =\n  require('./scenes/systemSceneV086.js');\n";

    mustContain(source, systemAnchor, 'main system scene import');

    source = source.replace(
      systemAnchor,
      systemAnchor +
      "\nconst featureHubScene =\n  require('./scenes/featureHubSceneV0810.js');\n"
    );

    const registerAnchor =
      "sceneManager.register(\n  'system',\n  systemScene\n);\n";

    mustContain(source, registerAnchor, 'main system scene registration');

    source = source.replace(
      registerAnchor,
      registerAnchor +
      "\nsceneManager.register(\n  'featureHub',\n  featureHubScene\n);\n\n// V0810_ENTRY_ROUTER_BOOT\nentryRouter.install();\n"
    );
  }

  write(rel, source);
}

function patchSystemScene() {
  const rel = 'src/scenes/systemSceneV086.js';
  let source = read(rel);

  if (!source.includes("'feature:hub'")) {
    const saveButton =
      "    this.drawButton(\n      ctx,\n      'save',\n      '立即保存',\n      250,\n      151,\n      108\n    );\n";

    mustContain(source, saveButton, 'system save button');

    source = source.replace(
      saveButton,
      saveButton +
      "\n    this.drawButton(\n      ctx,\n      'feature:hub',\n      '功能中心',\n      28,\n      151,\n      108,\n      'gold'\n    );\n"
    );

    const fontAnchor =
      "    if (\n      button.id ===\n      'font:normal'\n    ) {\n";

    mustContain(source, fontAnchor, 'system font handler');

    source = source.replace(
      fontAnchor,
      "    if (\n      button.id ===\n      'feature:hub'\n    ) {\n      sceneManager\n        .switchTo(\n          'featureHub'\n        );\n\n      return true;\n    }\n\n" +
      fontAnchor
    );
  }

  write(rel, source);
}

function patchV089Regression() {
  const rel = 'tests/updateInfrastructureV089.test.js';
  let source = read(rel);

  if (!source.includes('V0810_VERSION_GUARD')) {
    const exact =
      "assert.equal(\n  pkg.version,\n  '0.8.9',\n  '正式版本必须为0.8.9'\n);";

    mustContain(source, exact, 'V0.8.9 exact version assertion');

    const replacement =
`// V0810_VERSION_GUARD\nfunction versionAtLeast(current, minimum) {\n  const a = String(current || '0').split('.').map(Number);\n  const b = String(minimum || '0').split('.').map(Number);\n  const n = Math.max(a.length, b.length);\n  for (let i = 0; i < n; i++) {\n    const av = a[i] || 0;\n    const bv = b[i] || 0;\n    if (av > bv) return true;\n    if (av < bv) return false;\n  }\n  return true;\n}\n\nassert.ok(\n  versionAtLeast(pkg.version, '0.8.9'),\n  '正式版本不能低于0.8.9'\n);`;

    source = source.replace(exact, replacement);
  }

  write(rel, source);
}

function patchRunner() {
  const rel = 'scripts/run-ci-tests-v060.js';
  let source = read(rel);

  if (!source.includes('tests/featureRoutingV0810.test.js')) {
    const anchor =
      "    'tests/v60CleanBase.test.js'";

    mustContain(source, anchor, 'CI v60CleanBase test');

    source = source.replace(
      anchor,
      "    'tests/featureRoutingV0810.test.js',\n    'tests/updateInfrastructureV0810.test.js',\n" +
      anchor
    );
  }

  write(rel, source);
}

function checkSyntax(rel) {
  const result = cp.spawnSync(
    process.execPath,
    ['--check', path.join(ROOT, rel)],
    { cwd: ROOT, encoding: 'utf8' }
  );

  if (result.status !== 0) {
    process.stderr.write(result.stdout || '');
    process.stderr.write(result.stderr || '');
    throw new Error('[V0.8.10] syntax check failed: ' + rel);
  }
}

patchPackage();
patchMain();
patchSystemScene();
patchV089Regression();
patchRunner();

[
  'src/main.js',
  'src/core/entryRouterV0810.js',
  'src/scenes/featureHubSceneV0810.js',
  'src/scenes/systemSceneV086.js',
  'tests/updateInfrastructureV089.test.js',
  'tests/featureRoutingV0810.test.js',
  'tests/updateInfrastructureV0810.test.js',
  'scripts/run-ci-tests-v060.js'
].forEach(checkSyntax);

console.log('[V0.8.10] 1/26 功能入口与统一路由安装完成');
