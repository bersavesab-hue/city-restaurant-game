'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.47';
const TARGET_VERSION = '0.8.48';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0848] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0848] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* 1) 获取最近两天经营记录，为日环比反馈服务。 */
replaceExact(
  'src/scenes/businessScene.js',
`    const latest =
      cycle.latestClosed;`,
`    const latest =
      cycle.latestClosed;

    const dayHistory =
      operations
        .operatingDayHistory(
          shop.id,
          2
        );

    const previous =
      dayHistory &&
      dayHistory.length >
        1
        ? dayHistory[1]
        : null;`,
  'day history'
);

/* 2) 复盘卡增加空间，容纳趋势与量化调整效果。 */
replaceExact(
  'src/scenes/businessScene.js',
`      150,
      '日结复盘与第一次改善'`,
`      194,
      '日结复盘与连续改善'`,
  'review card expansion'
);

/* 3) 计算“昨日 vs 前日”和最近一次经营调整的量化结果。 */
replaceExact(
  'src/scenes/businessScene.js',
`    const primaryReason =
      latest &&
      latest.reasons &&
      latest.reasons[0];`,
`    const primaryReason =
      latest &&
      latest.reasons &&
      latest.reasons[0];

    const trendRevenue =
      latest &&
      previous
        ? Number(
            latest
              .financial
              .revenue
          ) -
          Number(
            previous
              .financial
              .revenue
          )
        : null;

    const trendProfit =
      latest &&
      previous
        ? Number(
            latest
              .financial
              .profit
          ) -
          Number(
            previous
              .financial
              .profit
          )
        : null;

    const impact =
      recent &&
      recent.impact
        ? recent.impact
        : null;

    const impactLabel =
      impact
        ? (
            impact.outcome ===
              'positive'
              ? '有效'
              : impact.outcome ===
                  'negative'
                ? '需修正'
                : '待观察'
          )
        : '暂无';`,
  'trend and impact data'
);

/* 4) 把“上次调整”从泛化文字升级为可感知的数值反馈。 */
replaceExact(
  'src/scenes/businessScene.js',
`      recent &&
      recent.impact
        ? '上次调整：' +
          recent.impact.explanation
        : '上次调整：尚无已完成的经营决策反馈',`,
`      latest &&
      previous
        ? '经营趋势：营收 ' +
          (
            trendRevenue >=
              0
              ? '+'
              : ''
          ) +
          opUi.money(
            trendRevenue
          ) +
          ' · 利润 ' +
          (
            trendProfit >=
              0
              ? '+'
              : ''
          ) +
          opUi.money(
            trendProfit
          )
        : '经营趋势：完成第二个营业日后显示昨日对比',`,
  'day over day trend'
);

replaceExact(
  'src/scenes/businessScene.js',
`      28,
      572,
      6.3,
      '#3A5665',
      '700'
    );

    ui.text(
      ctx,
      nextAction`,
`      28,
      572,
      6.3,
      latest &&
      previous &&
      Number(
        trendProfit
      ) >=
        0
        ? '#248B63'
        : latest &&
          previous
          ? '#C85242'
          : '#71858F',
      '700'
    );

    ui.text(
      ctx,
      impact
        ? '调整效果：' +
          impactLabel +
          ' · 评分 ' +
          (
            Number(
              impact.score
            ) >=
              0
              ? '+'
              : ''
          ) +
          Number(
            impact.score
          ) +
          ' · 利润 ' +
          (
            Number(
              impact.deltas &&
              impact.deltas.profit
            ) >=
              0
              ? '+'
              : ''
          ) +
          opUi.money(
            impact.deltas &&
            impact.deltas.profit
          )
        : '调整效果：完成一次菜单、采购、招聘或营销调整后显示',
      28,
      596,
      6.3,
      impact &&
      impact.outcome ===
        'positive'
        ? '#248B63'
        : impact &&
          impact.outcome ===
            'negative'
          ? '#C85242'
          : '#71858F',
      '800'
    );

    ui.text(
      ctx,
      nextAction`,
  'quantified decision impact'
);

/* 5) 下移建议、按钮和统计，保持信息层次。 */
replaceExact(
  'src/scenes/businessScene.js',
`      28,
      596,
      6.5,`,
`      28,
      620,
      6.5,`,
  'suggestion position'
);

replaceExact(
  'src/scenes/businessScene.js',
`        272,
        608,
        90,
        32,`,
`        272,
        632,
        90,
        32,`,
  'improve button visual position'
);

replaceExact(
  'src/scenes/businessScene.js',
`        264,
        602,
        106,
        44`,
`        264,
        626,
        106,
        44`,
  'improve button hitbox position'
);

replaceExact(
  'src/scenes/businessScene.js',
`      28,
      638,
      6.1,`,
`      28,
      680,
      6.1,`,
  'feedback metrics position'
);

/* 6) 回归测试纳入连续经营趋势与量化效果。 */
replaceExact(
  'tests/businessDayUiV0844.test.js',
`    '首要问题：'
  ),`,
`    '首要问题：'
  ) &&
  businessSource.includes(
    '经营趋势：'
  ) &&
  businessSource.includes(
    '调整效果：'
  ) &&
  businessSource.includes(
    '.operatingDayHistory('
  ),`,
  'continuous improvement assertions'
);

/* 7) 版本同步。 */
updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 847
        versionName '0.8.47'`,
`        versionCode 848
        versionName '0.8.48'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.47 第一次经营改善闭环版启动成功'",
  "'城市餐饮经营小游戏 V0.8.48 连续经营正反馈版启动成功'",
  'startup banner'
);

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0848] 连续经营正反馈补丁完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
