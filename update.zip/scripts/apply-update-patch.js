'use strict';

// V0864_ONE_CLICK_PATCH

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function read(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

function write(rel, content) {
  fs.writeFileSync(path.join(ROOT, rel), content, 'utf8');
}

function replaceOnce(rel, oldText, newText, label) {
  const source = read(rel);

  if (source.includes(newText)) {
    console.log('[V0864] already applied:', label || rel);
    return;
  }

  const index = source.indexOf(oldText);

  if (index < 0) {
    throw new Error('[V0864] patch anchor missing: ' + (label || rel));
  }

  const next = source.slice(0, index) + newText + source.slice(index + oldText.length);
  write(rel, next);
  console.log('[V0864] patched:', label || rel);
}

function replaceRegex(rel, regex, replacement, label) {
  const source = read(rel);

  if (typeof replacement === 'string' && source.includes(replacement)) {
    console.log('[V0864] already applied:', label || rel);
    return;
  }

  if (!regex.test(source)) {
    throw new Error('[V0864] regex anchor missing: ' + (label || rel));
  }

  regex.lastIndex = 0;
  write(rel, source.replace(regex, replacement));
  console.log('[V0864] patched:', label || rel);
}

// Version metadata.
replaceOnce(
  'package.json',
  '"version": "0.8.63"',
  '"version": "0.8.64"',
  'package version'
);

replaceOnce(
  'package-lock.json',
  '"version": "0.8.63"',
  '"version": "0.8.64"',
  'package-lock root version'
);

// package-lock contains the root package version a second time.
{
  const rel = 'package-lock.json';
  let source = read(rel);
  source = source.replace(/"version": "0\.8\.63"/g, '"version": "0.8.64"');
  write(rel, source);
}

replaceOnce(
  'android/app/build.gradle',
  "        versionCode 863\n        versionName '0.8.63'",
  "        versionCode 864\n        versionName '0.8.64'",
  'Android version'
);

replaceOnce(
  'src/main.js',
  '城市餐饮经营小游戏 V0.8.63 主动经营决策版启动成功',
  '城市餐饮经营小游戏 V0.8.64 真实空间装修体验版启动成功',
  'startup version label'
);

// Unified furniture footprint contract. These values represent the real
// operating envelope (table + chairs + basic service space), not just tabletop.
replaceOnce(
  'src/renovation/renovationConfig.js',
  `  // Furniture footprint includes basic chair pull-out + service clearance.\n  tableFootprint: {\n    2: 4.8,\n    4: 7.6,\n    6: 10.4,\n    8: 13.2\n  },`,
  `  // V0864_REAL_FURNITURE_FOOTPRINT\n  // Real operating envelope: tabletop + chairs + basic service clearance.\n  // Detailed collision geometry lives in renovationSpatialV0864.js.\n  tableFootprint: {\n    2: 2.4,\n    4: 3.6,\n    6: 4.8,\n    8: 6.0\n  },`,
  'real furniture footprints'
);

// Core renovation system: spatial model becomes authoritative for construction
// validity. Existing area math stays as a compatibility/economy input.
replaceOnce(
  'src/renovation/renovationSystem.js',
  `const floorGeometrySystem =\n  require('./floorGeometrySystem.js');`,
  `const floorGeometrySystem =\n  require('./floorGeometrySystem.js');\n\n// V0864_SPATIAL_VALIDATION_INTEGRATION\nconst renovationSpatial =\n  require('./renovationSpatialV0864.js');`,
  'spatial model require'
);

replaceRegex(
  'src/renovation/renovationSystem.js',
  /  createFloor\(\n    index,\n    area\n  \) \{[\s\S]*?\n  \}\n\n  ensurePlan\(shopId\) \{/,
  `  createFloor(\n    index,\n    area\n  ) {\n    // V0864_LEGAL_EMPTY_START\n    // Never create an illegal restaurant and ask the player to repair it.\n    // New floors start as a valid empty shell; the one-tap auto-layout or the\n    // furniture editor adds only placements that pass the spatial validator.\n    return {\n      index,\n      name:\n        '第' +\n        (index + 1) +\n        '层',\n\n      area:\n        Number(\n          area.toFixed(1)\n        ),\n\n      kitchenRatio:\n        index === 0\n          ? 0.27\n          : 0.18,\n\n      storageRatio:\n        0.08,\n\n      serviceRatio:\n        0.11,\n\n      aisleMode:\n        'standard',\n\n      tables: {\n        2: 0,\n        4: 0,\n        6: 0,\n        8: 0\n      },\n\n      editorPlacements: [],\n      privateRooms: []\n    };\n  }\n\n  ensurePlan(shopId) {`,
  'legal empty floor defaults'
);

// Legacy/add-button compatibility: the old adjustTable API must now mutate the
// same persistent real-space objects as the V0.8.64 editor. This keeps old
// saves, old pages and tests on one spatial source of truth.
replaceRegex(
  'src/renovation/renovationSystem.js',
  /  adjustTable\(\n    shopId,\n    floorIndex,\n    seats,\n    delta\n  \) \{[\s\S]*?\n  \}\n  adjustDecor\(/,
  `  adjustTable(\n    shopId,\n    floorIndex,\n    seats,\n    delta\n  ) {\n    const key =\n      String(seats);\n\n    if (\n      !config\n        .tableFootprint[\n          key\n        ]\n    ) {\n      return null;\n    }\n\n    const shop =\n      this.getShop(\n        shopId\n      );\n\n    return this.mutatePlan(\n      shopId,\n      plan => {\n        const index =\n          clamp(\n            floorIndex,\n            0,\n            plan.floors.length -\n              1\n          );\n\n        const floor =\n          plan.floors[index];\n\n        if (!Array.isArray(floor.editorPlacements)) {\n          floor.editorPlacements = [];\n        }\n\n        // Materialize old count-only tables into legal real-space objects\n        // before applying the requested delta.\n        const baseArea =\n          this.calculateFloorArea(\n            shop,\n            plan,\n            floor,\n            index\n          );\n\n        const materialized =\n          renovationSpatial\n            .materializeLegacyPlacements(\n              floor,\n              baseArea.geometry,\n              baseArea.usableDiningSlots,\n              floorGeometrySystem,\n              config.zoneRules\n                .entranceClearDepthM\n            );\n\n        const expectedCount =\n          Object.keys(floor.tables)\n            .reduce(\n              (sum, tableKey) =>\n                sum +\n                Math.max(\n                  0,\n                  Number(floor.tables[tableKey]) || 0\n                ),\n              0\n            );\n\n        const actualCount =\n          floor.editorPlacements\n            .filter(\n              item =>\n                renovationSpatial\n                  .isTable(item.kind)\n            )\n            .length;\n\n        if (actualCount < expectedCount) {\n          plan.editorPlacementSeq =\n            Math.max(0, Number(plan.editorPlacementSeq) || 0);\n\n          floor.editorPlacements =\n            materialized.map(\n              item => {\n                if (!item.synthetic) {\n                  return item;\n                }\n\n                plan.editorPlacementSeq += 1;\n\n                return {\n                  ...item,\n                  id:\n                    'reno_compat_' +\n                    index +\n                    '_' +\n                    item.kind +\n                    '_' +\n                    plan.editorPlacementSeq,\n                  synthetic: false\n                };\n              }\n            );\n        }\n\n        const amount =\n          Math.max(\n            1,\n            Math.floor(\n              Math.abs(\n                Number(delta) || 0\n              )\n            )\n          );\n\n        if (Number(delta) > 0) {\n          for (let step = 0; step < amount; step++) {\n            const area =\n              this.calculateFloorArea(\n                shop,\n                plan,\n                floor,\n                index\n              );\n\n            const currentTableCount =\n              Object.keys(floor.tables)\n                .reduce(\n                  (sum, tableKey) =>\n                    sum +\n                    Math.max(\n                      0,\n                      Number(floor.tables[tableKey]) || 0\n                    ),\n                  0\n                );\n\n            const extraArea =\n              config.tableFootprint[key] *\n              area.aisle.areaFactor;\n\n            if (\n              area.occupiedArea +\n                extraArea >\n                area.effectiveDiningArea +\n                0.01 ||\n              currentTableCount >=\n                area.usableDiningSlots.length\n            ) {\n              break;\n            }\n\n            const rotations =\n              Number(key) >= 6\n                ? [90, 0]\n                : [0, 90];\n\n            let committed =\n              false;\n\n            for (\n              let rotationIndex = 0;\n              rotationIndex < rotations.length;\n              rotationIndex++\n            ) {\n              const rotation =\n                rotations[rotationIndex];\n\n              const found =\n                renovationSpatial\n                  .findFirstValidPosition({\n                    kind:\n                      'table' +\n                      key,\n                    floor,\n                    geometry:\n                      area.geometry,\n                    placements:\n                      floor.editorPlacements,\n                    floorGeometrySystem,\n                    clearDepthM:\n                      config.zoneRules\n                        .entranceClearDepthM,\n                    rotation\n                  });\n\n              if (!found) {\n                continue;\n              }\n\n              plan.editorPlacementSeq =\n                Math.max(0, Number(plan.editorPlacementSeq) || 0) +\n                1;\n\n              const placement = {\n                id:\n                  'reno_compat_' +\n                  index +\n                  '_table' +\n                  key +\n                  '_' +\n                  plan.editorPlacementSeq,\n                kind:\n                  'table' +\n                  key,\n                mx:\n                  Number(found.x),\n                my:\n                  Number(found.y),\n                rotation:\n                  Number(found.rotation) ||\n                  rotation\n              };\n\n              floor.editorPlacements\n                .push(placement);\n\n              floor.tables[key] =\n                Math.min(\n                  40,\n                  Math.max(\n                    0,\n                    Number(floor.tables[key]) || 0\n                  ) +\n                    1\n                );\n\n              const afterArea =\n                this.calculateFloorArea(\n                  shop,\n                  plan,\n                  floor,\n                  index\n                );\n\n              const spatialCheck =\n                renovationSpatial\n                  .analyzeFloor({\n                    floor,\n                    geometry:\n                      afterArea.geometry,\n                    areaMetrics:\n                      afterArea,\n                    floorGeometrySystem,\n                    clearDepthM:\n                      config.zoneRules\n                        .entranceClearDepthM\n                  });\n\n              if (spatialCheck.valid) {\n                committed =\n                  true;\n                break;\n              }\n\n              floor.editorPlacements\n                .pop();\n\n              floor.tables[key] =\n                Math.max(\n                  0,\n                  Number(floor.tables[key]) -\n                    1\n                );\n            }\n\n            if (!committed) {\n              break;\n            }\n          }\n        } else if (Number(delta) < 0) {\n          for (let step = 0; step < amount; step++) {\n            if (\n              Math.max(0, Number(floor.tables[key]) || 0) <= 0\n            ) {\n              break;\n            }\n\n            let removeIndex =\n              -1;\n\n            for (\n              let i = floor.editorPlacements.length - 1;\n              i >= 0;\n              i--\n            ) {\n              if (\n                floor.editorPlacements[i].kind ===\n                  'table' +\n                  key\n              ) {\n                removeIndex =\n                  i;\n                break;\n              }\n            }\n\n            if (removeIndex >= 0) {\n              floor.editorPlacements\n                .splice(\n                  removeIndex,\n                  1\n                );\n            }\n\n            floor.tables[key] =\n              Math.max(\n                0,\n                Number(floor.tables[key]) -\n                  1\n              );\n          }\n        }\n\n        plan.editorPlacementVersion =\n          Math.max(\n            4,\n            Number(plan.editorPlacementVersion) || 0\n          );\n\n        // V0.8.62 signature code will refresh this lazily if the old editor is\n        // ever opened through a compatibility route.\n        plan.editorPlacementSignature =\n          null;\n      }\n    );\n  }\n  adjustDecor(`,
  'spatial-safe legacy table API'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  `      const areaMetrics =\n        this.calculateFloorArea(\n          shop,\n          plan,\n          floor,\n          i\n        );`,
  `      const areaMetrics =\n        this.calculateFloorArea(\n          shop,\n          plan,\n          floor,\n          i\n        );\n\n      const spatialAnalysis =\n        renovationSpatial\n          .analyzeFloor({\n            floor,\n            geometry,\n            areaMetrics,\n            floorGeometrySystem,\n            clearDepthM:\n              config\n                .zoneRules\n                .entranceClearDepthM\n          });`,
  'per-floor spatial analysis'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  `      const valid =\n        areaMetrics.valid;`,
  `      const valid =\n        areaMetrics.valid &&\n        spatialAnalysis.valid;`,
  'combined floor validity'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  `        areaWarnings:\n          areaMetrics\n            .warnings,`,
  `        areaWarnings:\n          [\n            ...areaMetrics\n              .warnings,\n            ...spatialAnalysis\n              .issues\n              .map(\n                issue =>\n                  issue.message\n              )\n          ],\n\n        spatial:\n          spatialAnalysis,\n\n        spatialRemainingArea:\n          spatialAnalysis\n            .remainingFrontArea,`,
  'spatial metrics exposure'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  `      serviceScore +=\n        aisle\n          .serviceEfficiency *\n        geometry\n          .efficiency\n          .service;`,
  `      serviceScore +=\n        aisle\n          .serviceEfficiency *\n        geometry\n          .efficiency\n          .service *\n        spatialAnalysis\n          .serviceFactor;`,
  'service efficiency spatial causality'
);

replaceOnce(
  'src/renovation/renovationSystem.js',
  `    if (!metrics.valid) {\n      return {\n        ok:\n          false,\n        message:\n          '当前布局存在面积或后厨承载问题'\n      };\n    }`,
  `    if (!metrics.valid) {\n      const spatialIssue =\n        metrics\n          .floors\n          .map(\n            floor =>\n              floor &&\n              floor.spatial &&\n              floor.spatial\n                .primaryIssue\n          )\n          .find(Boolean);\n\n      return {\n        ok:\n          false,\n        message:\n          spatialIssue\n            ? '当前布局不能施工：' +\n              spatialIssue.message\n            : '当前布局存在面积或后厨承载问题'\n      };\n    }`,
  'construction blocking reason'
);

// Install V0.8.64 after the V0.8.63 editor so the new interaction layer is
// authoritative while preserving old save migration and compatibility code.
replaceOnce(
  'src/scenes/renovationScene.js',
  `require('../renovation/renovationEditorV0862.js').install({\n  RenovationScene,\n  renovationSystem,\n  renovationConfig,\n  floorGeometrySystem,\n  saveSystem,\n  runtime,\n  ui,\n  COLORS,\n  V45_HALL_STYLE_VISUAL\n});\n\nmodule.exports =`,
  `require('../renovation/renovationEditorV0862.js').install({\n  RenovationScene,\n  renovationSystem,\n  renovationConfig,\n  floorGeometrySystem,\n  saveSystem,\n  runtime,\n  ui,\n  COLORS,\n  V45_HALL_STYLE_VISUAL\n});\n\n// V0864_RENOVATION_PLAYER_EXPERIENCE_INSTALL\nrequire('../renovation/renovationEditorV0864.js').install({\n  RenovationScene,\n  renovationSystem,\n  renovationConfig,\n  floorGeometrySystem,\n  saveSystem,\n  gameState,\n  ui,\n  COLORS\n});\n\nmodule.exports =`,
  'V0863 scene install'
);

replaceOnce(
  'scripts/run-ci-tests-v060.js',
  `    'tests/renovationEditorV0862.test.js',\n    'tests/preparationCommandCenterV0861.test.js',`,
  `    'tests/renovationEditorV0862.test.js',\n    'tests/renovationSpatialV0864.test.js',\n    'tests/preparationCommandCenterV0861.test.js',`,
  'V0863 test registration'
);

// Final safety checks.
const pkg = JSON.parse(read('package.json'));
if (pkg.version !== '0.8.64') {
  throw new Error('[V0864] package version did not reach 0.8.64');
}

for (const rel of [
  'src/renovation/renovationSpatialV0864.js',
  'src/renovation/renovationEditorV0864.js',
  'tests/renovationSpatialV0864.test.js'
]) {
  if (!fs.existsSync(path.join(ROOT, rel))) {
    throw new Error('[V0864] required file missing: ' + rel);
  }
}

console.log('[V0864-R2] unified renovation spatial patch applied successfully');
