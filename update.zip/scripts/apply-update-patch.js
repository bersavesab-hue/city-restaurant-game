'use strict';

const fs=require('fs');
const path=require('path');

const ROOT=path.resolve(__dirname,'..');
const BASE_VERSION='0.8.25';
const TARGET_VERSION='0.8.29';

function abs(rel){return path.join(ROOT,rel);}
function read(rel){return fs.readFileSync(abs(rel),'utf8');}
function write(rel,content){fs.writeFileSync(abs(rel),content,'utf8');}

function replaceOnce(source,from,to,label){
  if(source.includes(to))return source;
  const i=source.indexOf(from);
  if(i<0)throw new Error('V0.8.26-29 patch anchor missing: '+label);
  return source.slice(0,i)+to+source.slice(i+from.length);
}

function insertBefore(source,anchor,addition,marker,label){
  if(marker&&source.includes(marker))return source;
  const i=source.indexOf(anchor);
  if(i<0)throw new Error('V0.8.26-29 insertion anchor missing: '+label);
  return source.slice(0,i)+addition+source.slice(i);
}

function cleanupLegacyRootWorkflow(){
  if(fs.existsSync(abs('apply-update.yml'))){
    fs.unlinkSync(abs('apply-update.yml'));
    console.log('[V0.8.26-29] removed stray root apply-update.yml');
  }
}

function updatePackage(){
  const pkg=JSON.parse(read('package.json'));
  if(pkg.version!==BASE_VERSION&&pkg.version!==TARGET_VERSION){
    throw new Error('V0.8.26-29 requires formal V0.8.25 baseline; current='+pkg.version);
  }
  pkg.version=TARGET_VERSION;
  write('package.json',JSON.stringify(pkg,null,2)+'\n');
}

function updatePackageLock(){
  if(!fs.existsSync(abs('package-lock.json')))return;
  const lock=JSON.parse(read('package-lock.json'));
  lock.version=TARGET_VERSION;
  if(lock.packages&&lock.packages[''])lock.packages[''].version=TARGET_VERSION;
  write('package-lock.json',JSON.stringify(lock,null,2)+'\n');
}

function updateOperationsStore(){
  const rel='src/operations/operationsStoreV080.js';
  let source=read(rel);

  source=replaceOnce(
    source,
`const completeFinanceSystem =
  require('../finance/completeFinanceSystemV0825.js');

const customerRandomDatabase =`,
`const completeFinanceSystem =
  require('../finance/completeFinanceSystemV0825.js');

const marketingPlatformMembership =
  require('./marketingPlatformMembershipV0826.js');

const reputationMediaSystem =
  require('../reputation/reputationMediaSystemV0827.js');

const commercialEcologySystem =
  require('../world/commercialEcologySystemV0828.js');

const environmentWorldCoordinator =
  require('../world/environmentWorldCoordinatorV0829.js');

const customerRandomDatabase =`,
    'operations V0826-29 imports'
  );

  const apiBlock=
`function marketingCatalog() {
  return marketingPlatformMembership
    .campaignCatalog();
}

function marketingPlatformCatalog() {
  return marketingPlatformMembership
    .platformCatalog();
}

function configureMarketingPlatform(
  shopId,
  platformId,
  options
) {
  return marketingPlatformMembership
    .configurePlatform(
      shopId,
      platformId,
      options || {}
    );
}

function startMarketingCampaign(
  shopId,
  typeId,
  budget,
  days,
  options
) {
  return mutate(
    shopId,
    runtime =>
      marketingPlatformMembership
        .startCampaign(
          shopId,
          runtime,
          typeId,
          budget,
          days,
          {
            ...(options || {}),
            day:
              options &&
              options.day != null
                ? options.day
                : runtime.day
          }
        )
  );
}

function enrollMember(
  shopId,
  customerId,
  options
) {
  return marketingPlatformMembership
    .enrollMember(
      shopId,
      customerId,
      options || {}
    );
}

function recordMemberSpend(
  shopId,
  customerId,
  amount,
  options
) {
  return marketingPlatformMembership
    .recordMemberSpend(
      shopId,
      customerId,
      amount,
      options || {}
    );
}

function redeemMemberPoints(
  shopId,
  customerId,
  points
) {
  return marketingPlatformMembership
    .redeemPoints(
      shopId,
      customerId,
      points
    );
}

function marketingMembershipSnapshot(
  shopId
) {
  return marketingPlatformMembership
    .overview(
      shopId,
      getRuntime(shopId)
    );
}

function reputationSnapshot(
  shopId
) {
  return reputationMediaSystem
    .overview(
      shopId,
      getShop(shopId)
    );
}

function recordManualReview(
  shopId,
  experience,
  options
) {
  return reputationMediaSystem
    .recordReview(
      shopId,
      getShop(shopId),
      experience || {},
      {
        ...(options || {}),
        applyShopRating:
          options &&
          options.applyShopRating === false
            ? false
            : true
      }
    );
}

function createReputationRumor(
  shopId,
  options
) {
  return reputationMediaSystem
    .createRumor(
      shopId,
      options || {}
    );
}

function resolveReputationRumor(
  shopId,
  rumorId,
  options
) {
  return reputationMediaSystem
    .resolveRumor(
      shopId,
      rumorId,
      options || {}
    );
}

function publishReputationMedia(
  shopId,
  options
) {
  return reputationMediaSystem
    .publishMediaPost(
      shopId,
      options || {}
    );
}

function commercialEcologySnapshot(
  shopId,
  options
) {
  return commercialEcologySystem
    .snapshot(
      shopId,
      options || {}
    );
}

function processCommercialEcologyDay(
  day,
  options
) {
  return commercialEcologySystem
    .processDay(
      day,
      options || {}
    );
}

function environmentSnapshot(
  shopId,
  options
) {
  const shop=getShop(shopId);
  return environmentWorldCoordinator
    .snapshot({
      shopId,
      districtId:
        options &&
        options.districtId ||
        shop &&
        shop.districtId ||
        null,
      ...(options || {})
    });
}

function processEnvironmentDay(
  day,
  shopId,
  options
) {
  const shop=getShop(shopId);
  return environmentWorldCoordinator
    .processDay(
      day,
      {
        shopId,
        districtId:
          options &&
          options.districtId ||
          shop &&
          shop.districtId ||
          null,
        ...(options || {})
      }
    );
}

`;

  source=insertBefore(
    source,
    'function supplierCatalog(\n  shopId,',
    apiBlock,
    'function marketingCatalog()',
    'V0826-29 operation APIs'
  );

  const visitOld=
`      if (
        result &&
        result.ok
      ) {
        completeFinanceSystem
          .recordOrderSettlement(
            shopId,
            result.settlement,
            {
              day:
                runtime.day,
              orderId:
                result.order &&
                result.order.id,
              referenceId:
                'order:' +
                (
                  result.order &&
                  result.order.id ||
                  runtime
                    .history
                    .length
                ),
              applyCash:true
            }
          );
      }

      return result;`;

  const visitNew=
`      if (
        result &&
        result.ok
      ) {
        completeFinanceSystem
          .recordOrderSettlement(
            shopId,
            result.settlement,
            {
              day:
                runtime.day,
              orderId:
                result.order &&
                result.order.id,
              referenceId:
                'order:' +
                (
                  result.order &&
                  result.order.id ||
                  runtime
                    .history
                    .length
                ),
              applyCash:true
            }
          );

        marketingPlatformMembership
          .recordMemberSpend(
            shopId,
            profile &&
            profile.id,
            Number(
              result.settlement &&
              result.settlement.revenue
            ) || 0,
            {
              day:runtime.day,
              visits:1
            }
          );

        reputationMediaSystem
          .recordVisitOutcome(
            shopId,
            runtime.shop,
            result,
            {
              day:runtime.day
            }
          );
      }

      return result;`;

  source=replaceOnce(
    source,
    visitOld,
    visitNew,
    'visit marketing/reputation bridge'
  );

  const closeOld=
`      if (
        result &&
        result.ok &&
        result.result &&
        result.result.financial
      ) {
        completeFinanceSystem
          .syncDailyStatement(
            shopId,
            result
              .result
              .financial,
            result
              .result
              .day
          );
      }

      return result;`;

  const closeNew=
`      if (
        result &&
        result.ok &&
        result.result &&
        result.result.financial
      ) {
        completeFinanceSystem
          .syncDailyStatement(
            shopId,
            result
              .result
              .financial,
            result
              .result
              .day
          );

        const closedDay=
          result
            .result
            .day;

        reputationMediaSystem
          .processDay(
            shopId,
            closedDay
          );

        commercialEcologySystem
          .processDay(
            closedDay,
            {
              shopId
            }
          );

        processEnvironmentDay(
          closedDay,
          shopId,
          {}
        );
      }

      return result;`;

  source=replaceOnce(
    source,
    closeOld,
    closeNew,
    'day-close world bridge'
  );

  source=replaceOnce(
    source,
`  openingCreditStatus,
  generateCustomer,`,
`  openingCreditStatus,
  marketingCatalog,
  marketingPlatformCatalog,
  configureMarketingPlatform,
  startMarketingCampaign,
  enrollMember,
  recordMemberSpend,
  redeemMemberPoints,
  marketingMembershipSnapshot,
  reputationSnapshot,
  recordManualReview,
  createReputationRumor,
  resolveReputationRumor,
  publishReputationMedia,
  commercialEcologySnapshot,
  processCommercialEcologyDay,
  environmentSnapshot,
  processEnvironmentDay,
  generateCustomer,`,
    'operations V0826-29 exports'
  );

  write(rel,source);
}

function updateOperationsIndex(){
  write(
    'src/operations/index.js',
`'use strict';

module.exports = {
  settlement:
    require('./settlementEngineV10.js'),
  retention:
    require('./retentionEngineV10.js'),
  staff:
    require('./staffOperationsEngineV10.js'),
  staffManagement:
    require('./staffManagementCoordinatorV0823.js'),
  live:
    require('./liveOperationsCoordinatorV0824.js'),
  delivery:
    require('./deliveryEngineV10.js'),
  marketing:
    require('./marketingEngineV10.js'),
  marketingPlatformMembership:
    require('./marketingPlatformMembershipV0826.js'),
  brand:
    require('./brandGrowthEngineV10.js'),
  events:
    require('./restaurantEventEngineV10.js'),
  runtime:
    require('./restaurantRuntimeV10.js'),
  finance:
    require('../finance/completeFinanceSystemV0825.js'),
  reputation:
    require('../reputation/reputationMediaSystemV0827.js'),
  commercialEcology:
    require('../world/commercialEcologySystemV0828.js'),
  environment:
    require('../world/environmentWorldCoordinatorV0829.js')
};
`
  );
}

function updateRunner(){
  const rel='scripts/run-ci-tests-v060.js';
  let source=read(rel);

  if(source.includes('tests/updateInfrastructureV0829.test.js'))return;

  const anchor=`    'tests/v60CleanBase.test.js'`;

  const addition=
`    'tests/marketingPlatformMembershipV0826.test.js',
    'tests/reputationMediaSystemV0827.test.js',
    'tests/commercialEcologySystemV0828.test.js',
    'tests/environmentWorldCoordinatorV0829.test.js',
    'tests/megaMarketingWorldV0829.test.js',
    'tests/updateInfrastructureV0829.test.js',
`;

  const i=source.indexOf(anchor);
  if(i<0){
    throw new Error('V0.8.26-29 runner anchor missing: v60CleanBase');
  }

  source=
    source.slice(0,i)+
    addition+
    source.slice(i);

  write(rel,source);
}

function updateMainLabel(){
  const rel='src/main.js';
  let source=read(rel);
  source=source.replace(
    '城市餐饮经营小游戏 V0.8.25 员工经营财务四合一版启动成功',
    '城市餐饮经营小游戏 V0.8.29 营销口碑商圈环境四合一版启动成功'
  );
  write(rel,source);
}

function patchAndroidRunnerCompatibility(){
  const sdkRoot=process.env.ANDROID_SDK_ROOT||process.env.ANDROID_HOME||'/usr/local/lib/android/sdk';
  const latestDir=path.join(sdkRoot,'cmdline-tools','latest');
  const sourceProperties=path.join(latestDir,'source.properties');
  const sdkmanager=path.join(latestDir,'bin','sdkmanager');

  if(!fs.existsSync(sourceProperties)||!fs.existsSync(sdkmanager)){
    console.log('[V0.8.26-29] Android SDK runner compatibility: sdkmanager not found, skip');
    return;
  }

  let properties=fs.readFileSync(sourceProperties,'utf8');
  properties=properties
    .replace(/^Pkg\.Revision=.*$/m,'Pkg.Revision=16.0')
    .replace(/^Pkg\.Path=.*$/m,'Pkg.Path=cmdline-tools;16.0');
  fs.writeFileSync(sourceProperties,properties,'utf8');

  const real=path.join(path.dirname(sdkmanager),'sdkmanager.v0829-real');
  if(!fs.existsSync(real))fs.renameSync(sdkmanager,real);

  const wrapper=[
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0829-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then continue; fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then exit 0; fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join('\n');

  fs.writeFileSync(sdkmanager,wrapper,'utf8');
  fs.chmodSync(sdkmanager,0o755);
  console.log('[V0.8.26-29] Android SDK runner compatibility enabled');
}

function validate(){
  const pkg=JSON.parse(read('package.json'));
  if(pkg.version!==TARGET_VERSION)throw new Error('target version finalize failed');

  if(fs.existsSync(abs('apply-update.yml'))){
    throw new Error('stray root apply-update.yml cleanup failed');
  }

  const required=[
    'src/operations/marketingPlatformMembershipV0826.js',
    'src/reputation/reputationMediaSystemV0827.js',
    'src/world/commercialEcologySystemV0828.js',
    'src/world/environmentWorldCoordinatorV0829.js',
    'tests/marketingPlatformMembershipV0826.test.js',
    'tests/reputationMediaSystemV0827.test.js',
    'tests/commercialEcologySystemV0828.test.js',
    'tests/environmentWorldCoordinatorV0829.test.js',
    'tests/megaMarketingWorldV0829.test.js',
    'tests/updateInfrastructureV0829.test.js'
  ];

  for(const file of required){
    if(!fs.existsSync(abs(file)))throw new Error('required file missing: '+file);
  }

  const operations=read('src/operations/operationsStoreV080.js');
  for(const marker of [
    'marketingPlatformMembershipV0826.js',
    'reputationMediaSystemV0827.js',
    'commercialEcologySystemV0828.js',
    'environmentWorldCoordinatorV0829.js',
    'function marketingCatalog()',
    'function reputationSnapshot(',
    'function commercialEcologySnapshot(',
    'function environmentSnapshot('
  ]){
    if(!operations.includes(marker))throw new Error('operations integration missing '+marker);
  }

  const runner=read('scripts/run-ci-tests-v060.js');
  for(const marker of [
    'tests/marketingPlatformMembershipV0826.test.js',
    'tests/reputationMediaSystemV0827.test.js',
    'tests/commercialEcologySystemV0828.test.js',
    'tests/environmentWorldCoordinatorV0829.test.js',
    'tests/megaMarketingWorldV0829.test.js',
    'tests/updateInfrastructureV0829.test.js'
  ]){
    if(!runner.includes(marker))throw new Error('runner integration missing '+marker);
  }
}

cleanupLegacyRootWorkflow();
updatePackage();
updatePackageLock();
updateOperationsStore();
updateOperationsIndex();
updateRunner();
updateMainLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.29] PASS：17-20/26 营销/会员、口碑/媒体、商业生态、事件/政策/天气/季节四合一升级完成'
);
