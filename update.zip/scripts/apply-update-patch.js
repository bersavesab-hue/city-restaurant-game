'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.18';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.18 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function replaceSection(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  if (
    source.includes(
      replacement
    )
  ) {
    return source;
  }

  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V0.8.18 section start missing: ' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
      startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V0.8.18 section end missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    '\n\n' +
    source.slice(
      end
    )
  );
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      '0.8.17' &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.18 requires formal V0.8.17 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateOperationsStore() {
  const rel =
    'src/operations/operationsStoreV080.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const foodPack =
  require('../food/foodPackV10.js');`,
`const foodPack =
  require('../food/foodPackV10.js');

const menuEngine =
  require('../food/menuEngineV10.js');

const foodResearchDatabase =
  require('../food/foodResearchDatabaseV0818.js');

const foodResearchSystem =
  require('../food/foodResearchSystemV0818.js');`,
      'operations food research imports'
    );

  const defaultReplacement =
`function defaultRecipeIds() {
  return (
    foodResearchDatabase
      .STARTER_RECIPE_IDS
      .slice()
  );
}`;

  source =
    replaceSection(
      source,
      'function defaultRecipeIds() {',
      'function snapshotRuntime(',
      defaultReplacement,
      'default starter menu'
    );

  if (
    !source.includes(
      'function addMenuRecipe('
    )
  ) {
    const anchor =
      'function inventoryRows(\n  shopId\n) {';

    const index =
      source.indexOf(
        anchor
      );

    if (index < 0) {
      throw new Error(
        'V0.8.18 menu API insertion anchor missing'
      );
    }

    const apiBlock =
`function addMenuRecipe(
  shopId,
  recipeId,
  options
) {
  if (
    !foodResearchSystem
      .isUnlocked(
        recipeId
      )
  ) {
    return {
      ok:false,
      reason:
        '该菜品尚未研发完成'
    };
  }

  const recipe =
    foodResearchDatabase
      .getRecipe(
        recipeId
      );

  if (!recipe) {
    return {
      ok:false,
      reason:
        '配方不存在'
    };
  }

  const opts =
    options ||
    {};

  return mutate(
    shopId,
    runtime => {
      const portionId =
        opts.portionId ||
        'single';

      const duplicate =
        runtime.menu
          .find(
            item =>
              item.recipeId ===
                recipeId &&
              (
                item.portionId ||
                'single'
              ) ===
                portionId
          );

      if (duplicate) {
        return {
          ok:false,
          reason:
            '该菜品份量已经在菜单中',
          item:
            duplicate
        };
      }

      const item =
        menuEngine
          .createMenuItem(
            recipeId,
            {
              portionId,
              listPrice:
                opts.listPrice,
              channel:
                opts.channel ||
                'all',
              active:
                opts.active !==
                false,
              featured:
                !!opts.featured
            }
          );

      runtime.menu.push(
        item
      );

      return {
        ok:true,
        item
      };
    }
  );
}

function removeMenuItem(
  shopId,
  menuItemId
) {
  return mutate(
    shopId,
    runtime => {
      const index =
        runtime.menu
          .findIndex(
            item =>
              item.id ===
              menuItemId
          );

      if (index < 0) {
        return {
          ok:false,
          reason:
            '菜单项不存在'
        };
      }

      if (
        runtime.menu.length <=
        1
      ) {
        return {
          ok:false,
          reason:
            '至少保留一道菜品'
        };
      }

      const removed =
        runtime.menu
          .splice(
            index,
            1
          )[0];

      return {
        ok:true,
        item:
          removed
      };
    }
  );
}

function getAvailableRecipes(
  shopId,
  filters
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return [];
  }

  const existing =
    new Set(
      runtime.menu
        .map(
          item =>
            item.recipeId
        )
    );

  return (
    foodResearchSystem
      .getCatalog(
        filters ||
        {}
      )
      .filter(
        item =>
          item.unlocked &&
          !existing.has(
            item.id
          )
      )
  );
}

function getFoodResearchCatalog(
  filters
) {
  return (
    foodResearchSystem
      .getCatalog(
        filters ||
        {}
      )
  );
}

function startRecipeResearch(
  recipeId
) {
  return (
    foodResearchSystem
      .startResearch(
        recipeId
      )
  );
}

function getFoodResearchOverview() {
  return (
    foodResearchSystem
      .getOverview()
  );
}

`;

    source =
      source.slice(
        0,
        index
      ) +
      apiBlock +
      source.slice(
        index
      );
  }

  source =
    replaceOnce(
      source,
`  adjustMenuPrice,
  inventoryRows,`,
`  adjustMenuPrice,
  addMenuRecipe,
  removeMenuItem,
  getAvailableRecipes,
  getFoodResearchCatalog,
  startRecipeResearch,
  getFoodResearchOverview,
  inventoryRows,`,
      'operations food research exports'
    );

  write(
    rel,
    source
  );
}

function updateFoodIndex() {
  const rel =
    'src/food/index.js';

  write(
    rel,
`'use strict';

module.exports = {
  pack:
    require('./foodPackV10.js'),
  rules:
    require('./foodRulesV10.js'),
  recipes:
    require('./recipeEngineV10.js'),
  menu:
    require('./menuEngineV10.js'),
  database:
    require('./foodResearchDatabaseV0818.js'),
  research:
    require('./foodResearchSystemV0818.js')
};
`
  );
}

function updateMain() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const newGameFlow =
  require('./core/newGameFlowV0814.js');`,
`const newGameFlow =
  require('./core/newGameFlowV0814.js');

const foodResearchSystem =
  require('./food/foodResearchSystemV0818.js');`,
      'main food research require'
    );

  source =
    replaceOnce(
      source,
`const restoredFromSave =
  saveSystem.load();

newGameFlow`,
`const restoredFromSave =
  saveSystem.load();

foodResearchSystem
  .install();

runtime.foodResearch =
  foodResearchSystem;

newGameFlow`,
      'main food research install'
    );

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.17 装修设备施工数据库版启动成功',
      '城市餐饮经营小游戏 V0.8.18 菜品菜单研发数据库版启动成功'
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0818.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/renovationEquipmentDatabaseV0817.test.js',
    'tests/renovationEquipmentIntegrationV0817.test.js',
    'tests/updateInfrastructureV0817.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/renovationEquipmentDatabaseV0817.test.js',
    'tests/renovationEquipmentIntegrationV0817.test.js',
    'tests/updateInfrastructureV0817.test.js',
    'tests/foodResearchDatabaseV0818.test.js',
    'tests/foodResearchSystemV0818.test.js',
    'tests/foodMenuResearchIntegrationV0818.test.js',
    'tests/updateInfrastructureV0818.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0818'
    );

  write(
    rel,
    source
  );
}

// setup-android@v3 compatibility for the ephemeral GitHub runner only.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const binDir =
    path.join(
      latestDir,
      'bin'
    );

  const sdkmanager =
    path.join(
      binDir,
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.18] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const realSdkmanager =
    path.join(
      binDir,
      'sdkmanager.v0818-real'
    );

  if (
    !fs.existsSync(
      realSdkmanager
    )
  ) {
    fs.renameSync(
      sdkmanager,
      realSdkmanager
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0818-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.18] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.18 package version finalize failed'
    );
  }

  for (
    const rel
    of [
      'src/food/foodResearchDatabaseV0818.js',
      'src/food/foodResearchSystemV0818.js',
      'tests/foodResearchDatabaseV0818.test.js',
      'tests/foodResearchSystemV0818.test.js',
      'tests/foodMenuResearchIntegrationV0818.test.js',
      'tests/updateInfrastructureV0818.test.js'
    ]
  ) {
    if (
      !fs.existsSync(
        abs(rel)
      )
    ) {
      throw new Error(
        'V0.8.18 required file missing: ' +
        rel
      );
    }
  }

  const operations =
    read(
      'src/operations/operationsStoreV080.js'
    );

  for (
    const marker
    of [
      'foodResearchDatabaseV0818.js',
      'foodResearchSystemV0818.js',
      'function addMenuRecipe(',
      'function removeMenuItem(',
      'function getAvailableRecipes(',
      'function startRecipeResearch('
    ]
  ) {
    if (
      !operations.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.18 operations validation missing ' +
        marker
      );
    }
  }

  const main =
    read(
      'src/main.js'
    );

  if (
    !main.includes(
      "require('./food/foodResearchSystemV0818.js')"
    ) ||
    !main.includes(
      '.install();'
    )
  ) {
    throw new Error(
      'V0.8.18 main research boot missing'
    );
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/foodResearchDatabaseV0818.test.js',
      'tests/foodResearchSystemV0818.test.js',
      'tests/foodMenuResearchIntegrationV0818.test.js',
      'tests/updateInfrastructureV0818.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.18 runner validation missing ' +
        marker
      );
    }
  }
}

updatePackage();
updatePackageLock();
updateOperationsStore();
updateFoodIndex();
updateMain();
updateRunner();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.18] PASS：菜品 / 菜单 / 研发数据库统一完成'
);
