'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.44';
const TARGET_VERSION = '0.8.45';

function readJson(relative) {
  return JSON.parse(fs.readFileSync(path.join(ROOT, relative), 'utf8'));
}

function writeJson(relative, value) {
  fs.writeFileSync(
    path.join(ROOT, relative),
    JSON.stringify(value, null, 2) + '\n',
    'utf8'
  );
}

function requireToken(relative, token) {
  const source = fs.readFileSync(path.join(ROOT, relative), 'utf8');
  if (!source.includes(token)) {
    throw new Error('V0.8.45补丁文件校验失败：' + relative + ' 缺少 ' + token);
  }
}

const pkg = readJson('package.json');

if (pkg.version !== BASE_VERSION && pkg.version !== TARGET_VERSION) {
  throw new Error(
    'V0.8.45补丁基线不匹配：当前为 ' +
      pkg.version +
      '，要求 ' +
      BASE_VERSION
  );
}

requireToken('src/scenes/renovationScene.js', 'V0845_AREA_TRUTH_RENOVATION_UI');
requireToken('src/scenes/renovationScene.js', 'handleTouchMove(');
requireToken('src/renovation/renovationSystem.js', 'calculateFloorArea(');
requireToken('src/main.js', 'api.onTouchMove');
requireToken('scripts/run-ci-tests-v060.js', 'tests/renovationAreaV0845.test.js');

pkg.version = TARGET_VERSION;
writeJson('package.json', pkg);

const lock = readJson('package-lock.json');
lock.version = TARGET_VERSION;

if (lock.packages && lock.packages['']) {
  lock.packages[''].version = TARGET_VERSION;
}

writeJson('package-lock.json', lock);

console.log('V0.8.45装修面积与交互修复安装完成');
