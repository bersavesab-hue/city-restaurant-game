'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.50';
const TARGET_VERSION = '0.8.51';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0851] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0851] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* 1) 新店默认加入目标统计。旧存档缺少字段也能通过 Number(undefined)||0 安全工作。 */
replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`        totalRevenue:0,
        totalProfit:0
      }`,
`        totalRevenue:0,
        totalProfit:0,
        goalsCompleted:0,
        goalsMissed:0,
        goalStreak:0,
        bestGoalStreak:0
      }`,
  'goal metrics defaults'
);

/* 2) 营业日目标生成与判定。 */
replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`function buildReasons(
  financial,
  active,
  endSnapshot,
  extra
) {`,
`function buildDailyGoal(
  state
) {
  const previous =
    state.history.find(
      item =>
        item &&
        item.status ===
          'closed' &&
        item.financial &&
        typeof item.financial ===
          'object'
    ) ||
    null;

  if (!previous) {
    return {
      id:'first_order',
      kind:'orders_at_least',
      label:'拿下今天第一笔有效订单',
      target:1,
      routeId:'shop',
      sourceDay:null,
      status:'active'
    };
  }

  const financial =
    previous.financial ||
    {};

  const end =
    previous.endSnapshot ||
    {};

  if (
    Number(
      financial.orders
    ) <=
    0
  ) {
    return {
      id:'recover_orders',
      kind:'orders_at_least',
      label:'今天至少完成1笔有效订单',
      target:1,
      routeId:'shop',
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      end.tensionScore
    ) >=
    90
  ) {
    return {
      id:'cash_relief',
      kind:'tension_at_most',
      label:'把现金压力降到90以下',
      target:89,
      routeId:'business',
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      end.inventoryAlerts
    ) >
    0
  ) {
    return {
      id:'clear_inventory_alerts',
      kind:'inventory_alerts_at_most',
      label:'把库存预警清零',
      target:0,
      routeId:'supply',
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      financial.foodCostRate
    ) >
    42
  ) {
    return {
      id:'food_cost_control',
      kind:'food_cost_at_most',
      label:'把食材成本率压到42%以内',
      target:42,
      routeId:'research',
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      financial.profit
    ) <=
    0
  ) {
    return {
      id:'profit_turnaround',
      kind:'profit_at_least',
      label:'让今天净利润转正',
      target:1,
      routeId:'business',
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  if (
    Number(
      end.rating
    ) >
      0 &&
    Number(
      end.rating
    ) <
      3.8
  ) {
    return {
      id:'rating_recovery',
      kind:'rating_at_least',
      label:'把门店评分提升到3.8以上',
      target:3.8,
      routeId:'business',
      sourceDay:
        previous.day,
      status:'active'
    };
  }

  return {
    id:'profit_growth',
    kind:'profit_at_least',
    label:'今天净利润比昨日提升5%',
    target:
      Math.max(
        1,
        round(
          Number(
            financial.profit
          ) *
          1.05
        )
      ),
    baselineValue:
      round(
        financial.profit
      ),
    routeId:'shop',
    sourceDay:
      previous.day,
    status:'active'
  };
}

function evaluateDailyGoal(
  goal,
  financial,
  endSnapshot
) {
  if (
    !goal ||
    typeof goal !==
      'object'
  ) {
    return null;
  }

  let actual = 0;
  let completed = false;

  if (
    goal.kind ===
      'orders_at_least'
  ) {
    actual =
      Math.max(
        0,
        Number(
          financial.orders
        ) ||
        0
      );

    completed =
      actual >=
      Number(
        goal.target
      );
  } else if (
    goal.kind ===
      'profit_at_least'
  ) {
    actual =
      round(
        financial.profit
      );

    completed =
      actual >=
      Number(
        goal.target
      );
  } else if (
    goal.kind ===
      'food_cost_at_most'
  ) {
    actual =
      round(
        financial.foodCostRate
      );

    completed =
      Number(
        financial.orders
      ) >
        0 &&
      actual <=
        Number(
          goal.target
        );
  } else if (
    goal.kind ===
      'inventory_alerts_at_most'
  ) {
    actual =
      Math.max(
        0,
        Number(
          endSnapshot.inventoryAlerts
        ) ||
        0
      );

    completed =
      actual <=
      Number(
        goal.target
      );
  } else if (
    goal.kind ===
      'tension_at_most'
  ) {
    actual =
      round(
        endSnapshot.tensionScore
      );

    completed =
      actual <=
      Number(
        goal.target
      );
  } else if (
    goal.kind ===
      'rating_at_least'
  ) {
    actual =
      round(
        endSnapshot.rating
      );

    completed =
      actual >=
      Number(
        goal.target
      );
  }

  return {
    ...clone(
      goal
    ),
    status:
      completed
        ? 'completed'
        : 'missed',
    completed,
    actual,
    message:
      completed
        ? '今日目标完成'
        : '今日目标未完成'
  };
}

function buildReasons(
  financial,
  active,
  endSnapshot,
  extra
) {`,
  'daily goal functions'
);

/* 3) 每次新营业日生成目标。 */
replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  state.active = {
    id:`,
`  const dailyGoal =
    buildDailyGoal(
      state
    );

  state.active = {
    id:`,
  'build goal before active day'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`    baseline:
      normalizeSnapshot(
        baseline
      ),
    visits:{`,
`    baseline:
      normalizeSnapshot(
        baseline
      ),
    goal:
      clone(
        dailyGoal
      ),
    visits:{`,
  'store goal on active day'
);

/* 4) 日结判定目标，并保存到每日复盘。 */
replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  const reasons =
    buildReasons(
      financial,
      active,
      endSnapshot,
      extra
    );

  const brief = {`,
`  const reasons =
    buildReasons(
      financial,
      active,
      endSnapshot,
      extra
    );

  const goalResult =
    evaluateDailyGoal(
      active.goal,
      financial,
      endSnapshot
    );

  const brief = {`,
  'evaluate goal at close'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`    financial,
    deltas:{`,
`    financial,
    goal:
      clone(
        active.goal
      ),
    goalResult:
      clone(
        goalResult
      ),
    deltas:{`,
  'persist goal result'
);

/* 5) 完成/失败、当前连胜、历史最佳连胜。 */
replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`  state.metrics.totalRevenue =
    round(`,
`  if (goalResult) {
    if (
      goalResult.completed
    ) {
      state.metrics
        .goalsCompleted =
        (
          Number(
            state.metrics
              .goalsCompleted
          ) ||
          0
        ) +
        1;

      state.metrics
        .goalStreak =
        (
          Number(
            state.metrics
              .goalStreak
          ) ||
          0
        ) +
        1;

      state.metrics
        .bestGoalStreak =
        Math.max(
          Number(
            state.metrics
              .bestGoalStreak
          ) ||
          0,
          state.metrics
            .goalStreak
        );
    } else {
      state.metrics
        .goalsMissed =
        (
          Number(
            state.metrics
              .goalsMissed
          ) ||
          0
        ) +
        1;

      state.metrics
        .goalStreak =
        0;
    }
  }

  state.metrics.totalRevenue =
    round(`,
  'goal streak metrics'
);

/* 6) brief 暴露目标统计，UI和未来成就系统可直接复用。 */
replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`      active:
        clone(
          state.active
        ),
      latestClosed:`,
`      active:
        clone(
          state.active
        ),
      metrics:
        clone(
          state.metrics
        ),
      latestClosed:`,
  'open brief metrics'
);

replaceExact(
  'src/operations/dailyOperatingCycleV0840.js',
`    active:null,
    latestClosed:`,
`    active:null,
    metrics:
      clone(
        state.metrics
      ),
    latestClosed:`,
  'closed brief metrics'
);

/* 7) 营业日控制卡直接显示今天目标/昨日目标结果。 */
replaceExact(
  'src/scenes/businessScene.js',
`    ui.text(
      ctx,
      shop.status ===
        'trial_opening'
        ? '试营业中 · 顾客订单、营业额和成本会实时计入今日经营'
        : shop.status ===
            'open'
          ? '营业数据、决策和诊断会在日结时统一结算'
          : '完成开店筹备后即可进入试营业',
      28,
      207,
      6.5,
      '#71858F',
      '600'
    );`,
`    const goalStreak =
      cycle &&
      cycle.metrics
        ? Number(
            cycle.metrics
              .goalStreak
          ) ||
          0
        : 0;

    const goalLine =
      active &&
      active.goal
        ? '今日目标：' +
          active.goal.label +
          (
            goalStreak >
              0
              ? ' · 连续' +
                goalStreak +
                '天'
              : ''
          )
        : latest &&
          latest.goalResult
          ? (
              latest
                .goalResult
                .completed
                ? '上次目标完成：'
                : '上次目标未完成：'
            ) +
            latest
              .goalResult
              .label
          : shop.status ===
              'trial_opening'
            ? '试营业中 · 顾客订单、营业额和成本会实时计入今日经营'
            : shop.status ===
                'open'
              ? '营业数据、决策和诊断会在日结时统一结算'
              : '完成开店筹备后即可进入试营业';

    ui.text(
      ctx,
      goalLine,
      28,
      207,
      6.5,
      active &&
      active.goal
        ? '#C08824'
        : latest &&
          latest.goalResult
          ? latest
              .goalResult
              .completed
              ? '#248B63'
              : '#C85242'
          : '#71858F',
      active &&
      active.goal
        ? '800'
        : '600'
    );`,
  'render daily goal'
);

/* 8) 开始营业与日结即时反馈。 */
replaceExact(
  'src/scenes/businessScene.js',
`        opUi.toast(
          result.ok
            ? result.existing
              ? '本营业日已经开始'
              : '营业日已开始'
            : result.reason ||
              '无法开始营业日'
        );`,
`        opUi.toast(
          result.ok
            ? result.existing
              ? '本营业日已经开始'
              : result.day &&
                result.day.goal
                ? '营业日已开始 · ' +
                  result.day
                    .goal
                    .label
                : '营业日已开始'
            : result.reason ||
              '无法开始营业日'
        );`,
  'start goal toast'
);

replaceExact(
  'src/scenes/businessScene.js',
`          opUi.toast(
            result.ok
              ? '日结完成，经营复盘已生成'
              : result.reason ||
                '无法完成日结'
          );`,
`          opUi.toast(
            result.ok
              ? result.dailyBrief &&
                result.dailyBrief
                  .goalResult
                ? result.dailyBrief
                    .goalResult
                    .completed
                  ? '日结完成 · 今日目标达成'
                  : '日结完成 · 今日目标未达成'
                : '日结完成，经营复盘已生成'
              : result.reason ||
                '无法完成日结'
          );`,
  'close goal toast'
);

/* 9) 现有集成测试覆盖目标开始、完成与连胜。 */
replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`const opened=operations.startOperatingDay('shop_v0843_integration');
assert.ok(opened.ok);`,
`const opened=operations.startOperatingDay('shop_v0843_integration');
assert.ok(opened.ok);
assert.ok(
  opened.day &&
  opened.day.goal,
  '营业日开始时必须生成今日目标'
);
assert.equal(
  opened.day.goal.id,
  'first_order'
);`,
  'goal start integration test'
);

replaceExact(
  'tests/operatingDayIntegrationV0843.test.js',
`assert.ok(closed.dailyBrief,'日结必须返回统一复盘');`,
`assert.ok(closed.dailyBrief,'日结必须返回统一复盘');
assert.ok(
  closed.dailyBrief.goalResult,
  '日结必须结算今日目标'
);
assert.equal(
  closed.dailyBrief.goalResult.completed,
  true,
  '完成首单后首日目标必须达成'
);
assert.ok(
  operations
    .operatingDaySnapshot(
      'shop_v0843_integration'
    )
    .metrics
    .goalStreak >=
    1,
  '完成目标后必须形成连续完成记录'
);`,
  'goal close integration test'
);

/* 10) UI接线测试防止目标展示被未来改丢。 */
replaceExact(
  'tests/businessDayUiV0844.test.js',
`    'closedHistory'
  ),`,
`    'closedHistory'
  ) &&
  businessSource.includes(
    '今日目标：'
  ) &&
  businessSource.includes(
    'goalResult'
  ) &&
  businessSource.includes(
    'goalStreak'
  ),`,
  'goal UI assertions'
);

/* 11) 版本同步。 */
updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 850
        versionName '0.8.50'`,
`        versionCode 851
        versionName '0.8.51'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.50 旧存档运行时修复版启动成功'",
  "'城市餐饮经营小游戏 V0.8.51 每日经营目标版启动成功'",
  'startup banner'
);

const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0851] 每日经营目标闭环完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
