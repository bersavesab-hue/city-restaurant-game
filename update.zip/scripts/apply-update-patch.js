'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const MAIN_REL = 'src/main.js';
const MAIN_BACKUP_REL = '.v095-backup/main.js';
const PACKAGE_BACKUP_REL = '.v095-backup/package.json';
const STATE_REL = 'scripts/.v095-test-state.json';
const RUNNER_CMD = 'node scripts/v095-adaptive-test-runner.js';

function say(msg) {
  process.stdout.write(`[V0.9.5 installer] ${msg}\n`);
}

function must(relative) {
  const full = path.join(ROOT, relative);
  if (!fs.existsSync(full)) throw new Error(`required file missing: ${relative}`);
  return full;
}

function restoreOnFailure(mainPath, pkgPath, mainBytes, pkgBytes) {
  try { fs.writeFileSync(mainPath, mainBytes); } catch (_) {}
  try { fs.writeFileSync(pkgPath, pkgBytes); } catch (_) {}
}

function main() {
  const mainPath = must(MAIN_REL);
  const pkgPath = must('package.json');
  must('scripts/v095-perf-lib.js');
  must('scripts/v095-adaptive-test-runner.js');

  const originalMainBytes = fs.readFileSync(mainPath);
  const originalPackageBytes = fs.readFileSync(pkgPath);
  const pkg = JSON.parse(originalPackageBytes.toString('utf8'));

  if (!pkg.scripts || typeof pkg.scripts.test !== 'string' || !pkg.scripts.test.trim()) {
    throw new Error('package.json scripts.test missing; refusing to bypass repository tests');
  }
  if (pkg.scripts.test.includes('v095-adaptive-test-runner')) {
    throw new Error('V0.9.5 adaptive runner already installed unexpectedly');
  }

  const state = {
    version: '0.9.5',
    mainPath: MAIN_REL,
    mainBackupPath: MAIN_BACKUP_REL,
    packageBackupPath: PACKAGE_BACKUP_REL,
    originalPretest: typeof pkg.scripts.pretest === 'string' ? pkg.scripts.pretest : '',
    originalTest: pkg.scripts.test,
    originalPosttest: typeof pkg.scripts.posttest === 'string' ? pkg.scripts.posttest : ''
  };

  const backupDir = path.join(ROOT, '.v095-backup');
  fs.mkdirSync(backupDir, { recursive: true });
  fs.writeFileSync(path.join(ROOT, MAIN_BACKUP_REL), originalMainBytes);
  fs.writeFileSync(path.join(ROOT, PACKAGE_BACKUP_REL), originalPackageBytes);

  try {
    fs.writeFileSync(
      path.join(ROOT, STATE_REL),
      JSON.stringify(state, null, 2) + '\n',
      'utf8'
    );

    // 不在 installer 阶段修改 main.js。
    // 这样原 pretest 会先且只在仓库原 baseline 上执行一次，避免生成器/修复器被重复运行。
    delete pkg.scripts.pretest;
    delete pkg.scripts.posttest;
    pkg.scripts.test = RUNNER_CMD;
    fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');
  } catch (error) {
    restoreOnFailure(mainPath, pkgPath, originalMainBytes, originalPackageBytes);
    throw error;
  }

  say('已安装单次 pretest 的自适应倍速优化。');
  say('原 pretest 只执行一次，然后在同一准备态上验证 full -> throttle -> resolution -> baseline。');
  say('最终 package.json 会恢复为 pretest 执行后的仓库状态，不保留临时 runner。');
}

main();
