'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function read(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

function write(rel, content) {
  fs.writeFileSync(path.join(ROOT, rel), content, 'utf8');
}

function replaceOnce(source, oldText, newText, label) {
  const count = source.split(oldText).length - 1;

  if (count !== 1) {
    throw new Error(
      label + ' anchor mismatch: expected 1, got ' + count
    );
  }

  return source.replace(oldText, newText);
}

const pkg = JSON.parse(read('package.json'));

if (pkg.version === '0.8.62') {
  const sceneNow = read('src/scenes/renovationScene.js');

  if (sceneNow.includes('V0862_PRO_RENOVATION_EDITOR_INSTALL')) {
    console.log('V0.8.62 renovation editor already applied');
    process.exit(0);
  }
}

if (pkg.version !== '0.8.61') {
  throw new Error(
    'V0.8.62 patch expects base version 0.8.61, current=' +
      pkg.version
  );
}

let scene = read('src/scenes/renovationScene.js');

if (!scene.includes('V0850_FINAL_RENOVATION_MOBILE_FIX')) {
  throw new Error('V0.8.62 requires the V0.8.50 renovation mobile baseline');
}

if (!scene.includes('V0862_PRO_RENOVATION_EDITOR_INSTALL')) {
  const exportAnchor =
`}

module.exports =
  new RenovationScene();
`;

  const installBlock =
`}

// V0862_PRO_RENOVATION_EDITOR_INSTALL
// Real placement editor: drag / rotate / duplicate / delete furniture while
// preserving the existing renovation calculation, history and construction flow.
require('../renovation/renovationEditorV0862.js').install({
  RenovationScene,
  renovationSystem,
  renovationConfig,
  floorGeometrySystem,
  saveSystem,
  runtime,
  ui,
  COLORS,
  V45_HALL_STYLE_VISUAL
});

module.exports =
  new RenovationScene();
`;

  scene = replaceOnce(
    scene,
    exportAnchor,
    installBlock,
    'renovation editor installer'
  );

  write('src/scenes/renovationScene.js', scene);
}

let runner = read('scripts/run-ci-tests-v060.js');

if (!runner.includes('tests/renovationEditorV0862.test.js')) {
  runner = replaceOnce(
    runner,
    "    'tests/renovationFinalFixV0850.test.js',\n",
    "    'tests/renovationFinalFixV0850.test.js',\n" +
      "    'tests/renovationEditorV0862.test.js',\n",
    'test runner'
  );

  write('scripts/run-ci-tests-v060.js', runner);
}

pkg.version = '0.8.62';
write('package.json', JSON.stringify(pkg, null, 2) + '\n');

const lock = JSON.parse(read('package-lock.json'));
lock.version = '0.8.62';

if (lock.packages && lock.packages['']) {
  lock.packages[''].version = '0.8.62';
}

write('package-lock.json', JSON.stringify(lock, null, 2) + '\n');

let gradle = read('android/app/build.gradle');

gradle = gradle.replace(
  /versionCode\s+\d+/,
  'versionCode 862'
);

gradle = gradle.replace(
  /versionName\s+'[^']+'/,
  "versionName '0.8.62'"
);

write('android/app/build.gradle', gradle);

let main = read('src/main.js');

main = main.replace(
  /城市餐饮经营小游戏 V0\.8\.61 [^']*启动成功/,
  '城市餐饮经营小游戏 V0.8.62 装修专业编辑器版启动成功'
);

write('src/main.js', main);

for (const required of [
  'src/renovation/renovationEditorV0862.js',
  'tests/renovationEditorV0862.test.js',
  'PATCH_MANIFEST_V0862.json'
]) {
  if (!fs.existsSync(path.join(ROOT, required))) {
    throw new Error('V0.8.62 package missing ' + required);
  }
}

const sceneCheck = read('src/scenes/renovationScene.js');
const editorCheck = read('src/renovation/renovationEditorV0862.js');

for (const token of [
  'V0862_PRO_RENOVATION_EDITOR_INSTALL',
  'V0850_FINAL_RENOVATION_MOBILE_FIX',
  '拖动黄点/虚线调面积',
  '客流 ×',
  '客单 ×',
  '服务 ×'
]) {
  if (!sceneCheck.includes(token)) {
    throw new Error('renovation compatibility token missing: ' + token);
  }
}

for (const token of [
  'V0862_PRO_RENOVATION_EDITOR',
  'editorPlacements',
  "'editor:add:'",
  'editor:rotate',
  'editor:duplicate',
  'editor:delete',
  'nearestFreeSlot',
  'safeDecorPoint'
]) {
  if (!editorCheck.includes(token)) {
    throw new Error('renovation editor capability missing: ' + token);
  }
}

console.log('V0.8.62 professional renovation editor patch applied');
