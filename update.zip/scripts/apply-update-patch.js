'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.64';
const TARGET_VERSION = '0.8.65';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0865] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));

if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0865] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/*
 * 致命启动修复：
 * DATA_HUB 路由把 property 页面注册成了未定义变量 shopScene。
 * 实际已经引入的旧找铺场景变量是 propertyMarketScene。
 */
replaceExact(
  'src/main.js',
`sceneManager.register(
  'property',
  shopScene
);`,
`sceneManager.register(
  'property',
  propertyMarketScene
);`,
  'property route startup crash'
);

/*
 * 把真正执行 Android 入口的冒烟测试加入 pretest。
 * 以后 undefined variable 这类“测试全绿、APK能构建、真机才崩”的错误
 * 必须在合并前失败。
 */
updateJson(
  'package.json',
  pkg => {
    pkg.version = TARGET_VERSION;

    const smoke =
      'node tests/androidStartupSmoke.test.js';

    const pretest =
      String(
        pkg.scripts &&
        pkg.scripts.pretest ||
        ''
      );

    if (!pretest.includes(smoke)) {
      pkg.scripts =
        pkg.scripts ||
        {};

      pkg.scripts.pretest =
        pretest
          ? pretest +
            ' && ' +
            smoke
          : smoke;
    }
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version = TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'scripts/v60-audit.js',
`assert.equal(pkg.scripts.test, 'node scripts/run-ci-tests-v060.js');
assert.equal(pkg.scripts['build:android-js'], 'node scripts/build-android-js-v060.js');`,
`assert.equal(pkg.scripts.test, 'node scripts/run-ci-tests-v060.js');
assert.equal(pkg.scripts['build:android-js'], 'node scripts/build-android-js-v060.js');
assert.ok(
  String(pkg.scripts.pretest || '').includes(
    'node tests/androidStartupSmoke.test.js'
  ),
  '必须保留 Android 启动冒烟测试，防止真机启动级回归'
);`,
  'audit startup smoke protection'
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 864
        versionName '0.8.64'`,
`        versionCode 865
        versionName '0.8.65'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.64 真实空间装修体验版启动成功'",
  "'城市餐饮经营小游戏 V0.8.65 启动热修复版启动成功'",
  'startup banner'
);

const genericManifest = fp('PATCH_MANIFEST.json');

if (fs.existsSync(genericManifest)) {
  fs.rmSync(genericManifest, { force:true });
}

console.log(
  '[V0865-STARTUP-HOTFIX] fixed undefined shopScene and enabled real Android startup smoke test'
);
