'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const BASES = new Set(['0.8.49','0.8.50']);
const TARGET = '0.8.50';
const OPS = 'src/operations/operationsStoreV080.js';
const BUSINESS = 'src/scenes/businessScene.js';
const RESEARCH = 'src/scenes/researchScene.js';
const PRESTIGE = 'src/reputation/culinaryPrestigeSystemV085.js';
const MAIN = 'src/main.js';
const GRADLE = 'android/app/build.gradle';
const OPS_MARK = 'V085_CULINARY_PRESTIGE_BRIDGE';
const BIZ_MARK = 'V085_RANKING_BRIDGE';

function abs(rel){return path.join(ROOT,rel);}
function read(rel){return fs.readFileSync(abs(rel),'utf8');}
function write(rel,text){fs.writeFileSync(abs(rel),text,'utf8');}
function exists(rel){return fs.existsSync(abs(rel));}
function syntax(rel){const r=cp.spawnSync(process.execPath,['--check',abs(rel)],{cwd:ROOT,encoding:'utf8'});if(r.status!==0){process.stderr.write(r.stdout||'');process.stderr.write(r.stderr||'');throw new Error('语法检查失败：'+rel);}}
function appendOnce(rel,mark,block){const before=read(rel);if(before.includes(mark))return false;write(rel,before+'\n\n'+block.trim()+'\n');try{syntax(rel);}catch(e){write(rel,before);throw e;}return true;}
function readJson(rel){return JSON.parse(read(rel));}
function writeJson(rel,obj){write(rel,JSON.stringify(obj,null,2)+'\n');}

for(const rel of [OPS,BUSINESS,RESEARCH,PRESTIGE,MAIN,GRADLE])if(!exists(rel))throw new Error('V0.8.50缺少必需文件：'+rel);

const opsBridge = String.raw`
/* ${OPS_MARK} */
const __v085Prestige = require('../reputation/culinaryPrestigeSystemV085.js');

function __v085Context(shopId, runtime) {
  const costs = {};
  for (const item of (runtime && runtime.menu) || []) {
    try { costs[item.id] = estimateMenuItemCost(shopId, item); } catch (_) { costs[item.id] = 0; }
  }
  let finance = null;
  let reputation = null;
  try { finance = settlementEngine.summary(runtime.ledger); } catch (_) {}
  try { reputation = reputationSnapshot(shopId); } catch (_) {}
  return {
    costByItem: costs,
    profitRate: finance && Number(finance.profitRate) || 0,
    reputation
  };
}

function __v085Sync(shopId) {
  const runtime = getRuntime(shopId);
  if (!runtime) return null;
  return __v085Prestige.overview(shopId, runtime, __v085Context(shopId, runtime));
}

module.exports.culinaryPrestigeSnapshot = function culinaryPrestigeSnapshotV085(shopId) {
  return __v085Sync(shopId);
};

module.exports.improveCulinaryDish = function improveCulinaryDishV085(shopId, menuItemId, actionId) {
  const runtime = getRuntime(shopId);
  if (!runtime) return { ok:false, reason:'门店不存在' };
  const item = (runtime.menu || []).find(x => x.id === menuItemId);
  if (!item) return { ok:false, reason:'菜品不存在' };
  const costEstimate = estimateMenuItemCost(shopId, item);
  const plan = __v085Prestige.improvementPlan(shopId, item, actionId, costEstimate);
  if (!plan.ok) return plan;
  const spend = recordFinanceExpense(shopId, '菜品研发改良', plan.cost, {
    note: item.name + ' · ' + plan.action.name,
    referenceId: 'culinary_improve:' + menuItemId + ':' + actionId
  });
  if (spend && spend.ok === false) return { ok:false, reason:spend.reason || '研发资金不足' };
  const result = __v085Prestige.applyImprovement(shopId, item, actionId, {
    paidCost: plan.cost,
    costEstimate
  });
  if (result.ok && runtime.shop) {
    const gain = Math.max(0, Number(result.after) - Number(result.before));
    runtime.shop.rating = Math.max(1, Math.min(5, (Number(runtime.shop.rating) || 4) + gain * 0.0015));
  }
  persist(shopId);
  return result;
};

module.exports.evaluateCulinaryAwards = function evaluateCulinaryAwardsV085(shopId) {
  const runtime = getRuntime(shopId);
  if (!runtime) return { ok:false, reason:'门店不存在' };
  const result = __v085Prestige.evaluateAwards(shopId, runtime, {
    context: __v085Context(shopId, runtime)
  });
  persist(shopId);
  return result;
};

module.exports.holdCulinaryAwardCeremony = function holdCulinaryAwardCeremonyV085(shopId) {
  const runtime = getRuntime(shopId);
  if (!runtime) return { ok:false, reason:'门店不存在' };
  const result = __v085Prestige.holdAwardCeremony(shopId, runtime);
  persist(shopId);
  return result;
};

module.exports.culinaryRanking = function culinaryRankingV085(shopId, options) {
  const runtime = getRuntime(shopId);
  if (!runtime) return null;
  let baseRows = [];
  try { baseRows = storeRankingSnapshot() || []; } catch (_) {}
  return __v085Prestige.buildRanking(shopId, runtime, {
    ...(options || {}),
    baseRows,
    context: __v085Context(shopId, runtime)
  });
};

const __v085OldCloseSafe = module.exports.closeOperatingDaySafe;
if (typeof __v085OldCloseSafe === 'function') {
  module.exports.closeOperatingDaySafe = function closeOperatingDaySafeV085(shopId, options) {
    const result = __v085OldCloseSafe(shopId, options);
    if (result && result.ok) __v085Sync(shopId);
    return result;
  };
}

const __v085OldManualReview = module.exports.recordManualReview;
if (typeof __v085OldManualReview === 'function') {
  module.exports.recordManualReview = function recordManualReviewV085(shopId, rating, text, options) {
    const result = __v085OldManualReview(shopId, rating, text, options);
    __v085Sync(shopId);
    return result;
  };
}
/* V085_CULINARY_PRESTIGE_BRIDGE_END */
`;

const bizBridge = String.raw`
/* ${BIZ_MARK} */
const __v085RankingSystem = require('../reputation/culinaryPrestigeSystemV085.js');
const __v085BusinessScene = module.exports;

if (__v085BusinessScene && !__v085BusinessScene.__v085RankingInstalled) {
  __v085BusinessScene.__v085RankingInstalled = true;
  __v085BusinessScene.rankCategory = __v085BusinessScene.rankCategory || 'overall';
  __v085BusinessScene.rankScope = __v085BusinessScene.rankScope || 'district';

  __v085BusinessScene.renderRanking = function renderRankingV085(ctx, shop) {
    const ranking = operations.culinaryRanking(shop.id, {
      category: this.rankCategory,
      scope: this.rankScope
    });
    this.sectionCard(ctx, 14, 138, 362, 474, '动态排行榜 · 多维竞争');
    ui.text(ctx, '不是一个总分：口碑、菜品、性价比、效率和创新分别竞争', 28, 168, 6.7, '#71858F', '600');

    opUi.pill(ctx, '商圈', 28, 184, 74, this.rankScope === 'district');
    opUi.pill(ctx, '城市', 108, 184, 74, this.rankScope === 'city');
    this.addButton('rankscope:district', 24, 180, 82, 34);
    this.addButton('rankscope:city', 104, 180, 82, 34);

    const cats = __v085RankingSystem.RANK_CATEGORIES;
    for (let i = 0; i < cats.length; i++) {
      const col = i % 4;
      const row = Math.floor(i / 4);
      const x = 28 + col * 82;
      const y = 222 + row * 34;
      opUi.pill(ctx, cats[i].name, x, y, 76, this.rankCategory === cats[i].id);
      this.addButton('rankcat:' + cats[i].id, x - 3, y - 3, 82, 34);
    }

    if (!ranking) {
      ui.text(ctx, '暂无可用排名数据', 195, 340, 9, '#71858F', '700', 'center');
      return;
    }

    const rows = ranking.rows || [];
    let y = 306;
    for (const row of rows.slice(0, 7)) {
      const mine = !!row.isPlayer;
      if (mine) ui.card(ctx, 22, y - 13, 346, 36, {radius:9,fill:'#FFF4C8',stroke:'#E5B64D',shadow:false});
      ui.text(ctx, '#' + row.rank, 30, y, 7.5, row.rank <= 3 ? '#D29A18' : '#748791', '800');
      ui.text(ctx, row.name + (mine ? '  [我的门店]' : ''), 66, y, 7.1, mine ? '#173D54' : '#3A5665', mine ? '800' : '700');
      ui.text(ctx, row.score.toFixed(1), 292, y, 7.4, mine ? '#C77D00' : '#173D54', '800', 'right');
      const trend = row.change > 0 ? '▲' + row.change : row.change < 0 ? '▼' + Math.abs(row.change) : '—';
      ui.text(ctx, trend, 350, y, 6.7, row.change > 0 ? '#248B63' : row.change < 0 ? '#C85242' : '#71858F', '700', 'right');
      y += 39;
    }

    const p = ranking.player;
    if (p && p.rank > 7) {
      ui.text(ctx, '我的门店当前 #' + p.rank + ' · ' + p.score.toFixed(1) + '分', 28, 586, 7.2, '#173D54', '800');
    } else if (p) {
      const gap = p.rank > 1 ? p.gapToPrev.toFixed(1) : '0';
      ui.text(ctx, '当前 #' + p.rank + ' · 距上一名 ' + gap + '分 · Top3门槛 ' + (ranking.thresholdTop3 == null ? '—' : ranking.thresholdTop3.toFixed(1)), 28, 586, 6.8, '#71858F', '700');
    }
  };

  const __v085OldHandleTap = __v085BusinessScene.handleTap;
  __v085BusinessScene.handleTap = function handleTapV085(x, y) {
    const target = this.hit(x, y);
    if (target && target.id && target.id.indexOf('rankcat:') === 0) {
      this.rankCategory = target.id.slice('rankcat:'.length);
      return true;
    }
    if (target && target.id && target.id.indexOf('rankscope:') === 0) {
      this.rankScope = target.id.slice('rankscope:'.length);
      return true;
    }
    return __v085OldHandleTap.call(this, x, y);
  };
}
/* V085_RANKING_BRIDGE_END */
`;

appendOnce(OPS, OPS_MARK, opsBridge);
appendOnce(BUSINESS, BIZ_MARK, bizBridge);

// Keep the visible boot version in sync without replacing the whole main file.
{
  const before = read(MAIN);
  let after = before
    .replace(/城市餐饮经营小游戏 V0\.8\.49[^'\n]*/g, '城市餐饮经营小游戏 V0.8.50 菜品研发与餐饮荣誉版启动成功')
    .replace(/城市餐饮经营小游戏 V0\.8\.50[^'\n]*/g, '城市餐饮经营小游戏 V0.8.50 菜品研发与餐饮荣誉版启动成功');
  if (after !== before) write(MAIN, after);
}

// Android package version must advance with the JS/package version.
{
  const before = read(GRADLE);
  let after = before.replace(/versionCode\s+\d+/, 'versionCode 850');
  after = after.replace(/versionName\s+['"][^'"]+['"]/, "versionName '0.8.50'");
  if (!/versionCode\s+850/.test(after) || !/versionName\s+['"]0\.8\.50['"]/.test(after)) {
    throw new Error('V0.8.50 Android版本号更新失败');
  }
  if (after !== before) write(GRADLE, after);
}

syntax(RESEARCH);
syntax(PRESTIGE);
syntax(MAIN);

if (exists('package.json')) {
  const pkg = readJson('package.json');
  if (!BASES.has(String(pkg.version))) throw new Error('V0.8.50基线不匹配：当前 package.json 为 '+pkg.version+'，要求 0.8.49');
  pkg.version = TARGET;
  writeJson('package.json',pkg);
}
if (exists('package-lock.json')) {
  const lock = readJson('package-lock.json');
  lock.version = TARGET;
  if (lock.packages && lock.packages['']) lock.packages[''].version = TARGET;
  writeJson('package-lock.json',lock);
}

console.log('V0.8.50 菜品研发改良 / 多维评分 / 动态排行 / 提名颁奖系统安装完成');
