'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname,'..');

function read(rel){
  return fs.readFileSync(path.join(ROOT,rel),'utf8');
}

function write(rel,value){
  fs.writeFileSync(path.join(ROOT,rel),value,'utf8');
}

function replaceOne(rel, oldText, newText, label){
  const source = read(rel);
  const count = source.split(oldText).length - 1;

  if(count !== 1){
    throw new Error(
      '[V0866] ' + label + ' anchor mismatch in ' + rel + ': ' + count
    );
  }

  write(rel,source.replace(oldText,newText));
  console.log('[V0866] patched:',label);
}

function replaceAll(rel, oldText, newText, label){
  const source=read(rel);
  const count=source.split(oldText).length-1;

  if(count < 1){
    throw new Error('[V0866] '+label+' anchor missing in '+rel);
  }

  write(rel,source.split(oldText).join(newText));
  console.log('[V0866] patched:',label,'x'+count);
}

const pkg = JSON.parse(read('package.json'));

if(pkg.version === '0.8.66'){
  console.log('[V0866] already applied');
  process.exit(0);
}

if(pkg.version !== '0.8.65'){
  throw new Error(
    '[V0866] base version mismatch: expected 0.8.65, got ' + pkg.version
  );
}

// Version metadata. package.json is changed incrementally here, never shipped
// directly inside update.zip.
pkg.version='0.8.66';
write('package.json',JSON.stringify(pkg,null,2)+'\n');

const lock=JSON.parse(read('package-lock.json'));
lock.version='0.8.66';
if(lock.packages&&lock.packages['']){
  lock.packages[''].version='0.8.66';
}
write('package-lock.json',JSON.stringify(lock,null,2)+'\n');
console.log('[V0866] patched: package versions');

replaceOne(
  'android/app/build.gradle',
  "        versionCode 865\n        versionName '0.8.65'",
  "        versionCode 866\n        versionName '0.8.66'",
  'Android version'
);

replaceOne(
  'src/main.js',
  "城市餐饮经营小游戏 V0.8.65 启动热修复版启动成功",
  "城市餐饮经营小游戏 V0.8.66 自由建墙装修版启动成功",
  'startup version label'
);

replaceOne(
  'src/main.js',
  `  if (
    sceneManager
      .getCurrentId() !==
    'newGame'
  ) {
    drawBottomNav();
  }`,
  `  if (
    sceneManager
      .getCurrentId() !==
    'newGame' &&
    sceneManager
      .getCurrentId() !==
    'renovation'
  ) {
    // V0866_IMMERSIVE_RENOVATION_NAV
    // Renovation is a full-screen editor. The global seven-item nav would
    // waste 60-64px of the most valuable editing space on mobile.
    drawBottomNav();
  }`,
  'hide global nav in renovation'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `// V0864_SPATIAL_VALIDATION_INTEGRATION
const renovationSpatial =
  require('./renovationSpatialV0864.js');`,
  `// V0866_FREE_BUILD_SPATIAL_INTEGRATION
const renovationSpatial =
  require('./renovationFreeBuildV0866.js');`,
  'free-build spatial model'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `      editorPlacements: [],
      privateRooms: []`,
  `      editorPlacements: [],

      // V0866_FREE_BUILD_FLOOR
      // Player-facing space is defined by walls/doors, not zone percentages.
      freeBuildVersion:
        1,

      editorWalls:
        [],

      editorDoors:
        [],

      privateRooms: []`,
  'new floor free-build fields'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `    const geometry =
      floorGeometrySystem
        .getFloorGeometry(
          shop,
          floorIndex,
          floor.area,
          plan.floors.length
        );

    const kitchenArea =`,
  `    const geometry =
      floorGeometrySystem
        .getFloorGeometry(
          shop,
          floorIndex,
          floor.area,
          plan.floors.length
        );

    const freeBuildActive =
      Number(
        floor.freeBuildVersion
      ) >= 1 ||
      Number(
        plan.freeBuildVersion
      ) >= 1;

    const kitchenArea =`,
  'free-build area mode flag'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `    const minimumDining =
      Math.max(
        config.zoneRules
          .minDiningAreaM2,
        floor.area *
        config.zoneRules
          .minDiningRatio
      );`,
  `    const minimumDining =
      freeBuildActive
        ? 0
        : Math.max(
            config.zoneRules
              .minDiningAreaM2,
            floor.area *
            config.zoneRules
              .minDiningRatio
          );`,
  'remove forced dining percentage'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `    if (
      diningArea + 0.01 <
      minimumDining
    ) {
      warnings.push(
        '堂食区低于最小面积'
      );
    }`,
  `    if (
      !freeBuildActive &&
      diningArea + 0.01 <
      minimumDining
    ) {
      warnings.push(
        '堂食区低于最小面积'
      );
    }`,
  'disable legacy zone warning in free-build'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `    if (remainingArea < -0.01) {
      warnings.push(
        '家具与包厢超出可摆面积'
      );
    }`,
  `    if (
      !freeBuildActive &&
      remainingArea < -0.01
    ) {
      warnings.push(
        '家具与包厢超出可摆面积'
      );
    }`,
  'disable legacy area cap in free-build'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `    if (
      tableArea > 0 &&
      (
        usableDiningSlots
      ).length <
      Object.keys(
        floor.tables
      ).reduce(
        (sum, key) =>
          sum +
          Number(
            floor.tables[key]
          ),
        0
      )
    ) {
      warnings.push(
        '可落位餐桌点不足'
      );
    }`,
  `    if (
      !freeBuildActive &&
      tableArea > 0 &&
      (
        usableDiningSlots
      ).length <
      Object.keys(
        floor.tables
      ).reduce(
        (sum, key) =>
          sum +
          Number(
            floor.tables[key]
          ),
        0
      )
    ) {
      warnings.push(
        '可落位餐桌点不足'
      );
    }`,
  'disable old slot limit in free-build'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `    const totalCost =
      Math.round(
        constructionBase +
        lightingCost +
        furnitureCost +
        roomCost +
        kitchenComplexity +
        decorCost
      );`,
  `    const partitionCost =
      plan.floors
        .reduce(
          (
            sum,
            floor
          ) => {
            const wallCost =
              (
                floor.editorWalls ||
                []
              )
                .reduce(
                  (
                    inner,
                    wall
                  ) =>
                    inner +
                    renovationSpatial
                      .wallLength(
                        wall
                      ) *
                    280,
                  0
                );

            const doorCost =
              (
                floor.editorDoors ||
                []
              ).length *
              980;

            return (
              sum +
              wallCost +
              doorCost
            );
          },
          0
        );

    const totalCost =
      Math.round(
        constructionBase +
        lightingCost +
        furnitureCost +
        roomCost +
        kitchenComplexity +
        decorCost +
        partitionCost
      );`,
  'wall and door construction cost'
);

replaceOne(
  'src/renovation/renovationSystem.js',
  `      decorCost:
        Math.round(
          decorCost
        ),`,
  `      decorCost:
        Math.round(
          decorCost
        ),

      partitionCost:
        Math.round(
          partitionCost
        ),`,
  'expose partition cost'
);

replaceOne(
  'src/scenes/renovationScene.js',
  `require('../renovation/renovationEditorV0864.js').install({
  RenovationScene,
  renovationSystem,
  renovationConfig,
  floorGeometrySystem,
  saveSystem,
  gameState,
  ui,
  COLORS
});

module.exports =`,
  `require('../renovation/renovationEditorV0864.js').install({
  RenovationScene,
  renovationSystem,
  renovationConfig,
  floorGeometrySystem,
  saveSystem,
  gameState,
  ui,
  COLORS
});

// V0866_IMMERSIVE_FREE_BUILD_EDITOR_INSTALL
require('../renovation/renovationEditorV0866.js').install({
  RenovationScene,
  renovationSystem,
  renovationConfig,
  floorGeometrySystem,
  saveSystem,
  gameState,
  ui,
  COLORS
});

module.exports =`,
  'install free-build editor'
);

replaceOne(
  'scripts/run-ci-tests-v060.js',
  `    'tests/renovationSpatialV0864.test.js',
    'tests/preparationCommandCenterV0861.test.js',`,
  `    'tests/renovationSpatialV0864.test.js',
    'tests/renovationFreeBuildV0866.test.js',
    'tests/renovationImmersiveEditorV0866.test.js',
    'tests/preparationCommandCenterV0861.test.js',`,
  'register V0866 renovation tests'
);

console.log('[V0866] one-click free-build renovation patch applied successfully');
