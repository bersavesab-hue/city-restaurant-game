'use strict';

const fs=require('fs');
const path=require('path');

const ROOT=path.resolve(__dirname,'..');
const BASE_VERSION='0.8.39';
const TARGET_VERSION='0.8.43';

function abs(rel){return path.join(ROOT,rel);}
function read(rel){return fs.readFileSync(abs(rel),'utf8');}
function write(rel,content){fs.writeFileSync(abs(rel),content,'utf8');}

function replaceOnce(source,from,to,label){
  if(source.includes(to))return source;
  const i=source.indexOf(from);
  if(i<0)throw new Error('V0.8.40-43 patch anchor missing: '+label);
  return source.slice(0,i)+to+source.slice(i+from.length);
}

function insertBefore(source,anchor,addition,marker,label){
  if(marker&&source.includes(marker))return source;
  const i=source.indexOf(anchor);
  if(i<0)throw new Error('V0.8.40-43 insertion anchor missing: '+label);
  return source.slice(0,i)+addition+source.slice(i);
}

function cleanupLegacyRootWorkflow(){
  if(fs.existsSync(abs('apply-update.yml')))fs.unlinkSync(abs('apply-update.yml'));
}

function updatePackage(){
  const pkg=JSON.parse(read('package.json'));
  if(pkg.version!==BASE_VERSION&&pkg.version!==TARGET_VERSION){
    throw new Error('V0.8.40-43 requires formal V0.8.39 baseline; current='+pkg.version);
  }
  pkg.version=TARGET_VERSION;
  write('package.json',JSON.stringify(pkg,null,2)+'\n');
}

function updatePackageLock(){
  const rel='package-lock.json';
  if(!fs.existsSync(abs(rel)))return;
  const lock=JSON.parse(read(rel));
  lock.version=TARGET_VERSION;
  if(lock.packages&&lock.packages[''])lock.packages[''].version=TARGET_VERSION;
  write(rel,JSON.stringify(lock,null,2)+'\n');
}

function updateOperationsStore(){
  const rel='src/operations/operationsStoreV080.js';
  let source=read(rel);

  source=replaceOnce(source,
`const economyBalanceGuard =
  require('../core/economyBalanceGuardV0839.js');

const customerRandomDatabase =`,
`const economyBalanceGuard =
  require('../core/economyBalanceGuardV0839.js');

const gameplayFlowCoordinator =
  require('../core/gameplayFlowCoordinatorV0836.js');

const dailyOperatingCycle =
  require('./dailyOperatingCycleV0840.js');

const decisionFeedback =
  require('./decisionFeedbackV0841.js');

const playtestHealth =
  require('../diagnostics/playtestHealthV0842.js');

const operatingBalanceTuner =
  require('../balance/operatingBalanceTunerV0843.js');

const customerRandomDatabase =`,
  'V0840-43 imports');

  const helpers=
`function decisionContextSnapshot(
  shopId,
  runtimeValue,
  dailyFinancial
) {
  const runtime =
    runtimeValue ||
    getRuntime(
      shopId
    );

  if (!runtime) {
    return {
      day:currentDay(),
      cash:
        Number(
          gameState
            .getPlayer()
            .cash
        ) || 0
    };
  }

  const live =
    liveOperations
      .snapshot(
        runtime,
        {
          staff:
            staffManagement
              .teamSnapshot(
                shopId,
                gameState
                  .getTime()
              )
        }
      );

  const finance =
    dailyFinancial ||
    settlementEngine
      .summary(
        runtime.ledger
      );

  const marketing =
    marketingPlatformMembership
      .overview(
        shopId,
        runtime
      );

  const balance =
    economyBalanceGuard
      .snapshot(
        shopId
      );

  return {
    day:
      Number(
        runtime.day
      ) || currentDay(),
    cash:
      Number(
        gameState
          .getPlayer()
          .cash
      ) || 0,
    revenue:
      Number(
        finance &&
        finance.revenue
      ) || 0,
    profit:
      Number(
        finance &&
        finance.profit
      ) || 0,
    orders:
      Number(
        finance &&
        finance.orders
      ) ||
      Number(
        live &&
        live.today &&
        live.today.orders
      ) || 0,
    customers:
      Number(
        finance &&
        finance.customers
      ) ||
      Number(
        live &&
        live.today &&
        live.today.customers
      ) || 0,
    rating:
      Number(
        runtime.shop &&
        runtime.shop.rating
      ) || 0,
    memberCount:
      Number(
        marketing &&
        marketing.memberCount
      ) || 0,
    inventoryAlerts:
      live &&
      live.inventory &&
      Array.isArray(
        live.inventory.alerts
      )
        ? live.inventory.alerts.length
        : 0,
    staffCount:
      live &&
      live.staff
        ? Number(
            live.staff.headcount
          ) || 0
        : 0,
    tensionScore:
      Number(
        balance &&
        balance.tensionScore
      ) || 0
  };
}

function recordTrackedDecision(
  shopId,
  type,
  payload,
  baseline
) {
  const runtime =
    getRuntime(
      shopId
    );

  const day =
    runtime
      ? Number(
          runtime.day
        ) || currentDay()
      : currentDay();

  const row =
    decisionFeedback
      .record(
        shopId,
        day,
        type,
        payload || {},
        baseline ||
        decisionContextSnapshot(
          shopId,
          runtime
        )
      );

  dailyOperatingCycle
    .recordDecisionRef(
      shopId,
      day,
      row.id,
      type
    );

  return row;
}

function playtestContextSnapshot(
  shopId,
  runtimeValue
) {
  const runtime =
    runtimeValue ||
    getRuntime(
      shopId
    );

  const live =
    runtime
      ? liveOperations
          .snapshot(
            runtime,
            {
              staff:
                staffManagement
                  .teamSnapshot(
                    shopId,
                    gameState
                      .getTime()
                  )
            }
          )
      : null;

  const balance =
    economyBalanceGuard
      .snapshot(
        shopId
      );

  const credit =
    completeFinanceSystem
      .openingCreditStatus(
        shopId
      );

  const regulatory =
    regulatoryFoodSafetySystem
      .overview(
        shopId
      );

  const shop =
    getShop(
      shopId
    );

  return {
    runtimeExists:
      !!runtime,
    activeMenuCount:
      live &&
      live.menu
        ? Number(
            live.menu.active
          ) || 0
        : 0,
    featuredMissing:
      !!(
        live &&
        live.menu &&
        !live.menu.featured
      ),
    staffCount:
      live &&
      live.staff
        ? Number(
            live.staff.headcount
          ) || 0
        : 0,
    inventoryAlerts:
      live &&
      live.inventory &&
      Array.isArray(
        live.inventory.alerts
      )
        ? live.inventory.alerts.length
        : 0,
    cash:
      Number(
        gameState
          .getPlayer()
          .cash
      ) || 0,
    creditAvailable:
      !!(
        credit &&
        credit.offer &&
        credit.offer.available !== false &&
        Number(
          credit.offer.creditLimit
        ) > 0
      ),
    tensionScore:
      Number(
        balance &&
        balance.tensionScore
      ) || 0,
    openViolations:
      regulatory &&
      Array.isArray(
        regulatory.openViolations
      )
        ? regulatory.openViolations.length
        : 0,
    flowDiagnosis:
      gameplayFlowCoordinator
        .diagnose(),
    dayCycleDiagnosis:
      dailyOperatingCycle
        .diagnose(
          shopId
        ),
    todayOrders:
      live &&
      live.today
        ? Number(
            live.today.orders
          ) || 0
        : 0,
    runtimeDay:
      runtime
        ? Number(
            runtime.day
          ) || 1
        : 1,
    shopOpen:
      !!(
        shop &&
        [
          'open',
          'formal_open',
          'trial_opening'
        ].includes(
          shop.status
        )
      )
  };
}

`;

  source=insertBefore(
    source,
    'function setMenuActive(\n',
    helpers,
    'function decisionContextSnapshot(',
    'V0840-43 helper layer'
  );

  source=replaceOnce(source,
`function setMenuFeatured(
  shopId,
  menuItemId
) {
  return mutate(
    shopId,
    runtime => {
      let selected =
        null;

      for (
        const item
        of runtime.menu
      ) {
        item.featured =
          item.id ===
          menuItemId;

        if (
          item.featured
        ) {
          selected =
            item;
        }
      }

      return {
        ok:
          !!selected,
        item:
          selected
      };
    }
  );
}`,
`function setMenuFeatured(
  shopId,
  menuItemId
) {
  const baseline =
    decisionContextSnapshot(
      shopId
    );

  const result =
    mutate(
      shopId,
      runtime => {
        let selected =
          null;

        for (
          const item
          of runtime.menu
        ) {
          item.featured =
            item.id ===
            menuItemId;

          if (
            item.featured
          ) {
            selected =
              item;
          }
        }

        return {
          ok:
            !!selected,
          item:
            selected
        };
      }
    );

  if (
    result &&
    result.ok
  ) {
    recordTrackedDecision(
      shopId,
      'menu_featured',
      {
        menuItemId,
        name:
          result.item &&
          result.item.name ||
          null
      },
      baseline
    );
  }

  return result;
}`,
  'track featured decision');

  source=replaceOnce(source,
`function adjustMenuPrice(
  shopId,
  menuItemId,
  delta
) {
  return mutate(
    shopId,
    runtime => {
      const item =
        runtime.menu.find(
          row =>
            row.id ===
            menuItemId
        );

      if (!item) {
        return {
          ok: false,
          reason:
            '菜品不存在'
        };
      }

      item.listPrice =
        Math.round(
          Math.max(
            3,
            Math.min(
              999,
              (
                Number(
                  item.listPrice
                ) ||
                0
              ) +
              Number(
                delta
              )
            )
          ) *
          10
        ) /
        10;

      return {
        ok: true,
        item
      };
    }
  );
}`,
`function adjustMenuPrice(
  shopId,
  menuItemId,
  delta
) {
  const baseline =
    decisionContextSnapshot(
      shopId
    );

  const result =
    mutate(
      shopId,
      runtime => {
        const item =
          runtime.menu.find(
            row =>
              row.id ===
              menuItemId
          );

        if (!item) {
          return {
            ok:false,
            reason:'菜品不存在'
          };
        }

        const previousPrice =
          Number(
            item.listPrice
          ) || 0;

        item.listPrice =
          Math.round(
            Math.max(
              3,
              Math.min(
                999,
                previousPrice +
                Number(
                  delta
                )
              )
            ) *
            10
          ) /
          10;

        return {
          ok:true,
          item,
          previousPrice
        };
      }
    );

  if (
    result &&
    result.ok
  ) {
    recordTrackedDecision(
      shopId,
      'menu_price',
      {
        menuItemId,
        delta:
          Number(delta) || 0,
        previousPrice:
          result.previousPrice,
        newPrice:
          result.item &&
          result.item.listPrice
      },
      baseline
    );
  }

  return result;
}`,
  'track price decision');

  source=replaceOnce(source,
`function hireStaffCandidate(
  shopId,
  candidateId
) {
  const result =`,
`function hireStaffCandidate(
  shopId,
  candidateId
) {
  const baseline =
    decisionContextSnapshot(
      shopId
    );

  const result =`,
  'hire baseline');

  source=replaceOnce(source,
`    persist(
      shopId
    );
  }

  return result;
}

function dismissStaffMember(`,
`    persist(
      shopId
    );

    recordTrackedDecision(
      shopId,
      'staff_hire',
      {
        candidateId,
        staffId:
          result.staff &&
          result.staff.id ||
          null,
        signOnCost:
          Number(
            result.signOnCost
          ) || 0
      },
      baseline
    );
  }

  return result;
}

function dismissStaffMember(`,
  'hire decision record');

  source=replaceOnce(source,
`function startMarketingCampaign(
  shopId,
  typeId,
  budget,
  days,
  options
) {
  return mutate(
    shopId,
    runtime =>
      marketingPlatformMembership
        .startCampaign(
          shopId,
          runtime,
          typeId,
          budget,
          days,
          {
            ...(options || {}),
            day:
              options &&
              options.day != null
                ? options.day
                : runtime.day
          }
        )
  );
}`,
`function startMarketingCampaign(
  shopId,
  typeId,
  budget,
  days,
  options
) {
  const baseline =
    decisionContextSnapshot(
      shopId
    );

  const result =
    mutate(
      shopId,
      runtime =>
        marketingPlatformMembership
          .startCampaign(
            shopId,
            runtime,
            typeId,
            budget,
            days,
            {
              ...(options || {}),
              day:
                options &&
                options.day != null
                  ? options.day
                  : runtime.day
            }
          )
    );

  if (
    result &&
    result.ok
  ) {
    recordTrackedDecision(
      shopId,
      'marketing',
      {
        typeId,
        budget:
          Number(budget) || 0,
        days:
          Number(days) || 0
      },
      baseline
    );
  }

  return result;
}`,
  'track marketing decision');

  source=replaceOnce(source,
`      const result =
        liveOperations
          .simulateVisit(
            runtime,
            profile,
            options ||
            {}
          );`,
`      dailyOperatingCycle
        .beginDay(
          shopId,
          runtime.day,
          decisionContextSnapshot(
            shopId,
            runtime
          )
        );

      const result =
        liveOperations
          .simulateVisit(
            runtime,
            profile,
            options ||
            {}
          );

      dailyOperatingCycle
        .recordVisit(
          shopId,
          runtime.day,
          result
        );`,
  'visit day-cycle bridge');

  source=replaceOnce(source,
`    runtime => {
      const result =
        liveOperations
          .closeDay(`,
`    runtime => {
      dailyOperatingCycle
        .beginDay(
          shopId,
          runtime.day,
          decisionContextSnapshot(
            shopId,
            runtime
          )
        );

      const result =
        liveOperations
          .closeDay(`,
  'close-day begin bridge');

  const closeTail=
`      return result;
    }
  );
}

function financeSnapshot(
  shopId
) {`;

  const closeFinalize=
`      if (
        result &&
        result.ok &&
        result.result &&
        result.result.financial
      ) {
        const closedDay =
          Number(
            result.result.day
          ) ||
          Math.max(
            1,
            Number(
              runtime.day
            ) -
            1
          );

        const endSnapshot =
          decisionContextSnapshot(
            shopId,
            runtime,
            result.result.financial
          );

        const balanceV2 =
          operatingBalanceTuner
            .assessDay(
              result.result.financial,
              {
                tensionScore:
                  endSnapshot
                    .tensionScore
              }
            );

        const regulatoryView =
          regulatoryFoodSafetySystem
            .overview(
              shopId
            );

        const decisions =
          decisionFeedback
            .resolveDay(
              shopId,
              closedDay,
              endSnapshot
            );

        const daily =
          dailyOperatingCycle
            .finalizeDay(
              shopId,
              closedDay,
              result.result,
              endSnapshot,
              {
                balance:
                  balanceV2,
                decisionFeedback:
                  decisions,
                regulatory:{
                  openViolations:
                    regulatoryView &&
                    Array.isArray(
                      regulatoryView
                        .openViolations
                    )
                      ? regulatoryView
                          .openViolations
                          .length
                      : 0
                }
              }
            );

        const health =
          playtestHealth
            .record(
              shopId,
              playtestContextSnapshot(
                shopId,
                runtime
              )
            );

        result.dailyBrief =
          daily &&
          daily.brief ||
          null;

        result.decisionFeedback =
          decisions;

        result.balanceDiagnosis =
          balanceV2;

        result.playtestHealth =
          health;
      }

      return result;
    }
  );
}

function financeSnapshot(
  shopId
) {`;

  source=replaceOnce(
    source,
    closeTail,
    closeFinalize,
    'close-day feedback bridge'
  );

  const apis=
`function startOperatingDay(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return {
      ok:false,
      reason:'门店运行时不存在'
    };
  }

  return (
    dailyOperatingCycle
      .beginDay(
        shopId,
        runtime.day,
        decisionContextSnapshot(
          shopId,
          runtime
        )
      )
  );
}

function operatingDaySnapshot(
  shopId
) {
  return (
    dailyOperatingCycle
      .brief(
        shopId
      )
  );
}

function operatingDayHistory(
  shopId,
  limit
) {
  return (
    dailyOperatingCycle
      .history(
        shopId,
        limit
      )
  );
}

function closeOperatingDaySafe(
  shopId,
  options
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return {
      ok:false,
      reason:'门店运行时不存在'
    };
  }

  const live =
    liveOperations
      .snapshot(
        runtime,
        {
          staff:
            staffManagement
              .teamSnapshot(
                shopId,
                gameState
                  .getTime()
              )
        }
      );

  const check =
    dailyOperatingCycle
      .safeCloseCheck(
        shopId,
        runtime.day,
        {
          orders:
            live &&
            live.today &&
            live.today.orders,
          customers:
            live &&
            live.today &&
            live.today.customers
        }
      );

  if (!check.allowed) {
    return {
      ok:false,
      reason:
        check.message,
      code:
        check.code
    };
  }

  return closeOperatingDay(
    shopId,
    options ||
    {}
  );
}

function recordPlayerDecision(
  shopId,
  type,
  payload
) {
  return recordTrackedDecision(
    shopId,
    type,
    payload || {},
    decisionContextSnapshot(
      shopId
    )
  );
}

function decisionFeedbackSnapshot(
  shopId
) {
  return (
    decisionFeedback
      .overview(
        shopId
      )
  );
}

function playtestHealthSnapshot(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  return (
    playtestHealth
      .record(
        shopId,
        playtestContextSnapshot(
          shopId,
          runtime
        )
      )
  );
}

function operatingBalanceSnapshot(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return null;
  }

  const financial =
    settlementEngine
      .summary(
        runtime.ledger
      );

  const balance =
    economyBalanceGuard
      .snapshot(
        shopId
      );

  return (
    operatingBalanceTuner
      .assessDay(
        financial,
        {
          tensionScore:
            balance
              .tensionScore
        }
      )
  );
}

function runOperatingBalanceCalibration(
  count,
  options
) {
  return (
    operatingBalanceTuner
      .calibrate(
        count,
        options || {}
      )
  );
}

`;

  source=insertBefore(
    source,
    'function supplierCatalog(\n  shopId,',
    apis,
    'function startOperatingDay(',
    'V0840-43 operations APIs'
  );

  source=replaceOnce(source,
`  economyRecoveryOptions,
  generateCustomer,`,
`  economyRecoveryOptions,
  startOperatingDay,
  operatingDaySnapshot,
  operatingDayHistory,
  closeOperatingDaySafe,
  recordPlayerDecision,
  decisionFeedbackSnapshot,
  playtestHealthSnapshot,
  operatingBalanceSnapshot,
  runOperatingBalanceCalibration,
  generateCustomer,`,
  'V0840-43 exports');

  write(rel,source);
}

function updateOperationsIndex(){
  const rel='src/operations/index.js';
  let source=read(rel);

  source=replaceOnce(source,
`  multiStoreBrand:
    require('../brand/multiStoreBrandRankingV0834.js')`,
`  multiStoreBrand:
    require('../brand/multiStoreBrandRankingV0834.js'),
  dailyCycle:
    require('./dailyOperatingCycleV0840.js'),
  decisionFeedback:
    require('./decisionFeedbackV0841.js'),
  playtestHealth:
    require('../diagnostics/playtestHealthV0842.js'),
  balanceTuner:
    require('../balance/operatingBalanceTunerV0843.js')`,
  'operations index V0840-43');

  write(rel,source);
}

function updateMainLabel(){
  const rel='src/main.js';
  let source=read(rel);
  source=source.replace(
    '城市餐饮经营小游戏 V0.8.39 玩法串联与平衡版启动成功',
    '城市餐饮经营小游戏 V0.8.43 营业日复盘与决策反馈版启动成功'
  );
  write(rel,source);
}

function updateRunner(){
  const rel='scripts/run-ci-tests-v060.js';
  let source=read(rel);
  if(source.includes('tests/updateInfrastructureV0843.test.js'))return;
  const anchor=`    'tests/v60CleanBase.test.js'`;
  const addition=
`    'tests/dailyOperatingCycleV0840.test.js',
    'tests/decisionFeedbackV0841.test.js',
    'tests/playtestHealthV0842.test.js',
    'tests/operatingBalanceTunerV0843.test.js',
    'tests/operatingDayIntegrationV0843.test.js',
    'tests/updateInfrastructureV0843.test.js',
`;
  const i=source.indexOf(anchor);
  if(i<0)throw new Error('V0.8.40-43 runner anchor missing: v60CleanBase');
  source=source.slice(0,i)+addition+source.slice(i);
  write(rel,source);
}

function patchAndroidRunnerCompatibility(){
  const sdkRoot=process.env.ANDROID_SDK_ROOT||process.env.ANDROID_HOME||'/usr/local/lib/android/sdk';
  const latestDir=path.join(sdkRoot,'cmdline-tools','latest');
  const sourceProperties=path.join(latestDir,'source.properties');
  const sdkmanager=path.join(latestDir,'bin','sdkmanager');
  if(!fs.existsSync(sourceProperties)||!fs.existsSync(sdkmanager)){
    console.log('[V0.8.40-43] Android SDK runner compatibility: sdkmanager not found, skip');
    return;
  }
  let properties=fs.readFileSync(sourceProperties,'utf8');
  properties=properties.replace(/^Pkg\.Revision=.*$/m,'Pkg.Revision=16.0').replace(/^Pkg\.Path=.*$/m,'Pkg.Path=cmdline-tools;16.0');
  fs.writeFileSync(sourceProperties,properties,'utf8');
  const real=path.join(path.dirname(sdkmanager),'sdkmanager.v0843-real');
  if(!fs.existsSync(real))fs.renameSync(sdkmanager,real);
  const wrapper=[
    '#!/usr/bin/env bash','set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0843-real"',
    'ARGS=()','for ARG in "$@"; do','  if [ "$ARG" = "tools" ]; then continue; fi','  ARGS+=("$ARG")','done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then exit 0; fi','exec "$REAL" "${ARGS[@]}"',''
  ].join('\n');
  fs.writeFileSync(sdkmanager,wrapper,'utf8');
  fs.chmodSync(sdkmanager,0o755);
}

function validate(){
  const pkg=JSON.parse(read('package.json'));
  if(pkg.version!==TARGET_VERSION)throw new Error('target version failed');

  const required=[
    'src/operations/dailyOperatingCycleV0840.js',
    'src/operations/decisionFeedbackV0841.js',
    'src/diagnostics/playtestHealthV0842.js',
    'src/balance/operatingBalanceTunerV0843.js',
    'tests/dailyOperatingCycleV0840.test.js',
    'tests/decisionFeedbackV0841.test.js',
    'tests/playtestHealthV0842.test.js',
    'tests/operatingBalanceTunerV0843.test.js',
    'tests/operatingDayIntegrationV0843.test.js',
    'tests/updateInfrastructureV0843.test.js'
  ];
  for(const file of required){
    if(!fs.existsSync(abs(file)))throw new Error('missing '+file);
  }

  const operations=read('src/operations/operationsStoreV080.js');
  for(const marker of [
    'dailyOperatingCycleV0840.js',
    'decisionFeedbackV0841.js',
    'playtestHealthV0842.js',
    'operatingBalanceTunerV0843.js',
    'function startOperatingDay(',
    'function closeOperatingDaySafe(',
    'function decisionFeedbackSnapshot(',
    'function playtestHealthSnapshot(',
    'function operatingBalanceSnapshot('
  ]){
    if(!operations.includes(marker))throw new Error('operations missing '+marker);
  }

  const main=read('src/main.js');
  if(!/newGameFlow\s*\.\s*getStartupRoute\s*\(/.test(main)){
    throw new Error('V0814 startup contract lost');
  }
}

cleanupLegacyRootWorkflow();
updatePackage();
updatePackageLock();
updateOperationsStore();
updateOperationsIndex();
updateMainLabel();
updateRunner();
patchAndroidRunnerCompatibility();
validate();

console.log('[V0.8.43] PASS：营业日循环、决策反馈、试玩卡点诊断、第二轮平衡四合一完成');
