'use strict';

const fs = require('fs');
const cp = require('child_process');

const pkgPath = 'package.json';
if (!fs.existsSync(pkgPath)) throw new Error('package.json not found');

const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
pkg.scripts = pkg.scripts || {};
pkg.scripts['cleanup:scan'] = 'node scripts/project-cleaner.js';
pkg.scripts['cleanup:apply'] = 'node scripts/project-cleaner.js --apply';

// Remove old repair/migration hooks from pretest once the cleaner is installed.
if (typeof pkg.scripts.pretest === 'string') {
  const parts = pkg.scripts.pretest
    .split(/\s*&&\s*/)
    .filter(Boolean)
    .filter(cmd => !/(repair|apply|migrate|migration)[^&]*v\d+/i.test(cmd));
  if (parts.length) pkg.scripts.pretest = parts.join(' && ');
  else delete pkg.scripts.pretest;
}

fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + '\n', 'utf8');

const result = cp.spawnSync(process.execPath, ['scripts/project-cleaner.js', '--apply'], {
  cwd: process.cwd(),
  encoding: 'utf8',
  stdio: 'inherit'
});
if (result.status !== 0) process.exit(result.status || 1);

console.log('[cleanup-bot installer] cleanup completed and package.json scripts installed.');
