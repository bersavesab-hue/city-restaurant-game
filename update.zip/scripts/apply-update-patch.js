'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const BASE_VERSION =
  '0.8.35';

const TARGET_VERSION =
  '0.8.39';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs.readFileSync(
    abs(rel),
    'utf8'
  );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (
    index <
    0
  ) {
    throw new Error(
      'V0.8.36-39 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function insertBefore(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      anchor
    );

  if (
    index <
    0
  ) {
    throw new Error(
      'V0.8.36-39 insertion anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    addition +
    source.slice(
      index
    )
  );
}

function cleanupLegacyRootWorkflow() {
  if (
    fs.existsSync(
      abs(
        'apply-update.yml'
      )
    )
  ) {
    fs.unlinkSync(
      abs(
        'apply-update.yml'
      )
    );
  }
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      BASE_VERSION &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.36-39 requires formal V0.8.35 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateEntryRouter() {
  const rel =
    'src/core/entryRouterV0810.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`let lastError = null;
let currentRouteId = null;`,
`let lastError = null;
let currentRouteId = null;
let routeGuard = null;`,
      'router guard state'
    );

  source =
    replaceOnce(
      source,
`  if (!sceneManager.has(resolved.target)) {
    lastError = {
      code: 'SCENE_NOT_REGISTERED',
      routeId: resolved.id,
      target: resolved.target,
      at: Date.now()
    };
    return false;
  }

  const payload = mergedParams(resolved.id, params);`,
`  if (!sceneManager.has(resolved.target)) {
    lastError = {
      code: 'SCENE_NOT_REGISTERED',
      routeId: resolved.id,
      target: resolved.target,
      at: Date.now()
    };
    return false;
  }

  if (
    !opts.ignoreGuard &&
    routeGuard
  ) {
    const access =
      getGuardStatus(
        resolved.id,
        params
      );

    if (
      !access.allowed
    ) {
      lastError = {
        code:'ROUTE_BLOCKED',
        guardCode:
          access.code ||
          'ROUTE_BLOCKED',
        routeId:
          resolved.id,
        target:
          resolved.target,
        reason:
          access.reason ||
          '该功能当前不可用',
        recommended:
          access.recommended ||
          null,
        at:Date.now()
      };

      return false;
    }
  }

  const payload = mergedParams(resolved.id, params);`,
      'router guard enforcement'
    );

  const guardFunctions =
`function setGuard(guard) {
  routeGuard =
    typeof guard ===
    'function'
      ? guard
      : null;

  return !!routeGuard;
}

function getGuardStatus(
  routeId,
  params
) {
  const resolved =
    resolve(
      routeId
    );

  if (!resolved) {
    return {
      allowed:false,
      code:'ROUTE_NOT_FOUND',
      routeId:
        String(
          routeId ||
          ''
        ),
      reason:'入口不存在'
    };
  }

  if (!routeGuard) {
    return {
      allowed:true,
      routeId:
        resolved.id
    };
  }

  try {
    const result =
      routeGuard(
        resolved.id,
        cloneParams(
          params
        )
      );

    if (
      result ===
      false
    ) {
      return {
        allowed:false,
        routeId:
          resolved.id,
        code:'ROUTE_BLOCKED',
        reason:
          '该功能当前不可用'
      };
    }

    if (
      result ===
      true ||
      result == null
    ) {
      return {
        allowed:true,
        routeId:
          resolved.id
      };
    }

    if (
      typeof result ===
      'object'
    ) {
      return {
        routeId:
          resolved.id,
        allowed:
          result.allowed !==
          false,
        ...result
      };
    }

    return {
      allowed:true,
      routeId:
        resolved.id
    };
  } catch (error) {
    return {
      allowed:false,
      routeId:
        resolved.id,
      code:'ROUTE_GUARD_ERROR',
      reason:
        error &&
        error.message ||
        '入口权限检查异常'
    };
  }
}

`;

  source =
    insertBefore(
      source,
      'function listRoutes() {',
      guardFunctions,
      'function setGuard(',
      'router guard APIs'
    );

  source =
    replaceOnce(
      source,
`    routeCount: Object.keys(ROUTES).length,
    missing`,
`    routeCount: Object.keys(ROUTES).length,
    guardInstalled:
      !!routeGuard,
    missing`,
      'router diagnose guard marker'
    );

  source =
    replaceOnce(
      source,
`  lastError = null;
  currentRouteId = null;
}`,
`  lastError = null;
  currentRouteId = null;
  routeGuard = null;
}`,
      'router test reset guard'
    );

  source =
    replaceOnce(
      source,
`  resolve,
  listRoutes,`,
`  resolve,
  setGuard,
  getGuardStatus,
  listRoutes,`,
      'router guard exports'
    );

  write(
    rel,
    source
  );
}

function updateOperationsStore() {
  const rel =
    'src/operations/operationsStoreV080.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const multiStoreBrandRanking =
  require('../brand/multiStoreBrandRankingV0834.js');

const customerRandomDatabase =`,
`const multiStoreBrandRanking =
  require('../brand/multiStoreBrandRankingV0834.js');

const economyBalanceGuard =
  require('../core/economyBalanceGuardV0839.js');

const customerRandomDatabase =`,
      'operations balance import'
    );

  const apiBlock =
`function economyBalanceSnapshot(
  shopId
) {
  return (
    economyBalanceGuard
      .snapshot(
        shopId
      )
  );
}

function assessPlannedSpend(
  shopId,
  amount,
  category
) {
  return (
    economyBalanceGuard
      .assessSpend(
        shopId,
        amount,
        category
      )
  );
}

function economyRecoveryOptions(
  shopId
) {
  return (
    economyBalanceGuard
      .recoveryOptions(
        shopId
      )
  );
}

`;

  source =
    insertBefore(
      source,
      'function supplierCatalog(\n  shopId,',
      apiBlock,
      'function economyBalanceSnapshot(',
      'operations economy APIs'
    );

  source =
    replaceOnce(
      source,
`  storeRankingSnapshot,
  generateCustomer,`,
`  storeRankingSnapshot,
  economyBalanceSnapshot,
  assessPlannedSpend,
  economyRecoveryOptions,
  generateCustomer,`,
      'operations economy exports'
    );

  write(
    rel,
    source
  );
}

function updateMain() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const newGameFlow =
  require('./core/newGameFlowV0814.js');

const foodResearchSystem =`,
`const newGameFlow =
  require('./core/newGameFlowV0814.js');

const gameplayFlowCoordinator =
  require('./core/gameplayFlowCoordinatorV0836.js');

const featureAccessPolicy =
  require('./core/featureAccessPolicyV0837.js');

const interactionRecoverySystem =
  require('./core/interactionRecoverySystemV0838.js');

const economyBalanceGuard =
  require('./core/economyBalanceGuardV0839.js');

const foodResearchSystem =`,
      'main gameplay experience imports'
    );

  source =
    replaceOnce(
      source,
`function getHomeGoalState() {
  const business =`,
`function getHomeGoalState() {
  try {
    const unified =
      gameplayFlowCoordinator.goal();

    if (
      unified &&
      Array.isArray(
        unified.steps
      ) &&
      unified.steps.length
    ) {
      return unified;
    }
  } catch (error) {
  }

  const business =`,
      'main unified goal state'
    );

  source =
    replaceOnce(
      source,
`    if (
      target.id ===
      'goal:current'
    ) {
      const business =
        gameState
          .getBusiness();

      if (
        business.hasShop &&
        business.shops.length
      ) {
        sceneManager
          .switchTo(
            'shop'
          );

        return true;
      }

      if (
        !selectedDistrictId
      ) {
        selectBusiestDistrict();

        return true;
      }

      sceneManager
        .switchTo(
          'district',
          {
            districtId:
              selectedDistrictId
          }
        );

      return true;
    }`,
`    if (
      target.id ===
      'goal:current'
    ) {
      const action =
        interactionRecoverySystem
          .run(
            'home.goal.primary',
            () =>
              gameplayFlowCoordinator
                .executePrimary(),
            {
              transactional:true,
              rollbackOnFailure:true
            }
          );

      if (!action.ok) {
        showToast(
          action.value &&
          action.value.message ||
          action.error &&
          action.error.message ||
          '当前操作没有完成'
        );

        return true;
      }

      const result =
        action.value ||
        {};

      const route =
        result.route ||
        result.next ||
        null;

      if (
        route &&
        route.routeId
      ) {
        if (
          !entryRouter.open(
            route.routeId,
            route.params ||
            {}
          )
        ) {
          const routeError =
            entryRouter
              .getLastError();

          if (
            routeError &&
            routeError.recommended &&
            routeError
              .recommended
              .routeId
          ) {
            entryRouter.open(
              routeError
                .recommended
                .routeId,
              routeError
                .recommended
                .params ||
                {}
            );
          }

          showToast(
            routeError &&
            routeError.reason ||
            '该功能暂未解锁'
          );
        }

        render();

        return true;
      }

      if (
        result.ok
      ) {
        showToast(
          result.actionId ===
            'start_trial'
            ? '已开始试营业'
            : result.actionId ===
                'formal_open'
              ? '门店已正式开业'
              : '操作完成'
        );

        render();

        return true;
      }

      showToast(
        result.message ||
        '当前目标暂时无法推进'
      );

      return true;
    }`,
      'main goal primary action'
    );

  source =
    replaceOnce(
      source,
`// V0814_NEW_GAME_FLOW_BOOT
runtime.newGameFlow =
  newGameFlow;`,
`// V0814_NEW_GAME_FLOW_BOOT
runtime.newGameFlow =
  newGameFlow;

// V0836_V0839_GAMEPLAY_EXPERIENCE_BOOT
runtime.gameplayFlow =
  gameplayFlowCoordinator;

runtime.gameplayAccess =
  featureAccessPolicy;

runtime.interactionSafety =
  interactionRecoverySystem;

runtime.economyBalance =
  economyBalanceGuard;`,
      'main runtime gameplay exports'
    );

  source =
    replaceOnce(
      source,
`newGameFlow
  .initialize({
    fresh:
      !restoredFromSave,
    restoredFromSave
  });

simulationSystem
  .initialize();`,
`newGameFlow
  .initialize({
    fresh:
      !restoredFromSave,
    restoredFromSave
  });

gameplayFlowCoordinator
  .repairSafeInvariants();

interactionRecoverySystem
  .repairCriticalState();

entryRouter.setGuard(
  featureAccessPolicy.guard
);

simulationSystem
  .initialize();`,
      'main gameplay boot install'
    );

  source =
    replaceOnce(
      source,
`const startupRoute =
  newGameFlow
    .getStartupRoute();`,
`const startupRoute =
  gameplayFlowCoordinator
    .startupRoute();`,
      'main unified startup route'
    );

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.35 功能总集成版启动成功',
      '城市餐饮经营小游戏 V0.8.39 玩法串联与平衡版启动成功'
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0839.test.js'
    )
  ) {
    return;
  }

  const anchor =
    `    'tests/v60CleanBase.test.js'`;

  const addition =
`    'tests/gameplayFlowCoordinatorV0836.test.js',
    'tests/featureAccessPolicyV0837.test.js',
    'tests/routerGuardIntegrationV0837.test.js',
    'tests/interactionRecoverySystemV0838.test.js',
    'tests/economyBalanceGuardV0839.test.js',
    'tests/gameplayExperienceIntegrationV0839.test.js',
    'tests/updateInfrastructureV0839.test.js',
`;

  const index =
    source.indexOf(
      anchor
    );

  if (
    index <
    0
  ) {
    throw new Error(
      'V0.8.36-39 runner anchor missing: v60CleanBase'
    );
  }

  source =
    source.slice(
      0,
      index
    ) +
    addition +
    source.slice(
      index
    );

  write(
    rel,
    source
  );
}

function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const sdkmanager =
    path.join(
      latestDir,
      'bin',
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.36-39] Android SDK runner compatibility: sdkmanager not found, skip'
    );

    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const real =
    path.join(
      path.dirname(
        sdkmanager
      ),
      'sdkmanager.v0839-real'
    );

  if (
    !fs.existsSync(
      real
    )
  ) {
    fs.renameSync(
      sdkmanager,
      real
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0839-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then continue; fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then exit 0; fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.36-39 target version finalize failed'
    );
  }

  const required = [
    'src/core/gameplayFlowCoordinatorV0836.js',
    'src/core/featureAccessPolicyV0837.js',
    'src/core/interactionRecoverySystemV0838.js',
    'src/core/economyBalanceGuardV0839.js',
    'tests/gameplayFlowCoordinatorV0836.test.js',
    'tests/featureAccessPolicyV0837.test.js',
    'tests/routerGuardIntegrationV0837.test.js',
    'tests/interactionRecoverySystemV0838.test.js',
    'tests/economyBalanceGuardV0839.test.js',
    'tests/gameplayExperienceIntegrationV0839.test.js',
    'tests/updateInfrastructureV0839.test.js'
  ];

  for (
    const file
    of required
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.36-39 required file missing: ' +
        file
      );
    }
  }

  const router =
    read(
      'src/core/entryRouterV0810.js'
    );

  for (
    const marker
    of [
      'let routeGuard = null;',
      'function setGuard(',
      'function getGuardStatus(',
      "code:'ROUTE_BLOCKED'"
    ]
  ) {
    if (
      !router.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.36-39 router integration missing ' +
        marker
      );
    }
  }

  const main =
    read(
      'src/main.js'
    );

  for (
    const marker
    of [
      'gameplayFlowCoordinatorV0836.js',
      'featureAccessPolicyV0837.js',
      'interactionRecoverySystemV0838.js',
      'economyBalanceGuardV0839.js',
      'entryRouter.setGuard',
      'gameplayFlowCoordinator',
      '.goal()',
      '.executePrimary()',
      '.startupRoute()'
    ]
  ) {
    if (
      !main.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.36-39 main integration missing ' +
        marker
      );
    }
  }
}

cleanupLegacyRootWorkflow();
updatePackage();
updatePackageLock();
updateEntryRouter();
updateOperationsStore();
updateMain();
updateRunner();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.39] PASS：第二阶段首包——主循环、功能入口、交互回退、经济防卡死完成'
);
