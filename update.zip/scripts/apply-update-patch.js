'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.12';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs
    .writeFileSync(
      abs(rel),
      content,
      'utf8'
    );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.12 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function insertAfter(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      anchor
    );

  if (index < 0) {
    throw new Error(
      'V0.8.12 insert anchor missing: ' +
      label
    );
  }

  const end =
    index +
    anchor.length;

  return (
    source.slice(
      0,
      end
    ) +
    addition +
    source.slice(
      end
    )
  );
}

function replaceSection(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V0.8.12 section start missing: ' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
      startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V0.8.12 section end missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    '\n\n' +
    source.slice(
      end
    )
  );
}

function updatePackage() {
  const rel =
    'package.json';

  const pkg =
    JSON.parse(
      read(
        rel
      )
    );

  if (
    pkg.version !==
      '0.8.11' &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.12 requires formal V0.8.11 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    rel,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(
        rel
      )
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock
      .packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateMain() {
  const rel =
    'src/main.js';

  let source =
    read(
      rel
    );

  const stateBridgeRequire =
`const stateBridge =
  require('./core/stateBridgeV0811.js');`;

  source =
    insertAfter(
      source,
      stateBridgeRequire,
`

const timeScheduleCoordinator =
  require('./core/timeScheduleCoordinatorV0812.js');`,
      "require('./core/timeScheduleCoordinatorV0812.js')",
      'main coordinator require'
    );

  const bootAnchor =
`// V0811_GLOBAL_STATE_BUS_BOOT
stateBridge.install();
runtime.stateBus =
  globalStateBus;`;

  const bootReplacement =
`// V0811_GLOBAL_STATE_BUS_BOOT
stateBridge.install();
runtime.stateBus =
  globalStateBus;

// V0812_TIME_SCHEDULE_BOOT
timeScheduleCoordinator.install();
runtime.timeSchedule =
  timeScheduleCoordinator;`;

  source =
    replaceOnce(
      source,
      bootAnchor,
      bootReplacement,
      'main coordinator boot'
    );

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.11 全局状态总线启动成功',
      '城市餐饮经营小游戏 V0.8.12 时间与营业日程统一版启动成功'
    );

  write(
    rel,
    source
  );
}

function updateTimeSystem() {
  const rel =
    'src/core/timeSystem.js';

  let source =
    read(
      rel
    );

  const anchor =
`const simulationConfig =
  require('./simulationConfig.js');`;

  source =
    insertAfter(
      source,
      anchor,
`

const timeScheduleCoordinator =
  require('./timeScheduleCoordinatorV0812.js');`,
      "require('./timeScheduleCoordinatorV0812.js')",
      'timeSystem coordinator require'
    );

  source =
    replaceSection(
      source,
      '  isLeapYear(year) {',
      '  getDaysInMonth(',
`  isLeapYear(year) {
    return (
      timeScheduleCoordinator
        .isLeapYear(
          year
        )
    );
  }`,
      'timeSystem isLeapYear'
    );

  source =
    replaceSection(
      source,
      '  getDaysInMonth(',
      '  addMinutes(',
`  getDaysInMonth(
    year,
    month
  ) {
    return (
      timeScheduleCoordinator
        .daysInMonth(
          year,
          month
        )
    );
  }`,
      'timeSystem getDaysInMonth'
    );

  source =
    replaceSection(
      source,
      '  getMealPeriod() {',
      '}\n\nconst timeSystem =',
`  getMealPeriod() {
    return (
      timeScheduleCoordinator
        .mealPeriod(
          gameState
            .getTime()
        )
    );
  }`,
      'timeSystem getMealPeriod'
    );

  write(
    rel,
    source
  );
}

function updateSimulationSystem() {
  const rel =
    'src/core/simulationSystem.js';

  let source =
    read(
      rel
    );

  const anchor =
`const simulationConfig =
  require('./simulationConfig.js');`;

  source =
    insertAfter(
      source,
      anchor,
`

const timeScheduleCoordinator =
  require('./timeScheduleCoordinatorV0812.js');`,
      "require('./timeScheduleCoordinatorV0812.js')",
      'simulationSystem coordinator require'
    );

  source =
    replaceSection(
      source,
      '  isLeapYear(year) {',
      '  getDayOrdinal(',
`  isLeapYear(year) {
    return (
      timeScheduleCoordinator
        .isLeapYear(
          year
        )
    );
  }`,
      'simulationSystem isLeapYear'
    );

  source =
    replaceSection(
      source,
      '  getDayOrdinal(',
      '  getSeason(',
`  getDayOrdinal(
    time
  ) {
    return (
      timeScheduleCoordinator
        .dayOrdinal(
          time
        )
    );
  }`,
      'simulationSystem getDayOrdinal'
    );

  write(
    rel,
    source
  );
}

function updateOperationsSchedule() {
  const rel =
    'src/operations/operationsScheduleV087.js';

  let source =
    read(
      rel
    );

  const requireAnchor =
`const openingPrepSystem =
  require('../opening/openingPrepSystem.js');`;

  source =
    insertAfter(
      source,
      requireAnchor,
`

const timeScheduleCoordinator =
  require('../core/timeScheduleCoordinatorV0812.js');`,
      "require('../core/timeScheduleCoordinatorV0812.js')",
      'operationsSchedule coordinator require'
    );

  source =
    replaceSection(
      source,
      'function isLeapYear(year) {',
      'function daysInMonth(',
`function isLeapYear(year) {
  return (
    timeScheduleCoordinator
      .isLeapYear(
        year
      )
  );
}`,
      'operationsSchedule isLeapYear'
    );

  source =
    replaceSection(
      source,
      'function daysInMonth(',
      'function dayOrdinal(',
`function daysInMonth(
  year,
  month
) {
  return (
    timeScheduleCoordinator
      .daysInMonth(
        year,
        month
      )
  );
}`,
      'operationsSchedule daysInMonth'
    );

  source =
    replaceSection(
      source,
      'function dayOrdinal(time) {',
      'function weekDay(',
`function dayOrdinal(time) {
  return (
    timeScheduleCoordinator
      .dayOrdinal(
        time
      )
  );
}`,
      'operationsSchedule dayOrdinal'
    );

  source =
    replaceSection(
      source,
      'function weekDay(',
      'function getShop(',
`function weekDay(
  time
) {
  return (
    timeScheduleCoordinator
      .weekDay(
        time ||
        gameState.getTime()
      )
  );
}`,
      'operationsSchedule weekDay'
    );

  if (
    !source.includes(
      'function getBusinessHours('
    )
  ) {
    const insertionPoint =
      source.indexOf(
        'function defaultPreset('
      );

    if (
      insertionPoint <
      0
    ) {
      throw new Error(
        'V0.8.12 operationsSchedule defaultPreset anchor missing'
      );
    }

    const addition =
`function getBusinessHours(
  shopOrId
) {
  const shop =
    typeof shopOrId ===
      'object'
      ? shopOrId
      : getShop(
          shopOrId
        );

  if (!shop) {
    return {
      openHour:6,
      closeHour:23
    };
  }

  const liveShop =
    shop.id == null
      ? null
      : getShop(
          shop.id
        );

  // 兼容历史测试、预览对象和跨午夜营业对象：
  // 只有正式进入 business.shops 的门店才读取持久化排班。
  if (!liveShop) {
    const raw =
      shop.businessHours &&
      typeof shop.businessHours ===
        'object'
        ? shop.businessHours
        : {};

    const openHour =
      Number.isFinite(
        Number(
          raw.openHour
        )
      )
        ? Number(
            raw.openHour
          )
        : Number.isFinite(
            Number(
              shop.openHour
            )
          )
          ? Number(
              shop.openHour
            )
          : 6;

    const closeHour =
      Number.isFinite(
        Number(
          raw.closeHour
        )
      )
        ? Number(
            raw.closeHour
          )
        : Number.isFinite(
            Number(
              shop.closeHour
            )
          )
          ? Number(
              shop.closeHour
            )
          : 23;

    return {
      openHour:
        clamp(
          openHour,
          0,
          24
        ),
      closeHour:
        clamp(
          closeHour,
          0,
          24
        )
    };
  }

  const state =
    ensureShop(
      liveShop.id
    );

  return clone(
    state &&
    state.businessHours
      ? state.businessHours
      : normalizeHours(
          liveShop
        )
  );
}

function isOpenAt(
  shopOrId,
  time
) {
  const hours =
    getBusinessHours(
      shopOrId
    );

  return (
    timeScheduleCoordinator
      .isWithinHours(
        hours,
        time ||
        gameState.getTime()
      )
  );
}

`;

    source =
      source.slice(
        0,
        insertionPoint
      ) +
      addition +
      source.slice(
        insertionPoint
      );
  }

  const businessHoursAnchor =
`  state.updatedDay =
    dayOrdinal(
      gameState.getTime()
    );

  return {
    ok:true,
    businessHours:
      clone(
        state.businessHours
      )
  };`;

  const businessHoursReplacement =
`  state.updatedDay =
    dayOrdinal(
      gameState.getTime()
    );

  timeScheduleCoordinator
    .notifyScheduleChange(
      shopId,
      'business-hours'
    );

  return {
    ok:true,
    businessHours:
      clone(
        state.businessHours
      )
  };`;

  source =
    replaceOnce(
      source,
      businessHoursAnchor,
      businessHoursReplacement,
      'operationsSchedule business-hours notify'
    );

  const shiftAnchor =
`  state.employees[
    personId
  ].preset =
    preset;

  return {
    ok:true,
    preset
  };`;

  const shiftReplacement =
`  state.employees[
    personId
  ].preset =
    preset;

  timeScheduleCoordinator
    .notifyScheduleChange(
      shopId,
      'employee-shift'
    );

  return {
    ok:true,
    preset
  };`;

  source =
    replaceOnce(
      source,
      shiftAnchor,
      shiftReplacement,
      'operationsSchedule shift notify'
    );

  const offDayAnchor =
`  state.employees[
    personId
  ].offDay =
    (
      Math.round(
        Number(offDay) || 0
      ) %
      7 +
      7
    ) %
    7;

  return {
    ok:true,
    offDay:
      state.employees[
        personId
      ].offDay
  };`;

  const offDayReplacement =
`  state.employees[
    personId
  ].offDay =
    (
      Math.round(
        Number(offDay) || 0
      ) %
      7 +
      7
    ) %
    7;

  timeScheduleCoordinator
    .notifyScheduleChange(
      shopId,
      'employee-off-day'
    );

  return {
    ok:true,
    offDay:
      state.employees[
        personId
      ].offDay
  };`;

  source =
    replaceOnce(
      source,
      offDayAnchor,
      offDayReplacement,
      'operationsSchedule off-day notify'
    );

  const exportAnchor =
`  DAY_NAMES,
  weekDay,
  ensureShop,`;

  const exportReplacement =
`  DAY_NAMES,
  dayOrdinal,
  weekDay,
  getBusinessHours,
  isOpenAt,
  ensureShop,`;

  source =
    replaceOnce(
      source,
      exportAnchor,
      exportReplacement,
      'operationsSchedule exports'
    );

  write(
    rel,
    source
  );
}

function updateBusinessLifecycle() {
  const rel =
    'src/core/businessLifecycleV086.js';

  let source =
    read(
      rel
    );

  const requireAnchor =
`const renovationSystem =
  require('../renovation/renovationSystem.js');`;

  source =
    insertAfter(
      source,
      requireAnchor,
`

const timeScheduleCoordinator =
  require('./timeScheduleCoordinatorV0812.js');`,
      "require('./timeScheduleCoordinatorV0812.js')",
      'businessLifecycle coordinator require'
    );

  source =
    replaceSection(
      source,
      'function currentDay() {',
      'function ensureState() {',
`function currentDay() {
  return (
    timeScheduleCoordinator
      .dayOrdinal(
        gameState
          .getTime()
      )
  );
}`,
      'businessLifecycle currentDay'
    );

  write(
    rel,
    source
  );
}

function updateRestaurantSimulation() {
  const rel =
    'src/operations/restaurantSimulationV081.js';

  let source =
    read(
      rel
    );

  source =
    replaceSection(
      source,
      'function businessHours(shop) {',
      'function isWithinBusinessHours(shop, time) {',
`function businessHours(shop) {
  // V083_UNIFIED_DEMAND
  return (
    operationsSchedule
      .getBusinessHours(
        shop
      )
  );
}`,
      'restaurant businessHours'
    );

  source =
    replaceSection(
      source,
      'function isWithinBusinessHours(shop, time) {',
      'function expectedArrivalsPerMinute(',
`function isWithinBusinessHours(
  shop,
  time
) {
  return (
    operationsSchedule
      .isOpenAt(
        shop,
        time ||
        gameState.getTime()
      )
  );
}`,
      'restaurant isWithinBusinessHours'
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(
      rel
    );

  if (
    source.includes(
      'tests/updateInfrastructureV0812.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/globalStateBusV0811.test.js',
    'tests/stateBridgeV0811.test.js',
    'tests/updateInfrastructureV0811.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/globalStateBusV0811.test.js',
    'tests/stateBridgeV0811.test.js',
    'tests/updateInfrastructureV0811.test.js',
    'tests/timeScheduleCoordinatorV0812.test.js',
    'tests/timedProgressionV0812.test.js',
    'tests/updateInfrastructureV0812.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner'
    );

  write(
    rel,
    source
  );
}

function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const binDir =
    path.join(
      latestDir,
      'bin'
    );

  const sdkmanager =
    path.join(
      binDir,
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.12] Android SDK runner compatibility: preinstalled sdkmanager not found, skip'
    );

    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const realSdkmanager =
    path.join(
      binDir,
      'sdkmanager.v0812-real'
    );

  if (
    !fs.existsSync(
      realSdkmanager
    )
  ) {
    fs.renameSync(
      sdkmanager,
      realSdkmanager
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0812-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join('\n');

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.12] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.12 package version finalize failed'
    );
  }

  const checks = [
    [
      'src/main.js',
      [
        'V0812_TIME_SCHEDULE_BOOT',
        "require('./core/timeScheduleCoordinatorV0812.js')"
      ]
    ],
    [
      'src/core/timeSystem.js',
      [
        "require('./timeScheduleCoordinatorV0812.js')",
        'timeScheduleCoordinator',
        '.daysInMonth('
      ]
    ],
    [
      'src/core/simulationSystem.js',
      [
        "require('./timeScheduleCoordinatorV0812.js')",
        '.dayOrdinal('
      ]
    ],
    [
      'src/operations/operationsScheduleV087.js',
      [
        'function getBusinessHours(',
        'function isOpenAt(',
        'notifyScheduleChange'
      ]
    ],
    [
      'src/operations/restaurantSimulationV081.js',
      [
        'operationsSchedule',
        'V083_UNIFIED_DEMAND',
        '.getBusinessHours(',
        '.isOpenAt('
      ]
    ],
    [
      'src/core/businessLifecycleV086.js',
      [
        'timeScheduleCoordinator',
        '.dayOrdinal('
      ]
    ],
    [
      'scripts/run-ci-tests-v060.js',
      [
        'tests/timeScheduleCoordinatorV0812.test.js',
        'tests/timedProgressionV0812.test.js',
        'tests/updateInfrastructureV0812.test.js'
      ]
    ]
  ];

  for (
    const [
      file,
      markers
    ]
    of checks
  ) {
    const source =
      read(
        file
      );

    for (
      const marker
      of markers
    ) {
      if (
        !source.includes(
          marker
        )
      ) {
        throw new Error(
          'V0.8.12 validation missing ' +
          marker +
          ' in ' +
          file
        );
      }
    }
  }

  for (
    const file
    of [
      'src/core/timeScheduleCoordinatorV0812.js',
      'tests/timeScheduleCoordinatorV0812.test.js',
      'tests/timedProgressionV0812.test.js',
      'tests/updateInfrastructureV0812.test.js'
    ]
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.12 required file missing: ' +
        file
      );
    }
  }
}

updatePackage();
updatePackageLock();
updateMain();
updateTimeSystem();
updateSimulationSystem();
updateOperationsSchedule();
updateBusinessLifecycle();
updateRestaurantSimulation();
updateRunner();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.12] PASS：时间 / 日期 / 营业日程统一增量安装完成'
);
