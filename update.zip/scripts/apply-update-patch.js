'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = process.cwd();
const SCENE = path.join(ROOT, 'src/scenes/renovationScene.js');
const ANDROID = path.join(ROOT, 'android/entry.js');
const RUNNER = path.join(ROOT, 'scripts/run-ci-tests-v060.js');
const TEST = path.join(ROOT, 'tests/renovationFinalFixV0850.test.js');
const MANIFEST = path.join(ROOT, 'PATCH_MANIFEST_V0850_RENOVATION_FINAL_FIX.json');

function read(file) {
  if (!fs.existsSync(file)) throw new Error('缺少文件：' + path.relative(ROOT, file));
  return fs.readFileSync(file, 'utf8');
}

function write(file, content) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content, 'utf8');
}

function replaceBetween(source, startToken, endToken, replacement, label) {
  const start = source.indexOf(startToken);
  if (start < 0) throw new Error('找不到开始锚点：' + label);
  const end = source.indexOf(endToken, start + startToken.length);
  if (end < 0) throw new Error('找不到结束锚点：' + label);
  return source.slice(0, start) + replacement + source.slice(end);
}

let scene = read(SCENE);
let android = read(ANDROID);
let runner = read(RUNNER);

if (scene.includes('V0850_FINAL_RENOVATION_MOBILE_FIX')) {
  console.log('V0850 final renovation mobile fix already applied');
  process.exit(0);
}

scene = scene.replace(
  '// V0849_HOTFIX_RENOVATION_INTERACTION_LAYOUT',
  '// V0849_HOTFIX_RENOVATION_INTERACTION_LAYOUT\n// V0850_FINAL_RENOVATION_MOBILE_FIX'
);

if (!scene.includes('  requestRenderNow() {')) {
  const anchor = '  text(\n    ctx,';
  const insert = `  requestRenderNow() {\n    if (\n      runtime &&\n      typeof runtime.requestRender ===\n        'function'\n    ) {\n      runtime.requestRender();\n    }\n  }\n\n`;
  if (!scene.includes(anchor)) throw new Error('无法插入 requestRenderNow');
  scene = scene.replace(anchor, insert + anchor);
}

scene = replaceBetween(
  scene,
  '  getMainGeometry() {',
  '  drawZoneChip(',
`  getMainGeometry() {
    // V0850：主平面图优先。默认页不再被模板条挤压，
    // 600px 矮屏和常见 780px 手机都保留足够编辑空间。
    const y =
      this.viewH < 700
        ? 94
        : 104;

    const footerH =
      49;

    const available =
      Math.max(
        320,
        this.contentBottom - y
      );

    const lowerH =
      clamp(
        available * 0.19,
        96,
        118
      );

    const maxPlan =
      this.contentBottom -
      y -
      lowerH -
      footerH -
      16;

    const planH =
      clamp(
        maxPlan,
        this.viewH < 700
          ? 258
          : 330,
        432
      );

    const lowerY =
      y +
      planH +
      8;

    const footerY =
      this.contentBottom -
      footerH;

    return {
      y,
      planH,
      lowerY,
      lowerH:
        Math.max(
          90,
          Math.min(
            lowerH,
            footerY -
            lowerY -
            8
          )
        ),
      footerY,
      footerH
    };
  }

`,
  'getMainGeometry'
);

scene = replaceBetween(
  scene,
  '  drawFloorPlan(',
  '  drawTablePicker(',
`  drawFloorPlan(
    ctx,
    metrics,
    floor,
    geometry
  ) {
    const y =
      geometry.y;

    const h =
      geometry.planH;

    ui.card(
      ctx,
      7,
      y,
      376,
      h,
      {
        radius: 14,
        fill: COLORS.panel,
        stroke: COLORS.line,
        shadow: false
      }
    );

    const floorGeometry =
      floor.geometry ||
      floorGeometrySystem
        .getFloorGeometry(
          this.getShop(),
          floor.index,
          floor.area,
          metrics.plan.floors.length
        );

    this.text(
      ctx,
      '平面编辑',
      18,
      y + 18,
      9.4,
      COLORS.text,
      '800'
    );

    this.text(
      ctx,
      floorGeometry.shapeName +
        ' · ' +
        floorGeometry.areaM2.toFixed(0) +
        '㎡ · 拖黄点调区域',
      82,
      y + 18,
      4.7,
      COLORS.muted,
      '700'
    );

    ui.card(
      ctx,
      194,
      y + 5,
      44,
      26,
      {
        radius: 10,
        fill: '#EAF4F7',
        stroke: '#BDD6DF',
        shadow: false
      }
    );

    this.text(
      ctx,
      (metrics.plan.activeFloor + 1) + 'F',
      216,
      y + 18,
      5.8,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton(
      'floor:next',
      190,
      y + 1,
      52,
      34
    );

    this.text(ctx, '↶', 259, y + 18, 10, COLORS.navy, '800', 'center');
    this.text(ctx, '↷', 295, y + 18, 10, COLORS.navy, '800', 'center');

    this.addButton('history:undo', 242, y + 2, 34, 32);
    this.addButton('history:redo', 278, y + 2, 34, 32);

    ui.card(
      ctx,
      319,
      y + 5,
      55,
      26,
      {
        radius: 10,
        fill: '#FFF4D5',
        stroke: '#E2C16B',
        shadow: false
      }
    );

    this.text(
      ctx,
      '预览',
      346.5,
      y + 18,
      5.4,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton('preview', 315, y + 1, 63, 34);

    const planX = 14;
    const planY = y + 40;
    const planW = 362;
    const toolGap = 4;
    const toolH = 40;
    const toolY = y + h - toolH - 7;
    const planH = Math.max(150, toolY - planY - 7);

    this.drawFloorCanvas(
      ctx,
      metrics,
      floor,
      planX,
      planY,
      planW,
      planH
    );

    const tools = [
      ['page:zones', 'reno_prep', '分区'],
      ['page:furniture', 'reno_table_4', '家具'],
      [
        'page:style',
        V45_HALL_STYLE_VISUAL[metrics.plan.hallStyle] || 'reno_style_natural',
        '风格'
      ],
      ['page:rooms', 'reno_table_8', '包厢'],
      ['page:templates', 'reno_room_medium', '模板'],
      ['aisle:cycle', 'reno_corridor', '动线']
    ];

    const toolW =
      (
        planW -
        toolGap * (tools.length - 1)
      ) /
      tools.length;

    for (let i = 0; i < tools.length; i++) {
      this.drawToolButton(
        ctx,
        tools[i][0],
        tools[i][1],
        tools[i][2],
        planX + i * (toolW + toolGap),
        toolY,
        toolW,
        toolH,
        false
      );
    }
  }

`,
  'drawFloorPlan'
);

scene = replaceBetween(
  scene,
  '  drawTablePicker(',
  '  drawChairIcon(',
`  drawTablePicker(
    ctx,
    floor,
    geometry
  ) {
    const x = 7;
    const y = geometry.lowerY;
    const w = 207;
    const h = geometry.lowerH;

    ui.card(
      ctx,
      x,
      y,
      w,
      h,
      {
        radius: 13,
        fill: COLORS.panel,
        stroke: COLORS.line,
        shadow: false
      }
    );

    const keys = ['2', '4', '6', '8'];
    const totalTables = keys.reduce(
      (sum, key) =>
        sum + Math.max(0, Number(floor.tables[key]) || 0),
      0
    );
    const totalSeats = keys.reduce(
      (sum, key) =>
        sum +
        (Math.max(0, Number(floor.tables[key]) || 0) * Number(key)),
      0
    );

    this.text(
      ctx,
      '本层餐桌',
      x + 11,
      y + 15,
      7.7,
      COLORS.text,
      '800'
    );

    this.text(
      ctx,
      totalTables + '张 · ' + totalSeats + '席',
      x + w - 10,
      y + 15,
      5.0,
      COLORS.green,
      '800',
      'right'
    );

    const chipY = y + 27;
    const chipW = 43;

    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      const cx = x + 10 + i * 46;

      ui.card(
        ctx,
        cx,
        chipY,
        chipW,
        28,
        {
          radius: 8,
          fill: '#FFF8EA',
          stroke: '#E2D6C5',
          shadow: false
        }
      );

      this.text(
        ctx,
        key + '人×' + (Number(floor.tables[key]) || 0),
        cx + chipW / 2,
        chipY + 14,
        4.8,
        COLORS.navy,
        '800',
        'center'
      );
    }

    const buttonY = y + h - 31;

    ui.card(
      ctx,
      x + 10,
      buttonY,
      w - 20,
      25,
      {
        radius: 10,
        fill: '#FFE39A',
        stroke: '#E1B43A',
        shadow: false
      }
    );

    this.text(
      ctx,
      '编辑家具与餐桌  ›',
      x + w / 2,
      buttonY + 12.5,
      5.8,
      COLORS.text,
      '800',
      'center'
    );

    this.addButton(
      'page:furniture',
      x + 6,
      buttonY - 4,
      w - 12,
      33
    );
  }

`,
  'drawTablePicker'
);

scene = replaceBetween(
  scene,
  '  drawMetrics(',
  '  drawFooter(',
`  drawMetrics(
    ctx,
    metrics,
    geometry
  ) {
    const x = 219;
    const y = geometry.lowerY;
    const w = 164;
    const h = geometry.lowerH;

    ui.card(
      ctx,
      x,
      y,
      w,
      h,
      {
        radius: 13,
        fill: COLORS.panel,
        stroke: COLORS.line,
        shadow: false
      }
    );

    const floor =
      metrics.floors[
        metrics.plan.activeFloor
      ];

    this.text(
      ctx,
      '空间状态',
      x + 11,
      y + 15,
      7.7,
      COLORS.text,
      '800'
    );

    ui.card(
      ctx,
      x + 103,
      y + 6,
      50,
      20,
      {
        radius: 10,
        fill: floor.valid ? '#E8F7EF' : '#FFF0EA',
        stroke: floor.valid ? '#B9DDC7' : '#E8B3A9',
        shadow: false
      }
    );

    this.text(
      ctx,
      floor.valid ? '可施工' : '需调整',
      x + 128,
      y + 16,
      4.7,
      floor.valid ? COLORS.green : COLORS.red,
      '800',
      'center'
    );

    const rows = [
      ['本层面积', floor.area + '㎡'],
      ['可摆面积', floor.effectiveDiningArea + '㎡'],
      ['剩余面积', floor.remainingArea + '㎡']
    ];

    for (let i = 0; i < rows.length; i++) {
      const ry = y + 36 + i * 22;

      this.text(
        ctx,
        rows[i][0],
        x + 12,
        ry,
        4.8,
        COLORS.muted,
        '700'
      );

      this.text(
        ctx,
        rows[i][1],
        x + w - 11,
        ry,
        5.7,
        i === 2 && floor.remainingArea < 0
          ? COLORS.red
          : COLORS.navy,
        '800',
        'right'
      );
    }

    if (!floor.valid && floor.areaWarnings && floor.areaWarnings[0]) {
      this.text(
        ctx,
        floor.areaWarnings[0],
        x + 12,
        y + h - 8,
        4.1,
        COLORS.red,
        '700'
      );
    }
  }

`,
  'drawMetrics'
);

scene = replaceBetween(
  scene,
  '  renderFurniture(',
  '  renderStyle(',
`  renderFurniture(
    ctx,
    metrics,
    floor
  ) {
    const shell =
      this.drawSecondaryShell(
        ctx,
        '家具与软装',
        '餐桌自动落到可用餐位点；按钮状态会直接告诉你还能不能放'
      );

    const floorMetric =
      metrics.floors.find(
        value => value.index === floor.index
      ) ||
      metrics.floors[metrics.plan.activeFloor];

    const keys = ['2', '4', '6', '8'];
    const totalTables = keys.reduce(
      (sum, key) =>
        sum + Math.max(0, Number(floor.tables[key]) || 0),
      0
    );
    const slotCount =
      floorMetric &&
      floorMetric.usableDiningSlots
        ? floorMetric.usableDiningSlots.length
        : 0;

    let y = shell.y;

    ui.card(
      ctx,
      16,
      y,
      358,
      45,
      {
        radius: 11,
        fill: '#EFF7FA',
        stroke: '#C5DDE8',
        shadow: false
      }
    );

    this.text(
      ctx,
      '本层 ' + totalTables + '/' + slotCount + ' 个餐桌落位点',
      28,
      y + 16,
      6.1,
      COLORS.navy,
      '800'
    );

    this.text(
      ctx,
      '可摆 ' + floorMetric.effectiveDiningArea +
        '㎡ · 已用 ' + floorMetric.occupiedArea +
        '㎡ · 剩余 ' + floorMetric.remainingArea + '㎡',
      28,
      y + 34,
      4.8,
      floorMetric.remainingArea >= 0 ? COLORS.green : COLORS.red,
      '700'
    );

    y += 53;

    const cardGap = 8;
    const cardW = 171;
    const cardH = 73;

    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      const col = i % 2;
      const row = Math.floor(i / 2);
      const x = 16 + col * (cardW + cardGap);
      const cardY = y + row * (cardH + cardGap);
      const count = Number(floor.tables[key]) || 0;
      const extraArea =
        (renovationConfig.tableFootprint[key] || 0) *
        (floorMetric.aisle ? floorMetric.aisle.areaFactor : 1);
      const canAdd =
        totalTables < slotCount &&
        floorMetric.occupiedArea + extraArea <=
          floorMetric.effectiveDiningArea + 0.01;

      ui.card(
        ctx,
        x,
        cardY,
        cardW,
        cardH,
        {
          radius: 11,
          fill: '#FFF9EF',
          stroke: canAdd ? '#DFD5C8' : '#DDD7CF',
          shadow: false
        }
      );

      this.drawImageContain(
        ctx,
        'reno_table_' + key,
        x + 7,
        cardY + 8,
        62,
        50,
        1
      );

      this.text(
        ctx,
        key + '人桌',
        x + 79,
        cardY + 16,
        5.9,
        COLORS.text,
        '800'
      );

      this.text(
        ctx,
        '已摆 ' + count + ' 张',
        x + 79,
        cardY + 33,
        4.8,
        COLORS.muted,
        '700'
      );

      const minusX = x + 79;
      const plusX = x + 126;
      const buttonY = cardY + 42;

      ui.card(
        ctx,
        minusX,
        buttonY,
        39,
        25,
        {
          radius: 9,
          fill: count > 0 ? '#F2EEE7' : '#ECE9E4',
          stroke: '#D7CCBC',
          shadow: false
        }
      );

      ui.card(
        ctx,
        plusX,
        buttonY,
        39,
        25,
        {
          radius: 9,
          fill: canAdd ? '#FFE49A' : '#E8E4DC',
          stroke: canAdd ? '#E1B43A' : '#D3CDC4',
          shadow: false
        }
      );

      this.text(
        ctx,
        '−',
        minusX + 19.5,
        buttonY + 12.5,
        8.3,
        count > 0 ? COLORS.navy : COLORS.muted,
        '800',
        'center'
      );

      this.text(
        ctx,
        '+',
        plusX + 19.5,
        buttonY + 12.5,
        8.3,
        canAdd ? COLORS.navy : COLORS.muted,
        '800',
        'center'
      );

      this.addButton(
        'table:' + key + ':minus',
        minusX - 4,
        buttonY - 5,
        47,
        35
      );

      this.addButton(
        'table:' + key + ':plus',
        plusX - 4,
        buttonY - 5,
        47,
        35
      );
    }

    const decorY = y + 2 * (cardH + cardGap) + 4;

    this.text(
      ctx,
      '软装',
      19,
      decorY + 8,
      7.2,
      COLORS.text,
      '800'
    );

    const items = renovationConfig.decorItems || [];
    const itemY = decorY + 18;

    for (let i = 0; i < Math.min(items.length, 4); i++) {
      const item = items[i];
      const x = 16 + i * 89;
      const count =
        Number(metrics.decorCounts && metrics.decorCounts[item.id]) || 0;
      const imageMap = {
        plant: 'reno_plant_1',
        pendant: 'reno_pendant',
        screen: 'reno_screen',
        sofa: 'reno_sofa'
      };

      ui.card(
        ctx,
        x,
        itemY,
        82,
        68,
        {
          radius: 10,
          fill: '#FFF9EF',
          stroke: '#DFD5C8',
          shadow: false
        }
      );

      this.drawImageContain(
        ctx,
        imageMap[item.id] || 'reno_plant_1',
        x + 7,
        itemY + 5,
        35,
        31,
        1
      );

      this.text(
        ctx,
        item.name,
        x + 60,
        itemY + 15,
        4.6,
        COLORS.text,
        '800',
        'center'
      );

      this.text(
        ctx,
        '×' + count,
        x + 60,
        itemY + 31,
        5.0,
        COLORS.navy,
        '800',
        'center'
      );

      this.text(ctx, '−', x + 19, itemY + 53, 7.4, COLORS.navy, '800', 'center');
      this.text(ctx, '+', x + 63, itemY + 53, 7.4, COLORS.navy, '800', 'center');

      this.addButton('decor:' + item.id + ':minus', x + 1, itemY + 36, 36, 31);
      this.addButton('decor:' + item.id + ':plus', x + 45, itemY + 36, 36, 31);
    }

    const impactY = itemY + 76;

    ui.card(
      ctx,
      16,
      impactY,
      358,
      48,
      {
        radius: 11,
        fill: '#FFF6DD',
        stroke: '#E3C36B',
        shadow: false
      }
    );

    this.text(
      ctx,
      '装修评分 ' + metrics.renovationScore +
        ' · 软装 ' + money(metrics.decorCost),
      28,
      impactY + 16,
      6.4,
      COLORS.text,
      '800'
    );

    this.text(
      ctx,
      '客流 ×' + metrics.operatingImpact.trafficFactor.toFixed(2) +
        ' · 客单 ×' + metrics.operatingImpact.spendFactor.toFixed(2) +
        ' · 服务 ×' + metrics.operatingImpact.serviceFactor.toFixed(2),
      28,
      impactY + 34,
      4.8,
      COLORS.muted,
      '700'
    );
  }

`,
  'renderFurniture'
);

// 默认页不再渲染高占用的模板条；模板改为平面图底部的独立入口。
scene = scene.replace(
`    if (this.viewH >= 700) {
      this.drawTemplateStrip(
        ctx,
        plan
      );
    }
`,
`    // V0850：模板条从默认装修页移出，主平面图优先。
`
);

// 拖动时显示实时反馈卡片。
const interactionAnchor = '    this.floorCanvasInteraction = {';
if (!scene.includes('V0850_DRAG_LIVE_FEEDBACK')) {
  if (!scene.includes(interactionAnchor)) throw new Error('找不到 floorCanvasInteraction 锚点');
  scene = scene.replace(
    interactionAnchor,
`    // V0850_DRAG_LIVE_FEEDBACK
    if (
      this.areaDrag &&
      this.areaDrag.floorIndex === floor.index
    ) {
      const liveLabel =
        this.areaDrag.type === 'back'
          ? '正在调整 后厨/后区'
          : this.areaDrag.type === 'kitchen-storage'
            ? '正在调整 后厨/仓储'
            : '正在调整 服务/堂食';

      ui.card(
        ctx,
        frame.x + Math.max(5, frame.w - 128),
        frame.y + Math.max(5, frame.h - 29),
        122,
        23,
        {
          radius: 10,
          fill: 'rgba(255,244,213,0.96)',
          stroke: '#E2B843',
          shadow: false
        }
      );

      this.text(
        ctx,
        liveLabel,
        frame.x + frame.w - 67,
        frame.y + frame.h - 17.5,
        4.7,
        COLORS.navy,
        '800',
        'center'
      );
    }

` + interactionAnchor
  );
}

scene = replaceBetween(
  scene,
  '  handleTouchStart(',
  '  handleTouchMove(',
`  handleTouchStart(
    x,
    y
  ) {
    const data =
      this.floorCanvasInteraction;

    if (
      !data ||
      this.page !== 'layout' ||
      this.previewMode
    ) {
      return false;
    }

    const frame = data.frame;

    if (
      x < frame.x - 8 ||
      x > frame.x + frame.w + 8 ||
      y < frame.y - 8 ||
      y > frame.y + frame.h + 8
    ) {
      return false;
    }

    const horizontalY = frame.y + frame.h * data.backRatio;
    const topSplitX = frame.x + frame.w * data.kitchenWidthRatio;
    const serviceSplitX = frame.x + frame.w * data.serviceWidthRatio;

    let type = null;
    const hit = 26;

    if (Math.abs(y - horizontalY) <= hit) {
      type = 'back';
    } else if (
      y < horizontalY + 8 &&
      Math.abs(x - topSplitX) <= hit
    ) {
      type = 'kitchen-storage';
    } else if (
      y > horizontalY - 8 &&
      Math.abs(x - serviceSplitX) <= hit
    ) {
      type = 'service';
    }

    if (!type) {
      return false;
    }

    const plan = this.getPlan();

    renovationSystem.mutatePlan(
      this.shopId,
      () => {},
      { skipHistory: false }
    );

    this.areaDrag = {
      type,
      floorIndex: data.floorIndex,
      start: {
        kitchenRatio: plan.floors[data.floorIndex].kitchenRatio,
        storageRatio: plan.floors[data.floorIndex].storageRatio,
        serviceRatio: plan.floors[data.floorIndex].serviceRatio
      }
    };

    this.requestRenderNow();
    return true;
  }

`,
  'handleTouchStart'
);

scene = replaceBetween(
  scene,
  '  handleTouchMove(',
  '  handleTouchEnd() {',
`  handleTouchMove(
    x,
    y
  ) {
    if (
      !this.areaDrag ||
      !this.floorCanvasInteraction
    ) {
      return false;
    }

    const drag = this.areaDrag;
    const frame = this.floorCanvasInteraction.frame;
    const values = { ...drag.start };

    if (drag.type === 'back') {
      const back = clamp(
        (y - frame.y) / frame.h,
        renovationConfig.zoneRules.minKitchenRatio +
          renovationConfig.zoneRules.minStorageRatio,
        1 -
          renovationConfig.zoneRules.minDiningRatio -
          values.serviceRatio
      );

      values.kitchenRatio =
        back - values.storageRatio;
    } else if (drag.type === 'kitchen-storage') {
      const back = values.kitchenRatio + values.storageRatio;

      values.kitchenRatio = clamp(
        ((x - frame.x) / frame.w) * back,
        renovationConfig.zoneRules.minKitchenRatio,
        Math.min(
          renovationConfig.zoneRules.maxKitchenRatio,
          back - renovationConfig.zoneRules.minStorageRatio
        )
      );

      values.storageRatio =
        back - values.kitchenRatio;
    } else {
      const lower =
        1 - values.kitchenRatio - values.storageRatio;

      values.serviceRatio = clamp(
        ((x - frame.x) / frame.w) * lower,
        renovationConfig.zoneRules.minServiceRatio,
        Math.min(
          renovationConfig.zoneRules.maxServiceRatio,
          lower - renovationConfig.zoneRules.minDiningRatio
        )
      );
    }

    renovationSystem.setZoneRatios(
      this.shopId,
      drag.floorIndex,
      values,
      { skipHistory: true }
    );

    this.requestRenderNow();
    return true;
  }

`,
  'handleTouchMove'
);

scene = replaceBetween(
  scene,
  '  handleTouchEnd() {',
  '\n}\n\nmodule.exports',
`  handleTouchEnd() {
    if (!this.areaDrag) {
      return false;
    }

    this.areaDrag = null;
    saveSystem.autoSave(true);
    this.requestRenderNow();
    return true;
  }
`,
  'handleTouchEnd'
);

// 让家具操作的成功/失败都得到明确反馈，并立即重绘。
const oldTableSuccess = `      if (\n        delta > 0 &&\n        afterCount <=\n          beforeCount\n      ) {`;
if (!scene.includes(oldTableSuccess)) throw new Error('找不到餐桌反馈逻辑');

scene = scene.replace(
`      } else {
        saveSystem
          .autoSave(true);
      }

      return true;
    }

    if (
      id.indexOf(
        'zone:'
      ) ===
      0
    ) {`,
`      } else if (
        delta < 0 &&
        beforeCount <= 0
      ) {
        this.showToast(
          '当前没有' + tableKey + '人桌可移除'
        );
      } else {
        saveSystem.autoSave(true);
        this.showToast(
          delta > 0
            ? '已添加' + tableKey + '人桌 · 本层共' + afterCount + '张'
            : '已移除' + tableKey + '人桌 · 本层剩' + afterCount + '张'
        );
      }

      this.requestRenderNow();
      return true;
    }

    if (
      id.indexOf(
        'zone:'
      ) ===
      0
    ) {`
);

// Android：touchend + touchcancel 统一收尾，避免手指滑出/系统打断后卡在拖动状态。
android = replaceBetween(
  android,
  '  onTouchEnd(callback) {',
  '  showToast(options) {',
`  onTouchEnd(callback) {
    if (typeof callback !== 'function') {
      return;
    }

    function finishTouch(event) {
      lastTouchAt = Date.now();

      if (event.cancelable) {
        event.preventDefault();
      }

      const changed =
        event.changedTouches &&
        event.changedTouches.length
          ? event.changedTouches
          : [
              {
                clientX: 0,
                clientY: 0
              }
            ];

      callback({
        changedTouches: changed,
        cancelled: event.type === 'touchcancel'
      });
    }

    canvas.addEventListener(
      'touchend',
      finishTouch,
      { passive: false }
    );

    canvas.addEventListener(
      'touchcancel',
      finishTouch,
      { passive: false }
    );

    canvas.addEventListener(
      'click',
      function (event) {
        if (Date.now() - lastTouchAt < 700) {
          return;
        }

        callback({
          changedTouches: [
            {
              clientX: event.clientX,
              clientY: event.clientY
            }
          ]
        });
      }
    );
  },

`,
  'android onTouchEnd'
);

if (!android.includes('V0850_FINAL_RENOVATION_TOUCH_GUARD')) {
  android = android.replace(
    '// V0849_HOTFIX_TOUCH_BRIDGE',
    '// V0849_HOTFIX_TOUCH_BRIDGE\n// V0850_FINAL_RENOVATION_TOUCH_GUARD'
  );
}

const testSource = `'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const androidSource = fs.readFileSync(path.join(ROOT, 'android/entry.js'), 'utf8');
const sceneSource = fs.readFileSync(path.join(ROOT, 'src/scenes/renovationScene.js'), 'utf8');

for (const token of [
  'V0850_FINAL_RENOVATION_MOBILE_FIX',
  'V0850_DRAG_LIVE_FEEDBACK',
  'requestRenderNow()',
  "['page:templates', 'reno_room_medium', '模板']",
  '本层餐桌',
  '空间状态'
]) {
  assert.ok(sceneSource.includes(token), '最终装修修复缺失：' + token);
}

for (const token of [
  'V0850_FINAL_RENOVATION_TOUCH_GUARD',
  "'touchcancel'",
  'cancelled:'
]) {
  assert.ok(androidSource.includes(token), 'Android触控收尾缺失：' + token);
}

let height = 780;
let renderRequests = 0;

globalThis.GameRuntime = {
  api: {
    getSystemInfoSync() {
      return { windowWidth: 390, windowHeight: height };
    },
    showToast() {},
    setStorageSync() {},
    getStorageSync() { return null; }
  },
  requestRender() {
    renderRequests += 1;
  }
};

const gameState = require('../src/core/gameState.js');
const scene = require('../src/scenes/renovationScene.js');
const renovationSystem = require('../src/renovation/renovationSystem.js');

gameState.reset();
gameState.setCash(1000000);
gameState.addShop({
  id: 'v0850_final_shop',
  name: '最终装修测试店',
  status: 'leased_pending_renovation',
  grossArea: 128,
  usableArea: 108,
  floor: '1层',
  frontage: 8
});

scene.shopId = 'v0850_final_shop';
scene.page = 'layout';
scene.previewMode = false;

const gradient = { addColorStop() {} };
const ctx = new Proxy({}, {
  get(target, key) {
    if (key === 'createLinearGradient' || key === 'createRadialGradient') {
      return () => gradient;
    }
    if (key === 'measureText') {
      return value => ({ width: String(value).length * 5 });
    }
    if (!target[key]) target[key] = () => {};
    return target[key];
  },
  set(target, key, value) {
    target[key] = value;
    return true;
  }
});

function overlaps(buttons) {
  const found = [];
  for (let i = 0; i < buttons.length; i++) {
    for (let j = i + 1; j < buttons.length; j++) {
      const a = buttons[i];
      const b = buttons[j];
      const w = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
      const h = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
      if (w > 2 && h > 2) found.push([a.id, b.id]);
    }
  }
  return found;
}

for (const viewportHeight of [780, 667, 600]) {
  height = viewportHeight;
  scene.page = 'layout';
  scene.render(ctx);
  assert.deepStrictEqual(overlaps(scene.buttons), [], viewportHeight + 'px 主装修页点击区不能重叠');
  const geometry = scene.getMainGeometry();
  assert.ok(geometry.y >= 94, '装修主体不得侵入顶部');
  assert.ok(geometry.planH >= 250, '主平面图必须获得足够编辑高度');
}

height = 780;
scene.page = 'layout';
scene.render(ctx);

assert.ok(scene.buttons.some(item => item.id === 'page:furniture'), '主页面必须有家具入口');
assert.ok(scene.buttons.some(item => item.id === 'page:templates'), '主页面必须有模板入口');
assert.ok(scene.buttons.some(item => item.id === 'floor:next'), '主页面必须有楼层入口');
assert.ok(!scene.buttons.some(item => item.id.indexOf('table:') === 0), '主页面不再使用误触式点图加桌');

const interaction = scene.floorCanvasInteraction;
const dividerY = interaction.frame.y + interaction.frame.h * interaction.backRatio;
const beforeRender = renderRequests;
const beforeMetrics = renovationSystem.getMetrics('v0850_final_shop').floors[0];

assert.ok(scene.handleTouchStart(interaction.frame.x + 90, dividerY), '大触控区必须能抓住分区线');
assert.ok(scene.handleTouchMove(interaction.frame.x + 90, dividerY + 18), '拖动必须实时更新');
assert.ok(renderRequests > beforeRender, '拖动时必须立即请求重绘');
assert.ok(scene.handleTouchEnd(), '拖动结束必须正常提交');

const afterMetrics = renovationSystem.getMetrics('v0850_final_shop').floors[0];
assert.notStrictEqual(afterMetrics.kitchenRatio, beforeMetrics.kitchenRatio, '拖动后面积比例必须变化');
assert.ok(afterMetrics.valid, '拖动后方案仍需满足面积规则');

scene.page = 'furniture';
scene.render(ctx);
assert.deepStrictEqual(overlaps(scene.buttons), [], '家具页面点击区不能重叠');
for (const key of ['2', '4', '6', '8']) {
  assert.ok(scene.buttons.some(item => item.id === 'table:' + key + ':plus'), key + '人桌必须有加号');
  assert.ok(scene.buttons.some(item => item.id === 'table:' + key + ':minus'), key + '人桌必须有减号');
}

console.log('V0.8.50 final renovation mobile interaction tests passed');
`;

write(TEST, testSource);

if (!runner.includes('tests/renovationFinalFixV0850.test.js')) {
  const token = "    'tests/renovationHotfixV0849.test.js',";
  if (!runner.includes(token)) throw new Error('找不到测试插入点');
  runner = runner.replace(
    token,
    token + "\n    'tests/renovationFinalFixV0850.test.js',"
  );
}

write(SCENE, scene);
write(ANDROID, android);
write(RUNNER, runner);

write(
  MANIFEST,
  JSON.stringify(
    {
      id: 'V0850_FINAL_RENOVATION_MOBILE_FIX',
      baseVersion: '0.8.49',
      targetVersion: '0.8.49',
      hotfixRevision: 3,
      category: '装修页面最终交互与手机布局修复（回归兼容修正版）',
      features: [
        '默认页移除高占用模板条，主平面图扩展为核心操作区',
        '主页面取消误触式点图加桌，统一进入家具编辑页',
        '家具页增加餐桌落位点、已用面积、剩余面积实时状态',
        '餐桌加减按钮扩大并显示是否还能继续放置',
        '分区拖动触控容差扩大到26px并实时强制重绘',
        '拖动中显示正在调整的区域反馈',
        'Android增加touchcancel收尾，避免拖动状态卡死',
        '600/667/780手机高度点击区回归测试',
        '保留真实房源面积、户型、障碍物与落位点约束'
      ],
      workflowSafe: true,
      containsPackageJson: false,
      containsPackageLock: false,
      containsWorkflowFiles: false
    },
    null,
    2
  ) + '\n'
);

console.log('V0850 final renovation mobile fix applied');
