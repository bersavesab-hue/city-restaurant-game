'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BASE_VERSION = '0.8.44';
const TARGET_VERSION = '0.8.46';

function fp(rel) {
  return path.join(ROOT, rel);
}

function read(rel) {
  return fs.readFileSync(fp(rel), 'utf8');
}

function write(rel, content) {
  const full = fp(rel);
  fs.mkdirSync(path.dirname(full), { recursive:true });
  fs.writeFileSync(full, content, 'utf8');
}

function replaceExact(rel, before, after, label) {
  const source = read(rel);
  const count = source.split(before).length - 1;

  if (count !== 1) {
    throw new Error(
      `[V0846] ${label || rel}: expected exactly 1 match, found ${count}`
    );
  }

  write(rel, source.replace(before, after));
}

function updateJson(rel, updater) {
  const data = JSON.parse(read(rel));
  updater(data);
  write(rel, JSON.stringify(data, null, 2) + '\n');
}

const pkgBefore = JSON.parse(read('package.json'));
if (pkgBefore.version !== BASE_VERSION) {
  throw new Error(
    `[V0846] base version mismatch: expected ${BASE_VERSION}, got ${pkgBefore.version}`
  );
}

/* =========================================================
   A. V0.8.45 原计划：首店聚焦，避免开局入口过载
========================================================= */

replaceExact(
  'src/core/featureAccessPolicyV0837.js',
`    if (
      SHOP_REQUIRED.includes(
        id
      ) ||
      NO_SHOP_ALLOWED.includes(
        id
      )
    ) {
      return {
        allowed:true,
        routeId:id,
        state:'available',
        reason:null,
        recommended:
          clone(recommended)
      };
    }`,
`    if (
      NO_SHOP_ALLOWED.includes(
        id
      )
    ) {
      return {
        allowed:true,
        routeId:id,
        state:'available',
        reason:null,
        recommended:
          clone(recommended)
      };
    }

    if (
      SHOP_REQUIRED.includes(
        id
      )
    ) {
      const stage =
        String(
          flow.stage ||
          ''
        );

      const preparationRoutes = [
        'shop',
        'renovation',
        'equipment',
        'license',
        'staff'
      ];

      const trialRoutes = [
        'research',
        'supply',
        'schedule',
        'business'
      ];

      const trialUnlocked =
        [
          'trial',
          'formal_open',
          'complete'
        ].includes(
          stage
        );

      const available =
        preparationRoutes.includes(
          id
        ) ||
        (
          trialUnlocked &&
          trialRoutes.includes(
            id
          )
        ) ||
        (
          id ===
            'staffCareer' &&
          stage ===
            'complete'
        );

      if (available) {
        return {
          allowed:true,
          routeId:id,
          state:'available',
          reason:null,
          recommended:
            clone(recommended)
        };
      }

      return {
        allowed:false,
        routeId:id,
        state:'blocked',
        code:
          'OPENING_FOCUS_REQUIRED',
        reason:
          id ===
            'staffCareer'
            ? '团队成长会在首店正式开业后开放'
            : '菜单、供应链、排班和经营数据会在首店试营业阶段开放；当前先完成开店筹备',
        recommended:
          clone(recommended)
      };
    }`,
  'opening-stage access gate'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
  "opUi.header(ctx, '功能中心', '统一入口 · 所有核心功能从这里直达');",
  "opUi.header(ctx, '功能中心', '按经营阶段逐步开放 · 当前只突出真正需要的功能');",
  'feature hub header'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
`    const status = entryRouter.diagnose();

    ui.card(`,
`    const status = entryRouter.diagnose();

    const accessRows =
      ITEMS.map(
        item => ({
          item,
          access:
            entryRouter
              .getGuardStatus(
                item[0],
                {}
              )
        })
      );

    const availableCount =
      accessRows.filter(
        row =>
          row.access &&
          row.access.allowed
      ).length;

    const lockedCount =
      accessRows.length -
      availableCount;

    ui.card(`,
  'feature hub access summary'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
  "      '路由 ' + status.routeCount + ' 项 · 历史 ' + status.historyDepth + ' 层',",
  "      '可用 ' + availableCount + ' 项 · 待解锁 ' + lockedCount + ' 项',",
  'feature hub count'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
`      status.missing.length
        ? '有 ' + status.missing.length + ' 个入口尚未注册'
        : '入口检测正常',`,
`      status.missing.length
        ? '有 ' + status.missing.length + ' 个入口尚未注册'
        : '锁定入口会随首店经营进度自动开放',`,
  'feature hub status'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
`    ITEMS.forEach((item, index) => {
      const col = index % 2;`,
`    ITEMS.forEach((item, index) => {
      const access =
        entryRouter
          .getGuardStatus(
            item[0],
            {}
          );

      const locked =
        !access ||
        !access.allowed;

      const col = index % 2;`,
  'feature hub item access'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
`          fill: '#FFFDF8',
          stroke: '#D9D0C4',
          shadow: false`,
`          fill:
            locked
              ? '#F0F1ED'
              : '#FFFDF8',
          stroke:
            locked
              ? '#D4D7D2'
              : '#D9D0C4',
          shadow: false`,
  'feature hub locked card'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
`        item[1],
        x + 14,
        y + 21,
        8.3,
        '#173D54',
        '800'`,
`        item[1],
        x + 14,
        y + 21,
        8.3,
        locked
          ? '#7D8588'
          : '#173D54',
        '800'`,
  'feature hub locked title'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
`        item[0],
        x + 14,
        y + 41,
        5.8,
        '#7A8A92',
        '600'`,
`        locked
          ? '待解锁'
          : item[0],
        x + 14,
        y + 41,
        5.8,
        locked
          ? '#9A9F9F'
          : '#7A8A92',
        '600'`,
  'feature hub locked subtitle'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
`        '›',
        x + cellW - 16,
        y + cellH / 2,
        13,
        '#D99D2D',
        '800',`,
`        locked
          ? '锁'
          : '›',
        x + cellW - 16,
        y + cellH / 2,
        locked
          ? 7
          : 13,
        locked
          ? '#929999'
          : '#D99D2D',
        '800',`,
  'feature hub lock glyph'
);

replaceExact(
  'src/scenes/featureHubSceneV0810.js',
`      if (!ok && api && typeof api.showToast === 'function') {
        api.showToast({
          title: '入口暂不可用',
          icon: 'none'
        });
      }`,
`      if (!ok && api && typeof api.showToast === 'function') {
        const error =
          entryRouter
            .getLastError();

        api.showToast({
          title:
            error &&
            error.reason ||
            '入口暂不可用',
          icon: 'none'
        });
      }`,
  'feature hub blocked reason'
);

replaceExact(
  'src/scenes/newGameSceneV0814.js',
  "'从一座城市、一笔启动资金和第一家店开始'",
  "'从第一家小餐馆起步，靠选址和经营判断把生意做起来'",
  'new game pitch'
);

replaceExact(
  'src/scenes/newGameSceneV0814.js',
  "'首店路线'",
  "'首店主线'",
  'new game route title'
);

replaceExact(
  'src/scenes/newGameSceneV0814.js',
`      ['1','选商圈与找铺','客流、租金、竞争和风险会影响后续经营'],
      ['2','谈租约与装修','签约后按真实游戏时间施工'],
      ['3','设备、证照、招聘','筹备状态会跟随统一时间轴推进'],
      ['4','试营业','连续经营3天，产生真实经营数据'],
      ['5','正式开业','首店进入长期经营循环']`,
`      ['1','选址落脚','比较租金、客群和经营方向，签下第一家店'],
      ['2','基础筹备','装修、设备、证照和班组按目标逐步完成'],
      ['3','开始试营业','准备完成即可接待真实顾客，马上看到营业额和成本'],
      ['4','连续3天复盘','用真实经营数据调整菜单、备货和服务'],
      ['5','正式开业','确认经营方向后进入长期经营循环']`,
  'new game opening steps'
);

replaceExact(
  'src/main.js',
`    if (
      sceneManager
        .switchTo(
          sceneId
        )
    ) {
      render();
    }

    return;`,
`    if (
      sceneManager
        .switchTo(
          sceneId
        )
    ) {
      render();
      return;
    }

    const routeError =
      entryRouter
        .getLastError();

    showToast(
      routeError &&
      routeError.reason ||
      '该功能暂未解锁'
    );

    render();
    return;`,
  'bottom nav blocked feedback'
);

replaceExact(
  'tests/featureAccessPolicyV0837.test.js',
`for (
  const route
  of [
    'shop',
    'renovation',
    'equipment',
    'license',
    'staff',
    'research',
    'supply',
    'business'
  ]
) {
  assert.ok(
    policy
      .evaluate(
        route
      )
      .allowed,
    route
  );
}

const diagnostic =
  policy
    .diagnose([
      {
        id:'city'
      },
      {
        id:'shop'
      },
      {
        id:'staff'
      }
    ]);

assert.equal(
  diagnostic.available,
  3
);

assert.equal(
  diagnostic.blocked,
  0
);`,
`for (
  const route
  of [
    'shop',
    'renovation',
    'equipment',
    'license',
    'staff'
  ]
) {
  assert.ok(
    policy
      .evaluate(
        route
      )
      .allowed,
    route
  );
}

for (
  const route
  of [
    'research',
    'supply',
    'schedule',
    'business',
    'staffCareer'
  ]
) {
  const result =
    policy
      .evaluate(
        route
      );

  assert.equal(
    result.allowed,
    false,
    route
  );

  assert.equal(
    result.code,
    'OPENING_FOCUS_REQUIRED',
    route
  );
}

stage =
  'trial';

for (
  const route
  of [
    'research',
    'supply',
    'schedule',
    'business'
  ]
) {
  assert.ok(
    policy
      .evaluate(
        route
      )
      .allowed,
    route
  );
}

assert.equal(
  policy
    .evaluate(
      'staffCareer'
    )
    .allowed,
  false
);

stage =
  'complete';

assert.ok(
  policy
    .evaluate(
      'staffCareer'
    )
    .allowed
);

stage =
  'renovation';

const diagnostic =
  policy
    .diagnose([
      {
        id:'city'
      },
      {
        id:'shop'
      },
      {
        id:'staffCareer'
      }
    ]);

assert.equal(
  diagnostic.available,
  2
);

assert.equal(
  diagnostic.blocked,
  1
);`,
  'feature access stage tests'
);

/* =========================================================
   B. V0.8.46：试营业阶段真正能进入营业日，并统一实时经营数据
========================================================= */

replaceExact(
  'src/scenes/businessScene.js',
`    const source =
      active
        ? active.visits
        : latest &&
          latest.financial ||
          {};`,
`    const dashboard =
      operations
        .dashboard(
          shop.id
        );

    const liveFinance =
      dashboard &&
      dashboard.finance
        ? dashboard.finance
        : {};

    const operational =
      [
        'open',
        'trial_opening'
      ].includes(
        shop.status
      );

    const source =
      operational
        ? liveFinance
        : latest &&
          latest.financial ||
          {};`,
  'business day live source'
);

replaceExact(
  'src/scenes/businessScene.js',
`      shop.status ===
        'open'
        ? '营业数据、决策和诊断会在日结时统一结算'
        : '门店正式营业后才能开启经营日',`,
`      shop.status ===
        'trial_opening'
        ? '试营业中 · 顾客订单、营业额和成本会实时计入今日经营'
        : shop.status ===
            'open'
          ? '营业数据、决策和诊断会在日结时统一结算'
          : '完成开店筹备后即可进入试营业',`,
  'trial operation helper'
);

replaceExact(
  'src/scenes/businessScene.js',
`    if (
      shop.status ===
      'open'
    ) {`,
`    if (
      operational
    ) {`,
  'trial operation button gate'
);

replaceExact(
  'src/scenes/businessScene.js',
`      active
        ? '今日有效订单'
        : '最近日结订单',
      String(
        Number(
          active
            ? source.success
            : source.orders
        ) ||
        0
      ),`,
`      operational
        ? '今日有效订单'
        : '最近日结订单',
      String(
        Number(
          source.orders
        ) ||
        0
      ),`,
  'live order metric'
);

replaceExact(
  'src/scenes/businessScene.js',
`      active
        ? '今日顾客'
        : '最近日结顾客',`,
`      operational
        ? '今日顾客'
        : '最近日结顾客',`,
  'live customer label'
);

replaceExact(
  'src/scenes/businessScene.js',
`      active
        ? '今日营业额'
        : '最近日结营收',`,
`      operational
        ? '今日营业额'
        : '最近日结营收',`,
  'live revenue label'
);

replaceExact(
  'src/scenes/businessScene.js',
`      active
        ? '今日贡献毛利'
        : '最近日结利润',
      opUi.money(
        Number(
          active
            ? source.contribution
            : source.profit
        ) ||
        0
      ),
      206,
      314,
      Number(
        active
          ? source.contribution
          : source.profit
      ) >= 0`,
`      operational
        ? '今日净利润'
        : '最近日结利润',
      opUi.money(
        Number(
          source.profit
        ) ||
        0
      ),
      206,
      314,
      Number(
        source.profit
      ) >= 0`,
  'live profit metric'
);

/* 让V0.8.44旧基础设施测试只验证“不得回退”，避免未来每升一版都误报失败。 */
replaceExact(
  'tests/updateInfrastructureV0844.test.js',
`assert.equal(
  pkg.version,
  '0.8.44'
);`,
`const versionParts =
  String(
    pkg.version ||
    '0.0.0'
  )
    .split('.')
    .map(
      value =>
        Number(value) ||
        0
    );

const versionNumber =
  (
    versionParts[0] || 0
  ) *
    1000000 +
  (
    versionParts[1] || 0
  ) *
    1000 +
  (
    versionParts[2] || 0
  );

assert.ok(
  versionNumber >=
    8044,
  '项目版本不得低于0.8.44'
);`,
  'future proof package version test'
);

replaceExact(
  'tests/updateInfrastructureV0844.test.js',
`assert.ok(
  gradle.includes(
    'versionCode 844'
  ) &&
  gradle.includes(
    "versionName '0.8.44'"
  )
);`,
`const versionCodeMatch =
  gradle.match(
    /versionCode\\s+(\\d+)/
  );

const versionNameMatch =
  gradle.match(
    /versionName\\s+'([^']+)'/
  );

assert.ok(
  versionCodeMatch &&
  Number(
    versionCodeMatch[1]
  ) >=
    844,
  'Android versionCode不得低于844'
);

assert.ok(
  versionNameMatch &&
  versionNameMatch[1] ===
    pkg.version,
  'Android versionName必须与package.json一致'
);`,
  'future proof android version test'
);

/* 将现有UI回归测试切到试营业状态，确保首次真实营业入口不会再次断开。 */
replaceExact(
  'tests/businessDayUiV0844.test.js',
  "  status:'open',",
  "  status:'trial_opening',",
  'trial business day fixture'
);

replaceExact(
  'tests/businessDayUiV0844.test.js',
`assert.ok(
  businessSource.includes(
    'renderOperatingDay'
  ) &&
  businessSource.includes(
    "id:'day'"
  )
);`,
`assert.ok(
  businessSource.includes(
    'renderOperatingDay'
  ) &&
  businessSource.includes(
    "id:'day'"
  ) &&
  businessSource.includes(
    "'trial_opening'"
  ) &&
  businessSource.includes(
    '.dashboard('
  ),
  '试营业必须能进入营业日，并读取真实运行时经营数据'
);`,
  'trial business day source assertions'
);

/* =========================================================
   C. 版本同步
========================================================= */

updateJson(
  'package.json',
  pkg => {
    pkg.version =
      TARGET_VERSION;
  }
);

updateJson(
  'package-lock.json',
  lock => {
    lock.version =
      TARGET_VERSION;

    if (
      lock.packages &&
      lock.packages['']
    ) {
      lock.packages[''].version =
        TARGET_VERSION;
    }
  }
);

replaceExact(
  'android/app/build.gradle',
`        versionCode 844
        versionName '0.8.44'`,
`        versionCode 846
        versionName '0.8.46'`,
  'android version'
);

replaceExact(
  'src/main.js',
  "'城市餐饮经营小游戏 V0.8.44 稳定接线修复版启动成功'",
  "'城市餐饮经营小游戏 V0.8.46 首店真实营业优化版启动成功'",
  'startup banner'
);

/* 上传包通用清单仅用于预检，不留在仓库；版本清单保留。 */
const genericManifest =
  fp(
    'PATCH_MANIFEST.json'
  );

if (
  fs.existsSync(
    genericManifest
  )
) {
  fs.rmSync(
    genericManifest,
    {
      force:true
    }
  );
}

console.log(
  '[V0846] 首店聚焦 + 试营业真实经营修复完成：' +
  BASE_VERSION +
  ' -> ' +
  TARGET_VERSION
);
