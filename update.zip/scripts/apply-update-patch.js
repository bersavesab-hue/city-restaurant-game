'use strict';

// V0851_HEALING_INSTALLER
// Designed to recover from a failed/partial V0.8.50 install.

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const TARGET = '0.8.51';
const OPS = 'src/operations/operationsStoreV080.js';
const BUSINESS = 'src/scenes/businessScene.js';
const RESEARCH = 'src/scenes/researchScene.js';
const PRESTIGE = 'src/reputation/culinaryPrestigeSystemV0851.js';
const MAIN = 'src/main.js';
const GRADLE = 'android/app/build.gradle';
const RUNNER = 'scripts/run-ci-tests-v060.js';

const OPS_START = '/* V0851_CULINARY_PRESTIGE_BRIDGE */';
const OPS_END = '/* V0851_CULINARY_PRESTIGE_BRIDGE_END */';
const BIZ_START = '/* V0851_RANKING_BRIDGE */';
const BIZ_END = '/* V0851_RANKING_BRIDGE_END */';

const LEGACY_FILES = [
  'tests/culinaryPrestigeV085.test.js',
  'tests/culinaryUiV085.test.js',
  'tests/updateInfrastructureV0850.test.js'
];

function abs(rel){ return path.join(ROOT, rel); }
function exists(rel){ return fs.existsSync(abs(rel)); }
function read(rel){ return fs.readFileSync(abs(rel), 'utf8'); }
function write(rel, text){ fs.mkdirSync(path.dirname(abs(rel)), {recursive:true}); fs.writeFileSync(abs(rel), text, 'utf8'); }
function readJson(rel){ return JSON.parse(read(rel)); }
function writeJson(rel, value){ write(rel, JSON.stringify(value, null, 2) + '\n'); }
function syntax(rel){
  const r = cp.spawnSync(process.execPath, ['--check', abs(rel)], {cwd:ROOT, encoding:'utf8'});
  if (r.status !== 0) {
    process.stderr.write(r.stdout || '');
    process.stderr.write(r.stderr || '');
    throw new Error('语法检查失败：' + rel);
  }
}
function semverParts(v){ return String(v || '').split('.').map(x => Number(x) || 0); }
function acceptableBase(v){
  const [a,b,c] = semverParts(v);
  return a === 0 && b === 8 && c >= 44 && c <= 51;
}
function stripMarkedBlock(source, start, end){
  const a = source.indexOf(start);
  if (a < 0) return source;
  const b = source.indexOf(end, a);
  if (b < 0) {
    // A partial failed install: remove from marker to EOF rather than keeping corrupt tail.
    return source.slice(0, a).replace(/\s+$/, '') + '\n';
  }
  return source.slice(0, a).replace(/\s+$/, '') + '\n\n' + source.slice(b + end.length).replace(/^\s+/, '');
}
function stripLegacy(source, start, end){
  let out = source;
  while (out.includes(start)) out = stripMarkedBlock(out, start, end);
  return out;
}
function requireTokens(rel, tokens){
  const source = read(rel);
  for (const token of tokens) if (!source.includes(token)) throw new Error('底层接口缺失：' + rel + ' -> ' + token);
}

for (const rel of [OPS, BUSINESS, RESEARCH, PRESTIGE, MAIN, GRADLE, RUNNER, 'package.json']) {
  if (!exists(rel)) throw new Error('V0.8.51缺少必需文件：' + rel);
}

const pkgBefore = readJson('package.json');
if (!acceptableBase(pkgBefore.version)) {
  throw new Error('V0.8.51无法安全升级：当前 package.json=' + pkgBefore.version + '，支持 0.8.44 ~ 0.8.51');
}

requireTokens(OPS, [
  'function getRuntime(',
  'function estimateMenuItemCost(',
  'function recordFinanceExpense(',
  'function reputationSnapshot(',
  'function storeRankingSnapshot()',
  'module.exports = {'
]);
requireTokens(BUSINESS, ['class BusinessScene', 'renderRanking(', 'handleTap(', 'module.exports']);
requireTokens(RESEARCH, ["{id:'menu',name:'菜单'}", "{id:'awards',name:'奖项'}", 'culinaryPrestigeSystemV0851.js']);
requireTokens(PRESTIGE, ["const VERSION = '0.8.51'", 'function evaluateAwards(', 'function buildRanking(']);
requireTokens(RUNNER, ['V0851_AUTO_DISCOVERY_TEST_RUNNER', "filter(p => /\\.test\\.js$/i.test(p))"]);

const touched = new Map();
const deleted = new Map();
function remember(rel){ if (!touched.has(rel)) touched.set(rel, exists(rel) ? fs.readFileSync(abs(rel)) : null); }
function rememberDelete(rel){ if (!deleted.has(rel)) deleted.set(rel, exists(rel) ? fs.readFileSync(abs(rel)) : null); }
function rollback(){
  for (const [rel, buf] of touched.entries()) {
    if (buf === null) { try{ fs.unlinkSync(abs(rel)); }catch(_){} }
    else { fs.mkdirSync(path.dirname(abs(rel)), {recursive:true}); fs.writeFileSync(abs(rel), buf); }
  }
  for (const [rel, buf] of deleted.entries()) {
    if (buf !== null) { fs.mkdirSync(path.dirname(abs(rel)), {recursive:true}); fs.writeFileSync(abs(rel), buf); }
  }
}

const opsBridge = String.raw`
${OPS_START}
const __v0851Prestige = require('../reputation/culinaryPrestigeSystemV0851.js');

function __v0851Context(shopId, runtime) {
  const costs = {};
  for (const item of (runtime && runtime.menu) || []) {
    try { costs[item.id] = estimateMenuItemCost(shopId, item); } catch (_) { costs[item.id] = 0; }
  }
  let finance = null;
  let reputation = null;
  try { finance = settlementEngine.summary(runtime.ledger); } catch (_) {}
  try { reputation = reputationSnapshot(shopId); } catch (_) {}
  return {
    costByItem: costs,
    profitRate: finance && Number(finance.profitRate) || 0,
    reputation
  };
}

function __v0851Sync(shopId) {
  const runtime = getRuntime(shopId);
  if (!runtime) return null;
  return __v0851Prestige.overview(shopId, runtime, __v0851Context(shopId, runtime));
}

module.exports.culinaryPrestigeSnapshot = function culinaryPrestigeSnapshotV0851(shopId) {
  return __v0851Sync(shopId);
};

module.exports.improveCulinaryDish = function improveCulinaryDishV0851(shopId, menuItemId, actionId) {
  const runtime = getRuntime(shopId);
  if (!runtime) return {ok:false, reason:'门店不存在'};
  const item = (runtime.menu || []).find(x => x.id === menuItemId);
  if (!item) return {ok:false, reason:'菜品不存在'};
  const costEstimate = estimateMenuItemCost(shopId, item);
  const plan = __v0851Prestige.improvementPlan(shopId, item, actionId, costEstimate);
  if (!plan.ok) return plan;
  const spend = recordFinanceExpense(shopId, '菜品研发改良', plan.cost, {
    note: item.name + ' · ' + plan.action.name,
    referenceId: 'culinary_improve:' + menuItemId + ':' + actionId
  });
  if (spend && spend.ok === false) return {ok:false, reason:spend.reason || '研发资金不足'};
  const result = __v0851Prestige.applyImprovement(shopId, item, actionId, {paidCost:plan.cost, costEstimate});
  if (result.ok && runtime.shop) {
    const gain = Math.max(0, Number(result.after) - Number(result.before));
    runtime.shop.rating = Math.max(1, Math.min(5, (Number(runtime.shop.rating) || 4) + gain * 0.0015));
  }
  persist(shopId);
  return result;
};

module.exports.evaluateCulinaryAwards = function evaluateCulinaryAwardsV0851(shopId) {
  const runtime = getRuntime(shopId);
  if (!runtime) return {ok:false, reason:'门店不存在'};
  const result = __v0851Prestige.evaluateAwards(shopId, runtime, {context:__v0851Context(shopId, runtime)});
  persist(shopId);
  return result;
};

module.exports.holdCulinaryAwardCeremony = function holdCulinaryAwardCeremonyV0851(shopId) {
  const runtime = getRuntime(shopId);
  if (!runtime) return {ok:false, reason:'门店不存在'};
  const result = __v0851Prestige.holdAwardCeremony(shopId, runtime);
  persist(shopId);
  return result;
};

module.exports.culinaryRanking = function culinaryRankingV0851(shopId, options) {
  const runtime = getRuntime(shopId);
  if (!runtime) return null;
  let baseRows = [];
  try { baseRows = storeRankingSnapshot() || []; } catch (_) {}
  return __v0851Prestige.buildRanking(shopId, runtime, {...(options || {}), baseRows, context:__v0851Context(shopId, runtime)});
};

const __v0851OldCloseSafe = module.exports.closeOperatingDaySafe;
if (typeof __v0851OldCloseSafe === 'function') {
  module.exports.closeOperatingDaySafe = function closeOperatingDaySafeV0851(shopId, options) {
    const result = __v0851OldCloseSafe(shopId, options);
    if (result && result.ok) { try { __v0851Sync(shopId); } catch (_) {} }
    return result;
  };
}

// Important: preserve the real legacy signature (shopId, experience, options).
const __v0851OldManualReview = module.exports.recordManualReview;
if (typeof __v0851OldManualReview === 'function') {
  module.exports.recordManualReview = function recordManualReviewV0851(shopId, experience, options) {
    const result = __v0851OldManualReview(shopId, experience, options);
    try { __v0851Sync(shopId); } catch (_) {}
    return result;
  };
}
${OPS_END}
`;

const bizBridge = String.raw`
${BIZ_START}
const __v0851RankingSystem = require('../reputation/culinaryPrestigeSystemV0851.js');
const __v0851BusinessScene = module.exports;

if (__v0851BusinessScene && !__v0851BusinessScene.__v0851RankingInstalled) {
  __v0851BusinessScene.__v0851RankingInstalled = true;
  __v0851BusinessScene.rankCategory = __v0851BusinessScene.rankCategory || 'overall';
  __v0851BusinessScene.rankScope = __v0851BusinessScene.rankScope || 'district';

  __v0851BusinessScene.renderRanking = function renderRankingV0851(ctx, shop) {
    const ranking = operations.culinaryRanking(shop.id, {category:this.rankCategory, scope:this.rankScope});
    this.sectionCard(ctx, 14, 138, 362, 474, '动态排行榜 · 多维竞争');
    ui.text(ctx, '综合、口碑、菜品、性价比、效率、创新和势头分别竞争', 28, 168, 6.7, '#71858F', '600');

    opUi.pill(ctx, '商圈', 28, 184, 74, this.rankScope === 'district');
    opUi.pill(ctx, '城市', 108, 184, 74, this.rankScope === 'city');
    this.addButton('rankscope:district', 24, 180, 82, 34);
    this.addButton('rankscope:city', 104, 180, 82, 34);

    const cats = __v0851RankingSystem.RANK_CATEGORIES;
    for (let i = 0; i < cats.length; i++) {
      const col = i % 4, row = Math.floor(i / 4);
      const x = 28 + col * 82, y = 222 + row * 34;
      opUi.pill(ctx, cats[i].name, x, y, 76, this.rankCategory === cats[i].id);
      this.addButton('rankcat:' + cats[i].id, x - 3, y - 3, 82, 34);
    }

    if (!ranking) { ui.text(ctx, '暂无可用排名数据', 195, 340, 9, '#71858F', '700', 'center'); return; }
    let y = 306;
    for (const row of (ranking.rows || []).slice(0, 7)) {
      const mine = !!row.isPlayer;
      if (mine) ui.card(ctx, 22, y - 13, 346, 36, {radius:9,fill:'#FFF4C8',stroke:'#E5B64D',shadow:false});
      ui.text(ctx, '#' + row.rank, 30, y, 7.5, row.rank <= 3 ? '#D29A18' : '#748791', '800');
      ui.text(ctx, row.name + (mine ? '  [我的门店]' : ''), 66, y, 7.1, mine ? '#173D54' : '#3A5665', mine ? '800' : '700');
      ui.text(ctx, row.score.toFixed(1), 292, y, 7.4, mine ? '#C77D00' : '#173D54', '800', 'right');
      const trend = row.change > 0 ? '▲' + row.change : row.change < 0 ? '▼' + Math.abs(row.change) : '—';
      ui.text(ctx, trend, 350, y, 6.7, row.change > 0 ? '#248B63' : row.change < 0 ? '#C85242' : '#71858F', '700', 'right');
      y += 39;
    }
    const p = ranking.player;
    if (p) {
      const gap = p.rank > 1 ? p.gapToPrev.toFixed(1) : '0';
      ui.text(ctx, '我的门店 #' + p.rank + ' · 距上一名 ' + gap + '分 · Top3门槛 ' + (ranking.thresholdTop3 == null ? '—' : ranking.thresholdTop3.toFixed(1)), 28, 586, 6.8, '#71858F', '700');
    }
  };

  const __v0851OldHandleTap = __v0851BusinessScene.handleTap;
  __v0851BusinessScene.handleTap = function handleTapV0851(x, y) {
    const target = this.hit(x, y);
    if (target && target.id && target.id.indexOf('rankcat:') === 0) { this.rankCategory = target.id.slice('rankcat:'.length); return true; }
    if (target && target.id && target.id.indexOf('rankscope:') === 0) { this.rankScope = target.id.slice('rankscope:'.length); return true; }
    return __v0851OldHandleTap.call(this, x, y);
  };
}
${BIZ_END}
`;

try {
  for (const rel of [OPS, BUSINESS, MAIN, GRADLE, 'package.json']) remember(rel);
  if (exists('package-lock.json')) remember('package-lock.json');
  for (const rel of LEGACY_FILES) rememberDelete(rel);

  let ops = read(OPS);
  ops = stripLegacy(ops, '/* V085_CULINARY_PRESTIGE_BRIDGE */', '/* V085_CULINARY_PRESTIGE_BRIDGE_END */');
  ops = stripLegacy(ops, OPS_START, OPS_END);
  write(OPS, ops.replace(/\s+$/, '') + '\n\n' + opsBridge.trim() + '\n');

  let business = read(BUSINESS);
  business = stripLegacy(business, '/* V085_RANKING_BRIDGE */', '/* V085_RANKING_BRIDGE_END */');
  business = stripLegacy(business, BIZ_START, BIZ_END);
  write(BUSINESS, business.replace(/\s+$/, '') + '\n\n' + bizBridge.trim() + '\n');

  let main = read(MAIN);
  main = main
    .replace(/城市餐饮经营小游戏 V0\.8\.(49|50|51)[^'\n]*/g, '城市餐饮经营小游戏 V0.8.51 菜品研发与餐饮荣誉稳定版启动成功');
  write(MAIN, main);

  let gradle = read(GRADLE);
  gradle = gradle.replace(/versionCode\s+\d+/, 'versionCode 851');
  gradle = gradle.replace(/versionName\s+['"][^'"]+['"]/, "versionName '0.8.51'");
  if (!/versionCode\s+851/.test(gradle) || !/versionName\s+['"]0\.8\.51['"]/.test(gradle)) throw new Error('Android版本号更新失败');
  write(GRADLE, gradle);

  const pkg = readJson('package.json');
  pkg.version = TARGET;
  if (!pkg.scripts) pkg.scripts = {};
  pkg.scripts.test = 'node scripts/run-ci-tests-v060.js';
  writeJson('package.json', pkg);

  if (exists('package-lock.json')) {
    const lock = readJson('package-lock.json');
    lock.version = TARGET;
    if (lock.packages && lock.packages['']) lock.packages[''].version = TARGET;
    writeJson('package-lock.json', lock);
  }

  for (const rel of LEGACY_FILES) { try { fs.unlinkSync(abs(rel)); } catch (_) {} }

  for (const rel of [OPS, BUSINESS, RESEARCH, PRESTIGE, MAIN, RUNNER]) syntax(rel);

  // Run only the new self-contained smoke tests here. Full npm test follows in workflow.
  for (const rel of ['tests/culinaryPrestigeV0851.test.js','tests/culinaryUiV0851.test.js','tests/updateInfrastructureV0851.test.js']) {
    const r = cp.spawnSync(process.execPath, [abs(rel)], {cwd:ROOT, encoding:'utf8'});
    process.stdout.write(r.stdout || '');
    process.stderr.write(r.stderr || '');
    if (r.status !== 0) throw new Error('V0.8.51安装后冒烟测试失败：' + rel);
  }

  console.log('V0.8.51 healing installer PASS: partial V0.8.50 state repaired, full test runner upgraded');
} catch (err) {
  rollback();
  console.error('[V0.8.51 ROLLBACK]', err && err.stack || err);
  process.exit(1);
}
