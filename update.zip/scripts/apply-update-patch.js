'use strict';

/*
 * V0849_HOTFIX_RENOVATION_INTERACTION_LAYOUT
 * Existing Apply Update ZIP workflow runs this file, then removes it.
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function read(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

function write(rel, content) {
  const abs = path.join(ROOT, rel);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, content);
}

function replaceBetween(source, startMarker, endMarker, replacement, label) {
  const start = source.indexOf(startMarker);
  const end = source.indexOf(endMarker, start + startMarker.length);

  if (start < 0 || end < 0) {
    throw new Error('V0849 hotfix cannot find section: ' + label);
  }

  return source.slice(0, start) + replacement + source.slice(end);
}

function replaceOnce(source, oldText, newText, label) {
  if (!source.includes(oldText)) {
    throw new Error('V0849 hotfix cannot find anchor: ' + label);
  }

  return source.replace(oldText, newText);
}

/* 1. Android complete touch lifecycle */
{
  const rel = 'android/entry.js';
  let source = read(rel);

  if (!source.includes('V0849_HOTFIX_TOUCH_BRIDGE')) {
    source = replaceOnce(
      source,
      "const ctx = canvas.getContext('2d');\nif (!ctx) throw new Error('无法创建 Canvas 2D 环境');\n",
      "const ctx = canvas.getContext('2d');\nif (!ctx) throw new Error('无法创建 Canvas 2D 环境');\n\n// V0849_HOTFIX_TOUCH_BRIDGE\n// 装修分区拖拽需要完整 touchstart -> touchmove -> touchend 生命周期。\ncanvas.style.touchAction = 'none';\n",
      'android canvas'
    );

    const touchStartMove = `  onTouchStart(callback) {
    if (typeof callback !== 'function') {
      return;
    }

    canvas.addEventListener(
      'touchstart',
      function (event) {
        if (event.cancelable) {
          event.preventDefault();
        }

        if (!event.touches || !event.touches.length) {
          return;
        }

        callback({
          touches: event.touches
        });
      },
      { passive: false }
    );
  },

  onTouchMove(callback) {
    if (typeof callback !== 'function') {
      return;
    }

    canvas.addEventListener(
      'touchmove',
      function (event) {
        if (event.cancelable) {
          event.preventDefault();
        }

        if (!event.touches || !event.touches.length) {
          return;
        }

        callback({
          touches: event.touches
        });
      },
      { passive: false }
    );
  },

`;

    source = replaceOnce(
      source,
      '  onTouchEnd(callback) {\n',
      touchStartMove + '  onTouchEnd(callback) {\n',
      'android onTouchEnd'
    );
  }

  write(rel, source);
}

/* 2. Renovation page interaction and layout */
{
  const rel = 'src/scenes/renovationScene.js';
  let source = read(rel);

  if (!source.includes('V0849_HOTFIX_RENOVATION_INTERACTION_LAYOUT')) {
    source = replaceOnce(
      source,
      '// V0849_AREA_TRUTH_RENOVATION_UI\n',
      '// V0849_AREA_TRUTH_RENOVATION_UI\n// V0849_HOTFIX_RENOVATION_INTERACTION_LAYOUT\n',
      'renovation marker'
    );

    source = replaceBetween(
      source,
      '  getMainGeometry() {',
      '\n  drawZoneChip(',
`  getMainGeometry() {
    const y =
      this.viewH < 700
        ? 94
        : 200;

    const footerH =
      49;

    const lowerH =
      clamp(
        (
          this.contentBottom -
          y
        ) *
        0.23,
        112,
        132
      );

    const maxPlan =
      this.contentBottom -
      y -
      lowerH -
      footerH -
      22;

    const planH =
      clamp(
        maxPlan,
        this.viewH < 700
          ? 220
          : 276,
        348
      );

    const lowerY =
      y +
      planH +
      8;

    const footerY =
      this.contentBottom -
      footerH;

    return {
      y,
      planH,
      lowerY,
      lowerH:
        Math.max(
          86,
          Math.min(
            lowerH,
            footerY -
            lowerY -
            8
          )
        ),
      footerY,
      footerH
    };
  }
`,
      'getMainGeometry'
    );

    source = replaceBetween(
      source,
      '  getGeometryFrame(',
      '\n  mapGeometryPoint(',
`  getGeometryFrame(
    geometry,
    x,
    y,
    w,
    h
  ) {
    const margin =
      7;

    const fitScale =
      Math.min(
        (
          w -
          margin * 2
        ) /
          Math.max(
            0.1,
            geometry.widthM
          ),
        (
          h -
          margin * 2
        ) /
          Math.max(
            0.1,
            geometry.depthM
          )
      );

    const areaM2 =
      Math.max(
        1,
        Number(
          geometry.areaM2
        ) ||
        (
          Number(geometry.widthM) *
          Number(geometry.depthM)
        ) ||
        1
      );

    // 不再让所有面积的房源都强制铺满画布。
    const areaVisualScale =
      clamp(
        Math.pow(
          areaM2 /
          320,
          0.26
        ),
        0.62,
        1
      );

    const scale =
      fitScale *
      areaVisualScale;

    const drawW =
      geometry.widthM *
      scale;

    const drawH =
      geometry.depthM *
      scale;

    return {
      scale,
      areaVisualScale,
      x:
        x +
        (
          w -
          drawW
        ) /
        2,
      y:
        y +
        (
          h -
          drawH
        ) /
        2,
      w:
        drawW,
      h:
        drawH
    };
  }
`,
      'getGeometryFrame'
    );

    source = replaceBetween(
      source,
      '  drawToolButton(',
      '\n  drawTablePicker(',
`  drawToolButton(
    ctx,
    id,
    imageKey,
    label,
    x,
    y,
    w,
    h,
    active
  ) {
    const compact =
      w < 64;

    ui.card(
      ctx,
      x,
      y,
      w,
      h,
      {
        radius: 10,
        fill:
          active
            ? '#FFF2BF'
            : '#FFFDF7',
        stroke:
          active
            ? '#E8B326'
            : '#DED2C1',
        lineWidth:
          active
            ? 1.5
            : 1,
        shadow: false
      }
    );

    this.drawImageContain(
      ctx,
      imageKey,
      x +
        (
          compact
            ? 4
            : 7
        ),
      y + 6,
      compact
        ? 19
        : 25,
      h - 12,
      1
    );

    this.text(
      ctx,
      label,
      compact
        ? x + w * 0.68
        : x + 42,
      y + h / 2,
      compact
        ? 4.6
        : 5.3,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton(
      id,
      x,
      y,
      w,
      h
    );
  }

  drawFloorPlan(
    ctx,
    metrics,
    floor,
    geometry
  ) {
    const y =
      geometry.y;

    const h =
      geometry.planH;

    ui.card(
      ctx,
      7,
      y,
      376,
      h,
      {
        radius: 14,
        fill:
          COLORS.panel,
        stroke:
          COLORS.line,
        shadow: false
      }
    );

    this.text(
      ctx,
      '平面图',
      18,
      y + 17,
      9.8,
      COLORS.text,
      '800'
    );

    const floorGeometry =
      floor.geometry ||
      floorGeometrySystem
        .getFloorGeometry(
          this.getShop(),
          floor.index,
          floor.area,
          metrics.plan
            .floors
            .length
        );

    this.text(
      ctx,
      '拖动黄点/虚线调面积 · ' +
        floorGeometry.shapeName +
        ' · ' +
        floorGeometry.areaM2.toFixed(0) +
        '㎡',
      64,
      y + 17,
      4.9,
      COLORS.muted,
      '600'
    );

    this.text(
      ctx,
      '↶',
      263,
      y + 17,
      10,
      COLORS.navy,
      '800',
      'center'
    );

    this.text(
      ctx,
      '↷',
      301,
      y + 17,
      10,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton(
      'history:undo',
      245,
      y + 3,
      36,
      27
    );

    this.addButton(
      'history:redo',
      283,
      y + 3,
      36,
      27
    );

    ui.card(
      ctx,
      323,
      y + 5,
      51,
      25,
      {
        radius: 10,
        fill:
          '#FFF4D5',
        stroke:
          '#E2C16B',
        shadow: false
      }
    );

    this.text(
      ctx,
      '全屏预览',
      348.5,
      y + 17.5,
      5.2,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton(
      'preview',
      321,
      y + 2,
      55,
      31
    );

    const planX =
      14;

    const planY =
      y + 35;

    const planW =
      362;

    const toolGap =
      4;

    const toolH =
      40;

    const toolY =
      y +
      h -
      toolH -
      7;

    const planH =
      Math.max(
        120,
        toolY -
        planY -
        6
      );

    this.drawFloorCanvas(
      ctx,
      metrics,
      floor,
      planX,
      planY,
      planW,
      planH
    );

    const tools = [
      ['page:zones', 'reno_prep', '区域'],
      ['page:furniture', 'reno_table_4', '家具'],
      [
        'page:style',
        V45_HALL_STYLE_VISUAL[
          metrics.plan
            .hallStyle
        ] ||
          'reno_style_natural',
        '风格'
      ],
      ['page:rooms', 'reno_table_8', '包厢'],
      ['aisle:cycle', 'reno_corridor', '动线'],
      [
        'floor:next',
        'reno_room_small',
        '楼层' +
          (
            metrics.plan
              .activeFloor +
            1
          )
      ]
    ];

    const toolW =
      (
        planW -
        toolGap *
        (
          tools.length -
          1
        )
      ) /
      tools.length;

    for (
      let i = 0;
      i <
      tools.length;
      i++
    ) {
      this.drawToolButton(
        ctx,
        tools[i][0],
        tools[i][1],
        tools[i][2],
        planX +
          i *
          (
            toolW +
            toolGap
          ),
        toolY,
        toolW,
        toolH,
        false
      );
    }
  }
`,
      'drawToolButton/drawFloorPlan'
    );

    const dashedAnchor = `    ctx.restore();

    this.floorCanvasInteraction = {
`;

    if (!source.includes(dashedAnchor)) {
      throw new Error('V0849 hotfix cannot find drag-handle anchor');
    }

    source = source.replace(
      dashedAnchor,
`    ctx.restore();

    const dragHandles = [
      {
        type: 'back',
        x: frame.x + frame.w * 0.5,
        y: frame.y + frame.h * backRatio
      },
      {
        type: 'kitchen-storage',
        x: frame.x + frame.w * kitchenWidthRatio,
        y: frame.y + frame.h * backRatio * 0.5
      },
      {
        type: 'service',
        x: frame.x + frame.w * serviceWidthRatio,
        y:
          frame.y +
          frame.h *
          (
            backRatio +
            (
              1 -
              backRatio
            ) *
            0.5
          )
      }
    ];

    for (
      let i = 0;
      i <
      dragHandles.length;
      i++
    ) {
      const handle =
        dragHandles[i];

      const active =
        this.areaDrag &&
        this.areaDrag.type ===
          handle.type &&
        this.areaDrag.floorIndex ===
          floor.index;

      ctx.save();
      ctx.beginPath();
      ctx.arc(
        handle.x,
        handle.y,
        active
          ? 7
          : 5.5,
        0,
        Math.PI * 2
      );
      ctx.fillStyle =
        active
          ? '#FFB300'
          : '#FFD95A';
      ctx.strokeStyle =
        '#FFFFFF';
      ctx.lineWidth =
        1.5;
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    this.floorCanvasInteraction = {
`
    );

    source = replaceBetween(
      source,
      '  renderFurniture(',
      '\n  renderStyle(',
`  renderFurniture(
    ctx,
    metrics,
    floor
  ) {
    const shell =
      this.drawSecondaryShell(
        ctx,
        '家具与软装',
        '餐桌决定餐位；空间不足时会明确提示，不再出现“按钮没反应”'
      );

    const tableY =
      shell.y;

    this.text(
      ctx,
      '餐桌',
      19,
      tableY + 9,
      7.8,
      COLORS.text,
      '800'
    );

    const keys =
      ['2', '4', '6', '8'];

    const cols =
      2;

    const cardGap =
      8;

    const cardW =
      171;

    const cardH =
      78;

    const tableStartY =
      tableY + 21;

    for (
      let i = 0;
      i <
      keys.length;
      i++
    ) {
      const key =
        keys[i];

      const col =
        i %
        cols;

      const row =
        Math.floor(
          i /
          cols
        );

      const x =
        16 +
        col *
        (
          cardW +
          cardGap
        );

      const cardY =
        tableStartY +
        row *
        (
          cardH +
          cardGap
        );

      const count =
        Number(
          floor.tables[
            key
          ]
        ) || 0;

      ui.card(
        ctx,
        x,
        cardY,
        cardW,
        cardH,
        {
          radius: 11,
          fill:
            '#FFF9EF',
          stroke:
            '#DFD5C8',
          shadow: false
        }
      );

      this.drawImageContain(
        ctx,
        'reno_table_' +
          key,
        x + 7,
        cardY + 8,
        69,
        55,
        1
      );

      this.text(
        ctx,
        key +
          '人桌',
        x + 88,
        cardY + 17,
        6.0,
        COLORS.text,
        '800'
      );

      this.text(
        ctx,
        '已摆 ' +
          count +
          ' 张',
        x + 88,
        cardY + 35,
        5.1,
        COLORS.muted,
        '700'
      );

      const minusX =
        x + 91;

      const plusX =
        x + 132;

      const buttonY =
        cardY + 47;

      ui.card(
        ctx,
        minusX,
        buttonY,
        32,
        24,
        {
          radius: 9,
          fill:
            '#F2EEE7',
          stroke:
            '#D7CCBC',
          shadow: false
        }
      );

      ui.card(
        ctx,
        plusX,
        buttonY,
        32,
        24,
        {
          radius: 9,
          fill:
            '#FFE49A',
          stroke:
            '#E1B43A',
          shadow: false
        }
      );

      this.text(
        ctx,
        '−',
        minusX + 16,
        buttonY + 12,
        8.5,
        COLORS.navy,
        '800',
        'center'
      );

      this.text(
        ctx,
        '+',
        plusX + 16,
        buttonY + 12,
        8.5,
        COLORS.navy,
        '800',
        'center'
      );

      this.addButton(
        'table:' +
          key +
          ':minus',
        minusX - 2,
        buttonY - 4,
        36,
        32
      );

      this.addButton(
        'table:' +
          key +
          ':plus',
        plusX - 2,
        buttonY - 4,
        36,
        32
      );
    }

    const decorY =
      tableStartY +
      2 *
      (
        cardH +
        cardGap
      ) +
      7;

    this.text(
      ctx,
      '软装',
      19,
      decorY,
      7.8,
      COLORS.text,
      '800'
    );

    const items =
      renovationConfig
        .decorItems ||
      [];

    for (
      let i = 0;
      i <
      Math.min(
        items.length,
        4
      );
      i++
    ) {
      const item =
        items[i];

      const x =
        16 +
        i * 89;

      const count =
        Number(
          metrics.decorCounts &&
          metrics.decorCounts[
            item.id
          ]
        ) || 0;

      ui.card(
        ctx,
        x,
        decorY + 13,
        82,
        90,
        {
          radius: 11,
          fill:
            '#FFF9EF',
          stroke:
            '#DFD5C8',
          shadow: false
        }
      );

      const imageMap = {
        plant:
          'reno_plant_1',
        pendant:
          'reno_pendant',
        screen:
          'reno_screen',
        sofa:
          'reno_sofa'
      };

      this.drawImageContain(
        ctx,
        imageMap[
          item.id
        ] ||
          'reno_plant_1',
        x + 8,
        decorY + 19,
        66,
        39,
        1
      );

      this.text(
        ctx,
        item.name,
        x + 41,
        decorY + 61,
        5.2,
        COLORS.text,
        '800',
        'center'
      );

      this.text(
        ctx,
        '− ' +
          count +
          ' +',
        x + 41,
        decorY + 88,
        5.8,
        COLORS.navy,
        '800',
        'center'
      );

      this.addButton(
        'decor:' +
          item.id +
          ':minus',
        x + 3,
        decorY + 73,
        32,
        30
      );

      this.addButton(
        'decor:' +
          item.id +
          ':plus',
        x + 48,
        decorY + 73,
        32,
        30
      );
    }

    const impactY =
      decorY + 117;

    ui.card(
      ctx,
      16,
      impactY,
      358,
      56,
      {
        radius: 12,
        fill:
          '#EFF7FA',
        stroke:
          '#C5DDE8',
        shadow: false
      }
    );

    this.text(
      ctx,
      '装修评分 ' +
        metrics.renovationScore +
        ' · 软装 ' +
        money(
          metrics.decorCost
        ),
      28,
      impactY + 17,
      7.0,
      COLORS.text,
      '800'
    );

    this.text(
      ctx,
      '客流 ×' +
        metrics
          .operatingImpact
          .trafficFactor
          .toFixed(2) +
        ' · 客单 ×' +
        metrics
          .operatingImpact
          .spendFactor
          .toFixed(2) +
        ' · 服务 ×' +
        metrics
          .operatingImpact
          .serviceFactor
          .toFixed(2),
      28,
      impactY + 38,
      5.2,
      COLORS.muted,
      '600'
    );
  }
`,
      'renderFurniture'
    );

    const tableBranch = `    if (
      id.indexOf(
        'table:'
      ) ===
      0
    ) {
      const parts =
        id.split(':');

      renovationSystem
        .adjustTable(
          this.shopId,
          floorIndex,
          Number(
            parts[1]
          ),
          parts[2] ===
            'plus'
            ? 1
            : -1
        );

      return true;
    }
`;

    const tableBranchFixed = `    if (
      id.indexOf(
        'table:'
      ) ===
      0
    ) {
      const parts =
        id.split(':');

      const tableKey =
        String(
          Number(
            parts[1]
          )
        );

      const delta =
        parts[2] ===
          'plus'
          ? 1
          : -1;

      const beforeCount =
        Number(
          plan.floors[
            floorIndex
          ].tables[
            tableKey
          ]
        ) || 0;

      renovationSystem
        .adjustTable(
          this.shopId,
          floorIndex,
          Number(
            parts[1]
          ),
          delta
        );

      const currentPlan =
        this.getPlan();

      const afterCount =
        Number(
          currentPlan
            .floors[
              floorIndex
            ]
            .tables[
              tableKey
            ]
        ) || 0;

      if (
        delta > 0 &&
        afterCount <=
          beforeCount
      ) {
        const currentMetrics =
          this.getMetrics();

        const floorMetrics =
          currentMetrics &&
          currentMetrics
            .floors
            .find(
              value =>
                value.index ===
                floorIndex
            );

        const totalTables =
          Object.values(
            currentPlan
              .floors[
                floorIndex
              ]
              .tables
          )
          .reduce(
            (
              sum,
              value
            ) =>
              sum +
              Math.max(
                0,
                Number(value) ||
                0
              ),
            0
          );

        const slots =
          floorMetrics &&
          floorMetrics
            .usableDiningSlots
            ? floorMetrics
                .usableDiningSlots
                .length
            : 0;

        this.showToast(
          slots > 0 &&
          totalTables >=
            slots
            ? '餐桌落位点已满，请拖动分区扩大堂食区'
            : '堂食可用面积不足，请扩大堂食区或减少其他家具'
        );
      } else {
        saveSystem
          .autoSave(true);
      }

      return true;
    }
`;

    source = replaceOnce(
      source,
      tableBranch,
      tableBranchFixed,
      'table tap branch'
    );

    source = replaceBetween(
      source,
      '  handleTouchStart(',
      '\n  handleTouchMove(',
`  handleTouchStart(
    x,
    y
  ) {
    const data =
      this.floorCanvasInteraction;

    if (
      !data ||
      this.page !==
        'layout' ||
      this.previewMode
    ) {
      return false;
    }

    const frame =
      data.frame;

    if (
      x < frame.x ||
      x > frame.x + frame.w ||
      y < frame.y ||
      y > frame.y + frame.h
    ) {
      return false;
    }

    const horizontalY =
      frame.y +
      frame.h *
      data.backRatio;

    const topSplitX =
      frame.x +
      frame.w *
      data.kitchenWidthRatio;

    const serviceSplitX =
      frame.x +
      frame.w *
      data.serviceWidthRatio;

    let type = null;

    if (
      Math.abs(
        y -
        horizontalY
      ) <= 18
    ) {
      type = 'back';
    } else if (
      y < horizontalY &&
      Math.abs(
        x -
        topSplitX
      ) <= 18
    ) {
      type =
        'kitchen-storage';
    } else if (
      y > horizontalY &&
      Math.abs(
        x -
        serviceSplitX
      ) <= 18
    ) {
      type = 'service';
    }

    if (!type) {
      return false;
    }

    const plan =
      this.getPlan();

    renovationSystem
      .mutatePlan(
        this.shopId,
        () => {},
        {
          skipHistory: false
        }
      );

    this.areaDrag = {
      type,
      floorIndex:
        data.floorIndex,
      start:
        {
          kitchenRatio:
            plan.floors[
              data.floorIndex
            ].kitchenRatio,
          storageRatio:
            plan.floors[
              data.floorIndex
            ].storageRatio,
          serviceRatio:
            plan.floors[
              data.floorIndex
            ].serviceRatio
        }
    };

    return true;
  }
`,
      'handleTouchStart'
    );
  }

  write(rel, source);
}

/* 3. Regression test and runner registration */
const testRel =
  'tests/renovationHotfixV0849.test.js';

write(
  testRel,
`'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

const androidSource = fs.readFileSync(
  path.join(ROOT, 'android/entry.js'),
  'utf8'
);

const sceneSource = fs.readFileSync(
  path.join(ROOT, 'src/scenes/renovationScene.js'),
  'utf8'
);

for (const token of [
  'V0849_HOTFIX_TOUCH_BRIDGE',
  'onTouchStart(callback)',
  "'touchstart'",
  'onTouchMove(callback)',
  "'touchmove'",
  "canvas.style.touchAction = 'none'"
]) {
  assert.ok(androidSource.includes(token), 'Android拖动桥缺失：' + token);
}

for (const token of [
  'V0849_HOTFIX_RENOVATION_INTERACTION_LAYOUT',
  'areaVisualScale',
  '拖动黄点/虚线调面积',
  "const cols =\\n      2",
  '餐桌落位点已满，请拖动分区扩大堂食区'
]) {
  assert.ok(sceneSource.includes(token), '装修热修复缺失：' + token);
}

let height = 780;

globalThis.GameRuntime = {
  api: {
    getSystemInfoSync() {
      return {
        windowWidth: 390,
        windowHeight: height
      };
    },
    showToast() {},
    setStorageSync() {},
    getStorageSync() {
      return null;
    }
  },
  requestRender() {}
};

const scene = require('../src/scenes/renovationScene.js');

const small = scene.getGeometryFrame(
  {
    widthM: 8,
    depthM: 8,
    areaM2: 64
  },
  0,
  0,
  300,
  220
);

const large = scene.getGeometryFrame(
  {
    widthM: 16,
    depthM: 16,
    areaM2: 256
  },
  0,
  0,
  300,
  220
);

assert.ok(
  small.w * small.h < large.w * large.h,
  '64㎡门店不能再被放大成和256㎡门店一样大的装修区域'
);

height = 600;
scene.getLayout();
const shortLayout = scene.getMainGeometry();

assert.ok(
  shortLayout.y >= 92,
  '矮屏装修主体不能压进顶部88px门店头图'
);

console.log('V0.8.49 renovation interaction/layout hotfix tests passed');
`
);

{
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    !source.includes(
      testRel
    )
  ) {
    source =
      replaceOnce(
        source,
        "    'tests/renovationUiV0849.test.js',\n",
        "    'tests/renovationUiV0849.test.js',\n    'tests/renovationHotfixV0849.test.js',\n",
        'test runner V0849'
      );
  }

  write(rel, source);
}

/* 4. Hotfix manifest */
write(
  'PATCH_MANIFEST_V0849_RENOVATION_HOTFIX.json',
  JSON.stringify(
    {
      id: 'V0849_RENOVATION_INTERACTION_LAYOUT_HOTFIX',
      baseVersion: '0.8.49',
      targetVersion: '0.8.49',
      hotfixRevision: 1,
      category: '装修拖拽与手机布局修复',
      features: [
        'Android补齐touchstart和touchmove事件桥',
        'Canvas禁用浏览器默认触摸手势',
        '主平面图扩大并将工具栏移到底部',
        '门店装修图按真实面积产生视觉尺寸差异',
        '分区虚线加入黄色抓取点并扩大触摸容差',
        '家具餐桌改为双列大按钮布局',
        '餐桌添加失败时展示容量原因',
        '600至780高度手机继续做点击区回归测试'
      ],
      workflowSafe: true,
      containsPackageJson: false,
      containsPackageLock: false,
      containsWorkflowFiles: false
    },
    null,
    2
  ) + '\\n'
);

console.log('V0849 renovation interaction/layout hotfix applied');
