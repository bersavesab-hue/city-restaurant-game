'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const BASE_VERSION =
  '0.8.33';

const TARGET_VERSION =
  '0.8.35';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs.readFileSync(
    abs(rel),
    'utf8'
  );
}

function write(rel,content) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const i =
    source.indexOf(
      from
    );

  if (
    i <
    0
  ) {
    throw new Error(
      'V0.8.34-35 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      i
    ) +
    to +
    source.slice(
      i +
      from.length
    )
  );
}

function insertBefore(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const i =
    source.indexOf(
      anchor
    );

  if (
    i <
    0
  ) {
    throw new Error(
      'V0.8.34-35 insertion anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      i
    ) +
    addition +
    source.slice(i)
  );
}

function cleanupLegacyRootWorkflow() {
  if (
    fs.existsSync(
      abs(
        'apply-update.yml'
      )
    )
  ) {
    fs.unlinkSync(
      abs(
        'apply-update.yml'
      )
    );
  }
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      BASE_VERSION &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.34-35 requires formal V0.8.33 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateOperationsStore() {
  const rel =
    'src/operations/operationsStoreV080.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const growthAchievementSystem =
  require('../progress/growthAchievementSystemV0833.js');

const customerRandomDatabase =`,
`const growthAchievementSystem =
  require('../progress/growthAchievementSystemV0833.js');

const multiStoreBrandRanking =
  require('../brand/multiStoreBrandRankingV0834.js');

const customerRandomDatabase =`,
      'V0834 import'
    );

  const apiBlock =
`function brandPortfolioSnapshot() {
  const business =
    gameState.getBusiness();

  for (
    const shop
    of business.shops ||
    []
  ) {
    const runtime =
      getRuntime(
        shop.id
      );

    if (runtime) {
      multiStoreBrandRanking
        .registerShop(
          shop.id,
          runtime,
          {
            day:
              currentDay()
          }
        );
    }
  }

  return (
    multiStoreBrandRanking
      .portfolioSnapshot()
  );
}

function brandExpansionCatalog(
  cityId
) {
  return (
    multiStoreBrandRanking
      .expansionCatalog(
        cityId
      )
  );
}

function createBrandExpansionPlan(
  districtId,
  options
) {
  return (
    multiStoreBrandRanking
      .createExpansionPlan(
        districtId,
        {
          ...(options || {}),
          day:
            options &&
            options.day != null
              ? Number(
                  options.day
                )
              : currentDay()
        }
      )
  );
}

function commitBrandExpansionPlan(
  planId,
  options
) {
  return (
    multiStoreBrandRanking
      .commitExpansionPlan(
        planId,
        {
          ...(options || {}),
          day:
            options &&
            options.day != null
              ? Number(
                  options.day
                )
              : currentDay()
        }
      )
  );
}

function attachBrandExpansionShop(
  planId,
  shopId,
  options
) {
  return (
    multiStoreBrandRanking
      .attachExpansionShop(
        planId,
        shopId,
        getRuntime(
          shopId
        ),
        {
          ...(options || {}),
          day:
            options &&
            options.day != null
              ? Number(
                  options.day
                )
              : currentDay()
        }
      )
  );
}

function brandRankingSnapshot(
  options
) {
  brandPortfolioSnapshot();

  return (
    multiStoreBrandRanking
      .buildRanking({
        ...(options || {}),
        day:
          options &&
          options.day != null
            ? Number(
                options.day
              )
            : currentDay()
      })
  );
}

function storeRankingSnapshot() {
  brandPortfolioSnapshot();

  return (
    multiStoreBrandRanking
      .storeRanking()
  );
}

`;

  source =
    insertBefore(
      source,
      'function supplierCatalog(\n  shopId,',
      apiBlock,
      'function brandPortfolioSnapshot()',
      'V0834 operations APIs'
    );

  source =
    replaceOnce(
      source,
`        growthAchievementSystem
          .rollHidden(
            shopId,
            {
              daysPlayed:
                closedDay,`,
`        multiStoreBrandRanking
          .registerShop(
            shopId,
            runtime,
            {
              day:
                closedDay
            }
          );

        growthAchievementSystem
          .rollHidden(
            shopId,
            {
              daysPlayed:
                closedDay,`,
      'day close multi-store bridge'
    );

  source =
    replaceOnce(
      source,
`  rollEasterEggEvent,
  generateCustomer,`,
`  rollEasterEggEvent,
  brandPortfolioSnapshot,
  brandExpansionCatalog,
  createBrandExpansionPlan,
  commitBrandExpansionPlan,
  attachBrandExpansionShop,
  brandRankingSnapshot,
  storeRankingSnapshot,
  generateCustomer,`,
      'V0834 exports'
    );

  write(
    rel,
    source
  );
}

function updateOperationsIndex() {
  const rel =
    'src/operations/index.js';

  let source =
    read(rel);

  if (
    source.includes(
      "multiStoreBrandRankingV0834.js"
    )
  ) {
    return;
  }

  source =
    source.replace(
`  growth:
    require('../progress/growthAchievementSystemV0833.js')`,
`  growth:
    require('../progress/growthAchievementSystemV0833.js'),
  multiStoreBrand:
    require('../brand/multiStoreBrandRankingV0834.js')`
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0835.test.js'
    )
  ) {
    return;
  }

  const anchor =
    `    'tests/v60CleanBase.test.js'`;

  const addition =
`    'tests/multiStoreBrandRankingV0834.test.js',
    'tests/fullIntegrationSimulationV0835.test.js',
    'tests/updateInfrastructureV0835.test.js',
`;

  const i =
    source.indexOf(
      anchor
    );

  if (
    i <
    0
  ) {
    throw new Error(
      'V0.8.34-35 runner anchor missing: v60CleanBase'
    );
  }

  source =
    source.slice(
      0,
      i
    ) +
    addition +
    source.slice(
      i
    );

  write(
    rel,
    source
  );
}

function updateMainLabel() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.33 监管社交随机成长四合一版启动成功',
      '城市餐饮经营小游戏 V0.8.35 功能总集成版启动成功'
    );

  write(
    rel,
    source
  );
}

function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const sdkmanager =
    path.join(
      latestDir,
      'bin',
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.34-35] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const real =
    path.join(
      path.dirname(
        sdkmanager
      ),
      'sdkmanager.v0835-real'
    );

  if (
    !fs.existsSync(
      real
    )
  ) {
    fs.renameSync(
      sdkmanager,
      real
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0835-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then continue; fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then exit 0; fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.34-35 target version finalize failed'
    );
  }

  const required = [
    'src/brand/multiStoreBrandRankingV0834.js',
    'src/simulator/fullIntegrationSimulationV0835.js',
    'simulator/run100GameLoopsV0835.js',
    'tests/multiStoreBrandRankingV0834.test.js',
    'tests/fullIntegrationSimulationV0835.test.js',
    'tests/updateInfrastructureV0835.test.js'
  ];

  for (
    const file
    of required
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.34-35 required file missing: ' +
        file
      );
    }
  }

  const operations =
    read(
      'src/operations/operationsStoreV080.js'
    );

  for (
    const marker
    of [
      'multiStoreBrandRankingV0834.js',
      'function brandPortfolioSnapshot()',
      'function brandExpansionCatalog(',
      'function createBrandExpansionPlan(',
      'function brandRankingSnapshot('
    ]
  ) {
    if (
      !operations.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.34-35 operations integration missing ' +
        marker
      );
    }
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/multiStoreBrandRankingV0834.test.js',
      'tests/fullIntegrationSimulationV0835.test.js',
      'tests/updateInfrastructureV0835.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.34-35 runner integration missing ' +
        marker
      );
    }
  }
}

cleanupLegacyRootWorkflow();
updatePackage();
updatePackageLock();
updateOperationsStore();
updateOperationsIndex();
updateRunner();
updateMainLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.35] PASS：25-26/26 多店/品牌/扩张/排行榜 + 全系统100局集成模拟收尾完成'
);
