'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const MARKER = 'V104_RATING_VISUALIZATION';

function read(rel) {
  const abs = path.join(ROOT, rel);
  if (!fs.existsSync(abs)) throw new Error('[V104] missing file: ' + rel);
  return fs.readFileSync(abs, 'utf8');
}

function write(rel, content) {
  const abs = path.join(ROOT, rel);
  fs.writeFileSync(abs, content, 'utf8');
  console.log('[V104] patched', rel);
}

function replaceOnce(content, anchor, replacement, rel, label) {
  if (!content.includes(anchor)) {
    throw new Error('[V104] anchor not found in ' + rel + ': ' + label);
  }
  return content.replace(anchor, replacement);
}

function insertAfter(content, anchor, addition, rel, label) {
  return replaceOnce(content, anchor, anchor + addition, rel, label);
}

function patchMain() {
  const rel = 'src/main.js';
  let c = read(rel);
  if (!c.includes("require('./rating/ratingSystemV104.js')")) {
    c = insertAfter(
      c,
      "const financialSystem = require('./finance/financialSystemV103.js');",
      "\nconst ratingSystem = require('./rating/ratingSystemV104.js'); // " + MARKER,
      rel,
      'rating require'
    );
  }
  if (!c.includes('runtime.ratingSystem')) {
    c = insertAfter(
      c,
      "runtime.financialSystem =\n  financialSystem;",
      "\n\nruntime.ratingSystem =\n  ratingSystem; // " + MARKER,
      rel,
      'rating runtime bridge'
    );
  }
  write(rel, c);
}

function patchStoreDetail() {
  const rel = 'src/scenes/storeDetailScene.js';
  let c = read(rel);
  if (!c.includes("../rating/ratingSystemV104.js")) {
    c = insertAfter(
      c,
      "const ui = require('../ui/dataWidgets.js');",
      "\nconst ratingSystem = require('../rating/ratingSystemV104.js');\nconst ratingUi = require('../ui/ratingWidgetsV104.js'); // " + MARKER,
      rel,
      'rating imports'
    );
  }

  if (!c.includes('drawRating(ctx, d)')) {
    const method = `
  drawRating(ctx, d) {
    const rating = ratingSystem.evaluateStoreFromDashboard(d);
    const dishes = Array.isArray(d.dishes)
      ? d.dishes.map(item => ratingSystem.evaluateDish(item)).sort((a, b) => b.score - a.score)
      : [];
    const employees = d.staff && Array.isArray(d.staff.staff)
      ? d.staff.staff.map(item => ratingSystem.evaluateEmployee(item)).sort((a, b) => b.score - a.score)
      : [];

    ui.sectionTitle(ctx, '门店经营评级', 116, '经营能力与消费者口碑分开看', 390);
    ui.metricCard(ctx, 10, 130, 116, 72, '经营评级', rating.grade + ' · ' + Math.round(rating.score), rating.gradeLabel, { valueColor: ratingUi.colorForGrade(rating.grade) });
    ui.metricCard(ctx, 137, 130, 116, 72, '消费者口碑', rating.consumerStars.toFixed(2) + ' / 5', '顾客评分，不等于经营评级');
    ui.metricCard(ctx, 264, 130, 116, 72, '较上期', rating.delta == null ? '—' : ((rating.delta > 0 ? '+' : '') + rating.delta.toFixed(1)), rating.trendLabel, { valueColor: rating.delta > 0 ? ui.COLORS.green : rating.delta < 0 ? ui.COLORS.red : ui.COLORS.muted });

    ui.sectionTitle(ctx, '六维结构', 229, '一眼看出真正的短板', 390);
    ui.rect(ctx, 10, 243, 370, 174, { fill: ui.COLORS.panel, stroke: ui.COLORS.line });
    ratingUi.dimensionRows(ctx, 24, 265, 334, rating, { limit: 6, rowHeight: 24 });

    ui.sectionTitle(ctx, '诊断', 444, '', 390);
    ui.rect(ctx, 10, 458, 370, 72, { fill: ui.COLORS.paleBlue, stroke: '#BCD3DE' });
    ui.text(ctx, ratingUi.insightLine(rating) || '数据积累后会给出优势与短板。', 24, 480, 6.8, ui.COLORS.text, '700');
    const weak = rating.weaknesses && rating.weaknesses[0];
    ui.text(ctx, weak ? ('优先改善：' + weak.label + '，当前 ' + Math.round(weak.score) + ' 分') : '当前没有明显短板', 24, 507, 6.6, weak && weak.score < 70 ? ui.COLORS.red : ui.COLORS.muted, '600');

    ui.sectionTitle(ctx, '菜品与团队', 556, '评级来自现有经营数据', 390);
    ui.rect(ctx, 10, 570, 370, 68, { fill: ui.COLORS.panel, stroke: ui.COLORS.line });
    const topDish = dishes[0];
    const weakDish = dishes.length ? dishes[dishes.length - 1] : null;
    const topEmployee = employees[0];
    ui.row(ctx, 24, 590, 334, '最高菜品', topDish ? (topDish.name + ' · ' + topDish.grade + ' ' + Math.round(topDish.score)) : '暂无菜品数据', topDish ? ratingUi.colorForGrade(topDish.grade) : ui.COLORS.muted);
    ui.row(ctx, 24, 612, 334, '团队代表', topEmployee ? (topEmployee.name + ' · Lv.' + topEmployee.growthLevel + ' ' + topEmployee.tier) : '暂无员工数据');
    if (weakDish && topDish && weakDish.id !== topDish.id) {
      ui.text(ctx, '菜品短板：' + weakDish.name + ' ' + weakDish.grade + ' ' + Math.round(weakDish.score), 24, 632, 6.2, ui.COLORS.muted, '600');
    }
  }

`;
    c = replaceOnce(c, '  drawActions(ctx) {', method + '  drawActions(ctx) {', rel, 'drawRating insertion');
  }

  const oldTabs = "    ui.tabBar(ctx, [{label:'今日'}, {label:'顾客漏斗'}, {label:'产能装修'}, {label:'预警现金'}], this.tab, 75, this.addButton.bind(this), 390);\n    if (this.tab === 0) this.drawToday(ctx, d);\n    else if (this.tab === 1) this.drawFunnel(ctx, d);\n    else if (this.tab === 2) this.drawCapacity(ctx, d);\n    else this.drawRisks(ctx, d);";
  const newTabs = "    ui.tabBar(ctx, [{label:'今日'}, {label:'顾客漏斗'}, {label:'产能装修'}, {label:'预警现金'}, {label:'评级'}], this.tab, 75, this.addButton.bind(this), 390);\n    if (this.tab === 0) this.drawToday(ctx, d);\n    else if (this.tab === 1) this.drawFunnel(ctx, d);\n    else if (this.tab === 2) this.drawCapacity(ctx, d);\n    else if (this.tab === 3) this.drawRisks(ctx, d);\n    else this.drawRating(ctx, d);";
  if (!c.includes("{label:'评级'}")) {
    c = replaceOnce(c, oldTabs, newTabs, rel, 'rating tab');
  }
  write(rel, c);
}

function patchResearch() {
  const rel = 'src/scenes/researchScene.js';
  let c = read(rel);
  const importAnchor = "const opUi =\n  require('../ui/operationsUiV080.js');";
  if (!c.includes("../rating/ratingSystemV104.js")) {
    c = insertAfter(
      c,
      importAnchor,
      "\n\nconst ratingSystem =\n  require('../rating/ratingSystemV104.js');\n\nconst ratingUi =\n  require('../ui/ratingWidgetsV104.js'); // " + MARKER,
      rel,
      'rating imports'
    );
  }

  const craftAnchor = `      const craftable =
        operations
          .menuItemAvailability(
            shop.id,
            item
          );`;
  if (!c.includes('const dishRating =')) {
    c = insertAfter(
      c,
      craftAnchor,
      `

      const dishRating =
        ratingSystem
          .evaluateDish(
            item,
            {
              cost,
              craftable,
              shop,
              runtime
            }
          );`,
      rel,
      'dish rating calculation'
    );
  }

  if (!c.includes('ratingUi.badge(')) {
    const priceAnchor = `      ui.text(
        ctx,
        opUi.money(
          item.listPrice
        ),`;
    const badge = `      ratingUi.badge(
        ctx,
        236,
        y + 8,
        52,
        22,
        dishRating.grade,
        dishRating.score
      );

`;
    c = replaceOnce(c, priceAnchor, badge + priceAnchor, rel, 'dish badge');
  }
  write(rel, c);
}

function patchStaffRecruit() {
  const rel = 'src/scenes/staffScene.js';
  let c = read(rel);
  const importAnchor = "const openingConfig =\n  require('../opening/openingConfig.js');";
  if (!c.includes("../rating/ratingSystemV104.js")) {
    c = insertAfter(
      c,
      importAnchor,
      "\n\nconst ratingSystem =\n  require('../rating/ratingSystemV104.js'); // " + MARKER,
      rel,
      'rating import'
    );
  }

  const candidateAnchor = `      const candidate =
        candidates[i];`;
  if (!c.includes('const candidateRating =')) {
    c = insertAfter(
      c,
      candidateAnchor,
      `

      const candidateRating =
        ratingSystem
          .evaluateEmployee(
            candidate,
            {
              roleId:
                candidate.roleId ||
                this.roleId
            }
          );`,
      rel,
      'candidate rating'
    );
  }

  const oldLine = `        '技能 ' +
          candidate.skill +
          ' · ' +
          (
            candidate
              .personalityLabels &&
            candidate
              .personalityLabels
              .length
              ? candidate
                  .personalityLabels
                  .slice(
                    0,
                    2
                  )
                  .join(
                    '/'
                  )
              : '稳定 ' +
                candidate.stability
          ) +
          ' · 综合 ' +
          candidate.score,`;
  const newLine = `        '能力 Lv.' +
          candidateRating.growthLevel +
          ' ' +
          candidateRating.tier +
          ' · 技能 ' +
          candidate.skill +
          ' · 综合 ' +
          Math.round(
            candidateRating.score
          ),`;
  if (c.includes(oldLine)) {
    c = c.replace(oldLine, newLine);
  } else if (!c.includes("'能力 Lv.' +")) {
    throw new Error('[V104] anchor not found in ' + rel + ': candidate display');
  }
  write(rel, c);
}

function patchStaffCareer() {
  const rel = 'src/scenes/staffCareerSceneV088.js';
  let c = read(rel);
  const importAnchor = "const staffCareer =\n  require('../operations/staffCareerV088.js');";
  if (!c.includes("../rating/ratingSystemV104.js")) {
    c = insertAfter(
      c,
      importAnchor,
      "\n\nconst ratingSystem =\n  require('../rating/ratingSystemV104.js');\n\nconst ratingUi =\n  require('../ui/ratingWidgetsV104.js'); // " + MARKER,
      rel,
      'rating imports'
    );
  }

  const selectedAnchor = `      const selected =
        row.id ===
        this.selectedId;`;
  if (!c.includes('const rowRating =')) {
    c = insertAfter(
      c,
      selectedAnchor,
      `

      const rowRating =
        ratingSystem
          .evaluateEmployee(
            row
          );`,
      rel,
      'row rating'
    );
  }

  const oldRowText = `        '技能 ' +
          row.skill +
          ' · 绩效 ' +
          row.performance +
          ' · ' +
          row.statusLabel,`;
  const newRowText = `        '能力 Lv.' +
          rowRating.growthLevel +
          ' ' +
          rowRating.tier +
          ' · 绩效 ' +
          row.performance +
          ' · ' +
          row.statusLabel,`;
  if (c.includes(oldRowText)) c = c.replace(oldRowText, newRowText);
  else if (!c.includes("rowRating.growthLevel")) throw new Error('[V104] anchor not found in ' + rel + ': row level');

  const detailAnchor = `    if (selected) {
      const detailY =
        424;`;
  if (!c.includes('const selectedRating =')) {
    c = replaceOnce(
      c,
      detailAnchor,
      `    if (selected) {
      const selectedRating =
        ratingSystem
          .evaluateEmployee(
            selected
          );

      const detailY =
        424;`,
      rel,
      'selected rating'
    );
  }

  const oldTitle = `        selected.name +
          ' · Lv.' +
          selected.level +
          ' ' +
          selected.title,`;
  const newTitle = `        selected.name +
          ' · ' +
          selected.title +
          ' · 能力Lv.' +
          selectedRating.growthLevel,`;
  if (c.includes(oldTitle)) c = c.replace(oldTitle, newTitle);
  else if (!c.includes("' · 能力Lv.' +")) throw new Error('[V104] anchor not found in ' + rel + ': selected title');

  if (!c.includes('selectedRating.grade,')) {
    const detailSkillAnchor = `      ui.text(
        ctx,
        '技能 ' +`;
    const detailBadge = `      ratingUi.badge(
        ctx,
        302,
        detailY + 10,
        58,
        22,
        selectedRating.grade,
        selectedRating.score
      );

`;
    c = replaceOnce(c, detailSkillAnchor, detailBadge + detailSkillAnchor, rel, 'selected badge');
  }
  write(rel, c);
}

function patchAdvancedManagement() {
  const rel = 'src/scenes/advancedManagementSceneV0862.js';
  let c = read(rel);
  if (!c.includes("../rating/ratingSystemV104.js")) {
    c = insertAfter(
      c,
      "const progressSystem = require('../progress/operatingProgressV0862.js');",
      "\nconst ratingSystem = require('../rating/ratingSystemV104.js'); // " + MARKER,
      rel,
      'rating import'
    );
  }

  const growthAnchor = `    const growth=operations.growthSnapshot(shop.id)||{};
    const portfolio=operations.brandPortfolioSnapshot()||{};`;
  if (!c.includes('const brandRating=')) {
    c = insertAfter(
      c,
      growthAnchor,
      `
    const brandRating=ratingSystem.evaluateBrand({
      brand:growth.brand||{},
      portfolio,
      store:shop,
      growth
    });`,
      rel,
      'brand rating'
    );
  }

  const oldSummary = "    this.summaryCard(ctx,'品牌成长','Lv.'+num(growth.brand&&growth.brand.level)+' · '+(growth.brand&&growth.brand.name||'起步品牌'),'管理点 '+progress.managementPoints+' · 成就点 '+num(growth.achievementPoints),136);";
  const newSummary = "    this.summaryCard(ctx,'品牌成长','Lv.'+num(growth.brand&&growth.brand.level)+' · '+(growth.brand&&growth.brand.name||'起步品牌'),'评级 '+brandRating.grade+' '+Math.round(brandRating.score)+' · '+brandRating.tier+' · 管理点 '+progress.managementPoints,136);";
  if (c.includes(oldSummary)) c = c.replace(oldSummary, newSummary);
  else if (!c.includes("'评级 '+brandRating.grade")) throw new Error('[V104] anchor not found in ' + rel + ': brand summary');
  write(rel, c);
}

function patchTestRunner() {
  const rel = 'scripts/run-ci-tests-v060.js';
  let c = read(rel);
  if (!c.includes("'tests/ratingSystemV104.test.js'")) {
    c = replaceOnce(
      c,
      "    'tests/financialSystemV103.test.js',",
      "    'tests/ratingSystemV104.test.js',\n    'tests/financialSystemV103.test.js',",
      rel,
      'rating test registration'
    );
  }
  write(rel, c);
}

function main() {
  patchMain();
  patchStoreDetail();
  patchResearch();
  patchStaffRecruit();
  patchStaffCareer();
  patchAdvancedManagement();
  patchTestRunner();
  console.log('[V104] unified rating visualization patch applied successfully');
}

main();
