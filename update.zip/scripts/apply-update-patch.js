'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const TARGET_VERSION =
  '0.8.20';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs
    .readFileSync(
      abs(rel),
      'utf8'
    );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (index < 0) {
    throw new Error(
      'V0.8.20 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function insertBefore(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      anchor
    );

  if (index < 0) {
    throw new Error(
      'V0.8.20 insertion anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    addition +
    source.slice(
      index
    )
  );
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      '0.8.19' &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.20 requires formal V0.8.19 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateSupplierPack() {
  const rel =
    'src/supplier/supplierPackV10.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`  SUPPLIER_CATEGORIES,
  SUPPLIER_ARCHETYPES,`,
`  SUPPLIER_CATEGORIES,
  SCALE_TIERS,
  SUPPLIER_ARCHETYPES,`,
      'supplier pack SCALE_TIERS export'
    );

  write(
    rel,
    source
  );
}

function replaceSupplierEngine() {
  const templateRel =
    'scripts/V0820_SUPPLIER_ENGINE.template.txt';

  const template =
    read(
      templateRel
    );

  write(
    'src/supplier/supplierEngineV10.js',
    template
  );

  fs.unlinkSync(
    abs(
      templateRel
    )
  );
}

function replaceProcurementEngine() {
  const templateRel =
    'scripts/V0820_PROCUREMENT_ENGINE.template.txt';

  const template =
    read(
      templateRel
    );

  write(
    'src/supplier/procurementEngineV10.js',
    template
  );

  fs.unlinkSync(
    abs(
      templateRel
    )
  );
}

function updateSupplierIndex() {
  write(
    'src/supplier/index.js',
`'use strict';

module.exports = {
  pack:
    require('./supplierPackV10.js'),
  rules:
    require('./supplierRulesV10.js'),
  database:
    require('./supplierProcurementDatabaseV0820.js'),
  engine:
    require('./supplierEngineV10.js'),
  procurement:
    require('./procurementEngineV10.js')
};
`
  );
}

function updateOperationsStore() {
  const rel =
    'src/operations/operationsStoreV080.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const procurementEngine =
  require('../supplier/procurementEngineV10.js');`,
`const procurementEngine =
  require('../supplier/procurementEngineV10.js');

const supplierProcurementDatabase =
  require('../supplier/supplierProcurementDatabaseV0820.js');`,
      'operations supplier database import'
    );

  source =
    replaceOnce(
      source,
`          'orderedDay',
          'expectedDay',
          'receivedDay'`,
`          'orderedDay',
          'expectedDay',
          'paymentDueDay',
          'receivedDay'`,
      'legacy procurement calendar fields'
    );

  source =
    replaceOnce(
      source,
`  normalizeLegacyCalendar(
    runtime
  );`,
`  normalizeLegacyCalendar(
    runtime
  );

  procurementEngine
    .updatePurchaseOrderStatuses(
      runtime.procurement,
      runtime.day
    );`,
      'runtime procurement status sync'
    );

  const apiBlock =
`function supplierCatalog(
  shopId,
  filters
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return [];
  }

  return (
    supplierEngine
      .getSupplierCatalog(
        runtime.supplierNetwork,
        filters ||
        {}
      )
  );
}

function compareSupplierQuotes(
  shopId,
  ingredientId,
  qtyKg,
  options
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return [];
  }

  const shop =
    getShop(
      shopId
    );

  const modifiers =
    dynamicWorldSystem
      .getModifiers({
        shopId,
        districtId:
          shop &&
          shop.districtId
      });

  return (
    supplierEngine
      .compareQuotes(
        runtime.supplierNetwork,
        ingredientId,
        qtyKg,
        {
          day:
            runtime.day,
          marketIndex:
            Number(
              modifiers
                .supplyCostMultiplier
            ) || 1,
          ...(
            options ||
            {}
          )
        }
      )
  );
}

function negotiateSupplierQuote(
  shopId,
  supplierId,
  ingredientId,
  qtyKg,
  options
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return {
      ok:false,
      reason:'门店不存在'
    };
  }

  const supplier =
    runtime
      .supplierNetwork
      .find(
        item =>
          item.id ===
          supplierId
      );

  if (!supplier) {
    return {
      ok:false,
      reason:'供应商不存在'
    };
  }

  const requestedKg =
    Math.max(
      0.1,
      Number(
        qtyKg
      ) || 0
    );

  const orderKg =
    Math.max(
      requestedKg,
      supplierProcurementDatabase
        .minimumOrderKg(
          supplier
        )
    );

  return (
    supplierEngine
      .negotiateQuote(
        supplier,
        ingredientId,
        orderKg,
        {
          day:
            runtime.day,
          ...(
            options ||
            {}
          )
        }
      )
  );
}

function createManualPurchaseOrder(
  shopId,
  supplierId,
  ingredientId,
  qtyKg,
  options
) {
  const opts =
    options ||
    {};

  return mutate(
    shopId,
    runtime => {
      const supplier =
        runtime
          .supplierNetwork
          .find(
            item =>
              item.id ===
              supplierId
          );

      if (!supplier) {
        return {
          ok:false,
          reason:'供应商不存在'
        };
      }

      const requestedKg =
        Math.max(
          0.1,
          Number(
            qtyKg
          ) || 0
        );

      const orderKg =
        opts.adjustToMoq ===
          false
          ? requestedKg
          : Math.max(
              requestedKg,
              supplierProcurementDatabase
                .minimumOrderKg(
                  supplier
                )
            );

      const quote =
        opts.negotiate
          ? supplierEngine
              .negotiateQuote(
                supplier,
                ingredientId,
                orderKg,
                {
                  day:
                    runtime.day,
                  buyerPower:
                    opts.buyerPower,
                  rounds:
                    opts.rounds
                }
              )
          : supplierEngine
              .quote(
                supplier,
                ingredientId,
                orderKg,
                {
                  day:
                    runtime.day
                }
              );

      if (
        !quote ||
        !quote.ok
      ) {
        return quote || {
          ok:false,
          reason:'无法获得报价'
        };
      }

      quote.requestedKg =
        requestedKg;

      quote.moqAdjusted =
        orderKg >
        requestedKg +
          0.0001;

      return (
        procurementEngine
          .createPurchaseOrder(
            runtime.procurement,
            quote,
            {
              day:
                runtime.day,
              network:
                runtime.supplierNetwork,
              source:'manual'
            }
          )
      );
    }
  );
}

function receiveManualPurchaseOrder(
  shopId,
  poId,
  options
) {
  const opts =
    options ||
    {};

  return mutate(
    shopId,
    runtime => {
      procurementEngine
        .updatePurchaseOrderStatuses(
          runtime.procurement,
          runtime.day
        );

      const po =
        procurementEngine
          .getPurchaseOrder(
            runtime.procurement,
            poId
          );

      if (!po) {
        return {
          ok:false,
          reason:'采购单不存在'
        };
      }

      if (
        runtime.day <
          Number(
            po.expectedDay
          ) &&
        opts.allowEarly !==
          true
      ) {
        return {
          ok:false,
          reason:'货物尚未到达',
          expectedDay:
            po.expectedDay,
          currentDay:
            runtime.day
        };
      }

      const cash =
        Number(
          gameState
            .getPlayer()
            .cash
        ) || 0;

      if (
        cash <
        Number(
          po.total
        )
      ) {
        return {
          ok:false,
          reason:'资金不足',
          need:
            Number(
              po.total
            ) || 0,
          cash
        };
      }

      const received =
        procurementEngine
          .receivePurchaseOrder(
            runtime.procurement,
            poId,
            runtime.inventory,
            {
              day:
                runtime.day,
              network:
                runtime.supplierNetwork,
              enforceArrival:true,
              allowEarly:
                opts.allowEarly ===
                true
            }
          );

      if (!received.ok) {
        return received;
      }

      if (
        !gameState
          .spendCash(
            Number(
              po.total
            ) || 0
          )
      ) {
        return {
          ok:false,
          reason:'付款失败'
        };
      }

      po.paymentStatus =
        'paid';

      po.paidDay =
        runtime.day;

      return {
        ok:true,
        po,
        lot:
          received.lot
      };
    }
  );
}

function cancelManualPurchaseOrder(
  shopId,
  poId,
  reason
) {
  return mutate(
    shopId,
    runtime =>
      procurementEngine
        .cancelPurchaseOrder(
          runtime.procurement,
          poId,
          {
            day:
              runtime.day,
            reason:
              reason ||
              'manual'
          }
        )
  );
}

function procurementOverview(
  shopId
) {
  const runtime =
    getRuntime(
      shopId
    );

  if (!runtime) {
    return null;
  }

  return (
    procurementEngine
      .procurementOverview(
        runtime.procurement,
        runtime.supplierNetwork,
        runtime.day
      )
  );
}

`;

  source =
    insertBefore(
      source,
      'function autoRestock(\n  shopId\n) {',
      apiBlock,
      'function supplierCatalog(',
      'supplier/procurement operation APIs'
    );

  source =
    replaceOnce(
      source,
`              {
                day:
                  runtime.day
              }
            );`,
`              {
                day:
                  runtime.day,
                network:
                  runtime.supplierNetwork,
                source:
                  'auto_restock'
              }
            );`,
      'auto restock create order network context'
    );

  source =
    replaceOnce(
      source,
`              {
                day:
                  runtime.day
              }
            );

        if (
          !received.ok`,
`              {
                day:
                  runtime.day,
                network:
                  runtime.supplierNetwork,
                instant:true
              }
            );

        if (
          !received.ok`,
      'auto restock receive network context'
    );

  source =
    replaceOnce(
      source,
`  inventoryLotRows,
  inventoryHealth,
  autoRestock,`,
`  inventoryLotRows,
  inventoryHealth,
  supplierCatalog,
  compareSupplierQuotes,
  negotiateSupplierQuote,
  createManualPurchaseOrder,
  receiveManualPurchaseOrder,
  cancelManualPurchaseOrder,
  procurementOverview,
  autoRestock,`,
      'operations supplier/procurement exports'
    );

  write(
    rel,
    source
  );
}

function updateRestaurantRuntime() {
  const rel =
    'src/operations/restaurantRuntimeV10.js';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  let source =
    read(rel);

  source =
    source.replace(
      `for(const po of orders)procurement.receivePurchaseOrder(runtime.procurement,po.id,runtime.inventory,{day:runtime.day});`,
      `for(const po of orders)procurement.receivePurchaseOrder(runtime.procurement,po.id,runtime.inventory,{day:runtime.day,network:runtime.supplierNetwork,instant:true});`
    );

  write(
    rel,
    source
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0820.test.js'
    )
  ) {
    return;
  }

  const anchor =
`    'tests/ingredientInventoryDatabaseV0819.test.js',
    'tests/inventoryIntegrationV0819.test.js',
    'tests/updateInfrastructureV0819.test.js',
    'tests/v60CleanBase.test.js'`;

  const replacement =
`    'tests/ingredientInventoryDatabaseV0819.test.js',
    'tests/inventoryIntegrationV0819.test.js',
    'tests/updateInfrastructureV0819.test.js',
    'tests/supplierProcurementDatabaseV0820.test.js',
    'tests/procurementLogisticsIntegrationV0820.test.js',
    'tests/updateInfrastructureV0820.test.js',
    'tests/v60CleanBase.test.js'`;

  source =
    replaceOnce(
      source,
      anchor,
      replacement,
      'permanent CI runner V0820'
    );

  write(
    rel,
    source
  );
}

function updateMainLabel() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.19 食材库存数据库版启动成功',
      '城市餐饮经营小游戏 V0.8.20 供应商采购物流数据库版启动成功'
    );

  write(
    rel,
    source
  );
}

// setup-android@v3 compatibility for the ephemeral GitHub runner only.
function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const binDir =
    path.join(
      latestDir,
      'bin'
    );

  const sdkmanager =
    path.join(
      binDir,
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.20] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const realSdkmanager =
    path.join(
      binDir,
      'sdkmanager.v0820-real'
    );

  if (
    !fs.existsSync(
      realSdkmanager
    )
  ) {
    fs.renameSync(
      sdkmanager,
      realSdkmanager
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0820-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then',
    '    continue',
    '  fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then',
    '  exit 0',
    'fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.20] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.20 package version finalize failed'
    );
  }

  for (
    const rel
    of [
      'src/supplier/supplierProcurementDatabaseV0820.js',
      'tests/supplierProcurementDatabaseV0820.test.js',
      'tests/procurementLogisticsIntegrationV0820.test.js',
      'tests/updateInfrastructureV0820.test.js'
    ]
  ) {
    if (
      !fs.existsSync(
        abs(rel)
      )
    ) {
      throw new Error(
        'V0.8.20 required file missing: ' +
        rel
      );
    }
  }

  for (
    const helper
    of [
      'scripts/V0820_SUPPLIER_ENGINE.template.txt',
      'scripts/V0820_PROCUREMENT_ENGINE.template.txt'
    ]
  ) {
    if (
      fs.existsSync(
        abs(helper)
      )
    ) {
      throw new Error(
        'V0.8.20 disposable template not removed: ' +
        helper
      );
    }
  }

  const supplierEngine =
    read(
      'src/supplier/supplierEngineV10.js'
    );

  for (
    const marker
    of [
      'supplierProcurementDatabaseV0820.js',
      'function negotiateQuote(',
      'function getSupplierCatalog('
    ]
  ) {
    if (
      !supplierEngine.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.20 supplier engine validation missing ' +
        marker
      );
    }
  }

  const procurement =
    read(
      'src/supplier/procurementEngineV10.js'
    );

  for (
    const marker
    of [
      'supplierProcurementDatabaseV0820.js',
      'function updatePurchaseOrderStatuses(',
      'function cancelPurchaseOrder(',
      'function procurementOverview(',
      'enforceArrival',
      'batchNo:'
    ]
  ) {
    if (
      !procurement.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.20 procurement validation missing ' +
        marker
      );
    }
  }

  const operations =
    read(
      'src/operations/operationsStoreV080.js'
    );

  for (
    const marker
    of [
      'function supplierCatalog(',
      'function compareSupplierQuotes(',
      'function negotiateSupplierQuote(',
      'function createManualPurchaseOrder(',
      'function receiveManualPurchaseOrder(',
      'function cancelManualPurchaseOrder(',
      'function procurementOverview('
    ]
  ) {
    if (
      !operations.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.20 operations validation missing ' +
        marker
      );
    }
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/supplierProcurementDatabaseV0820.test.js',
      'tests/procurementLogisticsIntegrationV0820.test.js',
      'tests/updateInfrastructureV0820.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.20 runner validation missing ' +
        marker
      );
    }
  }
}

updatePackage();
updatePackageLock();
updateSupplierPack();
replaceSupplierEngine();
replaceProcurementEngine();
updateSupplierIndex();
updateOperationsStore();
updateRestaurantRuntime();
updateRunner();
updateMainLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.20] PASS：供应商 / 采购 / 物流数据库统一完成'
);
