'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const BASE_VERSION =
  '0.8.29';

const TARGET_VERSION =
  '0.8.33';

function abs(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function read(rel) {
  return fs.readFileSync(
    abs(rel),
    'utf8'
  );
}

function write(
  rel,
  content
) {
  fs.writeFileSync(
    abs(rel),
    content,
    'utf8'
  );
}

function replaceOnce(
  source,
  from,
  to,
  label
) {
  if (
    source.includes(
      to
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      from
    );

  if (
    index <
    0
  ) {
    throw new Error(
      'V0.8.30-33 patch anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    to +
    source.slice(
      index +
      from.length
    )
  );
}

function insertBefore(
  source,
  anchor,
  addition,
  marker,
  label
) {
  if (
    marker &&
    source.includes(
      marker
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      anchor
    );

  if (
    index <
    0
  ) {
    throw new Error(
      'V0.8.30-33 insertion anchor missing: ' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    addition +
    source.slice(
      index
    )
  );
}

function cleanupLegacyRootWorkflow() {
  if (
    fs.existsSync(
      abs(
        'apply-update.yml'
      )
    )
  ) {
    fs.unlinkSync(
      abs(
        'apply-update.yml'
      )
    );

    console.log(
      '[V0.8.30-33] removed stray root apply-update.yml'
    );
  }
}

function updatePackage() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
      BASE_VERSION &&
    pkg.version !==
      TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.30-33 requires formal V0.8.29 baseline; current=' +
      pkg.version
    );
  }

  pkg.version =
    TARGET_VERSION;

  write(
    'package.json',
    JSON.stringify(
      pkg,
      null,
      2
    ) +
    '\n'
  );
}

function updatePackageLock() {
  const rel =
    'package-lock.json';

  if (
    !fs.existsSync(
      abs(rel)
    )
  ) {
    return;
  }

  const lock =
    JSON.parse(
      read(rel)
    );

  lock.version =
    TARGET_VERSION;

  if (
    lock.packages &&
    lock.packages['']
  ) {
    lock.packages['']
      .version =
      TARGET_VERSION;
  }

  write(
    rel,
    JSON.stringify(
      lock,
      null,
      2
    ) +
    '\n'
  );
}

function updateOperationsStore() {
  const rel =
    'src/operations/operationsStoreV080.js';

  let source =
    read(rel);

  source =
    replaceOnce(
      source,
`const environmentWorldCoordinator =
  require('../world/environmentWorldCoordinatorV0829.js');

const customerRandomDatabase =`,
`const environmentWorldCoordinator =
  require('../world/environmentWorldCoordinatorV0829.js');

const regulatoryFoodSafetySystem =
  require('../regulatory/regulatoryFoodSafetySystemV0830.js');

const socialInteractionSystem =
  require('../social/socialInteractionSystemV0831.js');

const globalRandomEngine =
  require('../core/globalRandomEngineV0832.js');

const growthAchievementSystem =
  require('../progress/growthAchievementSystemV0833.js');

const customerRandomDatabase =`,
      'operations V0830-33 imports'
    );

  source =
    replaceOnce(
      source,
`          note:'招聘入职成本'
        }
      );

    persist(
      shopId
    );`,
`          note:'招聘入职成本'
        }
      );

    socialInteractionSystem
      .registerActor(
        shopId,
        result.staff &&
        (
          result.staff.personProfile ||
          result.staff
        ) ||
        {},
        {
          roleId:
            result.staff &&
            result.staff.roleId ||
            null,
          source:'staff',
          day:
            currentDay()
        }
      );

    persist(
      shopId
    );`,
      'hire -> social bridge'
    );



  const apiBlock =
`function regulatorySnapshot(
  shopId
) {
  return (
    regulatoryFoodSafetySystem
      .overview(
        shopId
      )
  );
}

function runRegulatoryInspection(
  shopId,
  options
) {
  const opts =
    options || {};

  const shop =
    getShop(
      shopId
    );

  return (
    regulatoryFoodSafetySystem
      .runInspection(
        shopId,
        opts.day == null
          ? currentDay()
          : Number(
              opts.day
            ),
        {
          ...opts,
          districtId:
            opts.districtId ||
            shop &&
            shop.districtId ||
            null
        }
      )
  );
}

function remediateRegulatoryInspection(
  shopId,
  inspectionId,
  options
) {
  return (
    regulatoryFoodSafetySystem
      .remediate(
        shopId,
        inspectionId,
        {
          ...(options || {}),
          day:
            options &&
            options.day != null
              ? Number(
                  options.day
                )
              : currentDay()
        }
      )
  );
}

function processRegulatoryDay(
  shopId,
  day,
  options
) {
  const shop =
    getShop(
      shopId
    );

  return (
    regulatoryFoodSafetySystem
      .processDay(
        shopId,
        day == null
          ? currentDay()
          : Number(day),
        {
          ...(options || {}),
          districtId:
            options &&
            options.districtId ||
            shop &&
            shop.districtId ||
            null
        }
      )
  );
}

function registerSocialActor(
  shopId,
  actor,
  options
) {
  return (
    socialInteractionSystem
      .registerActor(
        shopId,
        actor,
        options || {}
      )
  );
}

function socialInteract(
  shopId,
  actorId,
  otherId,
  effect,
  options
) {
  return (
    socialInteractionSystem
      .interact(
        shopId,
        actorId,
        otherId,
        effect || {},
        options || {}
      )
  );
}

function generateSocialDialogue(
  shopId,
  actorId,
  otherId,
  options
) {
  return (
    socialInteractionSystem
      .generateDialogue(
        shopId,
        actorId,
        otherId,
        options || {}
      )
  );
}

function generateSocialBarrage(
  shopId,
  options
) {
  return (
    socialInteractionSystem
      .generateBarrage(
        shopId,
        options || {}
      )
  );
}

function socialNetwork(
  shopId,
  actorId
) {
  return (
    socialInteractionSystem
      .network(
        shopId,
        actorId
      )
  );
}

function socialSnapshot(
  shopId
) {
  return (
    socialInteractionSystem
      .overview(
        shopId
      )
  );
}

function randomSnapshot() {
  return (
    globalRandomEngine
      .snapshot()
  );
}

function randomInt(
  namespace,
  scope,
  min,
  max
) {
  return (
    globalRandomEngine
      .int(
        namespace,
        scope,
        min,
        max
      )
  );
}

function randomChance(
  namespace,
  scope,
  probability
) {
  return (
    globalRandomEngine
      .chance(
        namespace,
        scope,
        probability
      )
  );
}

function resetRandomStream(
  namespace,
  scope
) {
  return (
    globalRandomEngine
      .resetStream(
        namespace,
        scope
      )
  );
}

function growthSnapshot(
  shopId
) {
  return (
    growthAchievementSystem
      .overview(
        shopId,
        getRuntime(
          shopId
        )
      )
  );
}

function evaluateGrowth(
  shopId,
  context
) {
  return (
    growthAchievementSystem
      .evaluate(
        shopId,
        getRuntime(
          shopId
        ),
        context || {}
      )
  );
}

function addHiddenClue(
  hiddenId,
  clue
) {
  return (
    growthAchievementSystem
      .addClue(
        hiddenId,
        clue
      )
  );
}

function discoverHiddenContent(
  shopId,
  hiddenId
) {
  return (
    growthAchievementSystem
      .discoverHidden(
        shopId,
        hiddenId
      )
  );
}

function rollHiddenEncounter(
  shopId,
  context
) {
  return (
    growthAchievementSystem
      .rollHidden(
        shopId,
        context || {}
      )
  );
}

function rollEasterEggEvent(
  shopId,
  context
) {
  return (
    growthAchievementSystem
      .rollEasterEvent(
        shopId,
        context || {}
      )
  );
}

`;

  source =
    insertBefore(
      source,
      'function supplierCatalog(\n  shopId,',
      apiBlock,
      'function regulatorySnapshot(',
      'V0830-33 operation APIs'
    );

  source =
    replaceOnce(
      source,
`        processEnvironmentDay(
          closedDay,
          shopId,
          {}
        );`,
`        processEnvironmentDay(
          closedDay,
          shopId,
          {}
        );

        const shop =
          getShop(
            shopId
          );

        regulatoryFoodSafetySystem
          .processDay(
            shopId,
            closedDay,
            {
              districtId:
                shop &&
                shop.districtId
            }
          );

        const financeView =
          completeFinanceSystem
            .snapshot(
              shopId,
              runtime.ledger
            );

        const dailyStatements =
          financeView &&
          Array.isArray(
            financeView
              .dailyStatements
          )
            ? financeView
                .dailyStatements
            : [];

        const marketingView =
          marketingPlatformMembership
            .overview(
              shopId,
              runtime
            );

        const regulatoryView =
          regulatoryFoodSafetySystem
            .overview(
              shopId
            );

        const staffView =
          staffManagement
            .teamSnapshot(
              shopId,
              gameState
                .getTime()
            );

        const profitDays =
          dailyStatements
            .filter(
              item =>
                Number(
                  item.profit
                ) >
                0
            )
            .length;

        const bestDailyRevenue =
          dailyStatements
            .reduce(
              (
                best,
                item
              ) =>
                Math.max(
                  best,
                  Number(
                    item.revenue
                  ) ||
                  0
                ),
              0
            );

        const totalCustomers =
          dailyStatements
            .reduce(
              (
                total,
                item
              ) =>
                total +
                (
                  Number(
                    item.customers
                  ) ||
                  0
                ),
              0
            );

        const latestViolation =
          regulatoryView
            .latestInspections
            .find(
              item =>
                item.result !==
                'pass'
            );

        const noViolationStreak =
          latestViolation
            ? Math.max(
                0,
                closedDay -
                Number(
                  latestViolation.day
                )
              )
            : closedDay;

        const growthResult =
          growthAchievementSystem
            .evaluate(
              shopId,
              runtime,
              {
                daysPlayed:
                  closedDay,
                profitDays,
                bestDailyRevenue,
                dailyRevenue:
                  result
                    .result
                    .financial
                    .revenue,
                totalCustomers,
                reviewCount:
                  Number(
                    runtime
                      .shop
                      .reviewCount
                  ) ||
                  0,
                rating:
                  Number(
                    runtime
                      .shop
                      .rating
                  ) ||
                  4,
                memberCount:
                  marketingView
                    .memberCount,
                staffCount:
                  staffView
                    .headcount,
                campaignCount:
                  marketingView
                    .metrics
                    .campaignsStarted,
                supplierCount:
                  runtime
                    .supplierNetwork
                    .length,
                inspectionsPassed:
                  regulatoryView
                    .metrics
                    .passed,
                noViolationStreak
              }
            );

        growthAchievementSystem
          .rollHidden(
            shopId,
            {
              daysPlayed:
                closedDay,
              reviewCount:
                Number(
                  runtime
                    .shop
                    .reviewCount
                ) ||
                0,
              storeQuality:
                Math.round(
                  (
                    Number(
                      runtime
                        .shop
                        .rating
                    ) ||
                    4
                  ) *
                  20
                ),
              quality:
                Math.round(
                  (
                    Number(
                      runtime
                        .shop
                        .rating
                    ) ||
                    4
                  ) *
                  20
                ),
              storeCount:
                gameState
                  .getBusiness()
                  .shops
                  .length,
              minProfitDays:
                profitDays,
              profitDays,
              cashflowScore:
                growthResult
                  .achievementPoints
            }
          );`,
      'day close regulatory/growth bridge'
    );

  source =
    replaceOnce(
      source,
`  processEnvironmentDay,
  generateCustomer,`,
`  processEnvironmentDay,
  regulatorySnapshot,
  runRegulatoryInspection,
  remediateRegulatoryInspection,
  processRegulatoryDay,
  registerSocialActor,
  socialInteract,
  generateSocialDialogue,
  generateSocialBarrage,
  socialNetwork,
  socialSnapshot,
  randomSnapshot,
  randomInt,
  randomChance,
  resetRandomStream,
  growthSnapshot,
  evaluateGrowth,
  addHiddenClue,
  discoverHiddenContent,
  rollHiddenEncounter,
  rollEasterEggEvent,
  generateCustomer,`,
      'operations V0830-33 exports'
    );

  write(
    rel,
    source
  );
}

function updateOperationsIndex() {
  write(
    'src/operations/index.js',
`'use strict';

module.exports = {
  settlement:
    require('./settlementEngineV10.js'),
  retention:
    require('./retentionEngineV10.js'),
  staff:
    require('./staffOperationsEngineV10.js'),
  staffManagement:
    require('./staffManagementCoordinatorV0823.js'),
  live:
    require('./liveOperationsCoordinatorV0824.js'),
  delivery:
    require('./deliveryEngineV10.js'),
  marketing:
    require('./marketingEngineV10.js'),
  marketingPlatformMembership:
    require('./marketingPlatformMembershipV0826.js'),
  brand:
    require('./brandGrowthEngineV10.js'),
  events:
    require('./restaurantEventEngineV10.js'),
  runtime:
    require('./restaurantRuntimeV10.js'),
  finance:
    require('../finance/completeFinanceSystemV0825.js'),
  reputation:
    require('../reputation/reputationMediaSystemV0827.js'),
  commercialEcology:
    require('../world/commercialEcologySystemV0828.js'),
  environment:
    require('../world/environmentWorldCoordinatorV0829.js'),
  regulatory:
    require('../regulatory/regulatoryFoodSafetySystemV0830.js'),
  social:
    require('../social/socialInteractionSystemV0831.js'),
  random:
    require('../core/globalRandomEngineV0832.js'),
  growth:
    require('../progress/growthAchievementSystemV0833.js')
};
`
  );
}

function updateRunner() {
  const rel =
    'scripts/run-ci-tests-v060.js';

  let source =
    read(rel);

  if (
    source.includes(
      'tests/updateInfrastructureV0833.test.js'
    )
  ) {
    return;
  }

  const anchor =
    `    'tests/v60CleanBase.test.js'`;

  const addition =
`    'tests/regulatoryFoodSafetySystemV0830.test.js',
    'tests/socialInteractionSystemV0831.test.js',
    'tests/globalRandomEngineV0832.test.js',
    'tests/growthAchievementSystemV0833.test.js',
    'tests/megaRegulatorySocialGrowthV0833.test.js',
    'tests/updateInfrastructureV0833.test.js',
`;

  const index =
    source.indexOf(
      anchor
    );

  if (
    index <
    0
  ) {
    throw new Error(
      'V0.8.30-33 runner anchor missing: v60CleanBase'
    );
  }

  source =
    source.slice(
      0,
      index
    ) +
    addition +
    source.slice(
      index
    );

  write(
    rel,
    source
  );
}

function updateMainLabel() {
  const rel =
    'src/main.js';

  let source =
    read(rel);

  source =
    source.replace(
      '城市餐饮经营小游戏 V0.8.29 营销口碑商圈环境四合一版启动成功',
      '城市餐饮经营小游戏 V0.8.33 监管社交随机成长四合一版启动成功'
    );

  write(
    rel,
    source
  );
}

function patchAndroidRunnerCompatibility() {
  const sdkRoot =
    process.env.ANDROID_SDK_ROOT ||
    process.env.ANDROID_HOME ||
    '/usr/local/lib/android/sdk';

  const latestDir =
    path.join(
      sdkRoot,
      'cmdline-tools',
      'latest'
    );

  const sourceProperties =
    path.join(
      latestDir,
      'source.properties'
    );

  const sdkmanager =
    path.join(
      latestDir,
      'bin',
      'sdkmanager'
    );

  if (
    !fs.existsSync(
      sourceProperties
    ) ||
    !fs.existsSync(
      sdkmanager
    )
  ) {
    console.log(
      '[V0.8.30-33] Android SDK runner compatibility: sdkmanager not found, skip'
    );
    return;
  }

  let properties =
    fs.readFileSync(
      sourceProperties,
      'utf8'
    );

  properties =
    properties
      .replace(
        /^Pkg\.Revision=.*$/m,
        'Pkg.Revision=16.0'
      )
      .replace(
        /^Pkg\.Path=.*$/m,
        'Pkg.Path=cmdline-tools;16.0'
      );

  fs.writeFileSync(
    sourceProperties,
    properties,
    'utf8'
  );

  const real =
    path.join(
      path.dirname(
        sdkmanager
      ),
      'sdkmanager.v0833-real'
    );

  if (
    !fs.existsSync(
      real
    )
  ) {
    fs.renameSync(
      sdkmanager,
      real
    );
  }

  const wrapper = [
    '#!/usr/bin/env bash',
    'set -e',
    'REAL="$(cd "$(dirname "$0")" && pwd)/sdkmanager.v0833-real"',
    'ARGS=()',
    'for ARG in "$@"; do',
    '  if [ "$ARG" = "tools" ]; then continue; fi',
    '  ARGS+=("$ARG")',
    'done',
    'if [ "${#ARGS[@]}" -eq 0 ]; then exit 0; fi',
    'exec "$REAL" "${ARGS[@]}"',
    ''
  ].join(
    '\n'
  );

  fs.writeFileSync(
    sdkmanager,
    wrapper,
    'utf8'
  );

  fs.chmodSync(
    sdkmanager,
    0o755
  );

  console.log(
    '[V0.8.30-33] Android SDK runner compatibility enabled'
  );
}

function validate() {
  const pkg =
    JSON.parse(
      read(
        'package.json'
      )
    );

  if (
    pkg.version !==
    TARGET_VERSION
  ) {
    throw new Error(
      'V0.8.30-33 target version finalize failed'
    );
  }

  if (
    fs.existsSync(
      abs(
        'apply-update.yml'
      )
    )
  ) {
    throw new Error(
      'V0.8.30-33 stray root apply-update.yml cleanup failed'
    );
  }

  const required = [
    'src/regulatory/regulatoryFoodSafetySystemV0830.js',
    'src/social/socialInteractionSystemV0831.js',
    'src/core/globalRandomEngineV0832.js',
    'src/progress/growthAchievementSystemV0833.js',
    'tests/regulatoryFoodSafetySystemV0830.test.js',
    'tests/socialInteractionSystemV0831.test.js',
    'tests/globalRandomEngineV0832.test.js',
    'tests/growthAchievementSystemV0833.test.js',
    'tests/megaRegulatorySocialGrowthV0833.test.js',
    'tests/updateInfrastructureV0833.test.js'
  ];

  for (
    const file
    of required
  ) {
    if (
      !fs.existsSync(
        abs(file)
      )
    ) {
      throw new Error(
        'V0.8.30-33 required file missing: ' +
        file
      );
    }
  }

  const operations =
    read(
      'src/operations/operationsStoreV080.js'
    );

  for (
    const marker
    of [
      'regulatoryFoodSafetySystemV0830.js',
      'socialInteractionSystemV0831.js',
      'globalRandomEngineV0832.js',
      'growthAchievementSystemV0833.js',
      'function regulatorySnapshot(',
      'function socialSnapshot(',
      'function randomSnapshot(',
      'function growthSnapshot('
    ]
  ) {
    if (
      !operations.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.30-33 operations integration missing ' +
        marker
      );
    }
  }

  const runner =
    read(
      'scripts/run-ci-tests-v060.js'
    );

  for (
    const marker
    of [
      'tests/regulatoryFoodSafetySystemV0830.test.js',
      'tests/socialInteractionSystemV0831.test.js',
      'tests/globalRandomEngineV0832.test.js',
      'tests/growthAchievementSystemV0833.test.js',
      'tests/megaRegulatorySocialGrowthV0833.test.js',
      'tests/updateInfrastructureV0833.test.js'
    ]
  ) {
    if (
      !runner.includes(
        marker
      )
    ) {
      throw new Error(
        'V0.8.30-33 runner integration missing ' +
        marker
      );
    }
  }
}

cleanupLegacyRootWorkflow();
updatePackage();
updatePackageLock();
updateOperationsStore();
updateOperationsIndex();
updateRunner();
updateMainLabel();
patchAndroidRunnerCompatibility();
validate();

console.log(
  '[V0.8.33] PASS：21-24/26 监管/食安、社交关系、全局随机、成长/解锁/成就/隐藏内容四合一升级完成'
);
