'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const target = path.join(root, 'src', 'scenes', 'renovationScene.js');
const MARK = 'V18_RENOVATION_LAYOUT_ENGINE_ADAPTER';

if (!fs.existsSync(target)) {
  console.error('[renovation V18.2] 缺少 src/scenes/renovationScene.js，停止以避免误改。');
  process.exit(1);
}

let source = fs.readFileSync(target, 'utf8');

if (source.includes(MARK)) {
  console.log('[renovation V18.2] 布局引擎已接入，跳过重复注入。');
  process.exit(0);
}

if (!source.includes('V17_RENOVATION_UI_REWRITE') && !source.includes('V48_DYNAMIC_FLOOR_GEOMETRY_UI')) {
  console.error('[renovation V18.2] 当前装修页结构未知，停止以避免覆盖新版本。');
  process.exit(1);
}

if (!/module\.exports\s*=/.test(source)) {
  console.error('[renovation V18.2] 未找到 module.exports，无法安全安装适配器。');
  process.exit(1);
}

const addon = `\n\n/* =========================\n   ${MARK}\n   V18.2 — 房源面积 / 0.5m网格 / 碰撞 / 遮挡 / 动线 / 设备条件\n   仅接管 layout 页面；装修风格、包间、模板、承包商等旧页面继续使用原系统。\n========================= */\n;(function installV18RenovationLayoutAdapter(){\n  try {\n    require('../renovation/renovationRuntimeV18.js').install(module.exports);\n  } catch (error) {\n    try { console.error('[V18.2 renovation adapter install]', error); } catch (_) {}\n  }\n})();\n`;

fs.writeFileSync(target, source + addon, 'utf8');
console.log('[renovation V18.2] 已安全接入布局引擎。');
