'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const pkgPath =
  path.join(
    ROOT,
    'package.json'
  );

const pkg =
  JSON.parse(
    fs.readFileSync(
      pkgPath,
      'utf8'
    )
  );

if (pkg.scripts) {
  delete pkg.scripts.pretest;
}

fs.writeFileSync(
  pkgPath,
  JSON.stringify(
    pkg,
    null,
    2
  ) + '\n',
  'utf8'
);

for (
  const name
  of [
    'apply-v45-renovation-phase1.js',
    'apply-v46-renovation-playability.js'
  ]
) {
  try {
    fs.unlinkSync(
      path.join(
        __dirname,
        name
      )
    );
  } catch (error) {}
}

try {
  fs.unlinkSync(
    __filename
  );
} catch (error) {}

console.log(
  'V46 装修可玩性阶段已固定'
);
