'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = process.cwd();
const APPLY = process.argv.includes('--apply');
const REPORT_ONLY = process.argv.includes('--report-only');
const REPORT = path.join(ROOT, 'cleanup-report.json');

const cfgPath = path.join(__dirname, 'cleanup-config.json');
const cfg = fs.existsSync(cfgPath) ? JSON.parse(fs.readFileSync(cfgPath, 'utf8')) : {};

const EXCLUDED_DIRS = new Set([
  '.git', 'node_modules', '.gradle', '.idea', '.vscode',
  'build', 'dist', 'coverage', '.cleanup-quarantine'
]);

const NEVER_DELETE = new Set([
  'package.json', 'package-lock.json',
  'android/entry.js',
  '.github/workflows/apply-update.yml',
  '.github/workflows/android-apk.yml'
]);

const TEXT_EXTS = new Set(['.js', '.cjs', '.mjs', '.json', '.yml', '.yaml', '.html', '.css', '.md', '.txt', '.gradle', '.xml', '.properties']);
const SOURCE_EXTS = new Set(['.js', '.cjs', '.mjs']);

const disposableRegexes = [
  /(^|\/)(?:update|patch)[-_]?(?:old|backup|bak|tmp|copy)?\.zip$/i,
  /\.(?:bak|old|orig|rej|tmp|temp|log)$/i,
  /(?:^|\/)(?:backup|backups|old|legacy|trash|temp|tmp)(?:\/|$)/i,
  /(?: copy| - copy|副本)(?:\.[^./]+)?$/i,
  /\((?:\d+)\)(?=\.[^./]+$)/i
];

const oldScriptRegexes = [
  /(^|\/)scripts\/(?:repair|fix|migrate|migration|apply)[-_].*v\d+/i,
  /(^|\/)scripts\/.*(?:legacy|obsolete|deprecated|old)[-_]?/i,
  /(^|\/)scripts\/apply-update-patch\.js$/i
];

function posix(p) { return p.split(path.sep).join('/'); }
function abs(rel) { return path.join(ROOT, rel); }
function exists(rel) { return fs.existsSync(abs(rel)); }
function isNeverDelete(rel) { return NEVER_DELETE.has(posix(rel)); }

function walk(dir = ROOT) {
  const out = [];
  for (const ent of fs.readdirSync(dir, {withFileTypes: true})) {
    if (EXCLUDED_DIRS.has(ent.name)) continue;
    const full = path.join(dir, ent.name);
    const rel = posix(path.relative(ROOT, full));
    if (ent.isDirectory()) out.push(...walk(full));
    else out.push(rel);
  }
  return out;
}

function readText(rel) {
  try { return fs.readFileSync(abs(rel), 'utf8'); } catch { return ''; }
}

function allReferences(files) {
  const refs = new Map();
  const ignoreSources = new Set(['scripts/project-cleaner.js', 'scripts/cleanup-config.json', 'cleanup-report.json', 'README.txt']);
  const textFiles = files.filter(f => TEXT_EXTS.has(path.extname(f).toLowerCase()) && !ignoreSources.has(f));
  for (const target of files) refs.set(target, []);
  for (const src of textFiles) {
    const txt = readText(src);
    if (!txt) continue;
    for (const target of files) {
      if (src === target) continue;
      const base = path.basename(target);
      const baseNoExt = base.replace(/\.[^.]+$/, '');
      const noExt = target.replace(/\.[^.]+$/, '');
      if (txt.includes(target) || txt.includes('./' + target) || txt.includes(base) || txt.includes(baseNoExt) || txt.includes(noExt)) {
        refs.get(target).push(src);
      }
    }
  }
  return refs;
}

function canonicalVersionName(rel) {
  const dir = path.posix.dirname(rel);
  const ext = path.posix.extname(rel);
  let base = path.posix.basename(rel, ext);

  // fooV081.js / foo-v0.8.1.js / foo_v12.js -> foo.js
  let stripped = base
    .replace(/(?:[-_.]?v(?:ersion)?[-_.]?\d+(?:[._-]\d+)*)$/i, '')
    .replace(/(?:[-_.]?(?:final|fixed|fix|new|latest|clean|rewrite|refactor|old|backup|copy))(?:[-_.]?\d+)?$/i, '');

  if (stripped === base || !stripped) return null;
  return posix(path.posix.join(dir === '.' ? '' : dir, stripped + ext));
}

function versionScore(rel) {
  const b = path.basename(rel);
  const m = b.match(/v(?:ersion)?[-_.]?(\d+(?:[._-]\d+)*)/i);
  if (!m) return 0;
  const parts = m[1].split(/[._-]/).map(x => parseInt(x, 10) || 0);
  return parts.reduce((n, x, i) => n + x * Math.pow(1000, Math.max(0, 3 - i)), 0);
}

function rewriteReferences(files, fromRel, toRel) {
  const fromBase = path.basename(fromRel);
  const toBase = path.basename(toRel);
  const fromNoExt = fromRel.replace(/\.[^.]+$/, '');
  const toNoExt = toRel.replace(/\.[^.]+$/, '');
  let changed = 0;

  for (const src of files) {
    if (!TEXT_EXTS.has(path.extname(src).toLowerCase()) || src === fromRel) continue;
    let txt = readText(src);
    if (!txt) continue;
    const before = txt;

    txt = txt.split(fromRel).join(toRel);
    txt = txt.split('./' + fromRel).join('./' + toRel);
    txt = txt.split(fromNoExt).join(toNoExt);
    if (path.posix.dirname(src) === path.posix.dirname(fromRel)) {
      txt = txt.split(fromBase).join(toBase);
      txt = txt.split(fromBase.replace(/\.[^.]+$/, '')).join(toBase.replace(/\.[^.]+$/, ''));
    }

    if (txt !== before && APPLY) fs.writeFileSync(abs(src), txt, 'utf8');
    if (txt !== before) changed++;
  }
  return changed;
}

function syntaxCheck(rel) {
  if (!SOURCE_EXTS.has(path.extname(rel).toLowerCase())) return {ok: true};
  const r = cp.spawnSync(process.execPath, ['--check', abs(rel)], {encoding: 'utf8'});
  return {ok: r.status === 0, stderr: r.stderr || r.stdout || ''};
}

function quarantine(rel, quarantineRoot) {
  const src = abs(rel);
  if (!fs.existsSync(src)) return;
  const dest = path.join(quarantineRoot, rel);
  fs.mkdirSync(path.dirname(dest), {recursive: true});
  fs.renameSync(src, dest);
}

function restoreQuarantine(quarantineRoot) {
  if (!fs.existsSync(quarantineRoot)) return;
  const restoreWalk = (dir) => {
    for (const ent of fs.readdirSync(dir, {withFileTypes: true})) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) restoreWalk(full);
      else {
        const rel = path.relative(quarantineRoot, full);
        const dest = path.join(ROOT, rel);
        fs.mkdirSync(path.dirname(dest), {recursive: true});
        if (fs.existsSync(dest)) fs.rmSync(dest, {recursive: true, force: true});
        fs.renameSync(full, dest);
      }
    }
  };
  restoreWalk(quarantineRoot);
  fs.rmSync(quarantineRoot, {recursive: true, force: true});
}

function run(cmd, args) {
  const r = cp.spawnSync(cmd, args, {cwd: ROOT, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe']});
  return {ok: r.status === 0, status: r.status, stdout: r.stdout || '', stderr: r.stderr || ''};
}

function main() {
  let files = walk();
  const refs = allReferences(files);
  const report = {
    mode: APPLY ? 'apply' : 'scan',
    generatedAt: new Date().toISOString(),
    normalized: [], deleted: [], keptBecauseReferenced: [], disposable: [], warnings: [], verification: {}
  };

  // 1) Normalize versioned JS source files into canonical names.
  const groups = new Map();
  for (const f of files) {
    if (!SOURCE_EXTS.has(path.extname(f).toLowerCase())) continue;
    const canon = canonicalVersionName(f);
    if (!canon) continue;
    if (!groups.has(canon)) groups.set(canon, []);
    groups.get(canon).push(f);
  }

  const quarantineRoot = path.join(ROOT, '.cleanup-quarantine');
  const createdCanonicals = new Set();
  if (APPLY) fs.rmSync(quarantineRoot, {recursive: true, force: true});

  try {
    for (const [canon, variants] of groups) {
      if (isNeverDelete(canon)) continue;
      const candidates = [...variants];
      if (exists(canon)) candidates.push(canon);

      candidates.sort((a, b) => {
        const ra = (refs.get(a) || []).length;
        const rb = (refs.get(b) || []).length;
        if (rb !== ra) return rb - ra;
        return versionScore(b) - versionScore(a);
      });
      const winner = candidates[0];

      if (winner !== canon) {
        const check = syntaxCheck(winner);
        if (!check.ok) {
          report.warnings.push({file: winner, reason: 'syntax-error-before-normalize', detail: check.stderr.slice(0, 1000)});
          continue;
        }
        report.normalized.push({from: winner, to: canon, referencesRewritten: null});
        if (APPLY) {
          const winnerBytes = fs.readFileSync(abs(winner));
          if (exists(canon)) quarantine(canon, quarantineRoot);
          quarantine(winner, quarantineRoot);
          fs.mkdirSync(path.dirname(abs(canon)), {recursive: true});
          fs.writeFileSync(abs(canon), winnerBytes);
          createdCanonicals.add(canon);
          const changed = rewriteReferences(walk(), winner, canon);
          report.normalized[report.normalized.length - 1].referencesRewritten = changed;
        }
      }

      for (const f of variants) {
        if (f === winner) continue;
        if (isNeverDelete(f) || !exists(f)) continue;
        const referencedBy = refs.get(f) || [];
        if (referencedBy.length > 0) {
          report.keptBecauseReferenced.push({file: f, references: referencedBy, action: 'rewrite-to-canonical'});
          if (APPLY && exists(canon)) rewriteReferences(walk(), f, canon);
        }
        report.deleted.push({file: f, reason: 'superseded-version'});
        if (APPLY && exists(f)) quarantine(f, quarantineRoot);
      }
    }

    files = walk();
    const refs2 = allReferences(files);

    // 2) Remove known disposable/residual files.
    for (const f of files) {
      if (isNeverDelete(f)) continue;
      if (f === 'cleanup-report.json') continue;
      const disposable = disposableRegexes.some(r => r.test(f));
      const oldScript = oldScriptRegexes.some(r => r.test(f));
      if (!disposable && !oldScript) continue;

      const referencedBy = refs2.get(f) || [];
      if (oldScript && referencedBy.length > 0) {
        report.keptBecauseReferenced.push({file: f, references: referencedBy, action: 'kept-active-script'});
        continue;
      }
      report.disposable.push({file: f, reason: oldScript ? 'obsolete-versioned-script' : 'residual-or-backup'});
      if (APPLY && exists(f)) quarantine(f, quarantineRoot);
    }

    // 3) Explicit configured globs are conservative suffix/prefix matches.
    for (const rule of (cfg.deleteExact || [])) {
      const rel = posix(rule);
      if (exists(rel) && !isNeverDelete(rel)) {
        const liveRefs = (allReferences(walk()).get(rel) || []);
        if (liveRefs.length > 0) {
          report.keptBecauseReferenced.push({file: rel, references: liveRefs, action: 'configured-delete-blocked'});
          continue;
        }
        report.deleted.push({file: rel, reason: 'configured-exact-delete'});
        if (APPLY) quarantine(rel, quarantineRoot);
      }
    }

    // 4) Basic syntax verification after normalization.
    const finalFiles = walk();
    const badSyntax = [];
    for (const f of finalFiles.filter(x => SOURCE_EXTS.has(path.extname(x).toLowerCase()))) {
      const c = syntaxCheck(f);
      if (!c.ok) badSyntax.push({file: f, error: c.stderr.slice(0, 1200)});
    }
    report.verification.syntax = {ok: badSyntax.length === 0, failures: badSyntax};

    if (APPLY && badSyntax.length) throw new Error('Cleanup created or exposed JavaScript syntax errors.');

    // 5) Run project tests/build if available. Existing CI will run them again.
    if (fs.existsSync(path.join(ROOT, 'package.json'))) {
      const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
      if (pkg.scripts && pkg.scripts.test) {
        const r = run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['test']);
        report.verification.test = {ok: r.ok, status: r.status, tail: (r.stdout + '\n' + r.stderr).slice(-4000)};
        if (APPLY && !r.ok) throw new Error('npm test failed after cleanup.');
      }
      if (pkg.scripts && pkg.scripts['build:android-js']) {
        const r = run(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['run', 'build:android-js']);
        report.verification.androidJs = {ok: r.ok, status: r.status, tail: (r.stdout + '\n' + r.stderr).slice(-4000)};
        if (APPLY && !r.ok) throw new Error('Android JS build failed after cleanup.');
      }
    }

    if (APPLY && fs.existsSync(quarantineRoot)) fs.rmSync(quarantineRoot, {recursive: true, force: true});
    fs.writeFileSync(REPORT, JSON.stringify(report, null, 2) + '\n', 'utf8');
    console.log(`[cleanup-bot] ${APPLY ? 'APPLY' : 'SCAN'} complete`);
    console.log(`[cleanup-bot] normalized=${report.normalized.length} deleted=${report.deleted.length + report.disposable.length} guarded=${report.keptBecauseReferenced.length}`);
    console.log(`[cleanup-bot] report=${path.relative(ROOT, REPORT)}`);
  } catch (err) {
    if (APPLY) {
      for (const rel of createdCanonicals) {
        if (exists(rel)) fs.rmSync(abs(rel), {recursive: true, force: true});
      }
      restoreQuarantine(quarantineRoot);
    }
    report.verification.failed = String(err && err.stack ? err.stack : err);
    fs.writeFileSync(REPORT, JSON.stringify(report, null, 2) + '\n', 'utf8');
    console.error('[cleanup-bot] FAILED, quarantined files restored.');
    console.error(err && err.stack ? err.stack : err);
    process.exit(1);
  }
}

if (!REPORT_ONLY) main();
