'use strict';

const fs =
  require('fs');

const path =
  require('path');

const childProcess =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const MAIN =
  path.join(
    ROOT,
    'src/main.js'
  );

const STAFF =
  path.join(
    ROOT,
    'src/scenes/staffScene.js'
  );

const RESTAURANT =
  path.join(
    ROOT,
    'src/operations/restaurantSimulationV081.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.7] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function syntaxCheck(file) {
  childProcess
    .execFileSync(
      process.execPath,
      [
        '--check',
        file
      ],
      {
        cwd:ROOT,
        stdio:'inherit'
      }
    );
}

function patchRestaurant() {
  let source =
    fs.readFileSync(
      RESTAURANT,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');`,
`const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');

const operationsSchedule =
  require('./operationsScheduleV087.js');`,
      '餐厅模拟接入排班'
    );

  source =
    replaceOnce(
      source,
`    return clamp(
      base *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ),
      0.25,
      1.2
    );`,
`    const scheduled =
      operationsSchedule
        .getCoverage(
          shop.id,
          gameState
            .getTime()
        );

    return clamp(
      Math.min(
        base,
        Number(
          scheduled.factor
        ) ||
        1
      ) *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ),
      0.10,
      1.2
    );`,
      '实时排班承载'
    );

  fs.writeFileSync(
    RESTAURANT,
    source,
    'utf8'
  );
}

function patchStaff() {
  let source =
    fs.readFileSync(
      STAFF,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`    this.rounded(
      ctx,
      10,
      actionY,
      370,
      40,
      11,
      overview.coverage >=
        0.9
        ? COLORS.green
        : COLORS.navy
    );

    this.text(
      ctx,
      overview
        .peopleSummary &&
      overview
        .peopleSummary
        .count
        ? '团队情绪 ' +
          overview
            .peopleSummary
            .avgMood +
          ' · 压力 ' +
          overview
            .peopleSummary
            .avgStress +
          ' · 高离职风险 ' +
          overview
            .peopleSummary
            .highTurnoverRisk
        : overview.coverage >=
            0.9
          ? '基本班组已齐备'
          : '候选人次日会自动更新',
      195,
      actionY + 20,
      8.5,
      COLORS.white,
      '700',
      'center'
    );

    this.addButton(
      'back',
      10,
      actionY,
      370,
      40
    );`,
`    this.rounded(
      ctx,
      10,
      actionY,
      177,
      40,
      11,
      COLORS.navy
    );

    this.text(
      ctx,
      '返回门店',
      98,
      actionY + 20,
      8.5,
      COLORS.white,
      '700',
      'center'
    );

    this.addButton(
      'back',
      10,
      actionY,
      177,
      40
    );

    this.rounded(
      ctx,
      193,
      actionY,
      187,
      40,
      11,
      overview.coverage >=
        0.9
        ? COLORS.green
        : COLORS.gold
    );

    this.text(
      ctx,
      '营业时间 / 员工排班',
      286,
      actionY + 20,
      8.1,
      overview.coverage >=
        0.9
        ? COLORS.white
        : COLORS.text,
      '700',
      'center'
    );

    this.addButton(
      'schedule',
      193,
      actionY,
      187,
      40
    );`,
      '招聘页增加排班入口'
    );

  source =
    replaceOnce(
      source,
`    if (
      item.id ===
      'back'
    ) {
      sceneManager
        .switchTo(
          'shop'
        );

      return true;
    }`,
`    if (
      item.id ===
      'back'
    ) {
      sceneManager
        .switchTo(
          'shop'
        );

      return true;
    }

    if (
      item.id ===
      'schedule'
    ) {
      sceneManager
        .switchTo(
          'schedule',
          {
            shopId:
              this.shopId
          }
        );

      return true;
    }`,
      '排班按钮点击'
    );

  fs.writeFileSync(
    STAFF,
    source,
    'utf8'
  );
}

function patchMain() {
  let source =
    fs.readFileSync(
      MAIN,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const staffScene =
  require('./scenes/staffScene.js');`,
`const staffScene =
  require('./scenes/staffScene.js');

const scheduleScene =
  require('./scenes/scheduleSceneV087.js');`,
      '排班页面require'
    );

  source =
    replaceOnce(
      source,
`sceneManager.register(
  'staff',
  staffScene
);`,
`sceneManager.register(
  'staff',
  staffScene
);

sceneManager.register(
  'schedule',
  scheduleScene
);`,
      '排班页面注册'
    );

  fs.writeFileSync(
    MAIN,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/operationsScheduleV087.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/businessLifecycleV086.test.js',
    'tests/v60CleanBase.test.js'`,
`    'tests/businessLifecycleV086.test.js',
    'tests/operationsScheduleV087.test.js',
    'tests/v60CleanBase.test.js'`,
        'V0.8.7测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.7';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node scripts/apply-v087-operations-schedule.js && node tests/operationsScheduleV087.test.js && node tests/businessLifecycleV086.test.js && node tests/managementCenterV085.test.js && node tests/liveWorldV084.test.js && node tests/foundationFixesV083.test.js && node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchRestaurant();
  patchStaff();
  patchMain();
  patchRunner();
  finalizePackage();

  for (
    const file
    of [
      MAIN,
      STAFF,
      RESTAURANT,
      path.join(
        ROOT,
        'src/operations/operationsScheduleV087.js'
      ),
      path.join(
        ROOT,
        'src/scenes/scheduleSceneV087.js'
      )
    ]
  ) {
    syntaxCheck(
      file
    );
  }

  console.log(
    '[V0.8.7] 营业时间与员工排班已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
