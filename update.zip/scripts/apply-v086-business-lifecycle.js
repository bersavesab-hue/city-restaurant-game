'use strict';

const fs =
  require('fs');

const path =
  require('path');

const childProcess =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const MAIN =
  path.join(
    ROOT,
    'src/main.js'
  );

const OPENING =
  path.join(
    ROOT,
    'src/opening/openingPrepSystem.js'
  );

const RESTAURANT =
  path.join(
    ROOT,
    'src/operations/restaurantSimulationV081.js'
  );

const STORE =
  path.join(
    ROOT,
    'src/scenes/storeScene.js'
  );

const PREMIUM_UI =
  path.join(
    ROOT,
    'src/ui/premiumUi.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.6] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function syntaxCheck(file) {
  childProcess
    .execFileSync(
      process.execPath,
      [
        '--check',
        file
      ],
      {
        cwd:ROOT,
        stdio:'inherit'
      }
    );
}

function patchOpening() {
  let source =
    fs.readFileSync(
      OPENING,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`    if (
      shop &&
      ready &&
      shop.status !==
        'open'
    ) {
      shop.status =
        'ready_for_trial';
    }`,
`    if (
      shop &&
      ready &&
      shop.status !==
        'open' &&
      shop.status !==
        'trial_opening' &&
      shop.status !==
        'trial_complete'
    ) {
      shop.status =
        'ready_for_trial';
    }`,
      'readiness不得覆盖试营业状态'
    );

  source =
    replaceOnce(
      source,
`    shop.status =
      'open';

    shop.trialOpenedDay =
      this.getCurrentDay();

    return {
      ok:
        true,
      day:
        shop.trialOpenedDay
    };`,
`    shop.status =
      'trial_opening';

    shop.trialOpenedDay =
      this.getCurrentDay();

    shop.trialEndDay =
      shop.trialOpenedDay +
      3;

    shop.trialCompletedDay =
      null;

    shop.trialReport =
      null;

    return {
      ok:
        true,
      day:
        shop.trialOpenedDay,
      endDay:
        shop.trialEndDay
    };`,
      '试营业不再直接open'
    );

  fs.writeFileSync(
    OPENING,
    source,
    'utf8'
  );
}

function patchRestaurant() {
  let source =
    fs.readFileSync(
      RESTAURANT,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`  return Math.max(
    0,
    averageRestaurantDemand /
      periodMinutes *
      ratingFactor *
      brandFactor *
      marketingFactor *
      saturationFactor *
      (
        0.7 +
        coverage *
          0.3
      ) *
      dynamicDemandFactor *
      competitionFactor *
      nightFactor
  );`,
`  const trialFactor =
    shop.status ===
      'trial_opening'
      ? 0.78
      : 1;

  return Math.max(
    0,
    averageRestaurantDemand /
      periodMinutes *
      ratingFactor *
      brandFactor *
      marketingFactor *
      saturationFactor *
      (
        0.7 +
        coverage *
          0.3
      ) *
      dynamicDemandFactor *
      competitionFactor *
      nightFactor *
      trialFactor
  );`,
      '试营业真实客流'
    );

  source =
    replaceOnce(
      source,
`    if (
      shop.status !==
      'open'
    ) {
      continue;
    }`,
`    if (
      shop.status !==
        'open' &&
      shop.status !==
        'trial_opening'
    ) {
      continue;
    }`,
      '试营业进入真实经营循环'
    );

  fs.writeFileSync(
    RESTAURANT,
    source,
    'utf8'
  );
}

function patchStore() {
  let source =
    fs.readFileSync(
      STORE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const openingFinanceSystem =
  require('../finance/openingFinanceSystem.js');`,
`const openingFinanceSystem =
  require('../finance/openingFinanceSystem.js');

const businessLifecycle =
  require('../core/businessLifecycleV086.js');`,
      '门店接入生命周期'
    );

  source =
    replaceOnce(
      source,
`    if (
      shop &&
      shop.status === 'open'
    ) {
      return 'operating';
    }`,
`    if (
      shop &&
      (
        shop.status ===
          'open' ||
        shop.status ===
          'trial_opening'
      )
    ) {
      return 'operating';
    }`,
      '试营业显示营业界面'
    );

  source =
    replaceOnce(
      source,
`    if (
      readiness
        .renovationReady
    ) {
      if (
        !readiness
          .permitsReady
      ) {
        recommendation = {
          id: 'license',
          title: '办理证照',
          detail:
            '完成营业、食品及消防手续',
          action: '办理证照'
        };
      } else if (
        !readiness
          .staffingReady
      ) {
        recommendation = {
          id: 'staff',
          title: '补齐员工',
          detail:
            '基础班组仍未达到开业要求',
          action: '去招聘'
        };
      } else if (
        !readiness
          .equipmentReady
      ) {
        recommendation = {
          id: 'equipment',
          title: '安装设备',
          detail:
            '完成后厨与前厅设备采购安装',
          action: '配置设备'
        };
      } else if (
        readiness.ready
      ) {
        recommendation = {
          id: 'trial',
          title: '开始试营业',
          detail:
            '基础筹备完成，可以验证真实经营',
          action: '试营业'
        };
      }
    }`,
`    if (
      shop.status ===
        'trial_complete'
    ) {
      recommendation = {
        id:'formal-open',
        title:'试营业复盘完成',
        detail:
          '查看3天结果后确认正式营业',
        action:'正式开业'
      };
    } else if (
      readiness
        .renovationReady
    ) {
      if (
        !readiness
          .equipmentReady
      ) {
        recommendation = {
          id:'equipment',
          title:'安装设备',
          detail:
            '装修后先完成后厨与前厅设备',
          action:'配置设备'
        };
      } else if (
        !readiness
          .permitsReady
      ) {
        recommendation = {
          id:'license',
          title:'办理证照',
          detail:
            '设备完成后办理营业、食品及消防手续',
          action:'办理证照'
        };
      } else if (
        !readiness
          .staffingReady
      ) {
        recommendation = {
          id:'staff',
          title:'补齐员工',
          detail:
            '证照齐备后组建基础班组',
          action:'去招聘'
        };
      } else if (
        readiness.ready
      ) {
        recommendation = {
          id:'trial',
          title:'开始3天试营业',
          detail:
            '用真实客流验证出餐、服务、库存与盈利',
          action:'试营业'
        };
      }
    }`,
      '开店流程顺序'
    );

  source =
    replaceOnce(
      source,
`    if (
      moduleId === 'trial'
    ) {
      const result =
        openingPrepSystem
          .startTrialOpening(
            shop.id
          );

      this.showToast(
        result.ok
          ? '试营业开始！'
          : result.message
      );

      textInput
        .requestRender();

      return true;
    }`,
`    if (
      moduleId ===
        'trial'
    ) {
      const result =
        businessLifecycle
          .startTrialOpening(
            shop.id
          );

      this.showToast(
        result.ok
          ? '3天试营业开始'
          : result.message
      );

      textInput
        .requestRender();

      return true;
    }

    if (
      moduleId ===
        'formal-open'
    ) {
      const report =
        businessLifecycle
          .getTrialReport(
            shop.id
          );

      const open =
        () => {
          const result =
            businessLifecycle
              .formalOpen(
                shop.id
              );

          this.showToast(
            result.ok
              ? '正式营业开始！'
              : result.message
          );

          textInput
            .requestRender();
        };

      if (
        api &&
        typeof api.showModal ===
          'function'
      ) {
        api.showModal({
          title:'试营业复盘',
          content:
            report
              ? (
                  '营业额 ' +
                  compactMoney(
                    report.revenue
                  ) +
                  '，利润 ' +
                  compactMoney(
                    report.profit
                  ) +
                  '，订单 ' +
                  report.orders +
                  '，评分 ' +
                  report.rating +
                  '。是否正式开业？'
                )
              : '试营业已完成，是否正式开业？',
          confirmText:'正式开业',
          cancelText:'继续复盘',
          success:result => {
            if (
              result &&
              result.confirm
            ) {
              open();
            }
          }
        });
      } else {
        open();
      }

      return true;
    }`,
      '试营业与正式开业按钮'
    );

  fs.writeFileSync(
    STORE,
    source,
    'utf8'
  );
}

function patchPremiumUi() {
  let source =
    fs.readFileSync(
      PREMIUM_UI,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`'use strict';

function roundedPath(`,
`'use strict';

const gameState =
  require('../core/gameState.js');

function roundedPath(`,
      '读取字号设置'
    );

  source =
    replaceOnce(
      source,
`  const readableSize =
    Math.max(
      7.3,
      Number(
        size
      ) ||
      7.3
    );`,
`  const progress =
    gameState
      .getData()
      .progress ||
    {};

  const settings =
    progress.settings ||
    {};

  const fontScale =
    Math.max(
      1,
      Math.min(
        1.15,
        Number(
          settings.fontScale
        ) ||
        1
      )
    );

  const readableSize =
    Math.max(
      7.3,
      Number(
        size
      ) ||
      7.3
    ) *
    fontScale;`,
      '大字模式真正生效'
    );

  fs.writeFileSync(
    PREMIUM_UI,
    source,
    'utf8'
  );
}

function patchMain() {
  let source =
    fs.readFileSync(
      MAIN,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const globalTimeline =
  require('./core/globalTimelineV0821.js');`,
`const globalTimeline =
  require('./core/globalTimelineV0821.js');

const businessLifecycle =
  require('./core/businessLifecycleV086.js');`,
      '主循环生命周期require'
    );

  source =
    replaceOnce(
      source,
`const dynamicWorldScene =
  require('./scenes/dynamicWorldScene.js');`,
`const dynamicWorldScene =
  require('./scenes/dynamicWorldScene.js');

const systemScene =
  require('./scenes/systemSceneV086.js');`,
      '系统页面require'
    );

  source =
    replaceOnce(
      source,
`sceneManager.register(
  'dynamicWorld',
  dynamicWorldScene
);`,
`sceneManager.register(
  'dynamicWorld',
  dynamicWorldScene
);

sceneManager.register(
  'system',
  systemScene
);`,
      '系统页面注册'
    );

  source =
    replaceOnce(
      source,
`    if (
      sceneId ===
      'system'
    ) {
      showToast(
        '系统设置将在下一阶段接入'
      );

      return;
    }`,
`    if (
      sceneId ===
      'system'
    ) {
      trafficMode =
        false;

      selectedDistrictId =
        null;

      sceneManager
        .switchTo(
          'system'
        );

      render();

      return;
    }`,
      '系统按钮取消占位'
    );

  source =
    replaceOnce(
      source,
`  let restaurantChanged =
    false;

  const advancedMinutes =`,
`  let restaurantChanged =
    false;

  let lifecycleChanged =
    false;

  const advancedMinutes =`,
      '生命周期变化标记'
    );

  source =
    replaceOnce(
      source,
`          if (
            restaurantSimulation
              .update(
                stepMinutes
              )
          ) {
            restaurantChanged =
              true;
          }
        }
      );`,
`          if (
            restaurantSimulation
              .update(
                stepMinutes
              )
          ) {
            restaurantChanged =
              true;
          }

          if (
            businessLifecycle
              .update()
          ) {
            lifecycleChanged =
              true;
          }
        }
      );`,
      '生命周期在餐厅模拟后执行'
    );

  source =
    replaceOnce(
      source,
`  if (
    simulationChanged ||
    timelineChanged ||
    restaurantChanged
  ) {`,
`  if (
    simulationChanged ||
    timelineChanged ||
    restaurantChanged ||
    lifecycleChanged
  ) {`,
      '生命周期自动保存'
    );

  source =
    replaceOnce(
      source,
`    simulationChanged ||
    timelineChanged ||
    restaurantChanged ||
    animationChanged ||`,
`    simulationChanged ||
    timelineChanged ||
    restaurantChanged ||
    lifecycleChanged ||
    animationChanged ||`,
      '生命周期触发重绘'
    );

  fs.writeFileSync(
    MAIN,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/businessLifecycleV086.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/timeScheduleV0821.test.js',
    'tests/v60CleanBase.test.js'`,
`    'tests/timeScheduleV0821.test.js',
    'tests/businessLifecycleV086.test.js',
    'tests/v60CleanBase.test.js'`,
        'V0.8.6测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.6';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node tests/businessLifecycleV086.test.js && node tests/managementCenterV085.test.js && node tests/liveWorldV084.test.js && node tests/foundationFixesV083.test.js && node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchOpening();
  patchRestaurant();
  patchStore();
  patchPremiumUi();
  patchMain();
  patchRunner();
  finalizePackage();

  for (
    const file
    of [
      MAIN,
      OPENING,
      RESTAURANT,
      STORE,
      PREMIUM_UI,
      path.join(
        ROOT,
        'src/core/businessLifecycleV086.js'
      ),
      path.join(
        ROOT,
        'src/scenes/systemSceneV086.js'
      )
    ]
  ) {
    syntaxCheck(
      file
    );
  }

  console.log(
    '[V0.8.6] 完整经营闭环已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
