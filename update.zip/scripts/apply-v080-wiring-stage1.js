'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const MAIN =
  path.join(
    ROOT,
    'src/main.js'
  );

const GAME_STATE =
  path.join(
    ROOT,
    'src/core/gameState.js'
  );

const ANDROID =
  path.join(
    ROOT,
    'android/entry.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.0] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function patchGameState() {
  let source =
    fs.readFileSync(
      GAME_STATE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`    finance: {
      openingLoans: {}
    }
  },`,
`    finance: {
      openingLoans: {}
    },

    restaurantOperations: {
      version: '0.8.0',
      sharedSupplierNetwork: null,
      shops: {}
    }
  },`,
      'restaurantOperations默认状态'
    );

  source =
    replaceOnce(
      source,
`  getSimulation() {`,
`  getRestaurantOperations() {
    const business =
      this.data.business;

    if (
      !business.restaurantOperations
    ) {
      business.restaurantOperations = {
        version: '0.8.0',
        sharedSupplierNetwork: null,
        shops: {}
      };
    }

    return business.restaurantOperations;
  }

  getSimulation() {`,
      'restaurantOperations getter'
    );

  fs.writeFileSync(
    GAME_STATE,
    source,
    'utf8'
  );
}

function patchMain() {
  let source =
    fs.readFileSync(
      MAIN,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const timeSystem =
  require('./core/timeSystem.js');`,
`const timeSystem =
  require('./core/timeSystem.js');

const saveSystem =
  require('./core/saveSystem.js');`,
      'saveSystem require'
    );

  source =
    replaceOnce(
      source,
`  const simulationChanged =
    advancedMinutes >
      0
      ? simulationSystem
          .update(
            advancedMinutes
          )
      : false;`,
`  const simulationChanged =
    advancedMinutes >
      0
      ? simulationSystem
          .update(
            advancedMinutes
          )
      : false;

  if (
    simulationChanged
  ) {
    saveSystem
      .autoSave();
  }`,
      '跨日自动保存'
    );

  source =
    replaceOnce(
      source,
`simulationSystem
  .initialize();

sceneManager
  .switchTo(
    'city'
  );`,
`const restoredFromSave =
  saveSystem.load();

simulationSystem
  .initialize();

if (
  !restoredFromSave
) {
  saveSystem.save();
}

if (
  api &&
  typeof api.onHide ===
    'function'
) {
  api.onHide(
    function () {
      saveSystem.save();
    }
  );
}

sceneManager
  .switchTo(
    'city'
  );`,
      '启动读档和生命周期保存'
    );

  source =
    source.replace(
      '城市餐饮经营小游戏 V35 顶部HUD精修版启动成功',
      '城市餐饮经营小游戏 V0.8.0 经营接线第一阶段启动成功'
    );

  fs.writeFileSync(
    MAIN,
    source,
    'utf8'
  );
}

function patchAndroid() {
  let source =
    fs.readFileSync(
      ANDROID,
      'utf8'
    );

  if (
    !source.includes(
      'onHide(callback)'
    )
  ) {
    source =
      replaceOnce(
        source,
`  onTouchEnd(callback) {`,
`  onHide(callback) {
    if (
      typeof callback !==
      'function'
    ) {
      return;
    }

    window.addEventListener(
      'pagehide',
      callback
    );

    document.addEventListener(
      'visibilitychange',
      function () {
        if (
          document.hidden
        ) {
          callback();
        }
      }
    );
  },

  onTouchEnd(callback) {`,
        'Android onHide'
      );
  }

  fs.writeFileSync(
    ANDROID,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/wiringStageV080.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/operationCoreV070.test.js',`,
`    'tests/operationCoreV070.test.js',
    'tests/wiringStageV080.test.js',`,
        'V0.8.0测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.0';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchGameState();
  patchMain();
  patchAndroid();
  patchRunner();
  finalizePackage();

  console.log(
    '[V0.8.0] 经营接线第一阶段已应用'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
