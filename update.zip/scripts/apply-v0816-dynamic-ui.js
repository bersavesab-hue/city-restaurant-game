'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const MAIN =
  path.join(
    ROOT,
    'src/main.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.16] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function patchMain() {
  let source =
    fs.readFileSync(
      MAIN,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const businessScene =
  require('./scenes/businessScene.js');`,
`const businessScene =
  require('./scenes/businessScene.js');

const dynamicWorldScene =
  require('./scenes/dynamicWorldScene.js');

const dynamicWorldSystem =
  require('./world/dynamicWorldSystemV0815.js');`,
      '动态中心require'
    );

  source =
    replaceOnce(
      source,
`sceneManager.register(
  'business',
  businessScene
);`,
`sceneManager.register(
  'business',
  businessScene
);

sceneManager.register(
  'dynamicWorld',
  dynamicWorldScene
);`,
      '动态中心注册'
    );

  source =
    replaceOnce(
      source,
`    if (
      toolId ===
      'news'
    ) {
      const bulletin =
        simulationSystem
          .getBulletin();

      if (
        bulletin &&
        bulletin.districtId &&
        citySystem
          .getDistrict(
            bulletin.districtId
          )
      ) {
        selectedDistrictId =
          bulletin.districtId;

        citySystem
          .setCurrentDistrict(
            bulletin.districtId
          );

        startDistrictFx(
          bulletin.districtId
        );
      }

      showToast(
        bulletin.title +
        '：' +
        bulletin.detail
      );
    } else {`,
`    if (
      toolId ===
      'news'
    ) {
      trafficMode =
        false;

      sceneManager
        .switchTo(
          'dynamicWorld'
        );

      render();
    } else {`,
      '城市播报打开动态中心'
    );

  source =
    replaceOnce(
      source,
`drawNewsTicker = function () {
  const feed = simulationSystem.getNewsFeed();
  const bulletin = simulationSystem.getBulletin();`,
`drawNewsTicker = function () {
  const feed = simulationSystem.getNewsFeed();
  const bulletin = simulationSystem.getBulletin();
  const unread = dynamicWorldSystem.getUnreadCounts();
  const unreadTotal = Number(unread.total || 0);`,
      '首页动态未读'
    );

  source =
    replaceOnce(
      source,
`  drawText('城市播报', x + 30, y + 13.8, 7.4, '#FFD85C', '800');`,
`  drawText(
    unreadTotal > 0
      ? '城市播报 ' + (unreadTotal > 99 ? '99+' : unreadTotal)
      : '城市播报',
    x + 30,
    y + 13.8,
    7.4,
    '#FFD85C',
    '800'
  );`,
      '首页未读数字'
    );

  fs.writeFileSync(
    MAIN,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/dynamicWorldUiV0816.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/dynamicWorldV0815.test.js',`,
`    'tests/dynamicWorldV0815.test.js',
    'tests/dynamicWorldUiV0816.test.js',`,
        'V0.8.16测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.16';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchMain();
  patchRunner();
  finalizePackage();

  console.log(
    '[V0.8.16] 动态世界可视化已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
