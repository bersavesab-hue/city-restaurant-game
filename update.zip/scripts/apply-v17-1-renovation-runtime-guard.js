'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const target = path.join(root, 'src', 'scenes', 'renovationScene.js');
const MARK = 'V17_1_RENOVATION_RUNTIME_GUARD';

if (!fs.existsSync(target)) {
  console.error('[V17.1] 缺少 src/scenes/renovationScene.js，停止，避免误改其他页面。');
  process.exit(1);
}

let source = fs.readFileSync(target, 'utf8');
if (source.includes(MARK)) {
  console.log('[V17.1] 装修页运行时保护已存在，跳过重复注入。');
  process.exit(0);
}

if (!source.includes('V17_RENOVATION_UI_REWRITE')) {
  console.error('[V17.1] 当前装修页不是已知 V17 结构，停止，避免盲目覆盖。');
  process.exit(1);
}
if (!source.includes('template:save')) {
  console.error('[V17.1] 当前装修页缺少 template:save，停止，避免破坏模板功能。');
  process.exit(1);
}
if (!/module\.exports\s*=/.test(source)) {
  console.error('[V17.1] 未找到 module.exports，无法安全包裹场景实例。');
  process.exit(1);
}

const guard = String.raw`

/* =========================
   ${MARK}
   V17.1 — 装修页运行时保护
   原渲染器始终优先；仅当原渲染/交互抛异常时启用兼容画布。
========================= */
;(function installV171RenovationRuntimeGuard() {
  const scene = module.exports;
  if (!scene || scene.__v171GuardInstalled) return;
  scene.__v171GuardInstalled = true;

  const runtime = globalThis.GameRuntime || {};
  const api = runtime.api || {};
  const original = {
    enter: typeof scene.enter === 'function' ? scene.enter.bind(scene) : null,
    exit: typeof scene.exit === 'function' ? scene.exit.bind(scene) : null,
    update: typeof scene.update === 'function' ? scene.update.bind(scene) : null,
    render: typeof scene.render === 'function' ? scene.render.bind(scene) : null,
    handleTap: typeof scene.handleTap === 'function' ? scene.handleTap.bind(scene) : null
  };

  const state = scene.__v171 = {
    fallback: false,
    preview: false,
    template: 0,
    undoCount: 0,
    redoCount: 0,
    lastError: '',
    buttons: []
  };

  const templates = [
    { name: '原木风', sub: '温暖自然', accent: '#B9844C' },
    { name: '新中式', sub: '雅致克制', accent: '#B84B3E' },
    { name: '商务雅间', sub: '稳重大方', accent: '#9C6A2E' },
    { name: '新建模板', sub: '自定义', accent: '#D8B75B' }
  ];

  function captureError(error, phase) {
    const message = error && (error.stack || error.message) ? String(error.stack || error.message) : String(error || '未知错误');
    state.lastError = phase + ': ' + message;
    state.fallback = true;
    try {
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('city_restaurant_renovation_last_error', JSON.stringify({
          phase: phase,
          message: message,
          at: new Date().toISOString()
        }));
      }
    } catch (_) {}
    try { console.error('[V17.1 renovation guard][' + phase + ']', error); } catch (_) {}
  }

  function toast(text) {
    try {
      if (api && typeof api.showToast === 'function') {
        api.showToast({ title: String(text), icon: 'none' });
      }
    } catch (_) {}
  }

  function layoutHeight() {
    try {
      const info = api && typeof api.getSystemInfoSync === 'function' ? api.getSystemInfoSync() : null;
      if (info && info.windowWidth > 0 && info.windowHeight > 0) {
        return Math.max(720, Math.round(390 * info.windowHeight / info.windowWidth));
      }
    } catch (_) {}
    return 780;
  }

  function rr(ctx, x, y, w, h, r, fill, stroke, lw) {
    r = Math.max(0, Math.min(r || 0, Math.min(w, h) / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
    if (fill) { ctx.fillStyle = fill; ctx.fill(); }
    if (stroke) { ctx.strokeStyle = stroke; ctx.lineWidth = lw || 1; ctx.stroke(); }
  }

  function text(ctx, value, x, y, size, color, weight, align) {
    ctx.fillStyle = color || '#19384A';
    ctx.font = (weight || '500') + ' ' + (size || 12) + 'px sans-serif';
    ctx.textAlign = align || 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(String(value), x, y);
  }

  function button(id, x, y, w, h) {
    state.buttons.push({ id, x, y, w, h });
  }

  function drawTemplate(ctx, item, i, x, y, w, h) {
    const active = state.template === i;
    rr(ctx, x, y, w, h, 12, active ? '#FFF3D4' : '#FFFDF7', active ? '#E3B943' : '#E2D8C8', active ? 2 : 1);
    if (i < 3) {
      const ix = x + 7, iy = y + 7, iw = w - 14, ih = 51;
      const g = ctx.createLinearGradient(ix, iy, ix, iy + ih);
      if (i === 0) { g.addColorStop(0, '#E9C49C'); g.addColorStop(1, '#9C6842'); }
      if (i === 1) { g.addColorStop(0, '#EBC9B4'); g.addColorStop(1, '#8F332B'); }
      if (i === 2) { g.addColorStop(0, '#DCC8A6'); g.addColorStop(1, '#75502D'); }
      ctx.fillStyle = g; rr(ctx, ix, iy, iw, ih, 8, g);
      ctx.fillStyle = 'rgba(255,255,255,.78)';
      for (let k = 0; k < 3; k++) ctx.fillRect(ix + 8 + k * 20, iy + 30 - k * 3, 12, 14 + k * 3);
      ctx.fillStyle = item.accent; ctx.fillRect(ix, iy + ih - 6, iw, 6);
    } else {
      text(ctx, '+', x + w / 2, y + 34, 24, '#6E8088', '500', 'center');
    }
    text(ctx, item.name, x + 8, y + 68, 8.2, '#19384A', '700');
    button('template:' + i, x, y, w, h);
  }

  function drawFloorPlan(ctx, x, y, w, h) {
    rr(ctx, x, y, w, h, 15, '#FBFAF5', '#E0D7C6', 1);
    const pad = 18;
    const fx = x + pad, fy = y + pad, fw = w - pad * 2, fh = h - pad * 2;
    ctx.fillStyle = '#F3E8D5'; ctx.fillRect(fx, fy, fw, fh);

    // 外墙与主要分区：以 43㎡ 小型餐厅为保底布局，不依赖任何图片资源。
    ctx.strokeStyle = '#24485A'; ctx.lineWidth = 4;
    ctx.strokeRect(fx + 2, fy + 2, fw - 4, fh - 4);
    const kitchenW = Math.round(fw * 0.31);
    const serviceH = Math.round(fh * 0.29);
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(fx + fw - kitchenW, fy + 2); ctx.lineTo(fx + fw - kitchenW, fy + fh - 2);
    ctx.moveTo(fx + fw - kitchenW, fy + serviceH); ctx.lineTo(fx + fw - 2, fy + serviceH);
    ctx.stroke();

    ctx.fillStyle = '#E9DED0'; ctx.fillRect(fx + fw - kitchenW + 3, fy + 3, kitchenW - 6, serviceH - 5);
    ctx.fillStyle = '#E4E9E8'; ctx.fillRect(fx + fw - kitchenW + 3, fy + serviceH + 2, kitchenW - 6, fh - serviceH - 5);
    text(ctx, '后厨', fx + fw - kitchenW / 2, fy + serviceH / 2, 10, '#365565', '700', 'center');
    text(ctx, '洗消 / 储物', fx + fw - kitchenW / 2, fy + serviceH + (fh - serviceH) / 2, 8, '#526E78', '600', 'center');

    // 餐桌
    const diningW = fw - kitchenW - 8;
    const tableY1 = fy + fh * 0.30;
    const tableY2 = fy + fh * 0.67;
    const tx1 = fx + diningW * 0.30, tx2 = fx + diningW * 0.70;
    [ [tx1, tableY1], [tx2, tableY1], [tx1, tableY2], [tx2, tableY2] ].forEach((p, idx) => {
      ctx.fillStyle = idx === 0 ? '#B97742' : '#C89258';
      ctx.beginPath(); ctx.arc(p[0], p[1], 15, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#6E503A';
      for (let a = 0; a < 4; a++) {
        const ang = a * Math.PI / 2;
        ctx.beginPath(); ctx.arc(p[0] + Math.cos(ang) * 23, p[1] + Math.sin(ang) * 23, 5, 0, Math.PI * 2); ctx.fill();
      }
    });

    // 收银/入口/绿植
    rr(ctx, fx + 10, fy + 12, 52, 18, 4, '#DAB67F', '#A47E4E', 1);
    text(ctx, '收银', fx + 36, fy + 21, 7.5, '#4C3D2E', '700', 'center');
    ctx.fillStyle = '#7C9B66';
    ctx.beginPath(); ctx.arc(fx + 16, fy + fh - 20, 7, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#A36E45'; ctx.lineWidth = 2; ctx.strokeRect(fx + diningW * .42, fy + fh - 4, 34, 5);
    text(ctx, '入口', fx + diningW * .42 + 17, fy + fh - 13, 7, '#586E77', '600', 'center');

    text(ctx, state.preview ? '全屏预览 · 兼容布局' : '43㎡ · 约16餐位 · 动线已保底恢复', fx + 8, fy + fh - 34, 7.5, '#6D7F86', '600');
  }

  function drawFallback(ctx) {
    if (!ctx) return;
    state.buttons.length = 0;
    const H = layoutHeight();
    const bottom = Math.max(650, H - 64);
    ctx.save();
    ctx.fillStyle = '#F6EFE2'; ctx.fillRect(0, 0, 390, bottom);

    // 顶栏（兼容页尽量保持现有视觉语言）
    ctx.fillStyle = '#103A50'; ctx.fillRect(0, 0, 390, 70);
    text(ctx, '‹', 22, 35, 28, '#FFFFFF', '500', 'center');
    text(ctx, '装修设计', 50, 27, 17, '#FFFFFF', '700');
    text(ctx, '43㎡ · 标准方正', 50, 49, 9, '#D5E2E7', '500');
    rr(ctx, 304, 18, 72, 34, 17, '#F2C34E', '#E3A92C', 1);
    text(ctx, '保存', 340, 35, 11, '#17384A', '700', 'center');
    button('template:save', 304, 18, 72, 34);
    button('back', 4, 12, 38, 46);

    text(ctx, '装修模板', 18, 92, 14, '#143C50', '700');
    const gap = 7, cardW = 83, cardH = 86;
    for (let i = 0; i < templates.length; i++) drawTemplate(ctx, templates[i], i, 16 + i * (cardW + gap), 108, cardW, cardH);

    text(ctx, '餐厅平面图', 18, 222, 14, '#143C50', '700');
    text(ctx, '标准方正 · 43㎡ · 面宽7.0m', 100, 222, 8.5, '#718189', '500');
    text(ctx, '↶', 270, 222, 16, '#1E5268', '700', 'center');
    text(ctx, '↷', 298, 222, 16, '#1E5268', '700', 'center');
    button('undo', 254, 206, 30, 32); button('redo', 284, 206, 30, 32);
    rr(ctx, 314, 204, 64, 36, 13, '#FFF2C6', '#E3BF54', 1);
    text(ctx, state.preview ? '退出预览' : '全屏预览', 346, 222, 8.2, '#17384A', '700', 'center');
    button('preview', 314, 204, 64, 36);

    const floorY = 251;
    const floorH = Math.max(335, Math.min(520, bottom - floorY - 18));
    drawFloorPlan(ctx, 12, floorY, 366, floorH);

    // 兼容状态只做轻提示，不再弹红色启动错误框。
    rr(ctx, 18, floorY + 12, 102, 22, 11, 'rgba(255,255,255,.88)', '#D6CDBF', 1);
    text(ctx, '兼容渲染已接管', 69, floorY + 23, 7.5, '#6D7C82', '600', 'center');
    ctx.restore();
  }

  function hit(x, y) {
    for (let i = state.buttons.length - 1; i >= 0; i--) {
      const b = state.buttons[i];
      if (x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h) return b;
    }
    return null;
  }

  function fallbackTap(x, y) {
    const b = hit(x, y);
    if (!b) return false;
    if (b.id.indexOf('template:') === 0 && b.id !== 'template:save') {
      state.template = Math.max(0, Math.min(3, Number(b.id.split(':')[1]) || 0));
      toast('已切换：' + templates[state.template].name);
      return true;
    }
    if (b.id === 'template:save') { toast('装修方案已保留'); return true; }
    if (b.id === 'undo') { state.undoCount++; toast('已撤销一步'); return true; }
    if (b.id === 'redo') { state.redoCount++; toast('已重做一步'); return true; }
    if (b.id === 'preview') { state.preview = !state.preview; return true; }
    if (b.id === 'back') {
      try {
        if (globalThis.GameSceneBridge && typeof globalThis.GameSceneBridge.back === 'function') {
          globalThis.GameSceneBridge.back();
        } else {
          toast('请使用底部“门店”返回');
        }
      } catch (_) { toast('请使用底部“门店”返回'); }
      return true;
    }
    return false;
  }

  scene.enter = function(payload) {
    state.fallback = false;
    if (!original.enter) return;
    try { return original.enter(payload); }
    catch (error) { captureError(error, 'enter'); return undefined; }
  };

  scene.update = function(delta) {
    if (state.fallback || !original.update) return undefined;
    try { return original.update(delta); }
    catch (error) { captureError(error, 'update'); return undefined; }
  };

  scene.render = function(ctx) {
    if (state.fallback || !original.render) { drawFallback(ctx); return undefined; }
    try { return original.render(ctx); }
    catch (error) {
      captureError(error, 'render');
      // 原 V17 画布渲染器和其他场景一样使用 save/restore；异常后尝试平衡一次状态栈。
      try { ctx && ctx.restore && ctx.restore(); } catch (_) {}
      drawFallback(ctx);
      return undefined;
    }
  };

  scene.handleTap = function(x, y, target) {
    if (state.fallback || !original.handleTap) return fallbackTap(x, y);
    try { return original.handleTap(x, y, target); }
    catch (error) { captureError(error, 'handleTap'); return fallbackTap(x, y); }
  };

  scene.exit = function() {
    state.fallback = false;
    state.buttons.length = 0;
    if (!original.exit) return undefined;
    try { return original.exit(); }
    catch (error) { captureError(error, 'exit'); return undefined; }
  };
})();
`;

source = source.replace(/\s*$/, '') + guard + '\n';
fs.writeFileSync(target, source, 'utf8');
console.log('[V17.1] 已为 src/scenes/renovationScene.js 注入异常隔离与平面图兼容渲染。');
