'use strict';

const fs =
  require('fs');

const path =
  require('path');

const childProcess =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const MAIN =
  path.join(
    ROOT,
    'src/main.js'
  );

const SYSTEM_SCENE =
  path.join(
    ROOT,
    'src/scenes/systemSceneV086.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const INFRA_TEST =
  path.join(
    ROOT,
    'tests/updateInfrastructureV088.test.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function read(file) {
  return fs.readFileSync(
    file,
    'utf8'
  );
}

function write(
  file,
  source
) {
  fs.writeFileSync(
    file,
    source,
    'utf8'
  );
}

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index < 0
  ) {
    throw new Error(
      '[V0.8.9] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function syntaxCheck(file) {
  childProcess.execFileSync(
    process.execPath,
    [
      '--check',
      file
    ],
    {
      cwd:ROOT,
      stdio:'inherit'
    }
  );
}

function patchMain() {
  let source =
    read(
      MAIN
    );

  source =
    replaceOnce(
      source,
`const staffCareerScene =
  require('./scenes/staffCareerSceneV088.js');`,
`const staffCareerScene =
  require('./scenes/staffCareerSceneV088.js');

const entryRouter =
  require('./core/entryRouterV089.js');

const featureHubScene =
  require('./scenes/featureHubSceneV089.js');`,
      '统一路由和功能中心require'
    );

  source =
    replaceOnce(
      source,
`sceneManager.register(
  'staffCareer',
  staffCareerScene
);`,
`sceneManager.register(
  'staffCareer',
  staffCareerScene
);

sceneManager.register(
  'featureHub',
  featureHubScene
);`,
      '功能中心注册'
    );

  source =
    replaceOnce(
      source,
`      sceneManager
        .switchTo(
          'system'
        );

      render();`,
`      entryRouter
        .open(
          'system'
        );

      render();`,
      '底部系统入口统一路由'
    );

  source =
    replaceOnce(
      source,
`      if (
        sceneManager
          .switchTo(
            'shop',
            {
              districtId:
                district.id
            }
          )
      ) {
        render();
      }`,
`      if (
        entryRouter
          .open(
            'shop',
            {
              districtId:
                district.id
            }
          )
      ) {
        render();
      }`,
      '城市进入门店统一路由'
    );

  source =
    replaceOnce(
      source,
`    if (
      sceneManager
        .switchTo(
          sceneId
        )
    ) {
      render();
    }`,
`    if (
      entryRouter
        .open(
          sceneId
        )
    ) {
      render();
    }`,
      '通用底部导航统一路由'
    );

  write(
    MAIN,
    source
  );
}

function patchSystemScene() {
  let source =
    read(
      SYSTEM_SCENE
    );

  source =
    replaceOnce(
      source,
`const lifecycle =
  require('../core/businessLifecycleV086.js');`,
`const lifecycle =
  require('../core/businessLifecycleV086.js');

const entryRouter =
  require('../core/entryRouterV089.js');`,
      '系统页接入统一路由'
    );

  source =
    replaceOnce(
      source,
`    this.drawButton(
      ctx,
      'save',
      '立即保存',
      250,
      151,
      108
    );`,
`    this.drawButton(
      ctx,
      'feature:hub',
      '功能中心',
      134,
      151,
      108,
      'gold'
    );

    this.drawButton(
      ctx,
      'save',
      '立即保存',
      250,
      151,
      108
    );`,
      '系统页增加功能中心入口'
    );

  source =
    replaceOnce(
      source,
`    if (
      button.id ===
      'save'
    ) {`,
`    if (
      button.id ===
      'feature:hub'
    ) {
      if (
        !entryRouter
          .open(
            'featureHub'
          )
      ) {
        this.toast(
          entryRouter
            .getLastError() ||
          '功能中心暂不可用'
        );
      }

      return true;
    }

    if (
      button.id ===
      'save'
    ) {`,
      '功能中心点击逻辑'
    );

  source =
    replaceOnce(
      source,
`          sceneManager
            .switchTo(
              'city'
            );`,
`          entryRouter
            .clearHistory();

          entryRouter
            .open(
              'city',
              null,
              {
                record:false
              }
            );`,
      '重新开局清理路由历史'
    );

  write(
    SYSTEM_SCENE,
    source
  );
}

function patchInfrastructureTest() {
  let source =
    read(
      INFRA_TEST
    );

  const before =
`assert.equal(
  pkg.version,
  '0.8.8',
  '正式版本必须为0.8.8'
);`;

  const after =
`function versionTuple(value) {
  return String(value || '')
    .split('.')
    .slice(0, 3)
    .map(
      item =>
        Math.max(
          0,
          Number.parseInt(
            item,
            10
          ) || 0
        )
    );
}

function atLeast(
  current,
  minimum
) {
  const a =
    versionTuple(
      current
    );

  const b =
    versionTuple(
      minimum
    );

  for (
    let i = 0;
    i < 3;
    i++
  ) {
    if (a[i] > b[i]) {
      return true;
    }

    if (a[i] < b[i]) {
      return false;
    }
  }

  return true;
}

assert.ok(
  atLeast(
    pkg.version,
    '0.8.8'
  ),
  '正式版本不得低于0.8.8'
);`;

  source =
    replaceOnce(
      source,
      before,
      after,
      '旧基础设施测试版本兼容'
    );

  write(
    INFRA_TEST,
    source
  );
}

function patchRunner() {
  let source =
    read(
      RUNNER
    );

  if (
    !source.includes(
      'tests/featureRoutingV089.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/updateInfrastructureV088.test.js',
    'tests/v60CleanBase.test.js'`,
`    'tests/updateInfrastructureV088.test.js',
    'tests/featureRoutingV089.test.js',
    'tests/v60CleanBase.test.js'`,
        'V0.8.9测试接入'
      );
  }

  write(
    RUNNER,
    source
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      read(
        PACKAGE
      )
    );

  pkg.version =
    '0.8.9';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node tests/featureRoutingV089.test.js && node tests/updateInfrastructureV088.test.js && node tests/staffCareerV088.test.js && node tests/operationsScheduleV087.test.js && node tests/businessLifecycleV086.test.js && node tests/managementCenterV085.test.js && node tests/liveWorldV084.test.js && node tests/foundationFixesV083.test.js && node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  write(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n'
  );
}

try {
  patchMain();
  patchSystemScene();
  patchInfrastructureTest();
  patchRunner();
  finalizePackage();

  for (
    const file
    of [
      MAIN,
      SYSTEM_SCENE,
      path.join(
        ROOT,
        'src/core/entryRouterV089.js'
      ),
      path.join(
        ROOT,
        'src/scenes/featureHubSceneV089.js'
      ),
      INFRA_TEST,
      path.join(
        ROOT,
        'tests/featureRoutingV089.test.js'
      )
    ]
  ) {
    syntaxCheck(
      file
    );
  }

  console.log(
    '[V0.8.9] 1/26 功能入口与统一路由已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
