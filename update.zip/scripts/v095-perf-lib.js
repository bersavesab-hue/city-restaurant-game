'use strict';

const THROTTLE_MARKER = 'V095_RENDER_THROTTLE_BEGIN';
const RESOLUTION_MARKER = 'V095_RESOLUTION_TUNE_BEGIN';

function applyRenderThrottle(source) {
  source = String(source);
  if (source.includes(THROTTLE_MARKER)) return source;

  const renderRe = /function\s+render\s*\(\s*\)\s*\{/m;
  const match = source.match(renderRe);
  if (!match) {
    throw new Error('V0.9.5: 无法定位 function render()，跳过该候选方案。');
  }

  const guard = `\n  // ${THROTTLE_MARKER}\n  // 只节流昂贵的整屏 Canvas 重绘；时间、经营模拟、场景更新仍逐帧执行。\n  const __v095Now = Date.now();\n  const __v095Speed =\n    timeSystem && typeof timeSystem.getSpeed === 'function'\n      ? Number(timeSystem.getSpeed()) || 1\n      : 1;\n  const __v095Paused =\n    timeSystem && typeof timeSystem.isPaused === 'function'\n      ? !!timeSystem.isPaused()\n      : false;\n  const __v095Interval =\n    __v095Speed >= 10 ? 50 :\n    __v095Speed >= 5 ? 40 :\n    __v095Speed >= 2 ? 25 : 0;\n\n  if (\n    !needsResize &&\n    !__v095Paused &&\n    __v095Interval > 0 &&\n    __v095Now - (render.__v095LastTime || 0) < __v095Interval\n  ) {\n    return;\n  }\n\n  render.__v095LastTime = __v095Now;\n  // V095_RENDER_THROTTLE_END\n`;

  return source.replace(renderRe, match[0] + guard);
}

function applyResolutionTune(source) {
  source = String(source);
  if (source.includes(RESOLUTION_MARKER)) return source;

  let changed = false;
  let out = source;

  const dprRe = /(pixelRatio\s*=\s*Math\.min\(\s*)2(\s*,)/m;
  if (dprRe.test(out)) {
    out = out.replace(dprRe, (_, a, b) => a + '1.5' + b);
    changed = true;
  }

  const cacheRe = /(const\s+cacheScale\s*=\s*)2(\s*;)/m;
  if (cacheRe.test(out)) {
    out = out.replace(cacheRe, (_, a, b) => a + '1.25' + b);
    changed = true;
  }

  if (!changed) {
    throw new Error('V0.9.5: 未找到 DPR/地图缓存倍率位置，跳过该候选方案。');
  }

  const pixelRe = /(pixelRatio\s*=\s*Math\.min\()/m;
  if (pixelRe.test(out)) {
    out = out.replace(pixelRe, `// ${RESOLUTION_MARKER}\n  $1`);
  } else {
    out += `\n// ${RESOLUTION_MARKER}\n// V095_RESOLUTION_TUNE_END\n`;
  }

  return out;
}

function applyVariant(baseSource, variant) {
  let out = String(baseSource);
  switch (variant) {
    case 'full':
      out = applyRenderThrottle(out);
      out = applyResolutionTune(out);
      return out;
    case 'throttle':
      return applyRenderThrottle(out);
    case 'resolution':
      return applyResolutionTune(out);
    case 'baseline':
      return out;
    default:
      throw new Error(`V0.9.5: unknown variant ${variant}`);
  }
}

module.exports = {
  THROTTLE_MARKER,
  RESOLUTION_MARKER,
  applyRenderThrottle,
  applyResolutionTune,
  applyVariant
};
