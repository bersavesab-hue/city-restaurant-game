'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const GAME_STATE =
  path.join(
    ROOT,
    'src/core/gameState.js'
  );

const SIMULATION =
  path.join(
    ROOT,
    'src/core/simulationSystem.js'
  );

const RESTAURANT =
  path.join(
    ROOT,
    'src/operations/restaurantSimulationV081.js'
  );

const OPERATIONS =
  path.join(
    ROOT,
    'src/operations/operationsStoreV080.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.15] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function patchGameState() {
  let source =
    fs.readFileSync(
      GAME_STATE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`      lastDailySnapshot: null
    }
  },`,
`      lastDailySnapshot: null
    },

    dynamicWorld: {
      version: '0.8.15',
      lastProcessedDay: null,
      eventState: null,
      policyState: null,
      npcPool: [],
      dialogueFeed: [],
      barrageFeed: [],
      signalHistory: [],
      modifiers: {},
      metrics: {
        eventsTriggered: 0,
        policiesProposed: 0,
        dialoguesGenerated: 0,
        barragesGenerated: 0
      }
    }
  },`,
      'dynamicWorld默认状态'
    );

  source =
    replaceOnce(
      source,
`  getSimulation() {`,
`  getDynamicWorld() {
    const world =
      this.data.world;

    if (
      !world.dynamicWorld
    ) {
      world.dynamicWorld = {
        version: '0.8.15',
        lastProcessedDay: null,
        eventState: null,
        policyState: null,
        npcPool: [],
        dialogueFeed: [],
        barrageFeed: [],
        signalHistory: [],
        modifiers: {},
        metrics: {
          eventsTriggered: 0,
          policiesProposed: 0,
          dialoguesGenerated: 0,
          barragesGenerated: 0
        }
      };
    }

    return world.dynamicWorld;
  }

  getSimulation() {`,
      'getDynamicWorld getter'
    );

  fs.writeFileSync(
    GAME_STATE,
    source,
    'utf8'
  );
}

function patchSimulation() {
  let source =
    fs.readFileSync(
      SIMULATION,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const propertySystem =
  require('../property/propertySystem.js');`,
`const propertySystem =
  require('../property/propertySystem.js');

const dynamicWorldSystem =
  require('../world/dynamicWorldSystemV0815.js');`,
      'dynamicWorld require'
    );

  source =
    replaceOnce(
      source,
`    this.buildDailyNews(
      dayOrdinal,
      weather,
      snapshot,
      events
    );

    return snapshot;`,
`    this.buildDailyNews(
      dayOrdinal,
      weather,
      snapshot,
      events
    );

    dynamicWorldSystem
      .processDay(
        dayOrdinal,
        {
          weather:
            weather.weather,
          temperature:
            weather.temperature
        }
      );

    return snapshot;`,
      '每日动态世界推进'
    );

  fs.writeFileSync(
    SIMULATION,
    source,
    'utf8'
  );
}

function patchRestaurant() {
  let source =
    fs.readFileSync(
      RESTAURANT,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const marketingEngine =
  require('./marketingEngineV10.js');`,
`const marketingEngine =
  require('./marketingEngineV10.js');

const dynamicWorldSystem =
  require('../world/dynamicWorldSystemV0815.js');`,
      '经营动态世界require'
    );

  source =
    replaceOnce(
      source,
`  const weatherFactor =
    weather ===
      'rain'
      ? 0.94
      : weather ===
          'storm'
        ? 0.78
        : weather ===
            'hot'
          ? 0.96
          : 1;`,
`  const weatherFactor =
    weather ===
      'rain'
      ? 0.94
      : weather ===
          'storm'
        ? 0.78
        : weather ===
            'hot'
          ? 0.96
          : 1;

  const worldModifiers =
    dynamicWorldSystem
      .getModifiers(
        {
          districtId:
            shop.districtId,
          shopId:
            shop.id
        }
      );

  const dynamicDemandFactor =
    Number(
      worldModifiers
        .demandMultiplier
    ) || 1;

  const nightFactor =
    period ===
      'night'
      ? Number(
          worldModifiers
            .nightDemandMultiplier
        ) || 1
      : 1;`,
      '经营需求读取动态世界'
    );

  source =
    replaceOnce(
      source,
`      weatherFactor
  );`,
`      weatherFactor *
      dynamicDemandFactor *
      nightFactor
  );`,
      '需求乘数落地'
    );

  source =
    replaceOnce(
      source,
`  const rent =
    (
      Number(
        shop.monthlyRent
      ) ||
      0
    ) /
    30 *
    ratio;

  const labor =
    dailyPayroll(
      shop
    ) *
    ratio;`,
`  const worldModifiers =
    dynamicWorldSystem
      .getModifiers(
        {
          districtId:
            shop.districtId,
          shopId:
            shop.id
        }
      );

  const rent =
    (
      Number(
        shop.monthlyRent
      ) ||
      0
    ) /
    30 *
    ratio *
    (
      Number(
        worldModifiers
          .rentCostMultiplier
      ) || 1
    );

  const labor =
    dailyPayroll(
      shop
    ) *
    ratio *
    (
      Number(
        worldModifiers
          .laborCostMultiplier
      ) || 1
    );`,
      '固定成本读取政策事件'
    );

  source =
    replaceOnce(
      source,
`  const utilities =
    (
      32 +
      area *
        0.42
    ) *
    ratio;`,
`  const utilities =
    (
      32 +
      area *
        0.42
    ) *
    ratio *
    (
      Number(
        worldModifiers
          .utilityCostMultiplier
      ) || 1
    );`,
      '水电成本动态修正'
    );

  source =
    replaceOnce(
      source,
`    runtime
      .dailySnapshots
      .push(
        closed
      );`,
`    runtime
      .dailySnapshots
      .push(
        closed
      );

    dynamicWorldSystem
      .onShopDayClosed(
        shop,
        runtime,
        closed
      );`,
      '日结触发社会反馈'
    );

  fs.writeFileSync(
    RESTAURANT,
    source,
    'utf8'
  );
}

function patchOperations() {
  let source =
    fs.readFileSync(
      OPERATIONS,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const settlementEngine =
  require('./settlementEngineV10.js');`,
`const settlementEngine =
  require('./settlementEngineV10.js');

const dynamicWorldSystem =
  require('../world/dynamicWorldSystemV0815.js');`,
      '供应链动态世界require'
    );

  source =
    replaceOnce(
      source,
`        const quote =
          procurementEngine
            .bestQuote(
              runtime
                .supplierNetwork,
              suggestion
                .ingredientId,
              requestedKg,
              {
                day:
                  runtime.day
              }
            );`,
`        const worldModifiers =
          dynamicWorldSystem
            .getModifiers(
              {
                shopId,
                districtId:
                  operationsShop &&
                  operationsShop.districtId
              }
            );

        const quote =
          procurementEngine
            .bestQuote(
              runtime
                .supplierNetwork,
              suggestion
                .ingredientId,
              requestedKg,
              {
                day:
                  runtime.day,
                marketIndex:
                  Number(
                    worldModifiers
                      .supplyCostMultiplier
                  ) || 1
              }
            );`,
      '采购价格动态修正'
    );

  source =
    replaceOnce(
      source,
`  return mutate(
    shopId,
    runtime => {
      const targets =`,
`  const operationsShop =
    getShop(
      shopId
    );

  return mutate(
    shopId,
    runtime => {
      const targets =`,
      'autoRestock读取门店'
    );

  fs.writeFileSync(
    OPERATIONS,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/dynamicWorldV0815.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/realOperationLoopV081.test.js',`,
`    'tests/realOperationLoopV081.test.js',
    'tests/dynamicWorldV0815.test.js',`,
        '动态世界测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.15';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchGameState();
  patchSimulation();
  patchRestaurant();
  patchOperations();
  patchRunner();
  finalizePackage();

  console.log(
    '[V0.8.15] 动态世界四大包已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
