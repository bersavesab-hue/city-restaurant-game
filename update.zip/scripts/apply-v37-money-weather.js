'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const MAIN = path.join(ROOT, 'src/main.js');
const STORE = path.join(ROOT, 'src/scenes/storeScene.js');
const PACKAGE = path.join(ROOT, 'package.json');

function mustReplace(source, regex, replacement, label) {
  if (!regex.test(source)) {
    throw new Error('[V37] 找不到替换位置：' + label);
  }
  regex.lastIndex = 0;
  return source.replace(regex, replacement);
}

function patchMain() {
  let source = fs.readFileSync(MAIN, 'utf8');

  // 可重复执行：最终方案已经存在时不重复插入。
  if (source.includes('/* V37_MONEY_WEATHER_FINAL */')) {
    return false;
  }

  // 顶部金额只显示紧凑数字，货币属性交给现金图标。
  source = mustReplace(
    source,
    /v32FormatMoney = function \(value\) \{[\s\S]*?\n\};\n\nconsole\.log\('V34_MONEY_FORMAT_FIX loaded'\);/,
`v32FormatMoney = function (value) {
  const n = Number(value) || 0;
  const abs = Math.abs(n);

  if (abs >= 1000000000000) {
    const v = n / 1000000000000;
    return v34TrimMoneyNumber(
      v,
      Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2
    ) + '万亿';
  }

  if (abs >= 100000000) {
    const v = n / 100000000;
    return v34TrimMoneyNumber(
      v,
      Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2
    ) + '亿';
  }

  if (abs >= 10000) {
    const v = n / 10000;
    return v34TrimMoneyNumber(
      v,
      Math.abs(v) >= 100 ? 0 : Math.abs(v) >= 10 ? 1 : 2
    ) + '万';
  }

  return String(Math.round(n));
};

console.log('V34_MONEY_FORMAT_FIX loaded');

/* V37_MONEY_WEATHER_FINAL */`,
    '首页紧凑金额函数'
  );

  // 重排天气、资金、等级三块；彻底移除资金“+”按钮。
  source = mustReplace(
    source,
    /  drawWeatherGlyph\(world\.weather, 180, 27 \+ SAFE_TOP\);[\s\S]*?  addButton\('brand:status', levelX - 3, 5 \+ SAFE_TOP, levelW \+ 6, 55\);\n/,
`  const weatherX = 164;
  const weatherW = 56;
  const topCardY = 9 + SAFE_TOP;
  const topCardH = 49;

  roundedRect(
    weatherX,
    topCardY,
    weatherW,
    topCardH,
    12,
    'rgba(3,57,91,0.88)',
    'rgba(72,183,236,0.42)'
  );

  drawWeatherGlyph(
    world.weather,
    weatherX + 15,
    25 + SAFE_TOP
  );

  drawText(
    WEATHER_NAMES[world.weather] || '晴',
    weatherX + 39,
    20 + SAFE_TOP,
    6.5,
    '#FFFFFF',
    '800',
    'center'
  );

  drawText(
    (Number(world.temperature) || 22) + '℃',
    weatherX + 39,
    38 + SAFE_TOP,
    6.6,
    '#DCEEF5',
    '700',
    'center'
  );

  const levelW = 72;
  const moneyW = 80;
  const right = VIEW_W - 7;
  const levelX = right - levelW;
  const moneyX = levelX - 5 - moneyW;

  roundedRect(
    moneyX,
    topCardY,
    moneyW,
    topCardH,
    12,
    'rgba(3,57,91,0.94)',
    'rgba(72,183,236,0.50)'
  );

  drawCashGlyph(
    moneyX + 14,
    26 + SAFE_TOP
  );

  const moneyText = v32FormatMoney(player.cash);
  const moneyFont =
    moneyText.length <= 4
      ? 11.3
      : moneyText.length <= 6
        ? 10.3
        : 9.3;

  drawText(
    fitText(
      moneyText,
      moneyW - 31,
      moneyFont,
      '800'
    ),
    moneyX + 50,
    22 + SAFE_TOP,
    moneyFont,
    '#FFF1A0',
    '800',
    'center'
  );

  drawText(
    '资金',
    moneyX + 50,
    42 + SAFE_TOP,
    6.2,
    '#DCEEF5',
    '600',
    'center'
  );

  roundedRect(
    levelX,
    topCardY,
    levelW,
    topCardH,
    12,
    'rgba(3,57,91,0.94)',
    'rgba(72,183,236,0.50)'
  );

  drawCrownGlyph(
    levelX + 15,
    26 + SAFE_TOP
  );

  drawText(
    'Lv.' + brand.level,
    levelX + 47,
    19 + SAFE_TOP,
    8.3,
    '#FFE77E',
    '800',
    'center'
  );

  roundedRect(
    levelX + 21,
    40 + SAFE_TOP,
    41,
    4,
    2,
    'rgba(255,255,255,0.22)'
  );

  roundedRect(
    levelX + 21,
    40 + SAFE_TOP,
    Math.max(4, 41 * brand.progress),
    4,
    2,
    '#FFD34B'
  );

  drawText(
    brand.reputation + '/100',
    levelX + 41,
    51 + SAFE_TOP,
    5.4,
    '#F0F8FB',
    '600',
    'center'
  );

  addButton(
    'brand:status',
    levelX - 3,
    5 + SAFE_TOP,
    levelW + 6,
    55
  );
`,
    '首页天气/资金/等级布局'
  );

  source = source.replace(
    '城市餐饮经营小游戏 V35 顶部HUD精修版启动成功',
    '城市餐饮经营小游戏 V37 资金天气最终版启动成功'
  );

  fs.writeFileSync(MAIN, source, 'utf8');
  return true;
}

function patchStore() {
  let source = fs.readFileSync(STORE, 'utf8');

  if (source.includes('/* V37_STORE_HEADER_MONEY_FINAL */')) {
    return false;
  }

  source = mustReplace(
    source,
    /    const cash =\n      compactMoney\(\n        gameState\.getPlayer\(\)\.cash\n      \);\n\n    ui\.card\(\n      ctx,\n      268,[\s\S]*?      'center'\n    \);\n\n    ui\.text\(\n      ctx,\n      '可用资金',[\s\S]*?      'center'\n    \);\n/,
`    /* V37_STORE_HEADER_MONEY_FINAL */
    const cash =
      compactMoney(
        gameState.getPlayer().cash
      ).replace(/^¥/, '');

    ui.card(
      ctx,
      286,
      14,
      90,
      34,
      {
        radius: 11,
        fill: 'rgba(3,52,81,0.90)',
        stroke: 'rgba(98,202,244,0.38)',
        shadow: false
      }
    );

    ui.text(
      ctx,
      '资金',
      302,
      31,
      6.1,
      '#DCEEF5',
      '700',
      'left'
    );

    ui.text(
      ctx,
      cash,
      365,
      31,
      cash.length > 6 ? 9.2 : 10.5,
      '#FFF0A0',
      '800',
      'right'
    );
`,
    '门店页顶部资金卡'
  );

  fs.writeFileSync(STORE, source, 'utf8');
  return true;
}

function finalizePackage() {
  const pkg = JSON.parse(fs.readFileSync(PACKAGE, 'utf8'));

  // 一次性应用脚本执行完后，不再残留在未来测试流程。
  pkg.scripts = pkg.scripts || {};
  pkg.scripts.pretest = 'node scripts/repo-cleanup.js --ci-auto';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(pkg, null, 2) + '\n',
    'utf8'
  );
}

try {
  const mainChanged = patchMain();
  const storeChanged = patchStore();

  finalizePackage();

  console.log(
    '[V37] 顶部资金/天气最终方案已应用。main=' +
    mainChanged +
    ', store=' +
    storeChanged
  );

  // 当前Node进程退出后，该文件不再需要。
  try {
    fs.unlinkSync(__filename);
  } catch (error) {
    console.warn('[V37] 一次性脚本未能自删除：' + error.message);
  }
} catch (error) {
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
}
