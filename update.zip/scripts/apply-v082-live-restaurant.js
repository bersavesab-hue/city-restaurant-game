'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const WORKFLOW = path.join(ROOT, '.github/workflows/apply-update.yml');
const PACKAGE = path.join(ROOT, 'package.json');
const LOCK = path.join(ROOT, 'package-lock.json');
const GENERATED_REPAIR = path.join(ROOT, 'scripts/repair-v082-generated.js');
const RUNNER = path.join(ROOT, 'scripts/run-ci-tests-v060.js');
const INFRA_TEST = path.join(ROOT, 'tests/updateInfrastructureV088.test.js');

function exists(rel) {
  return fs.existsSync(path.join(ROOT, rel));
}

function read(file) {
  return fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
}

function write(file, source) {
  fs.mkdirSync(path.dirname(file), {recursive:true});
  fs.writeFileSync(file, source, 'utf8');
}

function detectVersion() {
  if (
    exists('tests/globalStateBusV090.test.js') &&
    exists('src/core/globalStateBusV090.js')
  ) {
    return '0.9.0';
  }

  if (
    exists('tests/featureRoutingV089.test.js') &&
    exists('src/core/entryRouterV089.js') &&
    exists('src/scenes/featureHubSceneV089.js')
  ) {
    return '0.8.9';
  }

  if (
    exists('tests/staffCareerV088.test.js') ||
    exists('src/operations/staffCareerV088.js')
  ) {
    return '0.8.8';
  }

  return '0.8.8';
}

function repairWorkflow() {
  let source = read(WORKFLOW);

  if (!source) {
    throw new Error('[pipeline-rescue-v2] 缺少 .github/workflows/apply-update.yml');
  }

  const generic = [
    '      - name: Apply generic update patch',
    '        shell: bash',
    '        run: |',
    '          set -euo pipefail',
    '          if [ -f scripts/apply-update-patch.js ]; then',
    '            node scripts/apply-update-patch.js',
    '            rm -f scripts/apply-update-patch.js',
    '          else',
    '            echo "No generic patch installer; direct files only."',
    '          fi',
    '',
    ''
  ].join('\n');

  const legacyName = '      - name: Install persistent V0.8.2 generated-syntax repair';
  const testName = '      - name: Run all game tests';

  if (source.includes(legacyName)) {
    const start = source.indexOf(legacyName);
    const end = source.indexOf(testName, start);
    if (end < 0) {
      throw new Error('[pipeline-rescue-v2] 找不到 Run all game tests 锚点');
    }
    source = source.slice(0, start) + generic + source.slice(end);
  } else if (!source.includes('scripts/apply-update-patch.js')) {
    const idx = source.indexOf(testName);
    if (idx < 0) {
      throw new Error('[pipeline-rescue-v2] 工作流缺少测试锚点');
    }
    source = source.slice(0, idx) + generic + source.slice(idx);
  }

  if (source.includes('Install persistent V0.8.2 generated-syntax repair')) {
    throw new Error('[pipeline-rescue-v2] 旧V0.8.2硬编码步骤未删除');
  }

  if (!source.includes('scripts/apply-update-patch.js')) {
    throw new Error('[pipeline-rescue-v2] 通用补丁入口未建立');
  }

  write(WORKFLOW, source);
}

function patchInfrastructureCompatibility() {
  if (!fs.existsSync(INFRA_TEST)) return;

  let source = read(INFRA_TEST);

  const exact = [
    "assert.equal(",
    "  pkg.version,",
    "  '0.8.8',",
    "  '正式版本必须为0.8.8'",
    ");"
  ].join('\n');

  if (source.includes(exact) && detectVersion() !== '0.8.8') {
    const replacement = `function versionTuple(value) {\n  return String(value || '')\n    .split('.')\n    .slice(0, 3)\n    .map(item => Math.max(0, Number.parseInt(item, 10) || 0));\n}\n\nfunction atLeast(current, minimum) {\n  const a = versionTuple(current);\n  const b = versionTuple(minimum);\n  for (let i = 0; i < 3; i++) {\n    if (a[i] > b[i]) return true;\n    if (a[i] < b[i]) return false;\n  }\n  return true;\n}\n\nassert.ok(\n  atLeast(pkg.version, '0.8.8'),\n  '正式版本不得低于0.8.8'\n);`;
    source = source.replace(exact, replacement);
    write(INFRA_TEST, source);
  }
}

function patchRunnerCompatibility() {
  if (!fs.existsSync(RUNNER)) return;
  let source = read(RUNNER);

  if (
    exists('tests/featureRoutingV089.test.js') &&
    !source.includes('tests/featureRoutingV089.test.js')
  ) {
    const anchor = "    'tests/updateInfrastructureV088.test.js',";
    if (source.includes(anchor)) {
      source = source.replace(
        anchor,
        anchor + "\n    'tests/featureRoutingV089.test.js',"
      );
      write(RUNNER, source);
    }
  }
}

function stablePretest() {
  const candidates = [
    'tests/globalStateBusV090.test.js',
    'tests/stateBridgeV090.test.js',
    'tests/featureRoutingV089.test.js',
    'tests/updateInfrastructureV088.test.js',
    'tests/staffCareerV088.test.js',
    'tests/operationsScheduleV087.test.js',
    'tests/businessLifecycleV086.test.js',
    'tests/managementCenterV085.test.js',
    'tests/liveWorldV084.test.js',
    'tests/foundationFixesV083.test.js',
    'tests/timeScheduleV0821.test.js',
    'tests/liveRestaurantV082.test.js',
    'tests/dynamicWorldUiV0816.test.js',
    'tests/dynamicWorldV0815.test.js'
  ];

  const commands = candidates.filter(exists).map(file => 'node ' + file);

  if (exists('scripts/resource-lifecycle.js')) {
    commands.push('node scripts/resource-lifecycle.js sync-pools');
    if (exists('tests/resourceLifecycleV062.test.js')) {
      commands.push('node tests/resourceLifecycleV062.test.js');
    }
    commands.push('node scripts/resource-lifecycle.js gc --apply');
    commands.push('node scripts/resource-lifecycle.js audit');
  }

  if (exists('tools/devkit/devkit.js')) {
    commands.push('node tools/devkit/devkit.js self-check');
  }

  if (exists('tests/devkitV100.test.js')) {
    commands.push('node tests/devkitV100.test.js');
  }

  return commands.join(' && ');
}

function repairPackage() {
  let pkg = {};
  try {
    pkg = JSON.parse(read(PACKAGE) || '{}');
  } catch (error) {
    pkg = {};
  }

  const version = detectVersion();

  pkg.name = pkg.name || 'city-restaurant-game';
  pkg.version = version;
  pkg.private = true;
  pkg.scripts = pkg.scripts || {};
  pkg.scripts.pretest = stablePretest();
  pkg.scripts.test = 'node scripts/run-ci-tests-v060.js';
  pkg.scripts.health = pkg.scripts.health || 'node scripts/v60-audit.js';
  pkg.scripts['repo:cleanup'] = pkg.scripts['repo:cleanup'] || 'node scripts/repo-cleanup.js --untrack';
  pkg.scripts['repo:cleanup:dry'] = pkg.scripts['repo:cleanup:dry'] || 'node scripts/repo-cleanup.js --dry-run';
  pkg.scripts['assets:audit'] = pkg.scripts['assets:audit'] || 'node scripts/resource-lifecycle.js audit';
  pkg.scripts['assets:pools'] = pkg.scripts['assets:pools'] || 'node scripts/resource-lifecycle.js sync-pools';
  pkg.scripts['assets:cleanup:dry'] = pkg.scripts['assets:cleanup:dry'] || 'node scripts/resource-lifecycle.js gc';
  pkg.scripts['assets:cleanup'] = pkg.scripts['assets:cleanup'] || 'node scripts/resource-lifecycle.js gc --apply';
  pkg.scripts['dev:audit'] = pkg.scripts['dev:audit'] || 'node tools/devkit/devkit.js audit';
  pkg.scripts['dev:release'] = pkg.scripts['dev:release'] || 'node tools/devkit/devkit.js release-check';
  pkg.scripts['dev:hygiene'] = pkg.scripts['dev:hygiene'] || 'node tools/devkit/code-hygiene.js';
  pkg.scripts['dev:deps'] = pkg.scripts['dev:deps'] || 'node tools/devkit/dependency-audit.js';
  pkg.scripts['dev:data'] = pkg.scripts['dev:data'] || 'node tools/devkit/data-audit.js';
  pkg.scripts['dev:tests'] = pkg.scripts['dev:tests'] || 'node tools/devkit/test-discovery.js';
  pkg.scripts['dev:size'] = pkg.scripts['dev:size'] || 'node tools/devkit/size-report.js';
  pkg.scripts['dev:build-verify'] = pkg.scripts['dev:build-verify'] || 'node tools/devkit/build-verify.js';
  pkg.scripts['dev:snapshot'] = pkg.scripts['dev:snapshot'] || 'node tools/devkit/repo-snapshot.js';
  pkg.scripts['dev:impact'] = pkg.scripts['dev:impact'] || 'node tools/devkit/impact.js';
  pkg.scripts['dev:preflight'] = pkg.scripts['dev:preflight'] || 'node tools/devkit/update-preflight.js';
  pkg.scripts['build:android-js'] = pkg.scripts['build:android-js'] || 'node scripts/build-android-js-v060.js';
  pkg.scripts['build:mini-assets'] = pkg.scripts['build:mini-assets'] || 'node scripts/buildMiniAssets.js';
  pkg.scripts['player-lab'] = pkg.scripts['player-lab'] || 'node simulator/run100.js --report --output reports/player-lab/latest';
  pkg.scripts['player-lab:ci'] = pkg.scripts['player-lab:ci'] || 'node simulator/run100.js --ci --report --output reports/player-lab/latest';

  if (/scripts\/(?:apply|install)-/i.test(pkg.scripts.pretest || '')) {
    throw new Error('[pipeline-rescue-v2] 稳定pretest仍含一次性安装器');
  }

  write(PACKAGE, JSON.stringify(pkg, null, 2) + '\n');

  if (fs.existsSync(LOCK)) {
    try {
      const lock = JSON.parse(read(LOCK));
      lock.version = version;
      if (lock.packages && lock.packages['']) {
        lock.packages[''].version = version;
      }
      write(LOCK, JSON.stringify(lock, null, 2) + '\n');
    } catch (error) {
      console.log('[pipeline-rescue-v2] package-lock无法解析，保持原样');
    }
  }
}

function neutralizeGeneratedRepair() {
  if (!fs.existsSync(GENERATED_REPAIR)) return;

  const safe = `'use strict';\n\nconst fs = require('fs');\nconst cp = require('child_process');\nconst target = 'src/operations/restaurantSimulationV081.js';\n\ntry {\n  if (fs.existsSync(target)) {\n    let source = fs.readFileSync(target, 'utf8');\n    const bad = '\\n}}\\n\\nfunction update(';\n    const good = '\\n}\\n\\nfunction update(';\n    const count = source.split(bad).length - 1;\n    if (count > 1) throw new Error('duplicated-brace boundary appeared ' + count + ' times');\n    if (count === 1) {\n      source = source.replace(bad, good);\n      fs.writeFileSync(target, source, 'utf8');\n    }\n    const r = cp.spawnSync(process.execPath, ['--check', target], {encoding:'utf8'});\n    if (r.status !== 0) throw new Error(r.stderr || r.stdout || 'syntax check failed');\n    console.log('[pipeline-rescue-v2] legacy restaurant syntax compatibility PASS');\n  } else {\n    console.log('[pipeline-rescue-v2] legacy restaurant target absent; safe skip');\n  }\n} finally {\n  try { fs.unlinkSync(__filename); } catch (error) {}\n}\n`;

  write(GENERATED_REPAIR, safe);
}

function validate() {
  const workflow = read(WORKFLOW);
  const pkg = JSON.parse(read(PACKAGE));

  if (workflow.includes('Install persistent V0.8.2 generated-syntax repair')) {
    throw new Error('[pipeline-rescue-v2] 旧工作流仍存在');
  }
  if (!workflow.includes('scripts/apply-update-patch.js')) {
    throw new Error('[pipeline-rescue-v2] 通用补丁入口未写入');
  }
  if (/scripts\/(?:apply|install)-/i.test(pkg.scripts.pretest || '')) {
    throw new Error('[pipeline-rescue-v2] 正式pretest仍含一次性安装器');
  }
  if (!exists('scripts/run-ci-tests-v060.js')) {
    throw new Error('[pipeline-rescue-v2] 缺少永久CI运行器');
  }
}

try {
  repairWorkflow();
  patchInfrastructureCompatibility();
  patchRunnerCompatibility();
  repairPackage();
  neutralizeGeneratedRepair();
  validate();

  console.log('[pipeline-rescue-v2] PASS：旧更新管线已转换为通用增量补丁管线');

  try {
    fs.unlinkSync(__filename);
  } catch (error) {}
} catch (error) {
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
}
