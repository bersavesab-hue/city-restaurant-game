'use strict';

const fs =
  require('fs');

const path =
  require('path');

const childProcess =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const RESTAURANT =
  path.join(
    ROOT,
    'src/operations/restaurantSimulationV081.js'
  );

const OPERATIONS =
  path.join(
    ROOT,
    'src/operations/operationsStoreV080.js'
  );

const STORE =
  path.join(
    ROOT,
    'src/scenes/storeScene.js'
  );

const WORLD =
  path.join(
    ROOT,
    'src/world/dynamicWorldSystemV0815.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function syntaxCheck(
  file
) {
  childProcess.execFileSync(
    process.execPath,
    [
      '--check',
      file
    ],
    {
      cwd: ROOT,
      stdio: 'inherit'
    }
  );
}

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.2] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function patchOperations() {
  let source =
    fs.readFileSync(
      OPERATIONS,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`    dailySnapshots:
      clone(
        runtime.dailySnapshots ||
        []
      )
  };`,
`    dailySnapshots:
      clone(
        runtime.dailySnapshots ||
        []
      ),

    floor:
      clone(
        runtime.floor ||
        null
      )
  };`,
      '保存现场状态'
    );

  source =
    replaceOnce(
      source,
`        'simulation',
        'dailySnapshots'
      ]`,
`        'simulation',
        'dailySnapshots',
        'floor'
      ]`,
      '恢复现场状态'
    );

  fs.writeFileSync(
    OPERATIONS,
    source,
    'utf8'
  );
}

function patchRestaurant() {
  let source =
    fs.readFileSync(
      RESTAURANT,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const dynamicWorldSystem =
  require('../world/dynamicWorldSystemV0815.js');`,
`const dynamicWorldSystem =
  require('../world/dynamicWorldSystemV0815.js');

const floorSimulation =
  require('./floorSimulationV082.js');`,
      '现场模拟 require'
    );

  source =
    replaceOnce(
      source,
`    const closed =
      runtimeEngine
        .closeDay(
          runtime
        );`,
`    const closed =
      runtimeEngine
        .closeDay(
          runtime
        );

    closed.floor =
      floorSimulation
        .closeDay(
          runtime
        );`,
      '日结现场快照'
    );

  const start =
    source.indexOf(
`  if (
    arrivals <=
    0
  ) {`
    );

  const persist =
    source.indexOf(
`  operations
    .persist(
      shop.id
    );`,
      start
    );

  if (
    start <
      0 ||
    persist <
      0
  ) {
    throw new Error(
      '[V0.8.2] 找不到即时营业循环'
    );
  }

  const replacement =
`  const coverage =
    staffCoverage(
      shop
    );

  const worldModifiers =
    dynamicWorldSystem
      .getModifiers(
        {
          districtId:
            shop.districtId,
          shopId:
            shop.id
        }
      );

  const floorResult =
    floorSimulation
      .advance(
        runtime,
        shop,
        advancedMinutes,
        arrivals,
        {
          absoluteMinute:
            absoluteMinute(),
          staffCoverage:
            coverage,
          weather:
            gameState
              .getWorld()
              .weather,
          capacityMultiplier:
            Number(
              worldModifiers
                .capacityMultiplier
            ) || 1,
          seats:
            Number(
              shop.seatEstimate ||
              shop.seats ||
              36
            )
        }
      );

  if (
    floorResult.changed
  ) {
    changed =
      true;
  }

`;

  const returnStart =
    source.indexOf(
`  return {
    changed,
    orders:`,
      persist
    );

  const returnEnd =
    source.indexOf(
`  };
}`,
      returnStart
    );

  if (
    returnStart <
      0 ||
    returnEnd <
      0
  ) {
    throw new Error(
      '[V0.8.2] 找不到 simulateShop 返回块'
    );
  }

  source =
    source.slice(
      0,
      start
    ) +
    replacement +
    source.slice(
      persist,
      returnStart
    ) +
`  return {
    changed,
    orders:
      floorResult.completedOrders
  };
}` +
    source.slice(
      returnEnd +
      6
    );

  fs.writeFileSync(
    RESTAURANT,
    source,
    'utf8'
  );
}

function patchStore() {
  let source =
    fs.readFileSync(
      STORE,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const operationsStore =
  require('../operations/operationsStoreV080.js');`,
`const operationsStore =
  require('../operations/operationsStoreV080.js');

const floorSimulation =
  require('../operations/floorSimulationV082.js');`,
      '门店现场 require'
    );

  source =
    replaceOnce(
      source,
`    const openDay =
      Math.max(
        1,
        dayOrdinal() -
        (
          Number(
            shop.trialOpenedDay
          ) ||
          dayOrdinal()
        ) +
        1
      );

    return {`,
`    const openDay =
      Math.max(
        1,
        dayOrdinal() -
        (
          Number(
            shop.trialOpenedDay
          ) ||
          dayOrdinal()
        ) +
        1
      );

    const runtime =
      operationsStore
        .getRuntime(
          shop.id
        );

    const live =
      runtime
        ? floorSimulation
            .getSnapshot(
              runtime
            )
        : {
            queueParties:0,
            occupiedTables:0,
            totalTables:0,
            seatedPeople:0,
            kitchenQueue:0,
            kitchenActive:0,
            deliveryWaiting:0,
            deliveryOnRoad:0,
            walkawaysToday:0,
            stockoutsToday:0,
            mistakesToday:0,
            completedOrdersToday:0,
            avgWaitMinutes:0,
            avgCookMinutes:0
          };

    return {`,
      '门店读取现场状态'
    );

  source =
    replaceOnce(
      source,
`      profitRate:
        Number(
          finance.profitRate
        ) || 0,
      realOperation:
        true`,
`      profitRate:
        Number(
          finance.profitRate
        ) || 0,
      live,
      queueParties:
        live.queueParties,
      occupiedTables:
        live.occupiedTables,
      totalTables:
        live.totalTables,
      seatedPeople:
        live.seatedPeople,
      kitchenQueue:
        live.kitchenQueue,
      deliveryActive:
        live.deliveryWaiting +
        live.deliveryOnRoad,
      walkawaysToday:
        live.walkawaysToday,
      stockoutsToday:
        live.stockoutsToday,
      mistakesToday:
        live.mistakesToday,
      realOperation:
        true`,
      '门店返回现场指标'
    );

  const oldItems =
`    const stateItems = [
      [
        '当前客流',
        snap.customers +
        '人'
      ],
      [
        '翻台率',
        snap.turnover.toFixed(
          1
        )
      ],
      [
        '客单价',
        compactMoney(
          snap.avgSpend
        )
      ],
      [
        '员工覆盖',
        percent01(
          snap.staffCoverage
        )
      ]
    ];`;

  const newItems =
`    const stateItems = [
      [
        '等位',
        snap.queueParties +
        '桌'
      ],
      [
        '在座',
        snap.seatedPeople +
        '人'
      ],
      [
        '后厨队列',
        snap.kitchenQueue +
        '单'
      ],
      [
        '外卖配送',
        snap.deliveryActive +
        '单'
      ]
    ];`;

  source =
    replaceOnce(
      source,
      oldItems,
      newItems,
      '现场指标卡'
    );

  source =
    replaceOnce(
      source,
`    const warning =
      snap.staffCoverage < 0.9
        ? '员工覆盖不足'
        : !snap.state
            .readiness
            .equipmentReady
          ? '设备仍待完善'
          : !snap.state
              .readiness
              .permitsReady
            ? '证照仍待处理'
            : '今日经营稳定';`,
`    const warning =
      snap.walkawaysToday > 0
        ? '已有' +
          snap.walkawaysToday +
          '桌顾客等位离开'
        : snap.stockoutsToday > 0
          ? '今日出现' +
            snap.stockoutsToday +
            '次缺货'
          : snap.kitchenQueue > 6
            ? '后厨高峰拥堵'
            : snap.staffCoverage < 0.9
              ? '员工覆盖不足'
              : !snap.state
                  .readiness
                  .equipmentReady
                ? '设备仍待完善'
                : !snap.state
                    .readiness
                    .permitsReady
                  ? '证照仍待处理'
                  : '今日经营稳定';`,
      '现场预警'
    );

  fs.writeFileSync(
    STORE,
    source,
    'utf8'
  );
}

function patchWorld() {
  let source =
    fs.readFileSync(
      WORLD,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`  const rating =
    Number(
      closed &&
      closed.shopRating
    ) ||
    Number(
      runtime &&
      runtime.shop &&
      runtime.shop.rating
    ) ||
    4;

  const profit =`,
`  const rating =
    Number(
      closed &&
      closed.shopRating
    ) ||
    Number(
      runtime &&
      runtime.shop &&
      runtime.shop.rating
    ) ||
    4;

  const floorDaily =
    closed &&
    closed.floor ||
    {};

  const walkaways =
    Number(
      floorDaily.walkawaysToday ||
      0
    );

  const mistakes =
    Number(
      floorDaily.mistakesToday ||
      0
    );

  const stockouts =
    Number(
      floorDaily.stockoutsToday ||
      0
    );

  const profit =`,
      '日结读取现场负反馈'
    );

  source =
    replaceOnce(
      source,
`  const score =
    rating >=
      4.4 &&
    profit >
      0
      ? 82
      : profit <
          0
        ? 34
        : 60;

  const topicId =
    profit <
      0
      ? 'profit'
      : rating >=
          4.4
        ? 'rating'
        : revenue >
            3000
          ? 'crowd'
          : 'brand';`,
`  const score =
    walkaways >=
      3 ||
    mistakes >=
      2 ||
    stockouts >=
      3
      ? 30
      : rating >=
          4.4 &&
        profit >
          0
        ? 82
        : profit <
            0
          ? 34
          : 60;

  const topicId =
    walkaways >=
      3
      ? 'queue'
      : mistakes >=
          2
        ? 'service'
        : stockouts >=
            3
          ? 'supplier'
          : profit <
              0
            ? 'profit'
            : rating >=
                4.4
              ? 'rating'
              : revenue >
                  3000
                ? 'crowd'
                : 'brand';`,
      '现场反馈决定社会话题'
    );

  source =
    replaceOnce(
      source,
`            topicText:
              topicId ===
                'profit'
                ? \`\${shop.name || '这家店'}今天经营有点吃力\`
                : topicId ===
                    'rating'
                  ? \`\${shop.name || '这家店'}今天口碑不错\`
                  : topicId ===
                      'crowd'
                    ? \`\${shop.name || '这家店'}今天客流挺旺\`
                    : \`\${shop.name || '这家店'}今天表现比较平稳\`,`,
`            topicText:
              topicId ===
                'queue'
                ? \`\${shop.name || '这家店'}今天等位流失有点多\`
                : topicId ===
                    'service'
                  ? \`\${shop.name || '这家店'}今天服务出了几次差错\`
                  : topicId ===
                      'supplier'
                    ? \`\${shop.name || '这家店'}今天有菜品缺货\`
                    : topicId ===
                        'profit'
                      ? \`\${shop.name || '这家店'}今天经营有点吃力\`
                      : topicId ===
                          'rating'
                        ? \`\${shop.name || '这家店'}今天口碑不错\`
                        : topicId ===
                            'crowd'
                          ? \`\${shop.name || '这家店'}今天客流挺旺\`
                          : \`\${shop.name || '这家店'}今天表现比较平稳\`,`,
      '现场反馈弹幕文本'
    );

  fs.writeFileSync(
    WORLD,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/liveRestaurantV082.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/dynamicWorldUiV0816.test.js',`,
`    'tests/dynamicWorldUiV0816.test.js',
    'tests/liveRestaurantV082.test.js',`,
        'V0.8.2测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.2';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n',
    'utf8'
  );
}

try {
  patchOperations();
  patchRestaurant();
  patchStore();
  patchWorld();
  patchRunner();
  finalizePackage();

  syntaxCheck(
    RESTAURANT
  );

  syntaxCheck(
    OPERATIONS
  );

  syntaxCheck(
    STORE
  );

  syntaxCheck(
    WORLD
  );

  console.log(
    '[V0.8.2] 餐厅现场模拟已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
