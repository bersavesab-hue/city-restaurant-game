'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');
const perf = require('./v095-perf-lib.js');

const ROOT = process.cwd();
const STATE_PATH = path.join(ROOT, 'scripts', '.v095-test-state.json');

function say(msg) {
  process.stdout.write(`[V0.9.5 adaptive] ${msg}\n`);
}

function fail(msg) {
  process.stderr.write(`[V0.9.5 adaptive] ${msg}\n`);
}

function readState() {
  if (!fs.existsSync(STATE_PATH)) throw new Error('V0.9.5 state file missing');
  return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8'));
}

function runShell(command, label) {
  if (typeof command !== 'string' || !command.trim()) {
    return { label, status: 0, stdout: '', stderr: '' };
  }
  const result = cp.spawnSync(command, {
    cwd: ROOT,
    shell: true,
    encoding: 'utf8',
    env: process.env,
    maxBuffer: 64 * 1024 * 1024
  });
  return {
    label,
    status: Number.isInteger(result.status) ? result.status : 1,
    stdout: result.stdout || '',
    stderr: result.stderr || ''
  };
}

function printOutput(result) {
  if (result && result.stdout) process.stdout.write(result.stdout);
  if (result && result.stderr) process.stderr.write(result.stderr);
}

function restoreOriginalPackage(state) {
  fs.copyFileSync(path.join(ROOT, state.packageBackupPath), path.join(ROOT, 'package.json'));
}

function syntaxCheck(relative) {
  const result = cp.spawnSync(process.execPath, ['--check', relative], {
    cwd: ROOT,
    encoding: 'utf8'
  });
  if (result.status !== 0) {
    throw new Error(`${relative} syntax failed\n${result.stdout || ''}${result.stderr || ''}`);
  }
}

function writeVariantFromPreparedBase(state, preparedBase, variant) {
  const next = perf.applyVariant(preparedBase, variant);
  fs.writeFileSync(path.join(ROOT, state.mainPath), next, 'utf8');
  syntaxCheck(state.mainPath);
}

function writeSelectedMode(variant) {
  const out = path.join(ROOT, 'docs', 'V095_SELECTED_MODE.txt');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  const description = {
    full: '整屏重绘节流 + Android 高分屏/地图缓存降载',
    throttle: '仅整屏重绘节流',
    resolution: '仅 Android 高分屏/地图缓存降载',
    baseline: '仓库原渲染代码（测试保护回退；本轮不应用倍速性能改动）'
  }[variant] || variant;
  fs.writeFileSync(out, `V0.9.5 adaptive selected mode: ${variant}\n${description}\n`, 'utf8');
}

function cleanup(state, finalPackageBytes) {
  try {
    if (finalPackageBytes) fs.writeFileSync(path.join(ROOT, 'package.json'), finalPackageBytes);
    else restoreOriginalPackage(state);
  } catch (_) {}

  const targets = [
    path.join(ROOT, state.mainBackupPath),
    path.join(ROOT, state.packageBackupPath),
    STATE_PATH,
    path.join(ROOT, 'scripts', 'v095-perf-lib.js')
  ];
  for (const target of targets) {
    try { fs.rmSync(target, { force: true }); } catch (_) {}
  }
  try { fs.rmdirSync(path.join(ROOT, '.v095-backup')); } catch (_) {}
  try { fs.rmSync(__filename, { force: true }); } catch (_) {}
}

function main() {
  const state = readState();
  const mainPath = path.join(ROOT, state.mainPath);

  // 父级 npm test 启动时 package.json 是临时 runner 版。
  // 先还原仓库原 package，让原 pretest 获得与正常 npm test 相同的环境。
  restoreOriginalPackage(state);

  const pre = runShell(state.originalPretest, 'pretest');
  if (pre.status !== 0) {
    printOutput(pre);
    fail('仓库原 pretest 在未修改 main.js 的 baseline 上失败；停止性能补丁，避免重复执行有副作用的 pretest。');
    const packageAfterFailure = fs.existsSync(path.join(ROOT, 'package.json'))
      ? fs.readFileSync(path.join(ROOT, 'package.json'))
      : null;
    cleanup(state, packageAfterFailure);
    process.exit(pre.status || 1);
  }
  printOutput(pre);

  // pretest 可能生成/修复源码或调整 package.json。
  // 从这里开始冻结“准备完成”的基线，候选方案只修改 main.js，不再重复 pretest。
  const preparedBase = fs.readFileSync(mainPath, 'utf8');
  const packageAfterPretest = fs.readFileSync(path.join(ROOT, 'package.json'));
  syntaxCheck(state.mainPath);

  const variants = ['full', 'throttle', 'resolution', 'baseline'];
  let lastFailure = 1;

  for (const variant of variants) {
    try {
      // 某些 test 命令可能改 package.json；每个候选前恢复到同一个 pretest 完成态。
      fs.writeFileSync(path.join(ROOT, 'package.json'), packageAfterPretest);
      writeVariantFromPreparedBase(state, preparedBase, variant);
    } catch (error) {
      fail(`${variant} 无法应用：${error.message}`);
      continue;
    }

    say(`验证候选方案：${variant}`);
    const test = runShell(state.originalTest, 'test');
    if (test.status !== 0) {
      lastFailure = test.status || 1;
      if (variant === 'baseline') printOutput(test);
      else say(`${variant} 未通过原 test，自动尝试下一种。`);
      continue;
    }

    // 只对真正通过 test 的候选执行一次 posttest，避免 posttest 的副作用被重复触发。
    const post = runShell(state.originalPosttest, 'posttest');
    if (post.status !== 0) {
      printOutput(test);
      printOutput(post);
      fail(`${variant} 已通过 test，但仓库原 posttest 失败。为避免重复执行 posttest，停止自动尝试。`);
      cleanup(state, packageAfterPretest);
      process.exit(post.status || 1);
    }

    printOutput(test);
    printOutput(post);
    writeSelectedMode(variant);
    say(`仓库原测试通过，保留方案：${variant}`);
    cleanup(state, packageAfterPretest);
    process.exit(0);
  }

  // 所有候选（包括 baseline）都未通过 test。
  // 恢复 pretest 完成态的 main.js，避免失败工作区留下候选代码。
  try { fs.writeFileSync(mainPath, preparedBase, 'utf8'); } catch (_) {}
  fail('full / throttle / resolution / baseline 均未通过仓库原 test。');
  fail('baseline 也失败，说明当前失败不由倍速性能修改造成。');
  cleanup(state, packageAfterPretest);
  process.exit(lastFailure || 1);
}

main();
