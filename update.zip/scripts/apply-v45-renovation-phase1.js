'use strict';

const fs = require('fs');
const path = require('path');

const ROOT =
  path.resolve(__dirname, '..');

const file =
  path.join(
    ROOT,
    'src/scenes/renovationScene.js'
  );

let source =
  fs.readFileSync(
    file,
    'utf8'
  );

if (
  !source.includes(
    'V45_LIBRARY_RENOVATION_PHASE1'
  )
) {
  source = source.replace(
    '// V17_RENOVATION_UI_REWRITE',
    '// V17_RENOVATION_UI_REWRITE\n// V45_LIBRARY_RENOVATION_PHASE1'
  );

  // ----------------------------------------------------------
  // 1) resourceManager
  // ----------------------------------------------------------
  const requireNeedle =
`const visualAssetSystem =
  require('../ui/visualAssetSystem.js');

const ui =`;

  const requireReplace =
`const visualAssetSystem =
  require('../ui/visualAssetSystem.js');

const resourceManager =
  require('../core/resourceManager.js');

const ui =`;

  if (
    !source.includes(
      requireNeedle
    )
  ) {
    throw new Error(
      'V45：找不到 resourceManager 插入位置'
    );
  }

  source =
    source.replace(
      requireNeedle,
      requireReplace
    );

  // ----------------------------------------------------------
  // 2) asset map
  // ----------------------------------------------------------
  const colorNeedle =
`const COLORS = {`;

  const assetBlock =
`const V45_RENO_RESOURCES = [
  ['v45_store_hero', 'assets/images/library_store/store/storefront_hero_clean.png'],

  ['v45_style_natural', 'assets/images/library_store/renovation/styles/natural.png'],
  ['v45_style_chinese', 'assets/images/library_store/renovation/styles/chinese.png'],
  ['v45_style_modern', 'assets/images/library_store/renovation/styles/modern.png'],
  ['v45_style_night', 'assets/images/library_store/renovation/styles/night_market.png'],
  ['v45_style_business', 'assets/images/library_store/renovation/styles/business.png'],

  ['v45_table_2', 'assets/images/library_store/renovation/furniture/table_2.png'],
  ['v45_table_4', 'assets/images/library_store/renovation/furniture/table_4.png'],
  ['v45_table_6', 'assets/images/library_store/renovation/furniture/table_6_rect.png'],
  ['v45_table_8', 'assets/images/library_store/renovation/furniture/table_6_long.png'],
  ['v45_stove', 'assets/images/library_store/renovation/furniture/stove.png'],
  ['v45_fridge', 'assets/images/library_store/renovation/furniture/fridge.png'],
  ['v45_sink', 'assets/images/library_store/renovation/furniture/sink.png'],
  ['v45_cashier', 'assets/images/library_store/renovation/furniture/cashier.png'],
  ['v45_waiting_sofa', 'assets/images/library_store/renovation/furniture/waiting_sofa.png'],
  ['v45_plant', 'assets/images/library_store/renovation/furniture/plant_1.png'],
  ['v45_pendant', 'assets/images/library_store/renovation/furniture/pendant_gold.png'],
  ['v45_screen', 'assets/images/library_store/renovation/furniture/screen_round.png'],

  ['v45_layout_kitchen', 'assets/images/library_store/renovation/layouts/kitchen.png'],
  ['v45_layout_storage', 'assets/images/library_store/renovation/layouts/storage.png'],
  ['v45_layout_service', 'assets/images/library_store/renovation/layouts/service.png'],
  ['v45_layout_dining', 'assets/images/library_store/renovation/layouts/dining.png'],
  ['v45_layout_private_small', 'assets/images/library_store/renovation/layouts/private_small.png'],
  ['v45_layout_private_medium', 'assets/images/library_store/renovation/layouts/private_medium.png'],
  ['v45_layout_private_large', 'assets/images/library_store/renovation/layouts/private_large.png'],
  ['v45_layout_private_luxury', 'assets/images/library_store/renovation/layouts/private_luxury.png'],
  ['v45_layout_corridor', 'assets/images/library_store/renovation/layouts/corridor.png'],

  ['v45_advice_renovation', 'assets/images/library_store/store/advice_renovation.png']
];

const V45_RENO_VISUAL_MAP = {
  premium_template_1: 'v45_style_natural',
  premium_template_2: 'v45_style_chinese',
  premium_template_3: 'v45_style_modern',

  visual_table_2: 'v45_table_2',
  visual_table_4: 'v45_table_4',
  visual_table_6: 'v45_table_6',
  visual_table_8: 'v45_table_8',

  visual_stove: 'v45_stove',
  visual_fridge: 'v45_fridge'
};

const V45_HALL_STYLE_VISUAL = {
  simple: 'v45_style_modern',
  wood: 'v45_style_natural',
  modern_cn: 'v45_style_chinese',
  industrial: 'v45_style_modern',
  retro: 'v45_style_night',
  premium: 'v45_style_business'
};

`;

  if (
    !source.includes(
      colorNeedle
    )
  ) {
    throw new Error(
      'V45：找不到 COLORS 定义'
    );
  }

  source =
    source.replace(
      colorNeedle,
      assetBlock +
      colorNeedle
    );

  // ----------------------------------------------------------
  // 3) load Library resources
  // ----------------------------------------------------------
  const enterNeedle =
`  enter(payload) {
    const data =`;

  const enterReplace =
`  enter(payload) {
    for (
      let i = 0;
      i < V45_RENO_RESOURCES.length;
      i++
    ) {
      const item =
        V45_RENO_RESOURCES[i];

      resourceManager
        .loadImage(
          item[0],
          item[1],
          'v45-renovation-library'
        )
        .then(
          () => {
            if (
              runtime &&
              typeof runtime.requestRender ===
                'function'
            ) {
              runtime.requestRender();
            }
          }
        )
        .catch(
          () => {}
        );
    }

    const data =`;

  if (
    !source.includes(
      enterNeedle
    )
  ) {
    throw new Error(
      'V45：找不到 enter()'
    );
  }

  source =
    source.replace(
      enterNeedle,
      enterReplace
    );

  // ----------------------------------------------------------
  // 4) drawVisual: library first, legacy fallback
  // ----------------------------------------------------------
  const drawStart =
    source.indexOf(
      '  drawVisual('
    );

  const headerStart =
    source.indexOf(
      '\n  drawHeader(',
      drawStart
    );

  if (
    drawStart < 0 ||
    headerStart < 0
  ) {
    throw new Error(
      'V45：找不到 drawVisual'
    );
  }

  const drawVisual =
`  drawVisual(
    ctx,
    key,
    x,
    y,
    w,
    h,
    alpha
  ) {
    const mappedKey =
      V45_RENO_VISUAL_MAP[
        key
      ] ||
      key;

    const libraryImage =
      resourceManager
        .getImage(
          mappedKey
        );

    const image =
      libraryImage ||
      visualAssetSystem
        .get(
          key
        );

    if (!image) {
      return false;
    }

    ctx.save();

    if (
      Number.isFinite(
        Number(alpha)
      )
    ) {
      ctx.globalAlpha =
        alpha;
    }

    ui.coverImage(
      ctx,
      image,
      x,
      y,
      w,
      h,
      7,
      null
    );

    ctx.restore();

    return true;
  }`;

  source =
    source.slice(
      0,
      drawStart
    ) +
    drawVisual +
    source.slice(
      headerStart
    );

  // ----------------------------------------------------------
  // 5) Header: actual store image, no embedded emoji
  // ----------------------------------------------------------
  source =
    source.replace(
`      visualAssetSystem
        .get(
          'premium_reno_header'
        ),`,
`      resourceManager
        .getImage(
          'v45_store_hero'
        ) ||
      visualAssetSystem
        .get(
          'premium_reno_header'
        ),`
    );

  source =
    source.replace(
      "'📍 ' +",
      "'位置 · ' +"
    );

  source =
    source.replace(
      "'💾 保存模板'",
      "'保存模板'"
    );

  // ----------------------------------------------------------
  // 6) Template cards: use library style cards.
  // ----------------------------------------------------------
  const templateKeysOld =
`    const keys = [
      'premium_template_1',
      'premium_template_2',
      'premium_template_3'
    ];`;

  const templateKeysNew =
`    const keys = [
      'v45_style_natural',
      'v45_style_chinese',
      'v45_style_business'
    ];`;

  source =
    source.replace(
      templateKeysOld,
      templateKeysNew
    );

  // ----------------------------------------------------------
  // 7) style page: current hall style uses actual style art
  // ----------------------------------------------------------
  source =
    source.replace(
`        key:
          'premium_template_1'`,
`        key:
          V45_HALL_STYLE_VISUAL[
            plan.hallStyle
          ] ||
          'v45_style_natural'`
    );

  source =
    source.replace(
`        key:
          'premium_template_2'`,
`        key:
          plan.materialGrade === 'premium'
            ? 'v45_style_business'
            : plan.materialGrade === 'good'
              ? 'v45_style_chinese'
              : 'v45_style_natural'`
    );

  source =
    source.replace(
`        key:
          'premium_template_3'`,
`        key:
          plan.lightingLevel === 'premium'
            ? 'v45_style_business'
            : plan.lightingLevel === 'layered'
              ? 'v45_style_modern'
              : 'v45_style_natural'`
    );

  // ----------------------------------------------------------
  // 8) Toolbox: remove emoji and use actual library furniture images.
  // ----------------------------------------------------------
  const toolboxOld =
`    const toolbox = [
      [
        'style:hall',
        '🛋',
        '大厅风格'
      ],
      [
        'style:lighting',
        '💡',
        '灯光'
      ],
      [
        'style:material',
        '▱',
        '材料'
      ],
      [
        'page:rooms',
        '🚪',
        '包厢'
      ],
      [
        'page:layout',
        '🪑',
        '桌椅'
      ],
      [
        'floor:next',
        '▰',
        (
          '楼层 ' +
          (
            metrics.plan
              .activeFloor +
            1
          ) +
          'F'
        )
      ]
    ];`;

  const toolboxNew =
`    const toolbox = [
      [
        'style:hall',
        'v45_waiting_sofa',
        '大厅风格'
      ],
      [
        'style:lighting',
        'v45_pendant',
        '灯光'
      ],
      [
        'style:material',
        'v45_screen',
        '材料'
      ],
      [
        'page:rooms',
        'v45_layout_private_medium',
        '包厢'
      ],
      [
        'page:layout',
        'v45_table_4',
        '桌椅'
      ],
      [
        'floor:next',
        'v45_layout_corridor',
        (
          '楼层 ' +
          (
            metrics.plan
              .activeFloor +
            1
          ) +
          'F'
        )
      ]
    ];`;

  source =
    source.replace(
      toolboxOld,
      toolboxNew
    );

  const toolboxDrawOld =
`      ui.text(
        ctx,
        toolbox[i][1],
        toolX + 17,
        ty +
          toolH /
          2,
        9.2,
        COLORS.navy,
        '800',
        'center'
      );

      ui.text(
        ctx,
        toolbox[i][2],
        toolX + 45,
        ty +
          toolH /
          2,
        5.4,
        COLORS.text,
        '700',
        'center'
      );`;

  const toolboxDrawNew =
`      this.drawVisual(
        ctx,
        toolbox[i][1],
        toolX + 5,
        ty + 4,
        24,
        Math.max(
          18,
          toolH - 8
        ),
        1
      );

      ui.text(
        ctx,
        toolbox[i][2],
        toolX + 47,
        ty +
          toolH /
          2,
        5.4,
        COLORS.text,
        '700',
        'center'
      );`;

  source =
    source.replace(
      toolboxDrawOld,
      toolboxDrawNew
    );

  // ----------------------------------------------------------
  // 9) Floor plan zone headings: no emoji
  // ----------------------------------------------------------
  source =
    source.replace(
      "'👨‍🍳 后厨'",
      "'后厨'"
    );

  source =
    source.replace(
      "'⬡ 仓储'",
      "'仓储'"
    );

  source =
    source.replace(
      "'♟ 服务区'",
      "'服务区'"
    );

  source =
    source.replace(
      "'🍴 堂食区'",
      "'堂食区'"
    );

  // Actual functional-zone mini visuals
  source =
    source.replace(
`    this.drawVisual(
      ctx,
      'visual_stove',`,
`    this.drawVisual(
      ctx,
      'v45_layout_kitchen',
      px + 6,
      py + 25,
      serviceW - 12,
      ph * 0.27,
      0.88
    );

    this.drawVisual(
      ctx,
      'visual_stove',`
    );

  source =
    source.replace(
`    const rooms =
      floor.privateRooms`,
`    this.drawVisual(
      ctx,
      'v45_layout_dining',
      px + 78,
      py + ph * 0.44,
      107,
      ph * 0.47,
      0.30
    );

    const rooms =
      floor.privateRooms`
    );

  // ----------------------------------------------------------
  // 10) Footer: no emoji; cleaner game CTA
  // ----------------------------------------------------------
  source =
    source.replace(
      "'◉ 效果预览'",
      "'效果预览'"
    );

  source =
    source.replace(
      "'🔨 确认方案并开始施工  ›'",
      "'确认方案并开始施工  ›'"
    );

  // ----------------------------------------------------------
  // 11) Construction page: add real renovation image
  // ----------------------------------------------------------
  const constructionCardNeedle =
`    ui.text(
      ctx,
      plan.status ===
        'completed'
        ? '装修已经完工'
        : '装修施工中',
      195,
      157,
      18,
      COLORS.text,
      '800',
      'center'
    );`;

  const constructionCardReplace =
`    this.drawVisual(
      ctx,
      'v45_advice_renovation',
      28,
      137,
      78,
      95,
      1
    );

    ui.text(
      ctx,
      plan.status ===
        'completed'
        ? '装修已经完工'
        : '装修施工中',
      228,
      157,
      16,
      COLORS.text,
      '800',
      'center'
    );`;

  source =
    source.replace(
      constructionCardNeedle,
      constructionCardReplace
    );

  // ----------------------------------------------------------
  // 12) Money format: 万/亿 consistent with rest of game
  // ----------------------------------------------------------
  const moneyStart =
    source.indexOf(
      'function money(value)'
    );

  const clampStart =
    source.indexOf(
      '\nfunction clamp(',
      moneyStart
    );

  if (
    moneyStart < 0 ||
    clampStart < 0
  ) {
    throw new Error(
      'V45：找不到 money()'
    );
  }

  const moneyFn =
`function money(value) {
  const n =
    Number(value) || 0;

  const sign =
    n < 0
      ? '-'
      : '';

  const abs =
    Math.abs(n);

  function trim(
    v,
    decimals
  ) {
    return Number(v)
      .toFixed(decimals)
      .replace(/\\.0+$/, '')
      .replace(
        /(\\.\\d*?[1-9])0+$/,
        '$1'
      );
  }

  if (
    abs >=
    100000000
  ) {
    const v =
      abs /
      100000000;

    return (
      sign +
      '¥' +
      trim(
        v,
        v >= 100
          ? 0
          : v >= 10
            ? 1
            : 2
      ) +
      '亿'
    );
  }

  if (
    abs >=
    10000
  ) {
    const v =
      abs /
      10000;

    return (
      sign +
      '¥' +
      trim(
        v,
        v >= 100
          ? 0
          : v >= 10
            ? 1
            : 2
      ) +
      '万'
    );
  }

  return (
    sign +
    '¥' +
    Math.round(
      abs
    ).toLocaleString()
  );
}`;

  source =
    source.slice(
      0,
      moneyStart
    ) +
    moneyFn +
    source.slice(
      clampStart
    );

  fs.writeFileSync(
    file,
    source,
    'utf8'
  );
}

console.log(
  'V45 装修页第一阶段资料库接入完成'
);
