'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

function read(rel) {
  return fs.readFileSync(
    path.join(
      ROOT,
      rel
    ),
    'utf8'
  );
}

function write(rel, text) {
  fs.writeFileSync(
    path.join(
      ROOT,
      rel
    ),
    text
  );
}

function replaceBetween(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V14 patch 找不到开始标记：' +
        label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
        startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V14 patch 找不到结束标记：' +
        label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    source.slice(
      end
    )
  );
}

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    !source.includes(
      before
    )
  ) {
    throw new Error(
      'V14 patch 找不到替换内容：' +
        label
    );
  }

  return source.replace(
    before,
    after
  );
}

const MAIN_MARK =
  'V14_GOLDEN_UI_MAIN';

const STORE_MARK =
  'V14_GOLDEN_UI_STORE';

const DISTRICT_MARK =
  'V14_GOLDEN_UI_DISTRICT';

const RENO_MARK =
  'V14_GOLDEN_UI_RENOVATION';

function patchMain() {
  const rel =
    'src/main.js';

  let s =
    read(rel);

  if (
    s.includes(
      MAIN_MARK
    )
  ) {
    return;
  }

  s =
    s.replace(
      "'use strict';",
      "'use strict';\n\n// " +
        MAIN_MARK
    );

  s =
    replaceBetween(
      s,
      'const NAV_ITEMS = [',
      '/* =========================\n   地图小工具',
      `const NAV_ITEMS = [
  { id: 'city', name: '城市', icon: '城' },
  { id: 'shop', name: '门店', icon: '店' },
  { id: 'renovation', name: '装修', icon: '装' },
  { id: 'research', name: '菜单', icon: '菜' },
  { id: 'supply', name: '供应链', icon: '供' },
  { id: 'business', name: '数据', icon: '数' },
  { id: 'system', name: '系统', icon: '设' }
];

`,
      'NAV_ITEMS'
    );

  s =
    replaceBetween(
      s,
      'function updateLayout() {',
      '\nfunction resizeCanvas() {',
      `function updateLayout() {
  TOP_H =
    (
      VIEW_H < 740
        ? 88
        : 94
    ) +
    SAFE_TOP;

  NAV_H =
    (
      VIEW_H < 740
        ? 61
        : 66
    ) +
    SAFE_BOTTOM;

  MAP_X = 0;
  MAP_Y = TOP_H;
  MAP_W = VIEW_W;

  NAV_Y =
    VIEW_H -
    NAV_H;

  MAP_H =
    NAV_Y -
    MAP_Y;

  CARD_H =
    VIEW_H < 740
      ? 128
      : 150;

  CARD_X = 7;
  CARD_W =
    VIEW_W -
    14;

  CARD_Y =
    NAV_Y -
    CARD_H -
    7;
}
`,
      'updateLayout'
    );

  s =
    s.replace(
      /pixelRatio\s*=\s*Math\.min\(\s*2,\s*Math\.max\([\s\S]*?\)\s*\);/,
      `pixelRatio =
    Math.min(
      3,
      Math.max(
        1,
        Number(
          info.pixelRatio
        ) ||
        1
      )
    );`
    );

  s =
    replaceBetween(
      s,
      'function drawTopHud() {',
      '\n/* =========================\n   城市地图',
      `function drawTopHud() {
  const player =
    gameState
      .getPlayer();

  const world =
    gameState
      .getWorld();

  const display =
    timeSystem
      .getDisplayState();

  let cityName =
    gameState
      .getCityName();

  if (
    cityName ===
    '未命名城市'
  ) {
    cityName =
      '云州市';
  }

  const gradient =
    ctx.createLinearGradient(
      0,
      0,
      VIEW_W,
      TOP_H
    );

  gradient.addColorStop(
    0,
    '#0A4166'
  );

  gradient.addColorStop(
    0.55,
    '#164F72'
  );

  gradient.addColorStop(
    1,
    '#0A2C45'
  );

  ctx.fillStyle =
    gradient;

  ctx.fillRect(
    0,
    0,
    VIEW_W,
    TOP_H
  );

  const cityThumb =
    resourceManager
      .getImage(
        'city_header_thumb'
      );

  if (cityThumb) {
    drawImageFocus(
      ctx,
      cityThumb,
      12,
      9 + SAFE_TOP,
      43,
      43,
      1,
      0.5,
      0.5
    );

    roundedRect(
      12,
      9 + SAFE_TOP,
      43,
      43,
      10,
      null,
      'rgba(255,255,255,0.58)',
      1
    );
  } else {
    roundedRect(
      12,
      9 + SAFE_TOP,
      43,
      43,
      10,
      '#E7F0F3',
      'rgba(255,255,255,0.5)'
    );

    drawText(
      '城',
      33.5,
      30 + SAFE_TOP,
      16,
      COLORS.navy,
      '800',
      'center'
    );
  }

  drawText(
    cityName,
    64,
    19 + SAFE_TOP,
    15.5,
    COLORS.white,
    '800'
  );

  drawText(
    '打造属于你的美食帝国',
    64,
    40 + SAFE_TOP,
    7.3,
    'rgba(255,255,255,0.79)',
    '600'
  );

  const weather =
    WEATHER_NAMES[
      world.weather
    ] ||
    '多云';

  drawText(
    weather +
      ' ' +
      (
        Number.isFinite(
          Number(
            world.temperature
          )
        )
          ? world.temperature +
            '℃'
          : ''
      ),
    188,
    20 + SAFE_TOP,
    7.8,
    '#FFF0B5',
    '700',
    'center'
  );

  drawText(
    display.date +
      ' · ' +
      display.time,
    188,
    40 + SAFE_TOP,
    7,
    '#D7E8EE',
    '600',
    'center'
  );

  roundedRect(
    225,
    8 + SAFE_TOP,
    95,
    46,
    12,
    'rgba(5,36,54,0.78)',
    'rgba(255,255,255,0.28)'
  );

  drawText(
    '¥' +
      player.cash
        .toLocaleString(),
    272.5,
    24 + SAFE_TOP,
    11.5,
    '#FFF2B3',
    '800',
    'center'
  );

  drawText(
    '可用资金',
    272.5,
    42 + SAFE_TOP,
    6.5,
    '#D7E8EE',
    '600',
    'center'
  );

  roundedRect(
    326,
    8 + SAFE_TOP,
    52,
    46,
    12,
    'rgba(5,36,54,0.78)',
    'rgba(255,255,255,0.28)'
  );

  drawText(
    '♛ Lv.1',
    352,
    24 + SAFE_TOP,
    8.5,
    '#FFE393',
    '800',
    'center'
  );

  roundedRect(
    334,
    41 + SAFE_TOP,
    36,
    3,
    1.5,
    'rgba(255,255,255,0.23)'
  );

  roundedRect(
    334,
    41 + SAFE_TOP,
    8,
    3,
    1.5,
    COLORS.gold
  );

  const speedItems = [
    ['time:pause', timeSystem.isPaused() ? '▶' : 'Ⅱ'],
    ['time:speed:1', '1×'],
    ['time:speed:2', '2×'],
    ['time:speed:5', '5×'],
    ['time:speed:10', '10×']
  ];

  const speedY =
    TOP_H -
    28;

  const startX =
    13;

  for (
    let i = 0;
    i <
    speedItems.length;
    i++
  ) {
    const item =
      speedItems[i];

    const id =
      item[0];

    const speed =
      timeSystem
        .getSpeed();

    const paused =
      timeSystem
        .isPaused();

    const active =
      id ===
        'time:pause'
        ? paused
        : (
            !paused &&
            Number(
              id.split(':')[2]
            ) === speed
          );

    const x =
      startX +
      i * 45;

    roundedRect(
      x,
      speedY,
      39,
      22,
      8,
      active
        ? COLORS.gold
        : 'rgba(3,35,52,0.62)',
      active
        ? '#FFE29C'
        : 'rgba(255,255,255,0.22)'
    );

    drawText(
      item[1],
      x + 19.5,
      speedY + 11,
      8.3,
      active
        ? '#22353F'
        : COLORS.white,
      '800',
      'center'
    );

    addButton(
      id,
      x - 3,
      speedY - 5,
      45,
      32
    );
  }

  drawText(
    MEAL_NAMES[
      display.mealPeriod
    ] ||
    '',
    375,
    speedY + 11,
    7.1,
    '#D6E7ED',
    '700',
    'right'
  );
}
`,
      'drawTopHud'
    );

  s =
    replaceBetween(
      s,
      'function drawDistrictMarker(',
      '\nfunction startDistrictFx(',
      `function drawDistrictMarker(
  district
) {
  const point =
    getDistrictPoint(
      district.id
    );

  if (!point) {
    return;
  }

  const x =
    point.x;

  const y =
    point.y;

  const selected =
    selectedDistrictId ===
    district.id;

  const animated =
    districtFx.id ===
    district.id;

  const markerScale =
    animated
      ? districtFx.scale
      : 1;

  const color =
    selected
      ? '#FFC73D'
      : '#F1B22D';

  ctx.save();

  ctx.translate(
    x,
    y
  );

  ctx.scale(
    markerScale,
    markerScale
  );

  if (selected) {
    ctx.beginPath();

    ctx.arc(
      0,
      1,
      18 +
        districtFx.flash *
        4,
      0,
      Math.PI *
        2
    );

    ctx.fillStyle =
      'rgba(255,193,52,0.20)';

    ctx.fill();
  }

  ctx.beginPath();

  ctx.moveTo(
    0,
    13
  );

  ctx.lineTo(
    -7,
    0
  );

  ctx.arc(
    0,
    0,
    8,
    Math.PI,
    0,
    false
  );

  ctx.closePath();

  ctx.fillStyle =
    color;

  ctx.shadowColor =
    'rgba(0,0,0,0.30)';

  ctx.shadowBlur =
    5;

  ctx.fill();

  ctx.shadowColor =
    'transparent';

  ctx.beginPath();

  ctx.arc(
    0,
    0,
    4,
    0,
    Math.PI *
      2
  );

  ctx.fillStyle =
    COLORS.navy;

  ctx.fill();

  ctx.restore();

  const labelW =
    Math.max(
      55,
      Math.min(
        82,
        24 +
          district.name.length *
            11
      )
    );

  roundedRect(
    x + 8,
    y - 11,
    labelW,
    22,
    11,
    'rgba(6,45,66,0.90)',
    'rgba(255,255,255,0.28)'
  );

  drawText(
    district.name +
      ' ›',
    x + 8 +
      labelW / 2,
    y,
    7.7,
    COLORS.white,
    '800',
    'center'
  );

  addButton(
    'district:' +
      district.id,
    x - 17,
    y - 23,
    labelW + 35,
    50
  );
}
`,
      'drawDistrictMarker'
    );

  s =
    replaceBetween(
      s,
      'function drawNewsTicker() {',
      '\n/* =========================\n   地图侧边按钮',
      `function drawNewsTicker() {
  const bulletin =
    simulationSystem
      .getBulletin();

  const x =
    8;

  const y =
    MAP_Y +
    7;

  const w =
    VIEW_W -
    16;

  const h =
    31;

  roundedRect(
    x,
    y,
    w,
    h,
    15,
    'rgba(5,40,61,0.88)',
    'rgba(74,184,235,0.45)'
  );

  drawText(
    '📣 城市通报',
    x + 13,
    y + 15.5,
    7.4,
    '#FFD25C',
    '800'
  );

  drawText(
    fitText(
      bulletin.title +
        ' · ' +
        bulletin.detail,
      w - 118,
      6.8,
      '600'
    ),
    x + 86,
    y + 15.5,
    6.8,
    COLORS.white,
    '600'
  );

  drawText(
    '›',
    x + w - 14,
    y + 15.5,
    14,
    '#FFE49F',
    '800',
    'center'
  );

  addButton(
    'tool:news',
    x,
    y,
    w,
    h
  );
}
`,
      'drawNewsTicker'
    );

  s =
    replaceBetween(
      s,
      'function drawToolButton(',
      '\n/* =========================\n   商圈信息卡',
      `function drawToolButton() {
  return 0;
}

function drawSideTools() {
  // V14：首页取消两侧六个大按钮。
  // 地图操作只保留地点、新闻条和底部商圈卡，避免页游/山寨感。
}
`,
      'side tools'
    );

  s =
    replaceBetween(
      s,
      'function drawMetricChip(',
      '\n/* =========================\n   底部导航',
      `function drawMetricChip(
  x,
  y,
  w,
  label,
  value,
  color
) {
  roundedRect(
    x,
    y,
    w,
    37,
    9,
    'rgba(246,244,238,0.95)',
    'rgba(16,54,74,0.08)'
  );

  drawText(
    label,
    x + 8,
    y + 10,
    6.1,
    COLORS.muted,
    '700'
  );

  drawText(
    value,
    x + 8,
    y + 26,
    8.2,
    color,
    '800'
  );
}

function drawDistrictCard() {
  const x =
    CARD_X;

  const y =
    CARD_Y;

  const w =
    CARD_W;

  const h =
    CARD_H;

  roundedRect(
    x,
    y,
    w,
    h,
    16,
    'rgba(255,253,247,0.97)',
    'rgba(15,52,73,0.24)',
    1
  );

  if (
    !selectedDistrictId
  ) {
    drawText(
      '选择一个商圈',
      18,
      y + 23,
      12.5,
      COLORS.text,
      '800'
    );

    drawText(
      '点击地图地点查看人口、需求、客单、竞争和租金',
      18,
      y + 44,
      7,
      COLORS.muted,
      '600'
    );

    drawMetricChip(
      18,
      y + 57,
      108,
      '人口',
      '--',
      COLORS.blue
    );

    drawMetricChip(
      141,
      y + 57,
      108,
      '需求',
      '--',
      COLORS.danger
    );

    drawMetricChip(
      264,
      y + 57,
      108,
      '客单',
      '--',
      COLORS.green
    );

    return;
  }

  const district =
    citySystem
      .getDistrict(
        selectedDistrictId
      );

  if (!district) {
    return;
  }

  const currentDemand =
    demandSystem
      .getTotalDemand(
        district.id
      );

  const thumb =
    resourceManager
      .getImage(
        'city_header_thumb'
      );

  if (thumb) {
    drawImageFocus(
      ctx,
      thumb,
      x + 10,
      y + 10,
      92,
      h - 20,
      1.2,
      0.5,
      0.45
    );

    roundedRect(
      x + 10,
      y + 10,
      92,
      h - 20,
      11,
      null,
      'rgba(8,43,62,0.15)'
    );
  }

  drawText(
    district.name,
    x + 114,
    y + 23,
    14,
    COLORS.text,
    '800'
  );

  drawText(
    (
      district.saturation >=
      simulationConfig
        .city
        .competitionBands
        .high
        ? '竞争较强'
        : '仍有机会'
    ) +
      ' · 消费力 ' +
      (
        district.avgSpend >= 60
          ? '较高'
          : district.avgSpend >= 40
            ? '中等'
            : '亲民'
      ),
    x + 114,
    y + 43,
    6.8,
    COLORS.muted,
    '600'
  );

  const metrics = [
    ['人口', district.population.toLocaleString(), COLORS.blue],
    ['需求', currentDemand.toLocaleString(), COLORS.danger],
    ['客单', '¥' + district.avgSpend, COLORS.green],
    ['餐饮店', district.restaurantCount + '家', COLORS.navy],
    ['饱和度', district.saturation + '%', COLORS.orange],
    ['租金', district.rentIndex.toFixed(2), COLORS.navy]
  ];

  const metricY =
    y + 54;

  const metricW =
    41;

  for (
    let i = 0;
    i <
    metrics.length;
    i++
  ) {
    const mx =
      x + 113 +
      i * 43;

    roundedRect(
      mx,
      metricY,
      metricW,
      45,
      8,
      '#F6F3ED',
      'rgba(16,54,74,0.07)'
    );

    drawText(
      metrics[i][0],
      mx + 5,
      metricY + 11,
      5.4,
      COLORS.muted,
      '700'
    );

    drawText(
      fitText(
        metrics[i][1],
        metricW - 9,
        7.2,
        '800'
      ),
      mx + 5,
      metricY + 29,
      7.2,
      metrics[i][2],
      '800'
    );
  }

  roundedRect(
    x + 205,
    y + h - 38,
    158,
    31,
    15,
    COLORS.gold,
    '#DBA324'
  );

  drawText(
    '进入商圈  ›',
    x + 284,
    y + h - 22.5,
    8.4,
    '#23343D',
    '800',
    'center'
  );

  addButton(
    'district:details',
    x + 196,
    y + h - 44,
    176,
    43
  );
}
`,
      'district card'
    );

  s =
    replaceBetween(
      s,
      'function drawBottomNav() {',
      '\n/* =========================\n   城市场景',
      `function drawBottomNav() {
  const gradient =
    ctx.createLinearGradient(
      0,
      NAV_Y,
      0,
      VIEW_H
    );

  gradient.addColorStop(
    0,
    '#0B3B57'
  );

  gradient.addColorStop(
    1,
    '#06263A'
  );

  ctx.fillStyle =
    gradient;

  ctx.fillRect(
    0,
    NAV_Y,
    VIEW_W,
    NAV_H
  );

  ctx.fillStyle =
    'rgba(75,190,240,0.30)';

  ctx.fillRect(
    0,
    NAV_Y,
    VIEW_W,
    1
  );

  const current =
    sceneManager
      .getCurrentId();

  const cellW =
    VIEW_W /
    NAV_ITEMS.length;

  for (
    let i = 0;
    i <
    NAV_ITEMS.length;
    i++
  ) {
    const item =
      NAV_ITEMS[i];

    const cx =
      i * cellW +
      cellW / 2;

    const active =
      item.id === current ||
      (
        item.id ===
          'city' &&
        current ===
          'district'
      ) ||
      (
        item.id ===
          'shop' &&
        (
          current ===
            'propertyMarket' ||
          current ===
            'equipment' ||
          current ===
            'license' ||
          current ===
            'staff'
        )
      ) ||
      (
        item.id ===
          'renovation' &&
        current ===
          'renovation'
      );

    if (active) {
      roundedRect(
        i * cellW + 3,
        NAV_Y + 5,
        cellW - 6,
        NAV_H - 10,
        11,
        COLORS.gold,
        '#FFE29A'
      );
    }

    drawText(
      item.icon,
      cx,
      NAV_Y + NAV_H * 0.34,
      10.5,
      active
        ? '#163445'
        : '#E6F0F4',
      '800',
      'center'
    );

    drawText(
      item.name,
      cx,
      NAV_Y + NAV_H * 0.72,
      6.7,
      active
        ? '#153342'
        : '#E0EBEF',
      active
        ? '800'
        : '600',
      'center'
    );

    addButton(
      'nav:' +
        item.id,
      i * cellW,
      NAV_Y,
      cellW,
      NAV_H
    );
  }
}
`,
      'bottom nav'
    );

  s =
    replaceOnce(
      s,
      "'assets/images/map/city_base_01.webp'",
      "'assets/images/map/city_base_01.png'",
      'city map PNG'
    );

  const loaderNeedle =
    `resourceManager
      .loadImage(
        'property_icons_01',
        'assets/images/ui/property_icons_01.png',
        'property'
      )`;

  const loaderReplace =
    loaderNeedle +
    `,

    resourceManager
      .loadImage(
        'city_header_thumb',
        'assets/images/premium/district/header_city.jpg',
        'city'
      )`;

  s =
    replaceOnce(
      s,
      loaderNeedle,
      loaderReplace,
      'city header thumbnail loader'
    );

  s =
    s.replace(
      '城市餐饮经营小游戏 V12 玩家报告优化与高保真UI版启动成功',
      '城市餐饮经营小游戏 V14 金蓝高保真UI实装版启动成功'
    );

  write(
    rel,
    s
  );
}

function patchDistrict() {
  const rel =
    'src/scenes/districtScene.js';

  let s =
    read(rel);

  if (
    s.includes(
      DISTRICT_MARK
    )
  ) {
    return;
  }

  s =
    s.replace(
      "'use strict';",
      "'use strict';\n\n// " +
        DISTRICT_MARK
    );

  const ambienceBlock =
    `    ui.coverImage(
      ctx,
      visualAssetSystem
        .get(
          'premium_demand_ambience'
        ),
      11,
      369,
      368,
      127,
      14,
      'rgba(255,250,241,0.73)'
    );

`;

  if (
    s.includes(
      ambienceBlock
    )
  ) {
    s =
      s.replace(
        ambienceBlock,
        ''
      );
  }

  s =
    replaceBetween(
      s,
      '  drawFit(\n',
      '\n  render(ctx) {',
      `  drawFit(
    ctx,
    insight
  ) {
    const y =
      622;

    if (
      y + 78 >
      this.contentBottom
    ) {
      return;
    }

    ui.card(
      ctx,
      10,
      y,
      370,
      72,
      {
        radius:
          15,
        fill:
          '#FFF8E5',
        stroke:
          '#E9C66D'
      }
    );

    ui.text(
      ctx,
      '经营适配',
      22,
      y + 18,
      9,
      COLORS.orange,
      '800'
    );

    const hints =
      insight
        .businessHints
        .slice(
          0,
          5
        );

    for (
      let i = 0;
      i <
      hints.length;
      i++
    ) {
      const x =
        21 +
        i * 64;

      ui.pill(
        ctx,
        hints[i],
        x,
        y + 29,
        58,
        22,
        '#FFF1C8',
        COLORS.text,
        '#E9C873'
      );
    }

    ui.card(
      ctx,
      22,
      y + 53,
      112,
      28,
      {
        radius:
          14,
        fill:
          '#FFFDF7',
        stroke:
          '#D8CDBF',
        shadow:
          false
      }
    );

    ui.text(
      ctx,
      '☆ 收藏商圈',
      78,
      y + 67,
      7,
      COLORS.navy,
      '800',
      'center'
    );

    ui.card(
      ctx,
      145,
      y + 53,
      222,
      28,
      {
        radius:
          14,
        fill:
          '#F6B62B',
        stroke:
          '#E0A122',
        shadow:
          false
      }
    );

    ui.text(
      ctx,
      '选择该商圈开店  ›',
      256,
      y + 67,
      7.5,
      COLORS.text,
      '800',
      'center'
    );

    this.addButton(
      'open-here',
      139,
      y + 48,
      234,
      38
    );
  }
`,
      'district fit'
    );

  const handleNeedle =
    `    if (
      item.id ===
      'market'
    ) {`;

  const handleInsert =
    `    if (
      item.id ===
      'open-here'
    ) {
      sceneManager
        .switchTo(
          'propertyMarket',
          {
            districtId:
              this.districtId,
            source:
              'district'
          }
        );

      return true;
    }

` + handleNeedle;

  s =
    replaceOnce(
      s,
      handleNeedle,
      handleInsert,
      'district open-here handler'
    );

  write(
    rel,
    s
  );
}

function patchStore() {
  const rel =
    'src/scenes/storeScene.js';

  let s =
    read(rel);

  if (
    s.includes(
      STORE_MARK
    )
  ) {
    return;
  }

  s =
    s.replace(
      "'use strict';",
      "'use strict';\n\n// " +
        STORE_MARK
    );

  s =
    replaceBetween(
      s,
      '  drawRoomStrip(\n',
      '\n  renderNoShop(\n',
      `  drawRoomStrip(
    ctx,
    shop
  ) {
    const rooms =
      this.getRooms(
        shop.id
      );

    ui.card(
      ctx,
      9,
      230,
      372,
      120,
      {
        radius:
          14
      }
    );

    ui.text(
      ctx,
      '包厢名称',
      20,
      249,
      10,
      COLORS.text,
      '800'
    );

    ui.text(
      ctx,
      '精致包厢 · 名称、人数、风格均可自定义',
      82,
      249,
      6.5,
      COLORS.muted,
      '500'
    );

    ui.card(
      ctx,
      297,
      237,
      70,
      24,
      {
        radius:
          12,
        fill:
          '#FFF4D8',
        stroke:
          '#E7C46F',
        shadow:
          false
      }
    );

    ui.text(
      ctx,
      '管理包厢 ›',
      332,
      249,
      6.4,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton(
      'room:manage',
      292,
      233,
      80,
      32
    );

    const images = [
      'premium_room_1',
      'premium_room_2',
      'premium_room_3'
    ];

    const cardW =
      82;

    const gap =
      8;

    for (
      let i = 0;
      i < 4;
      i++
    ) {
      const x =
        18 +
        i *
        (
          cardW +
          gap
        );

      ui.card(
        ctx,
        x,
        265,
        cardW,
        70,
        {
          radius:
            9,
          fill:
            '#F8F3EA',
          stroke:
            '#DED3C5',
          shadow:
            false
        }
      );

      if (
        i < 3 &&
        rooms[i]
      ) {
        ui.coverImage(
          ctx,
          visualAssetSystem
            .get(
              images[i]
            ),
          x + 2,
          267,
          cardW - 4,
          46,
          8,
          null
        );

        ui.text(
          ctx,
          rooms[i].name ||
            (
              '包厢' +
              (
                i + 1
              )
            ),
          x + 5,
          325,
          6.3,
          COLORS.text,
          '700'
        );

        ui.card(
          ctx,
          x + cardW - 22,
          315,
          17,
          17,
          {
            radius:
              6,
            fill:
              '#FFF1C8',
            stroke:
              '#E2BF66',
            shadow:
              false
          }
        );

        ui.text(
          ctx,
          '✎',
          x + cardW - 13.5,
          323.5,
          6.4,
          COLORS.navy,
          '800',
          'center'
        );

        this.addButton(
          'room:rename:' +
            rooms[i].id,
          x + cardW - 27,
          310,
          27,
          27
        );
      } else if (
        i < 3
      ) {
        ui.text(
          ctx,
          '待规划',
          x + cardW / 2,
          299,
          7.2,
          COLORS.muted,
          '700',
          'center'
        );

        ui.text(
          ctx,
          '进入装修添加',
          x + cardW / 2,
          320,
          5.5,
          COLORS.muted,
          '600',
          'center'
        );

        this.addButton(
          'room:manage',
          x,
          265,
          cardW,
          70
        );
      } else {
        ui.text(
          ctx,
          '+',
          x + cardW / 2,
          292,
          17,
          '#9D8D7C',
          '500',
          'center'
        );

        ui.text(
          ctx,
          '添加包厢',
          x + cardW / 2,
          318,
          6.2,
          COLORS.navy,
          '700',
          'center'
        );

        this.addButton(
          'room:manage',
          x,
          265,
          cardW,
          70
        );
      }
    }
  }
`,
      'store room strip'
    );

  const renameNeedle =
    `    if (
      item.id.indexOf(
        'module:'
      ) ===
      0
    ) {`;

  const renameInsert =
    `    if (
      item.id ===
      'room:manage'
    ) {
      const shop =
        this.getCurrentShop();

      if (shop) {
        sceneManager
          .switchTo(
            'renovation',
            {
              shopId:
                shop.id,
              page:
                'rooms'
            }
          );
      }

      return true;
    }

    if (
      item.id.indexOf(
        'room:rename:'
      ) ===
      0
    ) {
      const shop =
        this.getCurrentShop();

      if (!shop) {
        return true;
      }

      const roomId =
        item.id.slice(
          'room:rename:'.length
        );

      const room =
        this.getRooms(
          shop.id
        )
        .find(
          roomItem =>
            roomItem.id ===
            roomId
        );

      if (room) {
        textInput
          .requestText({
            title:
              '修改包厢名称',
            value:
              room.name ||
              '',
            placeholder:
              '例如：牡丹厅',
            maxLength:
              12
          })
          .then(
            value => {
              if (!value) {
                return;
              }

              customizationSystem
                .renameRoom(
                  shop.id,
                  roomId,
                  value
                );

              textInput
                .requestRender();
            }
          );
      }

      return true;
    }

` + renameNeedle;

  s =
    replaceOnce(
      s,
      renameNeedle,
      renameInsert,
      'store room actions'
    );

  write(
    rel,
    s
  );
}

function patchRenovation() {
  const rel =
    'src/scenes/renovationScene.js';

  let s =
    read(rel);

  if (
    s.includes(
      RENO_MARK
    )
  ) {
    return;
  }

  s =
    s.replace(
      "'use strict';",
      "'use strict';\n\n// " +
        RENO_MARK
    );

  s =
    replaceOnce(
      s,
      `    this.page =
      'layout';
  }`,
      `    const requestedPage =
      data.page;

    this.page =
      [
        'layout',
        'tables',
        'rooms',
        'style',
        'templates'
      ].includes(
        requestedPage
      )
        ? requestedPage
        : 'layout';
  }`,
      'renovation enter page payload'
    );

  s =
    replaceBetween(
      s,
      '  drawHeader(\n',
      '\n  drawTemplateStrip(\n',
      `  drawHeader(
    ctx,
    shop
  ) {
    premiumUi.coverImage(
      ctx,
      visualAssetSystem
        .get(
          'premium_reno_header'
        ),
      0,
      0,
      DESIGN_W,
      88,
      0,
      'rgba(3,31,47,0.48)'
    );

    ctx.fillStyle =
      'rgba(4,35,51,0.36)';

    ctx.fillRect(
      0,
      0,
      DESIGN_W,
      88
    );

    premiumUi.card(
      ctx,
      8,
      14,
      38,
      38,
      {
        radius:
          11,
        fill:
          'rgba(5,48,68,0.88)',
        stroke:
          'rgba(255,255,255,0.30)',
        shadow:
          false
      }
    );

    this.text(
      ctx,
      '‹',
      27,
      33,
      22,
      '#FFE6A0',
      '800',
      'center'
    );

    this.addButton(
      'back',
      4,
      10,
      46,
      46
    );

    this.text(
      ctx,
      shop.name ||
        '我的酒楼',
      58,
      20,
      15.5,
      COLORS.white,
      '800'
    );

    this.text(
      ctx,
      shop.address,
      58,
      42,
      6.7,
      '#D8E8ED',
      '600'
    );

    premiumUi.card(
      ctx,
      250,
      12,
      62,
      29,
      {
        radius:
          13,
        fill:
          '#F6B62B',
        stroke:
          '#FFE0A0',
        shadow:
          false
      }
    );

    this.text(
      ctx,
      '保存模板',
      281,
      26.5,
      6.8,
      COLORS.text,
      '800',
      'center'
    );

    this.addButton(
      'template:quick-save',
      246,
      8,
      70,
      37
    );

    premiumUi.card(
      ctx,
      318,
      12,
      64,
      29,
      {
        radius:
          13,
        fill:
          '#FFFDF7',
        stroke:
          '#D7CDBF',
        shadow:
          false
      }
    );

    this.text(
      ctx,
      '另存模板',
      350,
      26.5,
      6.8,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton(
      'template:save-as',
      314,
      8,
      72,
      37
    );

    premiumUi.card(
      ctx,
      250,
      49,
      30,
      25,
      {
        radius:
          10,
        fill:
          'rgba(255,255,255,0.88)',
        stroke:
          'rgba(255,255,255,0.35)',
        shadow:
          false
      }
    );

    this.text(
      ctx,
      '↶',
      265,
      61.5,
      11,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton(
      'history:undo',
      245,
      45,
      40,
      33
    );

    premiumUi.card(
      ctx,
      286,
      49,
      30,
      25,
      {
        radius:
          10,
        fill:
          'rgba(255,255,255,0.88)',
        stroke:
          'rgba(255,255,255,0.35)',
        shadow:
          false
      }
    );

    this.text(
      ctx,
      '↷',
      301,
      61.5,
      11,
      COLORS.navy,
      '800',
      'center'
    );

    this.addButton(
      'history:redo',
      281,
      45,
      40,
      33
    );

    this.text(
      ctx,
      money(
        gameState
          .getPlayer()
          .cash
      ),
      377,
      62,
      7.5,
      '#FFE8AE',
      '800',
      'right'
    );

    this.addButton(
      'shop:rename',
      55,
      8,
      166,
      45
    );
  }
`,
      'renovation header'
    );

  const idNeedle =
    `    const id =
      item.id;

`;

  const quickSaveHandler =
    `    const id =
      item.id;

    if (
      id ===
        'template:quick-save' ||
      id ===
        'template:save-as'
    ) {
      const templates =
        customizationSystem
          .getTemplateList();

      textInput
        .requestText({
          title:
            id ===
              'template:save-as'
              ? '另存装修模板'
              : '保存装修模板',
          value:
            renovationConfig
              .templateRules
              .defaultNamePrefix +
            (
              templates.length +
              1
            ),
          placeholder:
            '请输入模板名称',
          maxLength:
            renovationConfig
              .nameRules
              .templateMaxLength
        })
        .then(
          value => {
            if (!value) {
              return;
            }

            const result =
              customizationSystem
                .saveTemplate(
                  this.shopId,
                  value
                );

            this.showToast(
              result.ok
                ? '模板已保存'
                : result.message
            );

            textInput
              .requestRender();
          }
        );

      return true;
    }

`;

  s =
    replaceOnce(
      s,
      idNeedle,
      quickSaveHandler,
      'renovation quick template handlers'
    );

  write(
    rel,
    s
  );
}

function cleanPackage() {
  const rel =
    'package.json';

  const pkg =
    JSON.parse(
      read(rel)
    );

  if (
    pkg.scripts &&
    pkg.scripts.pretest ===
      'node scripts/apply-v14-ui.js'
  ) {
    delete pkg
      .scripts
      .pretest;
  }

  write(
    rel,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\n'
  );
}

function main() {
  patchMain();
  patchDistrict();
  patchStore();
  patchRenovation();
  cleanPackage();

  try {
    fs.unlinkSync(
      path.join(
        ROOT,
        'scripts/apply-v14-ui.js'
      )
    );
  } catch (
    error
  ) {
  }

  console.log(
    'V14 金蓝高保真UI补丁已应用'
  );
}

main();
