'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const workflow = String(process.env.GITHUB_WORKFLOW || '');
const inActions = process.env.GITHUB_ACTIONS === 'true';

// Only the validated update workflow may remove the obsolete parallel updater.
// Other workflows and local npm installs must not mutate .github.
if (inActions && workflow === 'Apply Update ZIP') {
  const legacy = path.join(root, '.github', 'workflows', 'apply-update.yml');
  if (fs.existsSync(legacy)) {
    fs.rmSync(legacy, { force: true });
    console.log('[one-shot-repair] 已移除旧的并行 updater: .github/workflows/apply-update.yml');
  } else {
    console.log('[one-shot-repair] 旧 updater 已不存在。');
  }
} else {
  console.log('[one-shot-repair] 非 Apply Update ZIP 工作流，不修改 .github。');
}
