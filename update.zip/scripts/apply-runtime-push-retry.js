'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');

const githubPath = process.env.GITHUB_PATH;

if (githubPath) {
  const binDir =
    path.join(
      os.tmpdir(),
      'city-restaurant-git-retry-bin'
    );

  fs.mkdirSync(
    binDir,
    { recursive: true }
  );

  const wrapperPath =
    path.join(
      binDir,
      'git'
    );

  fs.writeFileSync(
    wrapperPath,
`#!/usr/bin/env bash
set -u
REAL_GIT="/usr/bin/git"
if [ "\${1:-}" != "push" ]; then
  exec "$REAL_GIT" "$@"
fi
for attempt in 1 2 3 4 5; do
  echo "[city-restaurant] git push attempt \${attempt}/5"
  if "$REAL_GIT" "$@"; then
    exit 0
  fi
  if [ "$attempt" -eq 5 ]; then
    exit 1
  fi
  sleep $((attempt * 5))
  "$REAL_GIT" fetch origin main || true
  if ! "$REAL_GIT" rebase origin/main; then
    "$REAL_GIT" rebase --abort || true
    exit 1
  fi
done
`,
    'utf8'
  );

  fs.chmodSync(
    wrapperPath,
    0o755
  );

  fs.appendFileSync(
    githubPath,
    binDir + '\n',
    'utf8'
  );
}

try {
  fs.unlinkSync(__filename);
} catch (error) {
}

console.log('Git push retry injected');
