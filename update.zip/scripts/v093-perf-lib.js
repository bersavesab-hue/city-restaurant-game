'use strict';

const THROTTLE_MARKER = 'V093_RENDER_THROTTLE_BEGIN';
const RESOLUTION_MARKER = 'V093_RESOLUTION_TUNE_BEGIN';

function applyRenderThrottle(source) {
  source = String(source);
  if (source.includes(THROTTLE_MARKER)) return source;

  const renderRe = /function\s+render\s*\(\s*\)\s*\{/m;
  const match = source.match(renderRe);
  if (!match) {
    throw new Error('V0.9.3: 无法定位 function render()，拒绝修改。');
  }

  const guard = `\n  // ${THROTTLE_MARKER}\n  // 只节流昂贵的整屏 Canvas 重绘，不改变时间、场景或经营模拟更新。\n  const __v093Now = Date.now();\n  const __v093Speed =\n    timeSystem && typeof timeSystem.getSpeed === 'function'\n      ? Number(timeSystem.getSpeed()) || 1\n      : 1;\n  const __v093Paused =\n    timeSystem && typeof timeSystem.isPaused === 'function'\n      ? !!timeSystem.isPaused()\n      : false;\n  const __v093Interval =\n    __v093Speed >= 10 ? 50 :\n    __v093Speed >= 5 ? 40 :\n    __v093Speed >= 2 ? 25 : 0;\n\n  if (\n    !needsResize &&\n    !__v093Paused &&\n    __v093Interval > 0 &&\n    __v093Now - (render.__v093LastTime || 0) < __v093Interval\n  ) {\n    return;\n  }\n\n  render.__v093LastTime = __v093Now;\n  // V093_RENDER_THROTTLE_END\n`;

  return source.replace(renderRe, match[0] + guard);
}

function applyResolutionTune(source) {
  source = String(source);
  if (source.includes(RESOLUTION_MARKER)) return source;

  let changed = false;
  let out = source;

  const dprRe = /(pixelRatio\s*=\s*Math\.min\(\s*)2(\s*,)/m;
  if (dprRe.test(out)) {
    out = out.replace(dprRe, function (_, a, b) {
      return a + '1.5' + b;
    });
    changed = true;
  }

  const cacheRe = /(const\s+cacheScale\s*=\s*)2(\s*;)/m;
  if (cacheRe.test(out)) {
    out = out.replace(cacheRe, function (_, a, b) {
      return a + '1.25' + b;
    });
    changed = true;
  }

  if (!changed) {
    throw new Error('V0.9.3: 未找到 DPR/地图缓存倍率位置，拒绝盲改。');
  }

  const pixelRe = /(pixelRatio\s*=\s*Math\.min\()/m;
  if (pixelRe.test(out)) {
    out = out.replace(pixelRe, `// ${RESOLUTION_MARKER}\n  $1`);
  } else {
    out += `\n// ${RESOLUTION_MARKER}\n// V093_RESOLUTION_TUNE_END\n`;
  }

  return out;
}

function applyVariant(baseSource, variant) {
  let out = String(baseSource);
  switch (variant) {
    case 'full':
      out = applyRenderThrottle(out);
      out = applyResolutionTune(out);
      return out;
    case 'throttle':
      return applyRenderThrottle(out);
    case 'resolution':
      return applyResolutionTune(out);
    case 'baseline':
      return out;
    default:
      throw new Error(`V0.9.3: unknown variant ${variant}`);
  }
}

module.exports = {
  THROTTLE_MARKER,
  RESOLUTION_MARKER,
  applyRenderThrottle,
  applyResolutionTune,
  applyVariant
};
