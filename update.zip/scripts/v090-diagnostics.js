'use strict';

const core = require('../src/simulation/v090/restaurantCore.js');
const space = require('../src/simulation/v090/spaceModel.js');

const smoke = core.simulateDay({
  seed: 'diagnostic',
  day: { day: 1, weekday: 2 },
  context: { weather: 'sunny' },
  district: { id: 'diagnostic', name: '诊断商圈', baseDemand: 260, avgSpend: 28, saturation: 65, segmentMix: { office: 0.5, resident: 0.5 } },
  store: {
    id: 'diagnostic-store', cash: 50000, rating: 4, reputation: 52, visibility: 70,
    rentMonthly: 8000, property: { grossArea: 78 }, layout: { tables: { 2: 4, 4: 6 } }, stoves: 3,
    staff: [
      { role: 'chef', skill: 1, dailyWage: 260 }, { role: 'cook', skill: 0.9, dailyWage: 210 },
      { role: 'waiter', skill: 0.95, dailyWage: 165 }, { role: 'waiter', skill: 0.9, dailyWage: 160 }, { role: 'waiter', skill: 0.88, dailyWage: 155 }
    ],
    menu: [
      { id: 'rice', name: '诊断盖饭', price: 28, cookMinutes: 9, quality: 78, popularity: 70, segmentFit: { office: 0.9, resident: 0.8 }, ingredients: [{ id: 'rice', qty: 0.18 }, { id: 'meat', qty: 0.1 }] }
    ],
    inventory: { rice: { qty: 30, unitCost: 4.5, freshness: 1, shelfLifeDays: 30 }, meat: { qty: 18, unitCost: 20, freshness: 0.9, shelfLifeDays: 4 } }
  },
  competitors: [{ id: 'npc', rating: 3.8, reputation: 48, quality: 65, priceFit: 0.9, visibility: 62 }]
});

console.log(JSON.stringify({
  version: core.version,
  paidCovers: smoke.report.funnel.paidCovers,
  revenue: smoke.report.finance.revenue,
  netProfit: smoke.report.finance.netProfit,
  health: smoke.report.health,
  primaryDriver: smoke.report.primaryDriver,
  space: smoke.report.space,
  coreReady: true
}, null, 2));
