'use strict';
const fs=require('fs');
const path=require('path');
const cp=require('child_process');
const root=path.resolve(__dirname,'..');
if(process.env.GITHUB_ACTIONS!=='true'||String(process.env.GITHUB_WORKFLOW||'')!=='Apply Update ZIP')process.exit(0);
function run(args){return cp.spawnSync('git',args,{cwd:root,encoding:'utf8',stdio:'pipe'});}
function remoteFile(rel){const r=run(['show','origin/main:'+rel]);return r.status===0?String(r.stdout||''):null;}
function localPatch(){try{return JSON.parse(fs.readFileSync(path.join(root,'PATCH_MANIFEST.json'),'utf8')).patch||'';}catch(_){return '';}}
const expected=localPatch();
if(!expected){console.log('[ci-sync] 无 PATCH_MANIFEST patch，跳过并发同步。');process.exit(0);}
let matched=false;
for(let i=0;i<120;i++){
  run(['fetch','origin','main','--quiet']);
  let remotePatch='';
  const raw=remoteFile('PATCH_MANIFEST.json');
  if(raw){try{remotePatch=JSON.parse(raw).patch||'';}catch(_){}}
  const updateStillRemote=remoteFile('update.zip')!==null;
  if(remotePatch===expected&&!updateStillRemote){matched=true;break;}
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,1500);
}
if(!matched){console.error('[ci-sync] 旧快速 updater 未在时限内提交当前补丁：'+expected);process.exit(1);}
const reset=cp.spawnSync('git',['reset','--hard','origin/main'],{cwd:root,stdio:'inherit'});
if(reset.status!==0)process.exit(reset.status||1);
console.log('[ci-sync] 已对齐快速 updater 当前补丁：'+expected);
