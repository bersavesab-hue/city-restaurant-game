'use strict';
const fs=require('fs');
const path=require('path');
const root=path.resolve(__dirname,'..');
const target=path.join(root,'src','scenes','renovationScene.js');
const MARK='V18_RENOVATION_LAYOUT_ENGINE_ADAPTER';
if(!fs.existsSync(target)){
  console.error('[V18] 缺少 src/scenes/renovationScene.js，停止，避免误改其他页面。');
  process.exit(1);
}
let source=fs.readFileSync(target,'utf8');
if(source.includes(MARK)){
  console.log('[V18] 装修布局引擎接入已存在，跳过重复注入。');
  process.exit(0);
}
if(!source.includes('V17_RENOVATION_UI_REWRITE')){
  console.error('[V18] 当前装修页不是已知 V17 结构，停止，避免覆盖未知版本。');
  process.exit(1);
}
if(!source.includes('template:save')){
  console.error('[V18] 当前装修页缺少 template:save 兼容标记，停止。');
  process.exit(1);
}
if(!/module\.exports\s*=/.test(source)){
  console.error('[V18] 未找到 module.exports，无法安全接入。');
  process.exit(1);
}
const addon=String.raw`

/* =========================
   ${MARK}
   V18 — 面积/网格/碰撞/遮挡/经营能力装修内核
   不替换 V17 文件；在现有场景导出后安装适配器。
========================= */
;(function installV18RenovationLayoutAdapter(){
  try {
    require('../renovation/renovationRuntimeV18.js').install(module.exports);
  } catch (error) {
    try { console.error('[V18 renovation adapter install]', error); } catch (_) {}
  }
})();
`;
fs.writeFileSync(target,source+addon);
console.log('[V18] 已把面积/碰撞/遮挡装修内核接入当前 V17 装修页。');
