'use strict';

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const REL =
  'src/main.js';

const MARK =
  'V18_CITY_UI_REWRITE';

function read() {
  return fs.readFileSync(
    path.join(
      ROOT,
      REL
    ),
    'utf8'
  );
}

function write(text) {
  fs.writeFileSync(
    path.join(
      ROOT,
      REL
    ),
    text
  );
}

function replaceBetween(
  source,
  startMarker,
  endMarker,
  replacement,
  label
) {
  const start =
    source.indexOf(
      startMarker
    );

  if (start < 0) {
    throw new Error(
      'V18首页找不到开始标记：' +
      label
    );
  }

  const end =
    source.indexOf(
      endMarker,
      start +
        startMarker.length
    );

  if (end < 0) {
    throw new Error(
      'V18首页找不到结束标记：' +
      label
    );
  }

  return (
    source.slice(
      0,
      start
    ) +
    replacement +
    source.slice(
      end
    )
  );
}

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    !source.includes(
      before
    )
  ) {
    throw new Error(
      'V18首页找不到替换目标：' +
      label
    );
  }

  return source.replace(
    before,
    after
  );
}

let s =
  read();

if (
  s.includes(
    MARK
  )
) {
  console.log(
    'V18首页已经应用'
  );
  process.exit(
    0
  );
}

s =
  s.replace(
    "'use strict';",
    "'use strict';\n\n// " +
      MARK
  );

s =
  replaceBetween(
    s,
    'function updateLayout() {',
    '\nfunction resizeCanvas() {',
    `function updateLayout() {
  TOP_H =
    (
      VIEW_H < 740
        ? 91
        : 97
    ) +
    SAFE_TOP;

  NAV_H =
    (
      VIEW_H < 740
        ? 61
        : 66
    ) +
    SAFE_BOTTOM;

  MAP_X = 0;
  MAP_Y = TOP_H;
  MAP_W = VIEW_W;

  NAV_Y =
    VIEW_H -
    NAV_H;

  MAP_H =
    NAV_Y -
    MAP_Y;

  CARD_H =
    VIEW_H < 740
      ? 126
      : 144;

  CARD_X = 7;
  CARD_W =
    VIEW_W -
    14;

  CARD_Y =
    NAV_Y -
    CARD_H -
    7;
}
`,
    '布局'
  );

s =
  replaceBetween(
    s,
    'function drawTopHud() {',
    '\n/* =========================\n   城市地图',
    `function drawTopHud() {
  const player =
    gameState
      .getPlayer();

  const world =
    gameState
      .getWorld();

  const display =
    timeSystem
      .getDisplayState();

  let cityName =
    gameState
      .getCityName();

  if (
    !cityName ||
    cityName ===
      '未命名城市'
  ) {
    cityName =
      '云州市';
  }

  const headerImage =
    resourceManager
      .getImage(
        'city_header_thumb'
      );

  if (headerImage) {
    drawImageFocus(
      ctx,
      headerImage,
      0,
      0,
      VIEW_W,
      TOP_H,
      1.30,
      0.5,
      0.52
    );

    ctx.fillStyle =
      'rgba(4,35,58,0.61)';

    ctx.fillRect(
      0,
      0,
      VIEW_W,
      TOP_H
    );
  } else {
    ctx.fillStyle =
      COLORS.navy;

    ctx.fillRect(
      0,
      0,
      VIEW_W,
      TOP_H
    );
  }

  roundedRect(
    10,
    8 + SAFE_TOP,
    45,
    45,
    10,
    'rgba(255,255,255,0.92)',
    '#F4C349'
  );

  if (headerImage) {
    drawImageFocus(
      ctx,
      headerImage,
      13,
      11 + SAFE_TOP,
      39,
      39,
      1.75,
      0.18,
      0.54
    );
  } else {
    drawText(
      '城',
      32.5,
      30 + SAFE_TOP,
      15,
      COLORS.navy,
      '800',
      'center'
    );
  }

  drawText(
    cityName,
    66,
    20 + SAFE_TOP,
    15.5,
    COLORS.white,
    '800'
  );

  drawText(
    '打造属于你的美食帝国',
    66,
    42 + SAFE_TOP,
    7.2,
    '#DFEEF4',
    '600'
  );

  drawText(
    WEATHER_NAMES[
      world.weather
    ] ||
    '晴',
    184,
    21 + SAFE_TOP,
    7.7,
    '#FFF1B2',
    '700',
    'center'
  );

  drawText(
    (
      Number.isFinite(
        Number(
          world.temperature
        )
      )
        ? world.temperature +
          '℃'
        : ''
    ),
    184,
    42 + SAFE_TOP,
    6.8,
    '#D7E8EE',
    '600',
    'center'
  );

  roundedRect(
    217,
    9 + SAFE_TOP,
    101,
    45,
    12,
    'rgba(5,39,60,0.86)',
    'rgba(255,255,255,0.30)'
  );

  drawText(
    '¥' +
      player.cash
        .toLocaleString(),
    267.5,
    24 + SAFE_TOP,
    11,
    '#FFF0A8',
    '800',
    'center'
  );

  drawText(
    '可用资金',
    267.5,
    42 + SAFE_TOP,
    6.3,
    '#D6E7ED',
    '600',
    'center'
  );

  roundedRect(
    325,
    9 + SAFE_TOP,
    55,
    45,
    12,
    'rgba(5,39,60,0.86)',
    'rgba(255,255,255,0.30)'
  );

  drawText(
    '♛ Lv.1',
    352.5,
    23 + SAFE_TOP,
    8.2,
    '#FFE081',
    '800',
    'center'
  );

  roundedRect(
    334,
    42 + SAFE_TOP,
    37,
    3,
    1.5,
    'rgba(255,255,255,0.24)'
  );

  roundedRect(
    334,
    42 + SAFE_TOP,
    9,
    3,
    1.5,
    COLORS.gold
  );

  const speedItems = [
    [
      'time:pause',
      timeSystem
        .isPaused()
        ? '▶'
        : 'Ⅱ'
    ],
    [
      'time:speed:1',
      '1×'
    ],
    [
      'time:speed:2',
      '2×'
    ],
    [
      'time:speed:5',
      '5×'
    ],
    [
      'time:speed:10',
      '10×'
    ]
  ];

  const y =
    TOP_H -
    27;

  for (
    let i = 0;
    i <
    speedItems.length;
    i++
  ) {
    const id =
      speedItems[i][0];

    const speed =
      timeSystem
        .getSpeed();

    const paused =
      timeSystem
        .isPaused();

    const active =
      id ===
        'time:pause'
        ? paused
        : (
            !paused &&
            Number(
              id.split(':')[2]
            ) === speed
          );

    const x =
      12 +
      i * 45;

    roundedRect(
      x,
      y,
      39,
      21,
      8,
      active
        ? COLORS.gold
        : 'rgba(4,40,60,0.82)',
      active
        ? '#FFE38D'
        : 'rgba(255,255,255,0.20)'
    );

    drawText(
      speedItems[i][1],
      x + 19.5,
      y + 10.5,
      8,
      active
        ? '#173444'
        : COLORS.white,
      '800',
      'center'
    );

    addButton(
      id,
      x - 3,
      y - 5,
      45,
      31
    );
  }

  drawText(
    display.date +
      ' · ' +
      display.time +
      ' · ' +
      (
        MEAL_NAMES[
          display.mealPeriod
        ] ||
        ''
      ),
    375,
    y + 10.5,
    6.5,
    '#DCEBF0',
    '600',
    'right'
  );
}
`,
    '顶部HUD'
  );

s =
  replaceBetween(
    s,
    'function drawDistrictMarker(',
    '\nfunction startDistrictFx(',
    `function drawDistrictMarker(
  district
) {
  const point =
    getDistrictPoint(
      district.id
    );

  if (!point) {
    return;
  }

  const x =
    point.x;

  const y =
    point.y;

  const selected =
    selectedDistrictId ===
      district.id;

  const markerKeys = {
    university:
      'district_marker_gold',
    hightech:
      'district_marker_blue',
    cbd:
      'district_marker_orange',
    oldtown:
      'district_marker_purple',
    village:
      'district_marker_green',
    market:
      'district_marker_red',
    industry:
      'district_marker_blue'
  };

  const image =
    resourceManager
      .getImage(
        markerKeys[
          district.id
        ]
      );

  if (selected) {
    ctx.beginPath();

    ctx.arc(
      x,
      y,
      20 +
        districtFx.flash *
          4,
      0,
      Math.PI *
        2
    );

    ctx.fillStyle =
      'rgba(255,191,45,0.22)';

    ctx.fill();
  }

  if (image) {
    ctx.drawImage(
      image,
      x - 16,
      y - 23,
      32,
      44
    );
  } else {
    ctx.beginPath();

    ctx.arc(
      x,
      y,
      8,
      0,
      Math.PI *
        2
    );

    ctx.fillStyle =
      COLORS.gold;

    ctx.fill();
  }

  const labelW =
    Math.max(
      63,
      31 +
        district.name.length *
          10
    );

  roundedRect(
    x + 8,
    y - 11,
    labelW,
    23,
    11,
    '#063C5B',
    '#F0BA37'
  );

  drawText(
    district.name +
      '  ›',
    x + 8 +
      labelW / 2,
    y + 0.5,
    7.6,
    '#F8FBFC',
    '800',
    'center'
  );

  addButton(
    'district:' +
      district.id,
    x - 20,
    y - 28,
    labelW + 42,
    56
  );
}
`,
    '商圈标记'
  );

s =
  replaceBetween(
    s,
    'function drawNewsTicker() {',
    '\n/* =========================\n   地图侧边按钮',
    `function drawNewsTicker() {
  const bulletin =
    simulationSystem
      .getBulletin();

  const x =
    8;

  const y =
    MAP_Y +
    7;

  const w =
    VIEW_W -
    16;

  const h =
    31;

  roundedRect(
    x,
    y,
    w,
    h,
    15,
    'rgba(3,40,62,0.92)',
    'rgba(73,192,239,0.52)'
  );

  drawText(
    '📣 城市通报',
    x + 13,
    y + 15.5,
    7,
    '#FFD66B',
    '800'
  );

  drawText(
    fitText(
      bulletin.title +
        '  ·  ' +
        bulletin.detail,
      w - 116,
      6.5,
      '600'
    ),
    x + 87,
    y + 15.5,
    6.5,
    '#F3FAFC',
    '600'
  );

  drawText(
    '›',
    x + w - 14,
    y + 15.5,
    14,
    '#FFE49C',
    '800',
    'center'
  );

  addButton(
    'tool:news',
    x,
    y,
    w,
    h
  );
}
`,
    '城市通报'
  );

s =
  replaceBetween(
    s,
    'function drawToolButton(',
    '\n/* =========================\n   商圈信息卡',
    `function drawToolButton() {
  return 0;
}

function drawSideTools() {
  // V18首页不再使用左右两排页游式大按钮。
}
`,
    '移除侧边按钮'
  );

s =
  replaceBetween(
    s,
    'function drawMetricChip(',
    '\n/* =========================\n   底部导航',
    `function drawMetricChip(
  x,
  y,
  w,
  label,
  value,
  color
) {
  roundedRect(
    x,
    y,
    w,
    38,
    9,
    '#F7F4EE',
    'rgba(15,53,73,0.08)'
  );

  drawText(
    label,
    x + 8,
    y + 10,
    5.8,
    COLORS.muted,
    '700'
  );

  drawText(
    value,
    x + 8,
    y + 27,
    8.1,
    color,
    '800'
  );
}

function drawDistrictCard() {
  const x =
    CARD_X;

  const y =
    CARD_Y;

  const w =
    CARD_W;

  const h =
    CARD_H;

  roundedRect(
    x,
    y,
    w,
    h,
    16,
    'rgba(255,253,247,0.985)',
    'rgba(17,53,72,0.25)',
    1
  );

  if (
    !selectedDistrictId
  ) {
    drawText(
      '请选择一个商圈',
      18,
      y + 22,
      12.3,
      COLORS.text,
      '800'
    );

    drawText(
      '点击地图地点，查看经营数据与开店机会',
      18,
      y + 43,
      6.8,
      COLORS.muted,
      '600'
    );

    drawMetricChip(
      18,
      y + 58,
      108,
      '人口',
      '--',
      COLORS.blue
    );

    drawMetricChip(
      141,
      y + 58,
      108,
      '日需求',
      '--',
      COLORS.danger
    );

    drawMetricChip(
      264,
      y + 58,
      108,
      '客单价',
      '--',
      COLORS.green
    );

    return;
  }

  const district =
    citySystem
      .getDistrict(
        selectedDistrictId
      );

  if (!district) {
    return;
  }

  const currentDemand =
    demandSystem
      .getTotalDemand(
        district.id
      );

  const thumb =
    resourceManager
      .getImage(
        'city_header_thumb'
      );

  if (thumb) {
    drawImageFocus(
      ctx,
      thumb,
      x + 9,
      y + 9,
      91,
      h - 18,
      1.45,
      0.5,
      0.55
    );

    roundedRect(
      x + 9,
      y + 9,
      91,
      h - 18,
      11,
      null,
      'rgba(9,45,63,0.16)'
    );
  }

  drawText(
    district.name,
    x + 112,
    y + 22,
    13.4,
    COLORS.text,
    '800'
  );

  drawText(
    district.saturation >= 95
      ? '竞争激烈 · 仍需谨慎选址'
      : '客群活跃 · 仍有经营机会',
    x + 112,
    y + 42,
    6.3,
    district.saturation >= 95
      ? COLORS.danger
      : COLORS.blue,
    '600'
  );

  const metrics = [
    [
      '人口',
      district.population
        .toLocaleString(),
      COLORS.blue
    ],
    [
      '需求',
      currentDemand
        .toLocaleString(),
      COLORS.green
    ],
    [
      '客单',
      '¥' +
        district.avgSpend,
      COLORS.navy
    ],
    [
      '餐饮店',
      district.restaurantCount +
        '家',
      COLORS.navy
    ],
    [
      '饱和度',
      district.saturation +
        '%',
      district.saturation >= 95
        ? COLORS.danger
        : COLORS.blue
    ],
    [
      '租金',
      district.rentIndex
        .toFixed(
          2
        ),
      COLORS.navy
    ]
  ];

  for (
    let i = 0;
    i <
    metrics.length;
    i++
  ) {
    drawMetricChip(
      x + 111 +
        i * 43,
      y + 53,
      40,
      metrics[i][0],
      metrics[i][1],
      metrics[i][2]
    );
  }

  drawText(
    '实时数据会随人口、城市事件、竞争和租金变化',
    x + 112,
    y + 107,
    5.8,
    COLORS.muted,
    '600'
  );

  roundedRect(
    x + 263,
    y + h - 39,
    101,
    31,
    15,
    COLORS.gold,
    '#D99E22'
  );

  drawText(
    '进入商圈  ›',
    x + 313.5,
    y + h - 23.5,
    8,
    '#213541',
    '800',
    'center'
  );

  addButton(
    'district:details',
    x + 255,
    y + h - 45,
    117,
    44
  );
}
`,
    '商圈卡'
  );

s =
  replaceBetween(
    s,
    'function drawBottomNav() {',
    '\n/* =========================\n   城市场景',
    `function drawBottomNav() {
  const gradient =
    ctx.createLinearGradient(
      0,
      NAV_Y,
      0,
      VIEW_H
    );

  gradient.addColorStop(
    0,
    '#0A405E'
  );

  gradient.addColorStop(
    1,
    '#05263A'
  );

  ctx.fillStyle =
    gradient;

  ctx.fillRect(
    0,
    NAV_Y,
    VIEW_W,
    NAV_H
  );

  ctx.fillStyle =
    'rgba(84,194,237,0.28)';

  ctx.fillRect(
    0,
    NAV_Y,
    VIEW_W,
    1
  );

  const current =
    sceneManager
      .getCurrentId();

  const cellW =
    VIEW_W /
    NAV_ITEMS.length;

  for (
    let i = 0;
    i <
    NAV_ITEMS.length;
    i++
  ) {
    const item =
      NAV_ITEMS[i];

    const cx =
      i * cellW +
      cellW / 2;

    const active =
      item.id ===
        current ||
      (
        item.id ===
          'city' &&
        current ===
          'district'
      ) ||
      (
        item.id ===
          'shop' &&
        (
          current ===
            'propertyMarket' ||
          current ===
            'equipment' ||
          current ===
            'license' ||
          current ===
            'staff'
        )
      ) ||
      (
        item.id ===
          'renovation' &&
        current ===
          'renovation'
      );

    if (
      active
    ) {
      roundedRect(
        i * cellW + 4,
        NAV_Y + 6,
        cellW - 8,
        NAV_H - 12,
        11,
        COLORS.gold,
        '#FFE09A'
      );
    }

    drawText(
      item.icon,
      cx,
      NAV_Y +
        NAV_H *
        0.34,
      10.2,
      active
        ? '#163445'
        : '#E7F1F4',
      '800',
      'center'
    );

    drawText(
      item.name,
      cx,
      NAV_Y +
        NAV_H *
        0.72,
      6.4,
      active
        ? '#153342'
        : '#E0EBEF',
      active
        ? '800'
        : '600',
      'center'
    );

    addButton(
      'nav:' +
        item.id,
      i * cellW,
      NAV_Y,
      cellW,
      NAV_H
    );
  }
}
`,
    '底部导航'
  );

const imageNeedle =
  `    resourceManager
      .loadImage(
        'city_header_thumb',
        'assets/images/premium/district/header_city.jpg',
        'city'
      )`;

const imageReplace =
  imageNeedle +
  `,

    resourceManager
      .loadImage(
        'district_marker_gold',
        'assets/images/split/ui/marker_gold.png',
        'city'
      ),

    resourceManager
      .loadImage(
        'district_marker_blue',
        'assets/images/split/ui/marker_blue.png',
        'city'
      ),

    resourceManager
      .loadImage(
        'district_marker_orange',
        'assets/images/split/ui/marker_orange.png',
        'city'
      ),

    resourceManager
      .loadImage(
        'district_marker_purple',
        'assets/images/split/ui/marker_purple.png',
        'city'
      ),

    resourceManager
      .loadImage(
        'district_marker_green',
        'assets/images/split/ui/marker_green.png',
        'city'
      ),

    resourceManager
      .loadImage(
        'district_marker_red',
        'assets/images/split/ui/marker_red.png',
        'city'
      )`;

s =
  replaceOnce(
    s,
    imageNeedle,
    imageReplace,
    '地图标记资源'
  );

s =
  s.replace(
    '城市餐饮经营小游戏 V14 金蓝高保真UI实装版启动成功',
    '城市餐饮经营小游戏 V18 核心四页全量重构版启动成功'
  );

write(
  s
);

const pkgPath =
  path.join(
    ROOT,
    'package.json'
  );

const pkg =
  JSON.parse(
    fs.readFileSync(
      pkgPath,
      'utf8'
    )
  );

if (
  pkg.scripts &&
  pkg.scripts.pretest ===
    'node scripts/apply-v18-city-ui.js'
) {
  delete pkg.scripts.pretest;
}

fs.writeFileSync(
  pkgPath,
  JSON.stringify(
    pkg,
    null,
    2
  ) +
    '\n'
);

try {
  fs.unlinkSync(
    path.join(
      ROOT,
      'scripts/apply-v18-city-ui.js'
    )
  );
} catch (
  error
) {
}

console.log(
  'V18城市首页全量重构已应用'
);
