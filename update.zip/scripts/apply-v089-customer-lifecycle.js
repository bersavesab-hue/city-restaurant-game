'use strict';

const fs =
  require('fs');

const path =
  require('path');

const childProcess =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const RESTAURANT =
  path.join(
    ROOT,
    'src/operations/restaurantSimulationV081.js'
  );

const BUSINESS =
  path.join(
    ROOT,
    'src/scenes/businessScene.js'
  );

const RUNNER =
  path.join(
    ROOT,
    'scripts/run-ci-tests-v060.js'
  );

const PACKAGE =
  path.join(
    ROOT,
    'package.json'
  );

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  const index =
    source.indexOf(
      before
    );

  if (
    index <
    0
  ) {
    throw new Error(
      '[V0.8.9] 找不到锚点：' +
      label
    );
  }

  return (
    source.slice(
      0,
      index
    ) +
    after +
    source.slice(
      index +
      before.length
    )
  );
}

function syntaxCheck(
  file
) {
  childProcess
    .execFileSync(
      process.execPath,
      [
        '--check',
        file
      ],
      {
        cwd:ROOT,
        stdio:'inherit'
      }
    );
}

function patchRestaurant() {
  let source =
    fs.readFileSync(
      RESTAURANT,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const operationsSchedule =
  require('./operationsScheduleV087.js');`,
`const operationsSchedule =
  require('./operationsScheduleV087.js');

const customerLifecycle =
  require('./customerLifecycleV089.js');`,
      '餐厅模拟接入顾客长期系统'
    );

  source =
    replaceOnce(
      source,
`  const trialFactor =
    shop.status ===
      'trial_opening'
      ? 0.78
      : 1;

  return Math.max(`,
`  const trialFactor =
    shop.status ===
      'trial_opening'
      ? 0.78
      : 1;

  const customerFactor =
    customerLifecycle
      .getDemandMultiplier(
        shop.id
      );

  return Math.max(`,
      '顾客关系需求系数'
    );

  source =
    replaceOnce(
      source,
`      competitionFactor *
      nightFactor *
      trialFactor
  );`,
`      competitionFactor *
      nightFactor *
      trialFactor *
      customerFactor
  );`,
      '顾客关系影响真实客流'
    );

  source =
    replaceOnce(
      source,
`    dynamicWorldSystem
      .onShopDayClosed(
        shop,
        runtime,
        closed
      );`,
`    dynamicWorldSystem
      .onShopDayClosed(
        shop,
        runtime,
        closed
      );

    customerLifecycle
      .onDayClosed(
        shop,
        runtime,
        closed
      );`,
      '每日结算驱动顾客生命周期'
    );

  fs.writeFileSync(
    RESTAURANT,
    source,
    'utf8'
  );
}

function patchBusinessScene() {
  let source =
    fs.readFileSync(
      BUSINESS,
      'utf8'
    );

  source =
    replaceOnce(
      source,
`const managementSystem =
  require('../world/managementWorldSystemV085.js');`,
`const managementSystem =
  require('../world/managementWorldSystemV085.js');

const customerLifecycle =
  require('../operations/customerLifecycleV089.js');`,
      '经营管理接入顾客系统'
    );

  source =
    replaceOnce(
      source,
`  {
    id:'staff',
    name:'员工'
  },
  {
    id:'competitor',`,
`  {
    id:'staff',
    name:'员工'
  },
  {
    id:'customer',
    name:'顾客'
  },
  {
    id:'competitor',`,
      '经营管理增加顾客页签'
    );

  const renderCustomers =
"\n  renderCustomers(\n    ctx,\n    shop\n  ) {\n    const dashboard =\n      customerLifecycle\n        .getDashboard(\n          shop.id\n        );\n\n    const stats =\n      dashboard.stats;\n\n    const cards = [\n      {\n        label:'长期顾客',\n        value:\n          String(\n            stats.knownCustomers\n          ),\n        tone:'#173D54'\n      },\n      {\n        label:'会员',\n        value:\n          String(\n            stats.members\n          ),\n        tone:'#2E8A67'\n      },\n      {\n        label:'复购率',\n        value:\n          stats.repeatRate +\n          '%',\n        tone:\n          stats.repeatRate >=\n            25\n            ? '#2E8A67'\n            : '#C27A35'\n      },\n      {\n        label:'顾客评分',\n        value:\n          stats.avgRating\n            ? stats\n                .avgRating\n                .toFixed(\n                  2\n                )\n            : '暂无',\n        tone:'#C77D00'\n      }\n    ];\n\n    for (\n      let i = 0;\n      i < cards.length;\n      i++\n    ) {\n      const col =\n        i %\n        2;\n\n      const row =\n        Math.floor(\n          i /\n          2\n        );\n\n      this.metric(\n        ctx,\n        cards[i].label,\n        cards[i].value,\n        14 +\n          col *\n          184,\n        142 +\n          row *\n          78,\n        cards[i].tone\n      );\n    }\n\n    ui.card(\n      ctx,\n      14,\n      304,\n      362,\n      72,\n      {\n        radius:14,\n        fill:'#FFFDF8',\n        stroke:'#DDD4C7',\n        shadow:false\n      }\n    );\n\n    ui.text(\n      ctx,\n      '口碑传播 ' +\n        stats.wordOfMouth +\n        ' · 流失 ' +\n        stats.churned +\n        ' · 需求系数 ×' +\n        stats.demandMultiplier,\n      28,\n      326,\n      7.2,\n      '#526B77',\n      '700'\n    );\n\n    ui.text(\n      ctx,\n      dashboard.membershipEnabled\n        ? '会员计划运行中：高满意熟客会逐步沉淀为会员'\n        : '会员计划未开启：熟客仍会复购，但不会沉淀会员',\n      28,\n      352,\n      6.7,\n      dashboard.membershipEnabled\n        ? '#2E8A67'\n        : '#8A7A68',\n      '700'\n    );\n\n    ui.card(\n      ctx,\n      264,\n      318,\n      96,\n      38,\n      {\n        radius:10,\n        fill:\n          dashboard\n            .membershipEnabled\n            ? '#2E8A67'\n            : '#E9B74B',\n        stroke:false,\n        shadow:false\n      }\n    );\n\n    ui.text(\n      ctx,\n      dashboard\n        .membershipEnabled\n        ? '关闭会员'\n        : '开启会员',\n      312,\n      337,\n      7,\n      dashboard\n        .membershipEnabled\n        ? '#FFFFFF'\n        : '#173D54',\n      '800',\n      'center'\n    );\n\n    this.addButton(\n      'customer:membership',\n      264,\n      318,\n      96,\n      38\n    );\n\n    ui.text(\n      ctx,\n      '近期评价',\n      20,\n      402,\n      9,\n      '#173D54',\n      '800'\n    );\n\n    const reviews =\n      dashboard\n        .recentReviews;\n\n    if (\n      !reviews.length\n    ) {\n      ui.text(\n        ctx,\n        '尚未沉淀长期顾客评价，正常营业后自动生成',\n        20,\n        430,\n        7,\n        '#7B8C94',\n        '700'\n      );\n    } else {\n      let y =\n        430;\n\n      for (\n        const review\n        of reviews.slice(\n          0,\n          4\n        )\n      ) {\n        ui.text(\n          ctx,\n          '★'.repeat(\n            Math.max(\n              1,\n              Math.min(\n                5,\n                Number(\n                  review.stars\n                ) ||\n                1\n              )\n            )\n          ) +\n            '  满意度 ' +\n            review.satisfaction +\n            '  · ' +\n            review.segmentId,\n          20,\n          y,\n          6.8,\n          Number(\n            review.stars\n          ) >=\n            4\n            ? '#2E8A67'\n            : '#A56A38',\n          '700'\n        );\n\n        y +=\n          28;\n      }\n    }\n\n    ui.text(\n      ctx,\n      '核心客群',\n      20,\n      558,\n      9,\n      '#173D54',\n      '800'\n    );\n\n    let y =\n      586;\n\n    for (\n      const row\n      of dashboard\n        .segments\n        .slice(\n          0,\n          4\n        )\n    ) {\n      ui.text(\n        ctx,\n        row.segmentId +\n          ' · 活跃 ' +\n          row.active +\n          ' · 累计来店 ' +\n          row.visits,\n        20,\n        y,\n        6.8,\n        '#5F737D',\n        '700'\n      );\n\n      y +=\n        26;\n    }\n  }\n\n";

  source =
    replaceOnce(
      source,
`  render(
    ctx
  ) {`,
renderCustomers +
`  render(
    ctx
  ) {`,
      '顾客管理渲染方法'
    );

  source =
    replaceOnce(
      source,
`    if (
      this.tab ===
      'staff'
    ) {
      this.renderStaff(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'competitor'
    ) {`,
`    if (
      this.tab ===
      'staff'
    ) {
      this.renderStaff(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'customer'
    ) {
      this.renderCustomers(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'competitor'
    ) {`,
      '顾客页签渲染分支'
    );

  source =
    replaceOnce(
      source,
`    if (
      target.id.indexOf(
        'staff:'
      ) ===
      0
    ) {`,
`    if (
      target.id ===
      'customer:membership'
    ) {
      const shop =
        operations
          .getCurrentShop();

      if (shop) {
        const result =
          customerLifecycle
            .toggleMembership(
              shop.id
            );

        opUi.toast(
          result.enabled
            ? '会员计划已开启'
            : '会员计划已关闭'
        );
      }

      return true;
    }

    if (
      target.id.indexOf(
        'staff:'
      ) ===
      0
    ) {`,
      '会员计划按钮'
    );

  fs.writeFileSync(
    BUSINESS,
    source,
    'utf8'
  );
}

function patchRunner() {
  let source =
    fs.readFileSync(
      RUNNER,
      'utf8'
    );

  if (
    !source.includes(
      'tests/customerLifecycleV089.test.js'
    )
  ) {
    source =
      replaceOnce(
        source,
`    'tests/updateInfrastructureV088.test.js',
    'tests/v60CleanBase.test.js'`,
`    'tests/updateInfrastructureV088.test.js',
    'tests/customerLifecycleV089.test.js',
    'tests/v60CleanBase.test.js'`,
        'V0.8.9测试接入'
      );
  }

  fs.writeFileSync(
    RUNNER,
    source,
    'utf8'
  );
}

function finalizePackage() {
  const pkg =
    JSON.parse(
      fs.readFileSync(
        PACKAGE,
        'utf8'
      )
    );

  pkg.version =
    '0.8.9';

  pkg.scripts =
    pkg.scripts ||
    {};

  pkg.scripts.pretest =
    'node tests/customerLifecycleV089.test.js && node tests/updateInfrastructureV088.test.js && node tests/staffCareerV088.test.js && node tests/operationsScheduleV087.test.js && node tests/businessLifecycleV086.test.js && node tests/managementCenterV085.test.js && node tests/liveWorldV084.test.js && node tests/foundationFixesV083.test.js && node scripts/resource-lifecycle.js sync-pools && node tests/resourceLifecycleV062.test.js && node scripts/resource-lifecycle.js gc --apply && node scripts/resource-lifecycle.js audit && node tools/devkit/devkit.js self-check && node tests/devkitV100.test.js';

  fs.writeFileSync(
    PACKAGE,
    JSON.stringify(
      pkg,
      null,
      2
    ) +
      '\\n',
    'utf8'
  );
}

try {
  patchRestaurant();
  patchBusinessScene();
  patchRunner();
  finalizePackage();

  for (
    const file
    of [
      RESTAURANT,
      BUSINESS,
      RUNNER,
      path.join(
        ROOT,
        'src/operations/customerLifecycleV089.js'
      ),
      path.join(
        ROOT,
        'tests/customerLifecycleV089.test.js'
      )
    ]
  ) {
    syntaxCheck(
      file
    );
  }

  console.log(
    '[V0.8.9] 顾客长期经营系统已接入'
  );

  try {
    fs.unlinkSync(
      __filename
    );
  } catch (error) {
  }
} catch (error) {
  console.error(
    error &&
    error.stack
      ? error.stack
      : error
  );

  process.exit(1);
}
