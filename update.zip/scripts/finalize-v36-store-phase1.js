'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const pkgPath = path.join(ROOT, 'package.json');

const pkg = JSON.parse(
  fs.readFileSync(pkgPath, 'utf8')
);

if (pkg.scripts) {
  delete pkg.scripts.pretest;
}

fs.writeFileSync(
  pkgPath,
  JSON.stringify(pkg, null, 2) + '\n',
  'utf8'
);

try {
  fs.unlinkSync(__filename);
} catch (error) {
}

console.log('V36门店第一阶段已固定');
