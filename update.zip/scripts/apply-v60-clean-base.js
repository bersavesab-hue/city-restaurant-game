'use strict';

// CLEAN_BASE_V060_APPLIER
//
// Converts the accumulated patch-style repository into a safer V0.6.0 baseline.
// This script is intentionally one-shot: at the end it removes its own
// preinstall hook and deletes itself so future npm install runs are clean.

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');

function read(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

function write(rel, content) {
  const file = path.join(ROOT, rel);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, content, 'utf8');
}

function remove(rel) {
  const p = path.join(ROOT, rel);
  if (!fs.existsSync(p)) return false;
  fs.rmSync(p, { recursive: true, force: true });
  console.log('[clean-v060] removed', rel);
  return true;
}

function replaceOnce(source, before, after, label) {
  if (!source.includes(before)) {
    throw new Error('[clean-v060] missing target: ' + label);
  }
  return source.replace(before, after);
}

function cleanMain() {
  const rel = 'src/main.js';
  let source = read(rel);

  const legacyStart = '/* V21_HOME_ICON_POLISH */';
  const stableStart = '/* V29_CRISP_ICON_PASS */';

  const start = source.indexOf(legacyStart);
  const end = source.indexOf(stableStart);

  if (start >= 0) {
    if (end < 0 || end <= start) {
      throw new Error('[clean-v060] cannot locate stable V29 boundary');
    }

    source =
      source.slice(0, start) +
      '\n/* CLEAN_BASE_V060: V21-V28 overlay chain removed. */\n\n' +
      source.slice(end);
  }

  // V32 only depended on two tiny V26 helpers. Inline clean equivalents
  // before removing the old V26 overlay block.
  source = source.replace(
    'if (!point) return v26GetPoint(id);',
    'if (!point) return getDistrictPoint(id);'
  );

  source = source.replace(
    /v26GetBadgeSummary\(meta\)/g,
    'v60BadgeSummary(meta)'
  );

  if (
    source.includes('V32_REFERENCE_HOME_REBUILD') &&
    !source.includes('function v60BadgeSummary(')
  ) {
    const v32 = source.indexOf('/* V32_REFERENCE_HOME_REBUILD */');
    const load = source.indexOf('loadResources = function () {', v32);

    if (load < 0) {
      throw new Error('[clean-v060] cannot locate V32 resource boundary');
    }

    const helper = `
function v60BadgeSummary(meta) {
  if (meta.myShopCount > 0) return '已开门店 · 可继续深耕经营';
  if (meta.badge === '租金低') return '租金较低 · 适合抢先布局';
  if (meta.badge === '竞争高') return '竞争激烈 · 适合差异化经营';
  if (meta.badge === '需求↑') return '需求上涨 · 可优先进入';
  return '客群活跃 · 仍有经营机会';
}

`;

    source =
      source.slice(0, load) +
      helper +
      source.slice(load);
  }

  for (const token of [
    'V21_HOME_ICON_POLISH',
    'V22_HOME_MATCH',
    'V23_HOME_REMAP',
    'V24_FINAL_HOME_PACK',
    'V25_STRICT_HOME_LAYOUT',
    'V26_HARD_REBUILD_HOME',
    'V28_TARGET_MARKERS_AND_BADGES',
    'v26GetPoint(',
    'v26GetBadgeSummary('
  ]) {
    if (source.includes(token)) {
      throw new Error('[clean-v060] legacy main token survived: ' + token);
    }
  }

  if (!source.includes('V29_CRISP_ICON_PASS')) {
    throw new Error('[clean-v060] V29 stable icon layer missing');
  }

  if (!source.includes('V32_REFERENCE_HOME_REBUILD')) {
    throw new Error('[clean-v060] V32 stable homepage missing');
  }

  if (!source.includes('V33_GLOBAL_NAV_UNIFICATION')) {
    throw new Error('[clean-v060] V33 global nav missing');
  }

  write(rel, source);
}

function fixRenovationRuntime() {
  const rel = 'src/scenes/renovationScene.js';
  let source = read(rel);

  const start = source.indexOf('  drawFloorCanvas(');
  const end = source.indexOf('\n  drawToolButton(', start);

  if (start < 0 || end < 0) {
    throw new Error('[clean-v060] cannot locate renovation floor renderer');
  }

  let block = source.slice(start, end);

  if (!block.includes('const floorGeometry =')) {
    throw new Error('[clean-v060] floorGeometry declaration missing');
  }

  // The V48 renderer declared floorGeometry but accidentally kept using
  // a non-existent "geometry" variable. Replace only the isolated method.
  block = block.replace(/\bgeometry\b/g, 'floorGeometry');

  if (/\bgeometry\b/.test(block)) {
    throw new Error('[clean-v060] stray geometry variable remains');
  }

  if (!block.includes('this.drawGeometryShell(') ||
      !block.includes('floorGeometry')) {
    throw new Error('[clean-v060] geometry renderer was damaged');
  }

  source =
    source.slice(0, start) +
    block +
    source.slice(end);

  if (!source.includes('V48_DYNAMIC_FLOOR_GEOMETRY_UI')) {
    throw new Error('[clean-v060] V48 renovation UI marker missing');
  }

  write(rel, source);
}

function cleanLegacyFiles() {
  const explicit = [
    'update .zip',
    '.update-recovery-v052',

    'scripts/apply-v20-home-1to1.js',
    'scripts/apply-v21-home-polish.js',
    'scripts/apply-v26-home-rewrite.js',
    'scripts/apply-v42-store-master.js',
    'scripts/apply-v43-1-hotfix.js',
    'scripts/apply-v48-dynamic-floor.js',

    'scripts/ci-reconcile-update-race-v052.js',
    'scripts/run-ci-tests-v052.js',
    'scripts/build-android-js-v052.js',
    'scripts/project-health-check-v052.js',

    'tests/v48SafeReconcile.test.js',
    'tests/v48WorkspacePersistence.test.js',
    'tests/recoveryContractV052.test.js',
    'tests/v43_1ScriptErrorHotfix.test.js',

    'assets/images/v21',
    'assets/images/v24'
  ];

  explicit.forEach(remove);

  // Remove patch-note history from the live tree. The code history remains in git.
  const docsDir = path.join(ROOT, 'docs');
  if (fs.existsSync(docsDir)) {
    for (const name of fs.readdirSync(docsDir)) {
      if (/^[Vv]\d/.test(name) || /^RECOVERY_/i.test(name)) {
        remove(path.join('docs', name));
      }
    }
  }

  // Remove tests that validate superseded V18-V31 visual patch layers.
  const testsDir = path.join(ROOT, 'tests');
  if (fs.existsSync(testsDir)) {
    for (const name of fs.readdirSync(testsDir)) {
      if (
        /^uiV(?:14|18|19|20)\.test\.js$/i.test(name) ||
        /^v(?:18|20|21|22|23|24|25|26|27|28|29|30|31)[A-Za-z0-9_.-]*\.test\.js$/i.test(name)
      ) {
        remove(path.join('tests', name));
      }
    }
  }

  // The mistyped package is gone, so remove its obsolete ignore entry too.
  const ignorePath = path.join(ROOT, '.gitignore');
  if (fs.existsSync(ignorePath)) {
    let ignore = fs.readFileSync(ignorePath, 'utf8');
    ignore = ignore.replace(
      /\n# Historical mistyped update package\.[\s\S]*?\nupdate \.zip\s*/m,
      '\n'
    );
    fs.writeFileSync(ignorePath, ignore.trimEnd() + '\n', 'utf8');
  }
}

function finalizePackage() {
  const pkgPath = path.join(ROOT, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

  pkg.version = '0.6.0';

  if (!pkg.scripts) pkg.scripts = {};

  delete pkg.scripts.preinstall;
  delete pkg.scripts.postinstall;
  delete pkg.scripts['test:v48'];

  pkg.scripts.test = 'node scripts/run-ci-tests-v060.js';
  pkg.scripts['build:android-js'] = 'node scripts/build-android-js-v060.js';
  pkg.scripts.health = 'node scripts/v60-audit.js';

  fs.writeFileSync(
    pkgPath,
    JSON.stringify(pkg, null, 2) + '\n',
    'utf8'
  );

  // One-shot updater: it should not live in the clean repository.
  try {
    fs.unlinkSync(__filename);
  } catch (error) {
    throw new Error('[clean-v060] cannot remove one-shot applier: ' + error.message);
  }
}

cleanMain();
fixRenovationRuntime();
cleanLegacyFiles();
finalizePackage();

console.log('[clean-v060] CLEAN BASE V0.6.0 applied');
