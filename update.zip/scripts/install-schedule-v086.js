'use strict';

const fs =
  require('fs');

const path =
  require('path');

const cp =
  require('child_process');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

function file(rel) {
  return path.join(
    ROOT,
    rel
  );
}

function replaceOnce(
  source,
  before,
  after,
  label
) {
  if (
    source.includes(
      after
    )
  ) {
    return source;
  }

  if (
    !source.includes(
      before
    )
  ) {
    throw new Error(
      '[V0.8.6-SCHEDULE] 找不到接线锚点：' +
      label
    );
  }

  return source.replace(
    before,
    after
  );
}

function patchSimulation() {
  const rel =
    'src/operations/restaurantSimulationV081.js';

  let source =
    fs.readFileSync(
      file(rel),
      'utf8'
    );

  if (
    !source.includes(
      'V086_STAFF_SCHEDULE'
    )
  ) {
    source =
      replaceOnce(
        source,
`const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');
// V084_RESTAURANT_LIVE_WORLD`,
`const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');

const staffScheduleSystem =
  require('../world/staffScheduleSystemV086.js');
// V086_STAFF_SCHEDULE
// V084_RESTAURANT_LIVE_WORLD`,
        '经营模拟读取实时排班'
      );

    source =
      replaceOnce(
        source,
`    return clamp(
      base *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ),
      0.25,
      1.2
    );`,
`    const schedule =
      staffScheduleSystem
        .getCoverage(
          shop.id,
          gameState
            .getTime()
        );

    return clamp(
      base *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ) *
      (
        Number(
          schedule
            .coverageMultiplier
        ) ||
        1
      ),
      0.12,
      1.2
    );`,
        '实时班次产能进入员工覆盖率'
      );

    fs.writeFileSync(
      file(rel),
      source
    );
  }
}

const RENDER_SCHEDULE = String.raw`
  renderSchedule(
    ctx,
    shop
  ) {
    const schedule =
      staffScheduleSystem
        .getDashboard(
          shop.id,
          gameState
            .getTime()
        );

    if (!schedule) {
      return;
    }

    this.sectionCard(
      ctx,
      14,
      138,
      362,
      112,
      '营业时间'
    );

    ui.text(
      ctx,
      schedule.hours.label +
      ' · ' +
      (
        schedule.isOpen
          ? '营业中'
          : '已打烊'
      ),
      28,
      171,
      8.2,
      schedule.isOpen
        ? '#248B63'
        : '#748791',
      '800'
    );

    for (
      let i = 0;
      i <
      schedule.presets.length;
      i++
    ) {
      const preset =
        schedule.presets[i];

      const x =
        20 +
        i *
        88;

      const active =
        schedule.hours.openHour ===
          preset.openHour &&
        schedule.hours.closeHour ===
          preset.closeHour;

      opUi.button(
        ctx,
        preset.name,
        x,
        202,
        78,
        30,
        active
          ? 'gold'
          : null
      );

      this.addButton(
        'hours:' +
        preset.id,
        x,
        202,
        78,
        30
      );
    }

    this.sectionCard(
      ctx,
      14,
      264,
      362,
      94,
      '实时在岗'
    );

    ui.text(
      ctx,
      schedule.coverage.activeStaff +
      '/' +
      schedule.coverage.totalStaff +
      '人 · 产能 ' +
      schedule.coverage.coveragePercent +
      '%',
      28,
      298,
      8,
      schedule.coverage.underStaffed
        ? '#C85242'
        : '#248B63',
      '800'
    );

    const role =
      schedule.coverage.roleCoverage ||
      {};

    ui.text(
      ctx,
      '店长 ' +
      (
        role.manager
          ? role.manager.active +
            '/' +
            role.manager.required
          : '0/0'
      ) +
      ' · 厨师 ' +
      (
        role.chef
          ? role.chef.active +
            '/' +
            role.chef.required
          : '0/0'
      ) +
      ' · 服务 ' +
      (
        role.server
          ? role.server.active +
            '/' +
            role.server.required
          : '0/0'
      ) +
      ' · 前台 ' +
      (
        role.cashier
          ? role.cashier.active +
            '/' +
            role.cashier.required
          : '0/0'
      ),
      28,
      328,
      6.7,
      '#607986',
      '700'
    );

    this.sectionCard(
      ctx,
      14,
      372,
      362,
      72,
      '班次人数'
    );

    let sx =
      26;

    for (
      const shift
      of schedule.shifts
    ) {
      ui.text(
        ctx,
        shift.name +
        ' ' +
        shift.staffCount,
        sx,
        405,
        6.8,
        '#173D54',
        '800'
      );

      ui.text(
        ctx,
        shift.label,
        sx,
        428,
        6.1,
        '#748791',
        '600'
      );

      sx +=
        87;
    }

    const perPage =
      opUi.viewHeight() <
        740
        ? 2
        : 3;

    const pages =
      Math.max(
        1,
        Math.ceil(
          schedule.staff.length /
          perPage
        )
      );

    this.schedulePage =
      clamp(
        this.schedulePage,
        0,
        pages -
        1
      );

    const rows =
      schedule.staff.slice(
        this.schedulePage *
        perPage,
        this.schedulePage *
        perPage +
        perPage
      );

    let y =
      458;

    for (
      const staff
      of rows
    ) {
      ui.card(
        ctx,
        14,
        y,
        362,
        48,
        {
          radius:11,
          fill:
            staff.active
              ? '#F0FAF4'
              : '#FFFDF8',
          stroke:
            staff.active
              ? '#9CCBB0'
              : '#DDD4C7',
          shadow:false
        }
      );

      ui.text(
        ctx,
        staff.name,
        28,
        y +
        17,
        7.7,
        '#173D54',
        '800'
      );

      ui.text(
        ctx,
        staff.active
          ? '当前在岗'
          : '当前不在岗',
        28,
        y +
        35,
        6.3,
        staff.active
          ? '#248B63'
          : '#748791',
        '700'
      );

      opUi.button(
        ctx,
        staff.shiftName +
        ' ' +
        staff.shiftLabel,
        202,
        y +
        9,
        160,
        30,
        staff.active
          ? 'gold'
          : null
      );

      this.addButton(
        'shiftstaff:' +
        staff.id,
        194,
        y +
        4,
        174,
        40
      );

      y +=
        56;
    }

    if (
      !schedule.staff.length
    ) {
      ui.text(
        ctx,
        '暂无员工，录用员工后即可排班。',
        195,
        510,
        8.5,
        '#748791',
        '700',
        'center'
      );
    }

    if (
      pages >
      1
    ) {
      const py =
        Math.min(
          630,
          opUi.viewHeight() -
          96
        );

      opUi.button(
        ctx,
        '上一页',
        14,
        py,
        82,
        28
      );

      opUi.button(
        ctx,
        (
          this.schedulePage +
          1
        ) +
        '/' +
        pages,
        154,
        py,
        82,
        28,
        'gold'
      );

      opUi.button(
        ctx,
        '下一页',
        294,
        py,
        82,
        28
      );

      this.addButton(
        'schedprev',
        14,
        py,
        82,
        28
      );

      this.addButton(
        'schednext',
        294,
        py,
        82,
        28
      );
    }
  }

`;

const SCHEDULE_TAPS = String.raw`
    if (
      target.id.indexOf(
        'hours:'
      ) ===
      0
    ) {
      const shop =
        operations
          .getCurrentShop();

      if (!shop) {
        return true;
      }

      const result =
        staffScheduleSystem
          .setBusinessHoursPreset(
            shop.id,
            target.id.slice(
              6
            )
          );

      opUi.toast(
        result.message
      );

      return true;
    }

    if (
      target.id.indexOf(
        'shiftstaff:'
      ) ===
      0
    ) {
      const shop =
        operations
          .getCurrentShop();

      if (!shop) {
        return true;
      }

      const result =
        staffScheduleSystem
          .cycleStaffShift(
            shop.id,
            target.id.slice(
              11
            )
          );

      opUi.toast(
        result.message
      );

      return true;
    }

    if (
      target.id ===
      'schedprev'
    ) {
      this.schedulePage =
        Math.max(
          0,
          this.schedulePage -
          1
        );

      return true;
    }

    if (
      target.id ===
      'schednext'
    ) {
      this.schedulePage +=
        1;

      return true;
    }

`;

function patchBusinessScene() {
  const rel =
    'src/scenes/businessScene.js';

  let source =
    fs.readFileSync(
      file(rel),
      'utf8'
    );

  if (
    source.includes(
      'V086_BUSINESS_SCHEDULE'
    )
  ) {
    return;
  }

  source =
    replaceOnce(
      source,
`const managementSystem =
  require('../world/managementWorldSystemV085.js');

const ui =`,
`const managementSystem =
  require('../world/managementWorldSystemV085.js');

const staffScheduleSystem =
  require('../world/staffScheduleSystemV086.js');
// V086_BUSINESS_SCHEDULE

const ui =`,
      '经营管理读取排班系统'
    );

  source =
    replaceOnce(
      source,
`  {
    id:'staff',
    name:'员工'
  },
  {
    id:'competitor',
    name:'竞品'
  },`,
`  {
    id:'staff',
    name:'员工'
  },
  {
    id:'schedule',
    name:'排班'
  },
  {
    id:'competitor',
    name:'竞品'
  },`,
      '新增排班页签'
    );

  source =
    replaceOnce(
      source,
`    this.staffPage =
      0;

    this.competitorPage =`,
`    this.staffPage =
      0;

    this.schedulePage =
      0;

    this.competitorPage =`,
      '新增排班分页状态'
    );

  source =
    replaceOnce(
      source,
`  renderCompetitors(
    ctx,
    shop
  ) {`,
RENDER_SCHEDULE +
`  renderCompetitors(
    ctx,
    shop
  ) {`,
      '插入排班页面'
    );

  source =
    replaceOnce(
      source,
`      '经营、员工、竞品和商圈排名统一管理'`,
`      '经营、员工、排班、竞品和商圈排名统一管理'`,
      '更新页面说明'
    );

  source =
    replaceOnce(
      source,
`    if (
      this.tab ===
      'staff'
    ) {
      this.renderStaff(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'competitor'
    ) {`,
`    if (
      this.tab ===
      'staff'
    ) {
      this.renderStaff(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'schedule'
    ) {
      this.renderSchedule(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'competitor'
    ) {`,
      '接入排班页面渲染'
    );

  source =
    replaceOnce(
      source,
`    if (
      target.id.indexOf(
        'staff:'
      ) ===
      0
    ) {`,
SCHEDULE_TAPS +
`    if (
      target.id.indexOf(
        'staff:'
      ) ===
      0
    ) {`,
      '接入排班交互'
    );

  fs.writeFileSync(
    file(rel),
    source
  );
}

patchSimulation();
patchBusinessScene();

const pkgPath =
  file(
    'package.json'
  );

const pkg =
  JSON.parse(
    fs.readFileSync(
      pkgPath,
      'utf8'
    )
  );

const installCommand =
  'node scripts/install-schedule-v086.js && ';

if (
  pkg.scripts &&
  typeof pkg.scripts.pretest ===
    'string'
) {
  pkg.scripts.pretest =
    pkg.scripts.pretest.replace(
      installCommand,
      ''
    );
}

pkg.version =
  '0.8.6';

fs.writeFileSync(
  pkgPath,
  JSON.stringify(
    pkg,
    null,
    2
  ) + '\n'
);

const stale =
  fs.readdirSync(
    ROOT
  ).filter(
    name =>
      /^V086_/i.test(name) &&
      /\.zip$/i.test(name)
  );

for (
  const name
  of stale
) {
  fs.unlinkSync(
    file(name)
  );
}

for (
  const target
  of [
    'src/operations/restaurantSimulationV081.js',
    'src/scenes/businessScene.js',
    'src/world/staffScheduleSystemV086.js',
    'tests/staffScheduleV086.test.js'
  ]
) {
  const result =
    cp.spawnSync(
      process.execPath,
      [
        '--check',
        file(target)
      ],
      {
        encoding:'utf8'
      }
    );

  if (
    result.status !==
    0
  ) {
    throw new Error(
      '[V0.8.6-SCHEDULE] 语法检查失败：' +
      target +
      '\n' +
      (
        result.stderr ||
        result.stdout ||
        ''
      )
    );
  }
}

console.log(
  '[V0.8.6-SCHEDULE] 排班兼容补丁接入完成'
);

try {
  fs.unlinkSync(
    __filename
  );
} catch (error) {
  console.warn(
    '[V0.8.6-SCHEDULE] 安装器自清理失败：' +
    error.message
  );
}
