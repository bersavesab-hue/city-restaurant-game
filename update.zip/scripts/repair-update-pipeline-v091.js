'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const WORKFLOW = path.join(ROOT, '.github/workflows/apply-update.yml');
const PACKAGE = path.join(ROOT, 'package.json');
const RUNNER = path.join(ROOT, 'scripts/run-ci-tests-v060.js');

function exists(rel) {
  return fs.existsSync(path.join(ROOT, rel));
}

function read(file) {
  if (!fs.existsSync(file)) return '';
  return fs.readFileSync(file, 'utf8');
}

function write(file, source) {
  fs.mkdirSync(path.dirname(file), {recursive:true});
  fs.writeFileSync(file, source, 'utf8');
}

function repairWorkflow() {
  let source = read(WORKFLOW);
  if (!source) {
    throw new Error('[pipeline-rescue] 缺少 .github/workflows/apply-update.yml');
  }

  const genericStep = `      - name: Apply patch installer\n        shell: bash\n        run: |\n          set -euo pipefail\n          if [ -f scripts/apply-update-patch.js ]; then\n            node scripts/apply-update-patch.js\n            rm -f scripts/apply-update-patch.js\n          else\n            echo "No patch installer; files were applied directly."\n          fi\n\n`;

  // Remove the hard-coded V0.8.2 compatibility block that made every newer
  // package depend on an obsolete pretest marker.
  source = source.replace(
    /      - name: Install persistent V0\.8\.2 generated-syntax repair[\s\S]*?(?=      - name: Run all game tests)/,
    genericStep
  );

  // If the legacy block was already absent, insert the generic patch hook
  // immediately before the test stage.
  if (!source.includes('- name: Apply patch installer')) {
    const marker = '      - name: Run all game tests\n';
    if (!source.includes(marker)) {
      throw new Error('[pipeline-rescue] 找不到 Run all game tests 工作流锚点');
    }
    source = source.replace(marker, genericStep + marker);
  }

  if (source.includes('Install persistent V0.8.2 generated-syntax repair')) {
    throw new Error('[pipeline-rescue] 旧V0.8.2硬编码步骤仍然存在');
  }
  if (!source.includes('scripts/apply-update-patch.js')) {
    throw new Error('[pipeline-rescue] 通用补丁入口未写入工作流');
  }

  write(WORKFLOW, source);
}

function inferVersion() {
  const checks = [
    ['tests/updateInfrastructureV088.test.js', '0.8.8'],
    ['tests/staffCareerV088.test.js', '0.8.8'],
    ['tests/operationsScheduleV087.test.js', '0.8.7'],
    ['tests/businessLifecycleV086.test.js', '0.8.6'],
    ['tests/managementCenterV085.test.js', '0.8.5'],
    ['tests/liveWorldV084.test.js', '0.8.4'],
    ['tests/foundationFixesV083.test.js', '0.8.3'],
    ['tests/timeScheduleV0821.test.js', '0.8.21'],
    ['tests/liveRestaurantV082.test.js', '0.8.2']
  ];
  for (const [file, version] of checks) {
    if (exists(file)) return version;
  }
  return '0.8.0';
}

function stablePretest() {
  const tests = [
    'tests/updateInfrastructureV088.test.js',
    'tests/staffCareerV088.test.js',
    'tests/operationsScheduleV087.test.js',
    'tests/businessLifecycleV086.test.js',
    'tests/managementCenterV085.test.js',
    'tests/liveWorldV084.test.js',
    'tests/foundationFixesV083.test.js',
    'tests/timeScheduleV0821.test.js',
    'tests/liveRestaurantV082.test.js',
    'tests/dynamicWorldUiV0816.test.js',
    'tests/dynamicWorldV0815.test.js'
  ].filter(exists);

  const commands = tests.map(file => 'node ' + file);

  if (exists('scripts/resource-lifecycle.js')) {
    commands.push('node scripts/resource-lifecycle.js sync-pools');
    if (exists('tests/resourceLifecycleV062.test.js')) {
      commands.push('node tests/resourceLifecycleV062.test.js');
    }
    commands.push('node scripts/resource-lifecycle.js gc --apply');
    commands.push('node scripts/resource-lifecycle.js audit');
  }

  if (exists('tools/devkit/devkit.js')) {
    commands.push('node tools/devkit/devkit.js self-check');
  }
  if (exists('tests/devkitV100.test.js')) {
    commands.push('node tests/devkitV100.test.js');
  }

  return commands.join(' && ');
}

function repairPackage() {
  let pkg = {};
  try {
    pkg = JSON.parse(read(PACKAGE) || '{}');
  } catch (error) {
    pkg = {};
  }

  pkg.name = pkg.name || 'city-restaurant-game';
  pkg.version = inferVersion();
  pkg.private = true;
  pkg.scripts = pkg.scripts || {};
  pkg.scripts.pretest = stablePretest();
  pkg.scripts.test = pkg.scripts.test || 'node scripts/run-ci-tests-v060.js';
  pkg.scripts.health = pkg.scripts.health || 'node scripts/v60-audit.js';
  pkg.scripts['repo:cleanup'] = pkg.scripts['repo:cleanup'] || 'node scripts/repo-cleanup.js --untrack';
  pkg.scripts['repo:cleanup:dry'] = pkg.scripts['repo:cleanup:dry'] || 'node scripts/repo-cleanup.js --dry-run';
  pkg.scripts['assets:audit'] = pkg.scripts['assets:audit'] || 'node scripts/resource-lifecycle.js audit';
  pkg.scripts['assets:pools'] = pkg.scripts['assets:pools'] || 'node scripts/resource-lifecycle.js sync-pools';
  pkg.scripts['assets:cleanup:dry'] = pkg.scripts['assets:cleanup:dry'] || 'node scripts/resource-lifecycle.js gc';
  pkg.scripts['assets:cleanup'] = pkg.scripts['assets:cleanup'] || 'node scripts/resource-lifecycle.js gc --apply';
  pkg.scripts['dev:audit'] = pkg.scripts['dev:audit'] || 'node tools/devkit/devkit.js audit';
  pkg.scripts['dev:release'] = pkg.scripts['dev:release'] || 'node tools/devkit/devkit.js release-check';
  pkg.scripts['dev:hygiene'] = pkg.scripts['dev:hygiene'] || 'node tools/devkit/code-hygiene.js';
  pkg.scripts['dev:deps'] = pkg.scripts['dev:deps'] || 'node tools/devkit/dependency-audit.js';
  pkg.scripts['dev:data'] = pkg.scripts['dev:data'] || 'node tools/devkit/data-audit.js';
  pkg.scripts['dev:tests'] = pkg.scripts['dev:tests'] || 'node tools/devkit/test-discovery.js';
  pkg.scripts['dev:size'] = pkg.scripts['dev:size'] || 'node tools/devkit/size-report.js';
  pkg.scripts['dev:build-verify'] = pkg.scripts['dev:build-verify'] || 'node tools/devkit/build-verify.js';
  pkg.scripts['dev:snapshot'] = pkg.scripts['dev:snapshot'] || 'node tools/devkit/repo-snapshot.js';
  pkg.scripts['dev:impact'] = pkg.scripts['dev:impact'] || 'node tools/devkit/impact.js';
  pkg.scripts['dev:preflight'] = pkg.scripts['dev:preflight'] || 'node tools/devkit/update-preflight.js';
  pkg.scripts['build:android-js'] = pkg.scripts['build:android-js'] || 'node scripts/build-android-js-v060.js';
  pkg.scripts['build:mini-assets'] = pkg.scripts['build:mini-assets'] || 'node scripts/buildMiniAssets.js';
  pkg.scripts['player-lab'] = pkg.scripts['player-lab'] || 'node simulator/run100.js --report --output reports/player-lab/latest';
  pkg.scripts['player-lab:ci'] = pkg.scripts['player-lab:ci'] || 'node simulator/run100.js --ci --report --output reports/player-lab/latest';

  // Permanent tree must not call one-shot apply/install scripts in pretest.
  if (/scripts\/(?:apply|install)-/i.test(pkg.scripts.pretest || '')) {
    throw new Error('[pipeline-rescue] 稳定pretest仍包含一次性安装器');
  }

  write(PACKAGE, JSON.stringify(pkg, null, 2) + '\n');
}

function validate() {
  const workflow = read(WORKFLOW);
  const pkg = JSON.parse(read(PACKAGE));

  if (/Install persistent V0\.8\.2 generated-syntax repair/.test(workflow)) {
    throw new Error('[pipeline-rescue] 旧硬编码工作流未清除');
  }
  if (!workflow.includes('scripts/apply-update-patch.js')) {
    throw new Error('[pipeline-rescue] 通用补丁钩子缺失');
  }
  if (/scripts\/(?:apply|install)-/i.test(pkg.scripts.pretest || '')) {
    throw new Error('[pipeline-rescue] package pretest仍含一次性安装器');
  }
  if (!exists('scripts/run-ci-tests-v060.js')) {
    throw new Error('[pipeline-rescue] 缺少永久CI运行器');
  }

  // Parse-check the CI runner when possible.
  const r = cp.spawnSync(process.execPath, ['--check', RUNNER], {cwd:ROOT, encoding:'utf8'});
  if (r.status !== 0) {
    throw new Error('[pipeline-rescue] CI运行器语法失败\n' + (r.stderr || r.stdout || ''));
  }
}

try {
  repairWorkflow();
  repairPackage();
  validate();

  // Clean temporary files created by the old workflow/this rescue package.
  for (const rel of [
    'scripts/repair-v082-generated.js',
    'scripts/repair-update-pipeline-v091.js'
  ]) {
    try { fs.unlinkSync(path.join(ROOT, rel)); } catch (error) {}
  }

  console.log('[pipeline-rescue] 更新管线已修复：旧V0.8.2硬编码已移除，通用增量补丁入口已启用');
} catch (error) {
  console.error(error && error.stack ? error.stack : error);
  process.exit(1);
}
