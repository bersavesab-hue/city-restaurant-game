"use strict";

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const mainPath = path.join(ROOT, "src/main.js");
const pkgPath = path.join(ROOT, "package.json");
const startupMarker = "/* =========================\n   启动\n========================= */";

let source = fs.readFileSync(mainPath, "utf8");

if (!source.includes("V30_LAYOUT_CALIBRATION")) {
  const insertAt = source.indexOf(startupMarker);
  if (insertAt < 0) throw new Error("V30无法找到启动标记");

  const block = String.raw`
/* V30_LAYOUT_CALIBRATION */

updateLayout = function () {
  TOP_H = (VIEW_H < 740 ? 92 : 96) + SAFE_TOP;
  NAV_H = (VIEW_H < 740 ? 80 : 84) + SAFE_BOTTOM;

  MAP_X = 0;
  MAP_Y = TOP_H;
  MAP_W = VIEW_W;

  NAV_Y = VIEW_H - NAV_H;
  MAP_H = NAV_Y - MAP_Y;

  CARD_H = VIEW_H < 740 ? 148 : 156;
  CARD_X = 7;
  CARD_W = VIEW_W - 14;
  CARD_Y = NAV_Y - CARD_H - 6;
};

drawWeatherGlyph = function (weather, x, y) {
  if (v29Img('v29_hud_weather', x, y, 36, 30)) return;
};

drawCashGlyph = function (x, y) {
  if (v29Img('v29_hud_money', x, y, 38, 30)) return;
};

drawCrownGlyph = function (x, y) {
  if (v29Img('v29_hud_crown', x, y, 34, 27)) return;
};

drawMetricSymbol = function (label, x, y, color) {
  const key = V29_METRIC_KEYS[label];
  if (key && v29Img(key, x, y, 21, 21)) return;
};

drawNavIcon = function (id, cx, cy, active) {
  const keys = V29_NAV_KEYS[id];
  if (keys && v29Img(active ? keys[1] : keys[0], cx, cy, active ? 32 : 29, active ? 32 : 29, 1)) return;
};

drawTopHud = function () {
  const player = gameState.getPlayer();
  const world = gameState.getWorld();
  const display = timeSystem.getDisplayState();
  const brand = getBrandState(player);

  let cityName = gameState.getCityName();
  if (!cityName || cityName === '未命名城市') cityName = '美食市';

  const bg = resourceManager.getImage('city_base_01');
  if (bg) {
    drawImageFocus(ctx, bg, 0, 0, VIEW_W, TOP_H, 1.56, 0.54, 0.18);
    ctx.fillStyle = 'rgba(7,41,64,0.60)';
    ctx.fillRect(0, 0, VIEW_W, TOP_H);
  } else {
    ctx.fillStyle = COLORS.navy;
    ctx.fillRect(0, 0, VIEW_W, TOP_H);
  }

  drawCityBadge(cityName, 10, 9 + SAFE_TOP, 44);

  drawText(
    fitText(cityName, 114, 18.5, '800'),
    66,
    20 + SAFE_TOP,
    18.5,
    COLORS.white,
    '800'
  );

  roundedRect(
    145,
    12 + SAFE_TOP,
    18,
    18,
    5,
    'rgba(4,49,72,0.74)',
    'rgba(255,255,255,0.22)'
  );
  drawText('✎', 154, 21 + SAFE_TOP, 7.3, '#FFE08B', '800', 'center');
  addButton('city:rename', 140, 7 + SAFE_TOP, 28, 28);

  // Target reference only keeps one quiet subtitle line here.
  drawText(
    '打造属于你的美食之都',
    66,
    43 + SAFE_TOP,
    7.4,
    '#E7F0F5',
    '600'
  );

  drawWeatherGlyph(world.weather, 184, 27 + SAFE_TOP);
  drawText(
    WEATHER_NAMES[world.weather] || '多云',
    203,
    18 + SAFE_TOP,
    7.7,
    '#FFFFFF',
    '800',
    'center'
  );
  drawText(
    (Number(world.temperature) || 22) + '℃',
    203,
    36 + SAFE_TOP,
    7.7,
    '#E9F4F8',
    '700',
    'center'
  );

  // Wider and better spaced money / level cards.
  roundedRect(
    211,
    9 + SAFE_TOP,
    97,
    49,
    12,
    'rgba(5,43,65,0.92)',
    'rgba(114,208,244,0.40)'
  );
  drawCashGlyph(228, 26 + SAFE_TOP);
  drawText(
    fitText('¥' + player.cash.toLocaleString(), 61, 11.8, '800'),
    266,
    21 + SAFE_TOP,
    11.8,
    '#FFF1A7',
    '800',
    'center'
  );
  drawText('可用资金', 266, 42 + SAFE_TOP, 6.9, '#DCEBF1', '600', 'center');

  roundedRect(291, 16 + SAFE_TOP, 13, 13, 4, '#F5B62D', '#FFE598');
  drawText('+', 297.5, 22.5 + SAFE_TOP, 8.6, '#FFFFFF', '800', 'center');

  roundedRect(
    312,
    9 + SAFE_TOP,
    71,
    49,
    12,
    'rgba(5,43,65,0.92)',
    'rgba(114,208,244,0.40)'
  );
  drawCrownGlyph(326, 26 + SAFE_TOP);
  drawText('Lv.' + brand.level, 357, 19 + SAFE_TOP, 8.6, '#FFE27D', '800', 'center');
  roundedRect(332, 40 + SAFE_TOP, 42, 4, 2, 'rgba(255,255,255,0.22)');
  roundedRect(332, 40 + SAFE_TOP, Math.max(4, 42 * brand.progress), 4, 2, COLORS.gold);
  drawText(brand.reputation + '/100', 353, 51 + SAFE_TOP, 5.5, '#E7F2F6', '600', 'center');
  addButton('brand:status', 309, 5 + SAFE_TOP, 76, 55);

  const speedItems = [
    ['time:pause', 'Ⅱ'],
    ['time:speed:1', '1x'],
    ['time:speed:2', '2x'],
    ['time:speed:5', '5x'],
    ['time:speed:10', '10x']
  ];

  const y = TOP_H - 30;
  for (let i = 0; i < speedItems.length; i++) {
    const id = speedItems[i][0];
    const speed = timeSystem.getSpeed();
    const paused = timeSystem.isPaused();
    const active =
      id === 'time:pause'
        ? paused
        : (!paused && Number(id.split(':')[2]) === speed);

    const x = 10 + i * 47;

    roundedRect(
      x,
      y,
      40,
      22,
      8,
      active ? COLORS.gold : 'rgba(4,40,60,0.86)',
      active ? '#FFE38D' : 'rgba(255,255,255,0.18)'
    );

    drawText(
      speedItems[i][1],
      x + 20,
      y + 11,
      8,
      active ? '#173444' : COLORS.white,
      '800',
      'center'
    );

    addButton(id, x - 3, y - 5, 46, 31);
  }

  drawText(
    fitText(
      display.date + ' · ' + display.time + ' · ' + (MEAL_NAMES[display.mealPeriod] || ''),
      171,
      6.7,
      '600'
    ),
    VIEW_W - 9,
    y + 11,
    6.7,
    '#E5F0F4',
    '600',
    'right'
  );
};

drawNewsTicker = function () {
  const feed = simulationSystem.getNewsFeed();
  const bulletin = simulationSystem.getBulletin();

  const x = 8;
  const y = MAP_Y + 4;
  const w = VIEW_W - 16;
  const h = 27;

  roundedRect(
    x,
    y,
    w,
    h,
    13.5,
    'rgba(3,41,64,0.96)',
    'rgba(77,194,240,0.48)'
  );

  drawText('🔊', x + 15, y + 13.8, 9.4, '#FFD65A', '800', 'center');
  drawText('城市播报', x + 30, y + 13.8, 7.4, '#FFD65A', '800');

  const items = ((feed && feed.length ? feed : [bulletin])).slice(0, 3);
  const startX = x + 85;
  const sectionW = (w - 109) / 3;

  for (let i = 0; i < 3; i++) {
    const item =
      items[i] ||
      {
        title:
          i === 0
            ? '美食节即将盛大开幕'
            : i === 1
              ? '新活动：舌尖上的城市'
              : '餐饮品牌纷纷入驻'
      };

    if (i > 0) {
      ctx.fillStyle = 'rgba(230,242,247,0.32)';
      ctx.fillRect(startX + i * sectionW - 6, y + 7, 1, 13);
    }

    drawText(
      fitText(item.title || '城市运行平稳', sectionW - 12, 6.2, '600'),
      startX + i * sectionW,
      y + 13.6,
      6.2,
      '#F3FAFC',
      '600'
    );
  }

  drawText('›', x + w - 12, y + 13.7, 13.5, '#FFE49C', '800', 'center');
  addButton('tool:news', x, y, w, h);
};

drawGoalBar = function () {
  const goal = getHomeGoalState();

  const x = 8;
  const y = MAP_Y + 35;
  const w = VIEW_W - 16;
  const h = 26;

  roundedRect(
    x,
    y,
    w,
    h,
    13,
    'rgba(3,41,64,0.96)',
    'rgba(77,194,240,0.42)'
  );

  drawText('◎', x + 15, y + 13.2, 12, '#FFD85C', '800', 'center');
  drawText('当前目标：', x + 28, y + 13.2, 7.1, '#FFD85C', '800');
  drawText('开设餐厅', x + 83, y + 13.2, 7.2, '#FFFFFF', '800');

  const labels = V26_HOME_DEFAULT_GOAL_STEPS;
  const currentIndex = Math.max(0, Math.min(labels.length - 1, goal.current || 0));
  const startX = x + 167;
  const usable = w - 198;
  const gap = usable / (labels.length - 1);

  for (let i = 0; i < labels.length; i++) {
    const cx = startX + i * gap;
    const done = i < currentIndex;
    const active = i === currentIndex && !goal.completed;

    if (i < labels.length - 1) {
      ctx.strokeStyle = i < currentIndex ? '#F6CC4A' : 'rgba(220,234,240,0.38)';
      ctx.lineWidth = 1.1;
      ctx.beginPath();
      ctx.moveTo(cx + 8, y + 9.6);
      ctx.lineTo(cx + gap - 8, y + 9.6);
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.arc(cx, y + 9.6, 5, 0, Math.PI * 2);
    ctx.fillStyle = done ? '#F2C744' : (active ? '#FFF8CF' : 'rgba(225,239,244,0.18)');
    ctx.fill();
    ctx.strokeStyle = done || active ? '#FFE58B' : '#9DB8C5';
    ctx.lineWidth = 1;
    ctx.stroke();

    drawText(
      labels[i],
      cx,
      y + 21.2,
      5.8,
      active ? '#FFE08A' : '#E8F3F7',
      active ? '800' : '600',
      'center'
    );
  }

  drawText('🎁', x + w - 13, y + 13.2, 9.7, '#FFD85C', '800', 'center');
};

drawDistrictMarker = function (district) {
  const point = v26GetPoint(district.id);
  if (!point) return;

  const x = point.x;
  const y = point.y;
  const selected = selectedDistrictId === district.id;
  const meta = getDistrictVisualMeta(district);
  const config = V26_HOME_POINTS[district.id] || { side: 'right' };
  const animated = districtFx.id === district.id;
  const markerScale = animated ? districtFx.scale : 1;

  if (selected) {
    ctx.beginPath();
    ctx.arc(x, y, 24 + districtFx.flash * 4, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,195,54,0.16)';
    ctx.fill();
  }

  ctx.save();
  ctx.translate(x, y);
  ctx.scale(markerScale, markerScale);

  const markerSpec = V28_MARKER_DISPLAY[district.id] || { w: 44, h: 58, dy: -2 };
  const markerImage = resourceManager.getImage(V28_MARKER_IMAGE_KEYS[district.id]);

  if (markerImage) {
    v28DrawRawImage(
      markerImage,
      -markerSpec.w / 2,
      -markerSpec.h / 2 + markerSpec.dy,
      markerSpec.w,
      markerSpec.h
    );
  } else {
    const key = V21_DISTRICT_ICON_KEYS && V21_DISTRICT_ICON_KEYS[district.id];

    if (
      !key ||
      !(
        typeof v21DrawImage === 'function' &&
        v21DrawImage(key, 0, -4, 44, 56)
      )
    ) {
      drawDistrictPictogram(district.id, 0, -4);
    }
  }

  ctx.restore();

  // Narrower labels: let the map and the marker remain the visual focus.
  const boxW = Math.max(80, Math.min(96, 39 + district.name.length * 9));
  const boxXBase =
    config.side === 'left'
      ? x - boxW - 12
      : x + 12;

  const boxX = Math.max(6, Math.min(VIEW_W - boxW - 6, boxXBase));
  const boxY = Math.max(MAP_Y + 68, Math.min(CARD_Y - 48, y - 12));

  roundedRect(
    boxX,
    boxY,
    boxW,
    23,
    10,
    'rgba(5,53,79,0.97)',
    selected ? '#FFE06C' : 'rgba(255,218,93,0.82)',
    selected ? 1.25 : 1
  );

  drawText(district.name, boxX + 9, boxY + 11.5, 8.5, '#FFFFFF', '800');
  drawText('›', boxX + boxW - 8, boxY + 11.5, 9.5, '#FFE49C', '800', 'center');

  roundedRect(
    boxX + 5,
    boxY + 23,
    boxW - 10,
    16,
    7,
    'rgba(255,253,247,0.98)',
    'rgba(11,55,76,0.12)'
  );

  drawText(
    fitText(meta.subtitle, boxW - 16, 5.5, '700'),
    boxX + boxW / 2,
    boxY + 31.5,
    5.5,
    '#23455B',
    '700',
    'center'
  );

  if (meta.badge) {
    const badgeImage = resourceManager.getImage(V28_BADGE_IMAGE_KEYS[meta.badge]);
    const badgeW =
      meta.badge === '需求↑'
        ? 37
        : (meta.badge === '竞争高' ? 43 : 35);

    const badgeH = 16;
    const badgeX = Math.max(
      6,
      Math.min(VIEW_W - badgeW - 6, boxX + boxW - badgeW + 5)
    );

    if (badgeImage) {
      v28DrawRawImage(badgeImage, badgeX, boxY - 8, badgeW, badgeH);
    }
  }

  if (meta.myShopCount > 0) {
    const storeImage = resourceManager.getImage('v28_badge_my_store');
    const sw = meta.myShopCount > 1 ? 54 : 44;
    const sh = 17;
    const sx = Math.max(
      6,
      Math.min(VIEW_W - sw - 6, boxX + boxW - sw + 4)
    );

    if (storeImage) {
      v28DrawRawImage(storeImage, sx, boxY - 27, sw, sh);

      if (meta.myShopCount > 1) {
        drawText(
          '×' + meta.myShopCount,
          sx + sw - 8,
          boxY - 18.4,
          5,
          '#FFFFFF',
          '800',
          'center'
        );
      }
    }
  }

  const hitLeft = Math.min(x - 22, boxX - 4);
  const hitRight = Math.max(x + 22, boxX + boxW + 4);
  const hitTop = Math.min(y - 30, boxY - 28);
  const hitBottom = Math.max(y + 28, boxY + 41);

  addButton(
    'district:' + district.id,
    hitLeft,
    hitTop,
    hitRight - hitLeft,
    hitBottom - hitTop
  );
};

drawDistrictCard = function () {
  const district = v26GetSelectedDistrict();
  if (!district) return;

  const meta = getDistrictVisualMeta(district);
  const x = CARD_X;
  const y = CARD_Y;
  const w = CARD_W;
  const h = CARD_H;

  roundedRect(
    x,
    y,
    w,
    h,
    18,
    'rgba(255,255,255,0.988)',
    'rgba(10,56,79,0.16)',
    1.1
  );

  const previewKey =
    typeof V24_DISTRICT_PREVIEW_KEYS !== 'undefined'
      ? V24_DISTRICT_PREVIEW_KEYS[district.id]
      : null;

  const preview =
    previewKey
      ? resourceManager.getImage(previewKey)
      : resourceManager.getImage('city_base_01');

  const px = x + 10;
  const py = y + 9;
  const pw = 99;
  const ph = h - 18;

  if (preview) {
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(px + 14, py);
    ctx.arcTo(px + pw, py, px + pw, py + ph, 14);
    ctx.arcTo(px + pw, py + ph, px, py + ph, 14);
    ctx.arcTo(px, py + ph, px, py, 14);
    ctx.arcTo(px, py, px + pw, py, 14);
    ctx.closePath();
    ctx.clip();
    drawImageFocus(ctx, preview, px, py, pw, ph, 1.02, 0.5, 0.5);
    ctx.restore();
  }

  const iconKey = V21_DISTRICT_ICON_KEYS && V21_DISTRICT_ICON_KEYS[district.id];
  if (iconKey && typeof v21DrawImage === 'function') {
    v21DrawImage(iconKey, x + 121, y + 19, 20, 25);
  }

  drawText(district.name, x + 134, y + 19, 14.4, '#103655', '800');
  drawText('›', x + 205, y + 19, 13.2, '#2F5673', '800', 'center');

  drawText(
    v26GetBadgeSummary(meta),
    x + 134,
    y + 38,
    6.8,
    '#39627E',
    '700'
  );

  const metrics = [
    ['人口', district.population.toLocaleString(), '#1E76C5'],
    ['需求', demandSystem.getTotalDemand(district.id).toLocaleString(), '#1E9A5E'],
    ['客单', '¥' + district.avgSpend, '#164A86'],
    ['餐饮店', district.restaurantCount + '家', '#164A86'],
    ['饱和度', district.saturation + '%', '#1E76C5'],
    ['租金', district.rentIndex.toFixed(2), '#164A86']
  ];

  const metricX = x + 113;
  const metricY = y + 50;
  const metricGap = 4;
  const metricW = Math.floor((w - 123 - metricGap * 5) / 6);
  const metricH = 52;

  for (let i = 0; i < metrics.length; i++) {
    const mx = metricX + i * (metricW + metricGap);

    roundedRect(
      mx,
      metricY,
      metricW,
      metricH,
      9,
      '#FAF8F3',
      'rgba(17,62,92,0.10)'
    );

    drawMetricSymbol(
      metrics[i][0],
      mx + metricW / 2,
      metricY + 12,
      metrics[i][2]
    );

    drawText(
      metrics[i][0],
      mx + metricW / 2,
      metricY + 27,
      5.7,
      '#245276',
      '700',
      'center'
    );

    drawText(
      metrics[i][1],
      mx + metricW / 2,
      metricY + 43.5,
      7.4,
      metrics[i][2],
      '800',
      'center'
    );
  }

  drawText(
    '实时数据会随人口、城市事件、竞争和租金变化',
    x + 113,
    y + h - 17,
    5.8,
    '#607D92',
    '600'
  );

  roundedRect(
    x + w - 115,
    y + h - 44,
    104,
    36,
    18,
    '#FFC22D',
    '#DFA01B',
    1.2
  );

  drawText(
    '进入商圈  ›',
    x + w - 63,
    y + h - 25.5,
    8.9,
    '#123A53',
    '800',
    'center'
  );

  addButton(
    'district:details',
    x + w - 119,
    y + h - 48,
    112,
    44
  );
};

drawBottomNav = function () {
  const items = [
    { id: 'city', label: '城市', mapTo: 'city' },
    { id: 'shop', label: '门店', mapTo: 'shop' },
    { id: 'traffic', label: '客流', mapTo: 'city' },
    { id: 'research', label: '菜单', mapTo: 'menu' },
    { id: 'supply', label: '供应链', mapTo: 'supply' },
    { id: 'business', label: '数据', mapTo: 'business' },
    { id: 'system', label: '系统', mapTo: 'system' }
  ];

  roundedRect(0, NAV_Y, VIEW_W, NAV_H, 0, 'rgba(5,52,79,0.99)');

  const glow = ctx.createLinearGradient(0, NAV_Y, 0, NAV_Y + NAV_H);
  glow.addColorStop(0, 'rgba(23,125,203,0.22)');
  glow.addColorStop(1, 'rgba(23,125,203,0.00)');
  ctx.fillStyle = glow;
  ctx.fillRect(0, NAV_Y, VIEW_W, NAV_H);

  ctx.strokeStyle = 'rgba(85,191,243,0.38)';
  ctx.lineWidth = 1;
  ctx.strokeRect(0.5, NAV_Y + 0.5, VIEW_W - 1, NAV_H - 1);

  const cellW = VIEW_W / items.length;
  const current = sceneManager.getCurrentId();

  for (let i = 0; i < items.length; i++) {
    const item = items[i];

    const active =
      (item.id === 'city' && current === 'city' && !trafficMode) ||
      (item.id === 'traffic' && current === 'city' && trafficMode) ||
      (
        item.id === 'shop' &&
        (
          current === 'shop' ||
          current === 'propertyMarket' ||
          current === 'equipment' ||
          current === 'license' ||
          current === 'staff' ||
          current === 'renovation'
        )
      ) ||
      (
        item.id !== 'city' &&
        item.id !== 'traffic' &&
        item.id !== 'shop' &&
        item.mapTo === current
      );

    const cellX = i * cellW;

    if (active) {
      roundedRect(
        cellX + 4,
        NAV_Y + 5,
        cellW - 8,
        NAV_H - 10,
        15,
        '#F5C529',
        '#FFE79B',
        1.2
      );
    }

    drawNavIcon(
      item.id,
      cellX + cellW / 2,
      NAV_Y + 25,
      active
    );

    drawText(
      item.label,
      cellX + cellW / 2,
      NAV_Y + 57,
      active ? 8.9 : 8.4,
      active ? '#173444' : '#FFFFFF',
      active ? '800' : '700',
      'center'
    );

    addButton(
      'nav:' + item.id,
      cellX,
      NAV_Y,
      cellW,
      NAV_H
    );
  }
};

console.log('V30_LAYOUT_CALIBRATION loaded');
`;

  source =
    source.slice(0, insertAt) +
    block +
    source.slice(insertAt);

  source = source.replace(
    '城市餐饮经营小游戏 V29 高清图标版启动成功',
    '城市餐饮经营小游戏 V30 版式校准版启动成功'
  );

  fs.writeFileSync(mainPath, source, "utf8");
}

const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf8"));
if (pkg.scripts) delete pkg.scripts.pretest;
fs.writeFileSync(pkgPath, JSON.stringify(pkg, null, 2) + "\n", "utf8");

try { fs.unlinkSync(__filename); } catch (e) {}

console.log("V30版式校准已应用");
