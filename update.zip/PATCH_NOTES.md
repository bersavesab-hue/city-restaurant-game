# V0.9.0 后端经营核心重构包

- 不改 UI。
- 不改 GitHub workflow。
- 不直接覆盖 package.json；通过 `scripts/apply-update-patch.js` 增量修改。
- 新增独立后端 `src/simulation/v090/`。
- 增加完整经营漏斗、空间/面积、桌型、员工、后厨、菜品、库存、供应链、NPC、商圈、财务、日结因果、存档迁移。
- 自动注册 Android 运行时 `RestaurantCoreV090`。
- 自动给当前最新 `restaurantSimulationV*.js` 追加兼容出口，但不替换原 API。
- 新增独立自动测试与诊断脚本。

使用现有一键更新流程时：把本压缩包改名为仓库根目录的 `update.zip` 并推送即可。
