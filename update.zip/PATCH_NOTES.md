# 餐饮 V0.9.4 倍速卡顿稳定修复

本包只处理倍速性能与上一版 V0.9.3 的测试流程缺陷，不改 UI。

## 修复重点

V0.9.3 的自适应 runner 只临时替换了 `scripts.test`，但 `npm test` 会自动先执行仓库已有的 `pretest`。因此旧 `pretest` 可以在自适应 runner 启动前直接失败，导致自动回退根本没有机会运行。

V0.9.4 临时移除父级 `pretest/posttest`，由 runner 对每个候选方案按仓库原顺序手动执行：

`pretest -> test -> posttest`

候选顺序：

`full -> throttle -> resolution -> baseline`

只要仓库原始 baseline 能通过原测试，本包就不会因为性能优化候选不兼容而阻断构建。

构建后查看 `docs/V094_SELECTED_MODE.txt` 可确认实际采用模式。
