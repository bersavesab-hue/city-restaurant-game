# V0.9.1 整合更新包

包含 V0.9.0 完整经营核心重构 + V0.9.1 倍速卡顿专项修复。

## 本轮新增

- 新增 `src/core/framePacing.js`。
- 1×/2×/5×/10× 使用分级 simulation/render cadence。
- 10× 不再强制全场景 60FPS 重绘。
- 后台恢复 delta 上限 100ms，避免恢复瞬间卡死。
- simulation tick / render tick 分离。
- 点击和短动画仍可临时 60FPS。
- 新增倍速性能自动测试。
- 安装脚本只对当前仓库 `src/main.js` 做结构化增量修改，不使用旧 main.js 覆盖新版本。
