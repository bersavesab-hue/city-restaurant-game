# 100名玩家实验室

这是开发测试项目，不属于正式游戏内容，不会出现在APK或小游戏界面中。

## 它不是100个乱点机器人

系统固定维护 **100个模拟玩家画像**：25类核心玩家 × 4种设备/耐心变体。

覆盖：
- 抖音3分钟新客、广告敏感、通勤碎片化、回流玩家
- TapTap经营模拟核心玩家、画面/UI党、数值硬核、养老休闲
- 零氪、轻氪、付费效率
- 装修审美、沙盒建造、餐饮经营深度
- 完全新手、大字体需求、小屏单手、低端机、高端机、平板
- 反复重开、收藏成就、速通、漏洞猎人、长线连锁经营

## 自动检查维度

UI、字体、点击热区、信息密度、界面结构、流程、新手引导、玩法深度、数值平衡、经济软锁、广告体验、性能、稳定性、无障碍、内容量、耐玩性、自定义自由度、反馈感。

## GitHub手机端怎么看

每次以后上传 `update.zip`，仓库会自动出现一个工作流：

**Actions → 100名玩家实验室 → 最新一次运行**

在运行页面最上方会直接显示 `100名玩家实验室` 的摘要和TOP问题。

页面底部的 **Artifacts** 会出现：

`100-player-lab-report`

下载解压后：
- `report.html`：最好看、手机浏览器可打开的完整报告
- `report.md`：完整文字报告
- `summary.json`：总览
- `issues.json`：全部问题
- `players.json`：100名玩家逐人反馈
- `issues.csv`：问题表格
- `players.csv`：玩家反馈表格
- `github-summary.md`：Actions摘要

## 手动测试

GitHub Actions 页面进入 `100名玩家实验室`，点 **Run workflow** 即可随时重新跑当前版本。

本地命令：
```bash
npm run player-lab
```

报告生成到：
`player-lab-output/`

## 正式游戏隔离

- `src/main.js` 不引用 `simulator/`
- `android/entry.js` 不引用 `simulator/`
- 玩家实验室不注册 sceneManager
- 生成报告目录被 `.gitignore` 排除
- `tests/playerLabIsolation.test.js` 会阻止测试代码误接入正式运行入口

因此正式玩家不会看到测试菜单、100名机器人或测试报告。
