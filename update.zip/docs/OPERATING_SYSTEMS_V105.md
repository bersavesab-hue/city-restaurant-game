# 餐饮经营中枢 V1.0.5

本版本是一次性底层整合包，不是单页面补丁。

## 已整合

- 事件核心引擎：普通 / 重要 / 强制三级。
- 强制事件弹窗：出现后自动暂停经营时间，处理后恢复原速度。
- 事件队列：同时只展示一个强制事件，其余排队。
- 事件冷却与权重：控制重复率和触发密度。
- 连续事件链：错误处理可触发复查、投诉、舆情等后续事件。
- 事件历史：记录触发日期、处理方案、后续结果。
- 事件存档恢复：退出时未处理事件不会消失。
- 消息中心：普通/重要事件与经营消息统一记录。
- 真实需求联动：事件需求倍率包装现有 demandSystem.getTotalDemand，不替换原需求算法。
- 金融：动态授信、经营贷款、每日计息、还款、逾期、信用评分、资金流水。
- 日 / 周 / 月结算：优先导入现有 dailyHistory；旧数据缺字段时标记来源完整度，不伪造。
- 客流漏斗：需求 → 潜在订单 → 实际订单 → 流失原因。
- 员工健康：士气、离职风险、人手风险与事件联动。
- 菜品：现有研发系统继续使用，同时新增统一导入、改良、成本/品质记录接口。
- 评分：口味、服务、环境、性价比、速度、食品安全六维动态评分。
- 排行：提供统一排名记录接口和历史。
- 奖项：按月根据评分、安全、利润、订单等产生提名和评奖结果。
- 经营引导：开店、研发、处理事件、7日数据、现金安全垫五个闭环目标。

## 接口入口

运行后会暴露：

`globalThis.RestaurantOperatingV105`

主要接口：

- `openEventCenter()`
- `openMessageCenter()`
- `openControlCenter(tab)`
- `getDemandMultiplier(districtId)`
- `getSupplyPriceMultiplier()`
- `recordFunnel(metrics)`
- `recordDish(dish)`
- `improveDish(id, dimension, spend)`
- `recordRating(parts)`
- `recordRanking(ranking)`

## 安装保障

`update.zip` 不直接覆盖 package.json，也不修改 GitHub workflow。

安装器执行顺序：

1. 验证主入口、需求系统、package.json 和全部新文件存在。
2. 在内存中生成所有增量改动。
3. 检查接线数量，阻止重复插入。
4. 一次性写入。
5. 对所有关键 JS 运行 `node --check`。
6. 运行经营中枢功能测试。
7. 运行接线审计。
8. GitHub Action 再运行项目原有 `npm test`、JS 打包和 Android APK 构建。
9. 只有所有步骤通过才提交 main；任何一步失败都不会提交半安装状态。

安装器已做两次连续执行测试，第二次不会重复插入代码。
