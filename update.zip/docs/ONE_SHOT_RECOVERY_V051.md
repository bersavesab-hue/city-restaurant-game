# V0.5.1 一次性恢复包

目的：一次修复此前更新链中的目录、npm ci、测试脚本、health 脚本和并行 updater 问题。

关键点：
- 恢复所有新底层到 src/：property/person/competitor/customer/easteregg/foundation/systems/entities/packs。
- package-lock.json 随包提供，Android Test APK / 游戏底层自动测试可使用 npm ci。
- npm test 不再引用不存在的历史测试文件，而是运行实际存在的基线测试 + 本包必需回归测试。
- Apply Update ZIP 的 npm install 阶段会自动移除旧 .github/workflows/apply-update.yml。
- 若旧 updater 与验证 updater 同时启动，ci-reconcile-update-race.js 会等待旧提交并对齐，避免 non-fast-forward push。
- 不覆盖 src/main.js、src/scenes/shopScene.js、android/entry.js 和现有房源市场运行文件。
