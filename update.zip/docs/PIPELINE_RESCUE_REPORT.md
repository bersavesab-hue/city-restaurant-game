# 更新管线救援包

根因：当前 GitHub Actions 工作流硬编码要求 `package.json` 的 `pretest` 永久包含 `node scripts/apply-v082-live-restaurant.js`，但 V0.8.2 及后续安装器安装完成后会删除一次性安装脚本并重写 `pretest`。因此新版 update.zip 一旦覆盖 package.json，就会在正式测试前被旧兼容步骤阻断。

修复：移除该硬编码步骤，新增统一 `scripts/apply-update-patch.js` 补丁钩子；永久 pretest 只保留真正的回归测试与工具检查。后续补丁不再通过覆盖 package.json 来触发安装。
