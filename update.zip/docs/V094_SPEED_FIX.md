# V0.9.4 倍速性能修复

目标：在不改变时间倍率、经营模拟结果和场景更新顺序的前提下，减少高倍速下 Canvas 全屏重绘与高分屏像素压力。

自适应候选：
- full：重绘节流 + DPR/地图缓存降载
- throttle：仅重绘节流
- resolution：仅 DPR/地图缓存降载
- baseline：完整回退原主循环/渲染代码

V0.9.4 同时修复 V0.9.3 的 npm 生命周期问题：父级 npm test 不再在 runner 之前执行旧 pretest。
