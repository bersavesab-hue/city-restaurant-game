# CI 工作流兼容修复

根因：较新的 update 包覆盖 package.json 时遗漏了 `health` / `repo:cleanup` 等脚本，而仓库中的 `test.yml` 与 `android-apk.yml` 仍会执行 `npm run health`，因此一次更新后会出现多个 GitHub Actions 检查同时失败。

本补丁只恢复 CI 契约，不修改游戏运行源码、房源页面、人物、竞对、顾客或 Android 入口。
