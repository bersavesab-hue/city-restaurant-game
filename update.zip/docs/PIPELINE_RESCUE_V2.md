# 更新管线救援 V2

用途：只修复 update.zip 更新管线，不新增玩法。

兼容：V0.8.8、已完成第一步的 V0.8.9，以及存在部分第一步文件的中间状态。

关键机制：利用旧工作流强制要求执行的 `scripts/apply-v082-live-restaurant.js` 作为一次性跳板，在 npm pretest 阶段修改已 checkout 的 `.github/workflows/apply-update.yml`。这不依赖 ZIP 直接覆盖 workflow，因此不受 `unzip -x '.github/workflows/apply-update.yml'` 限制。

成功后：
- 删除旧 V0.8.2 硬编码兼容步骤；
- 新增统一 `scripts/apply-update-patch.js` 增量补丁入口；
- 正式 `pretest` 不再引用任何一次性 apply/install 脚本；
- 救援脚本与旧临时 repair 脚本自删除；
- 保留已成功安装的 V0.8.9 路由功能，不主动回滚。
