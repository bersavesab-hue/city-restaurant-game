# V0.8.50 旧存档运行时修复

基线：V0.8.49  
目标：V0.8.50

## 真机故障

已在真实旧存档中出现：

- 顶部红色提示“游戏启动错误：Script error.”
- 营业日、订单、利润等上半部分仍能绘制
- “日结复盘与连续改善”卡片只有标题，内容完全空白

## 根因

营业日历史中不只有完整日结，还可能存在 `interrupted` 中断营业记录。

连续经营对比原先直接取历史第2条并读取：

- `previous.financial.revenue`
- `previous.financial.profit`

而中断记录没有 `financial`，因此旧存档进入经营日页面时会在真机渲染阶段抛异常。

同时 `dailyOperatingCycle.brief()` 原先也把 `history[0]` 无条件作为 `latestClosed`，语义上同样不安全。

## 修复

1. `latestClosed` 现在只从 `status === 'closed' && financial` 的记录中寻找。
2. 连续经营趋势从最多120条历史中筛选完整日结，再取最近两次进行比较。
3. 中断营业记录继续保留用于诊断，但不会进入日结趋势计算。
4. 增加旧存档夹入 `interrupted` 的回归测试。
5. 安卓错误框补充真实 `error.stack/error.message`，后续异常更容易定位。

该修复不会清空存档，也不会删除历史营业数据。
