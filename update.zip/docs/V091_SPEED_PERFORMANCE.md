# V0.9.2 倍速性能策略

高倍速卡顿的主要成本来自：只要 advancedMinutes > 0，旧主循环就会触发完整 Canvas render()。

V0.9.2 保留原始：
- sceneManager.update(deltaMs)
- animationManager.update(deltaMs)
- timeSystem.update(deltaMs)

仅对 render() 做帧率上限：
- 1×：60 FPS
- 2×：40 FPS
- 5×：25 FPS
- 10×：20 FPS

因此旧模拟语义、事件顺序、测试断言不需要改变，同时显著减少高倍速下 Canvas 绘制压力。
