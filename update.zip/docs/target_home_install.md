# 目标主页资源接入包

这个包已经按仓库可直接放入的目录结构整理好了。

## 直接放入仓库的位置
解压到仓库根目录即可，核心资源都在：

- `assets/images/target_home/markers/`
- `assets/images/target_home/nav/`
- `assets/images/target_home/hud/`
- `assets/images/target_home/status/`
- `assets/images/target_home/detail/`
- `assets/images/target_home/controls/`
- `assets/images/target_home/reference/`

## 你接入代码时最优先会用到的文件

### 商圈针标
- `assets/images/target_home/markers/university.png`
- `assets/images/target_home/markers/hightech.png`
- `assets/images/target_home/markers/cbd.png`
- `assets/images/target_home/markers/oldtown.png`
- `assets/images/target_home/markers/village.png`
- `assets/images/target_home/markers/industry.png`
- `assets/images/target_home/markers/market.png`

### 顶部 HUD
- `assets/images/target_home/hud/city_avatar.png`
- `assets/images/target_home/hud/icon_weather.png`
- `assets/images/target_home/hud/icon_cash.png`
- `assets/images/target_home/hud/icon_plus.png`
- `assets/images/target_home/hud/icon_crown.png`
- `assets/images/target_home/hud/icon_edit.png`
- `assets/images/target_home/hud/icon_broadcast.png`
- `assets/images/target_home/hud/icon_target.png`
- `assets/images/target_home/hud/icon_gift.png`

### 底栏图标
- `assets/images/target_home/nav/city.png`
- `assets/images/target_home/nav/store.png`
- `assets/images/target_home/nav/renovation.png`
- `assets/images/target_home/nav/menu.png`
- `assets/images/target_home/nav/supply.png`
- `assets/images/target_home/nav/data.png`
- `assets/images/target_home/nav/system.png`

### 状态徽记
- `assets/images/target_home/status/high_popularity.png`
- `assets/images/target_home/status/high_competition.png`
- `assets/images/target_home/status/low_rent.png`
- `assets/images/target_home/status/my_store.png`

### 详情卡资源
- `assets/images/target_home/detail/market_preview.png`
- `assets/images/target_home/detail/enter_button.png`
- `assets/images/target_home/detail/metric_population.png`
- `assets/images/target_home/detail/metric_demand.png`
- `assets/images/target_home/detail/metric_spend.png`
- `assets/images/target_home/detail/metric_restaurants.png`
- `assets/images/target_home/detail/metric_saturation.png`
- `assets/images/target_home/detail/metric_rent.png`

## 坐标与缩放
`layout.json` 已给出基于参考宽度 691px 的像素坐标。
运行时建议：

`scale = runtimeWidth / 691`

然后将所有 x/y/w/h 按 scale 等比缩放。

## 说明
- `*.png` 主要是透明可用版。
- `*_exact_crop.png` 是从目标截图直接精确裁下的像素对照版，适合一比一校正，不建议直接当最终动态素材使用。
