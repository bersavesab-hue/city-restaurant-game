# V0.9.0 数据接口契约

## 主入口

```js
const core = require('./src/simulation/v090/restaurantCore.js');
const result = core.simulateDay(input);
```

Android 运行时安装后也可使用：

```js
globalThis.RestaurantCoreV090.simulateDay(input)
```

## simulateDay 输入

最重要的字段：

```js
{
  seed,
  day: { day, weekday, type, holiday },
  context: {
    weather,
    eventMultiplier,
    openMinutes,
    averageDwellMinutes,
    peakConcurrencyFactor
  },
  district: {
    id,
    name,
    baseDemand,
    avgSpend,
    saturation,
    restaurantCount,
    rentIndex,
    segmentMix
  },
  store: {
    id,
    name,
    cash,
    rating,
    reputation,
    brandHeat,
    visibility,
    rentMonthly,
    propertyFeeMonthly,
    property: { grossArea, frontage, fixedAreas, constraints },
    layout: { tables, tableSpecs, furniture },
    staff: [],
    menu: [],
    inventory: {},
    suppliers: []
  },
  competitors: []
}
```

## simulateDay 输出

```js
{
  version,
  nextStore,
  nextDistrict,
  nextCompetitors,
  report,
  diagnostics
}
```

正式 UI 推荐只读取 `report` 和必要的 `nextStore`。`diagnostics` 用于开发调试，不应该原样展示给玩家。

## report 关键字段

```js
report.health
report.funnel
report.losses
report.metrics
report.drivers
report.primaryDriver
report.finance
report.inventory
report.staff
report.space
```

### funnel

```js
{
  marketAllocated,
  arrived,
  seated,
  serviceAccepted,
  kitchenAccepted,
  inventoryAccepted,
  paidCovers,
  completedRate
}
```

### losses

```js
{
  notEntered,
  seating,
  service,
  kitchen,
  stockout,
  total
}
```

### primaryDriver

```js
{
  code,
  severity,
  title,
  evidence,
  action
}
```

UI 以后可以直接显示 `title / evidence / action`，无需自己猜为什么亏损。

## 装修/面积接口

```js
const space = core.modules.spaceModel;

space.normalizeProperty(property);
space.evaluateAreaPlan(property, layout);
space.validateCoordinateLayout(room, objects, options);
space.suggestTableMix(usableDiningArea, customerProfile);
```

拖拽时每次移动家具调用 `validateCoordinateLayout` 即可获得：

- `valid`
- `errors`
- `warnings`
- `COLLISION`
- `OUT_OF_BOUNDS`
- `BLOCKED_DOOR`
- `AISLE_TIGHT`

## 旧存档适配

```js
core.migrateState(oldState)
core.simulateLegacyDay(oldState, options)
```

`migrateState` 为幂等操作，可以重复执行，不会重复插入数据。
