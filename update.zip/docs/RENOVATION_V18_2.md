# Renovation layout engine V18.2

This package is intentionally small and update-infrastructure-safe.

- Uses the repository-approved temporary `scripts/apply-update-patch.js`; the workflow deletes it before tests.
- Does **not** ship any persistent `scripts/apply-v*` file.
- Does not overwrite package.json, package-lock.json, or workflow files.
- Only the layout page is taken over by the new grid/collision renderer; legacy renovation sub-pages remain available.
- Property size follows usableArea/frontage/depth on a 0.5m grid.
- Includes collision, bounds, entrance clearance, utility requirements, z/Y ordering, auto-layout, move/rotate/delete/undo/save.
