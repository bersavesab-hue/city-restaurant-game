# 资源流水线 V0.5.4

目标：避免后续几千张图片导致 APK、update.zip 和上下文持续膨胀。

- 大场景使用 WebP；首页背景/商圈/门店图保持原分辨率但显著压缩。
- 小图标合并为 6 张 128px 单元图集，减少文件数和加载请求。
- `assets/ui/home/manifest.json` 记录路径、尺寸、分组、哈希与图集坐标。
- `src/assets/assetLoaderV2.js` 支持按场景懒加载，不要求启动时加载所有资源。
- `make-asset-delta-v054.js` 可比较两个 manifest，只列出新增/变化/删除资源。
- 首次安装 V0.5.4 时 postinstall 会验证新资源完整后，再删除旧的首页 PNG；删除范围被锁死在 `assets/ui/home/`。
- 不修改现有 main.js / shopScene.js；首页 V2 实装时再接入 loader。
