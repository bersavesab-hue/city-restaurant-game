'use strict';

const assert =
  require('assert');

const fs =
  require('fs');

const path =
  require('path');

const ROOT =
  path.resolve(
    __dirname,
    '..'
  );

const gameState =
  require('../src/core/gameState.js');

const scheduleSystem =
  require('../src/world/staffScheduleSystemV086.js');

gameState.reset();

gameState
  .getBusiness()
  .shops = [
    {
      id:'shop_v086',
      name:'排班测试店',
      status:'open',
      districtId:'university',
      seatEstimate:44
    }
  ];

gameState
  .getBusiness()
  .hasShop = true;

gameState
  .getBusiness()
  .currentShopId =
  'shop_v086';

const prep =
  gameState
    .getOpeningPrep();

prep.staffing.shop_v086 = {
  candidateDay:null,
  candidates:[],
  hired:[
    {
      id:'manager_1',
      name:'周安',
      roleId:'manager',
      wage:7200
    },
    {
      id:'chef_1',
      name:'李文',
      roleId:'chef',
      wage:6800
    },
    {
      id:'server_1',
      name:'陈宁',
      roleId:'server',
      wage:4200
    },
    {
      id:'server_2',
      name:'林佳',
      roleId:'server',
      wage:4200
    },
    {
      id:'cashier_1',
      name:'王晓',
      roleId:'cashier',
      wage:4300
    }
  ]
};

const dash =
  scheduleSystem
    .getDashboard(
      'shop_v086',
      {
        hour:11,
        minute:30
      }
    );

assert.ok(
  dash,
  '必须生成排班面板'
);

assert.strictEqual(
  dash.hours.label,
  '06:00–23:00',
  '老存档默认营业时间必须兼容06:00–23:00'
);

assert.strictEqual(
  dash.staff.length,
  5,
  '必须自动接管已有员工'
);

assert.ok(
  dash.staff.every(
    row =>
      scheduleSystem
        .SHIFT_DEFS
        .some(
          shift =>
            shift.id ===
            row.shiftId
        )
  ),
  '旧员工必须自动分配有效班次'
);

const night =
  scheduleSystem
    .setBusinessHoursPreset(
      'shop_v086',
      'night'
    );

assert.ok(
  night.ok,
  '夜宵营业时间必须可设置'
);

assert.ok(
  scheduleSystem
    .isOpen(
      gameState
        .getBusiness()
        .shops[0],
      {
        hour:1,
        minute:0
      }
    ),
  '跨午夜营业时间凌晨1点必须保持营业'
);

assert.ok(
  !scheduleSystem
    .isOpen(
      gameState
        .getBusiness()
        .shops[0],
      {
        hour:5,
        minute:0
      }
    ),
  '跨午夜营业时间凌晨5点必须打烊'
);

const changed =
  scheduleSystem
    .setStaffShift(
      'shop_v086',
      'chef_1',
      'night'
    );

assert.ok(
  changed.ok,
  '员工班次必须可调整'
);

const oneAM =
  scheduleSystem
    .getCoverage(
      'shop_v086',
      {
        hour:1,
        minute:0
      }
    );

assert.ok(
  oneAM.isOpen,
  '夜宵店凌晨1点必须处于营业状态'
);

assert.ok(
  oneAM.activeStaff >=
  1,
  '夜班员工凌晨必须真实在岗'
);

assert.ok(
  oneAM.coverageMultiplier >=
    0.35 &&
  oneAM.coverageMultiplier <=
    1.08,
  '排班产能修正必须有安全边界'
);

const simulationSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/operations/restaurantSimulationV081.js'
    ),
    'utf8'
  );

assert.ok(
  simulationSource.includes(
    'V086_STAFF_SCHEDULE'
  ) &&
  simulationSource.includes(
    'staffScheduleSystem'
  ) &&
  simulationSource.includes(
    'coverageMultiplier'
  ),
  '真实经营模拟必须接入排班产能'
);

const businessSource =
  fs.readFileSync(
    path.join(
      ROOT,
      'src/scenes/businessScene.js'
    ),
    'utf8'
  );

assert.ok(
  businessSource.includes(
    'V086_BUSINESS_SCHEDULE'
  ) &&
  businessSource.includes(
    "id:'schedule'"
  ) &&
  businessSource.includes(
    'renderSchedule'
  ) &&
  businessSource.includes(
    'shiftstaff:'
  ),
  '经营管理页必须有可操作排班页'
);

console.log(
  'V0.8.6 staff schedule tests passed'
);
