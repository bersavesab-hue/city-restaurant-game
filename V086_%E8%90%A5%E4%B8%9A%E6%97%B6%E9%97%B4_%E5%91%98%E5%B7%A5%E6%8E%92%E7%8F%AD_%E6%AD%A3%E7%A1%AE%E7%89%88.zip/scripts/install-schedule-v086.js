'use strict';

const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname,'..');

function file(rel) {
  return path.join(ROOT,rel);
}

function replaceOnce(source,before,after,label) {
  if (source.includes(after)) {
    return source;
  }

  if (!source.includes(before)) {
    throw new Error(
      '[V0.8.6] 找不到接线锚点：' + label
    );
  }

  console.log('[V0.8.6] 接入：' + label);
  return source.replace(before,after);
}

function patchRestaurantSimulation() {
  const rel =
    'src/operations/restaurantSimulationV081.js';

  let source =
    fs.readFileSync(
      file(rel),
      'utf8'
    );

  if (
    !source.includes(
      'V086_STAFF_SCHEDULE'
    )
  ) {
    source =
      replaceOnce(
        source,
`const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');
// V084_RESTAURANT_LIVE_WORLD`,
`const liveWorldSystem =
  require('../world/liveWorldSystemV084.js');

const staffScheduleSystem =
  require('../world/staffScheduleSystemV086.js');
// V086_STAFF_SCHEDULE
// V084_RESTAURANT_LIVE_WORLD`,
        '经营模拟读取实时排班'
      );

    source =
      replaceOnce(
        source,
`    return clamp(
      base *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ),
      0.25,
      1.2
    );`,
`    const schedule =
      staffScheduleSystem
        .getCoverage(
          shop.id,
          gameState
            .getTime()
        );

    return clamp(
      base *
      (
        Number(
          people
            .capacityMultiplier
        ) ||
        1
      ) *
      (
        Number(
          schedule
            .coverageMultiplier
        ) ||
        1
      ),
      0.12,
      1.2
    );`,
        '当前班次产能进入真实员工覆盖率'
      );

    fs.writeFileSync(
      file(rel),
      source
    );
  }
}

function patchBusinessScene() {
  const rel =
    'src/scenes/businessScene.js';

  let source =
    fs.readFileSync(
      file(rel),
      'utf8'
    );

  if (
    source.includes(
      'V086_BUSINESS_SCHEDULE'
    )
  ) {
    return;
  }

  source =
    replaceOnce(
      source,
`const managementSystem =
  require('../world/managementWorldSystemV085.js');

const ui =`,
`const managementSystem =
  require('../world/managementWorldSystemV085.js');

const staffScheduleSystem =
  require('../world/staffScheduleSystemV086.js');
// V086_BUSINESS_SCHEDULE

const ui =`,
      '经营管理页读取排班系统'
    );

  source =
    replaceOnce(
      source,
`  {
    id:'staff',
    name:'员工'
  },
  {
    id:'competitor',
    name:'竞品'
  },`,
`  {
    id:'staff',
    name:'员工'
  },
  {
    id:'schedule',
    name:'排班'
  },
  {
    id:'competitor',
    name:'竞品'
  },`,
      '经营管理新增排班页签'
    );

  source =
    replaceOnce(
      source,
`    this.staffPage =
      0;

    this.competitorPage =`,
`    this.staffPage =
      0;

    this.schedulePage =
      0;

    this.competitorPage =`,
      '排班页增加分页状态'
    );

  source =
    replaceOnce(
      source,
`  renderCompetitors(
    ctx,
    shop
  ) {`,
"  renderSchedule(\n    ctx,\n    shop\n  ) {\n    const schedule =\n      staffScheduleSystem\n        .getDashboard(\n          shop.id,\n          gameState\n            .getTime()\n        );\n\n    if (!schedule) {\n      return;\n    }\n\n    this.sectionCard(\n      ctx,\n      14,\n      138,\n      362,\n      116,\n      '营业时间'\n    );\n\n    ui.text(\n      ctx,\n      '当前 ' +\n      schedule.hours.label +\n      ' · ' +\n      (\n        schedule.isOpen\n          ? '营业中'\n          : '已打烊'\n      ),\n      28,\n      171,\n      8,\n      schedule.isOpen\n        ? '#248B63'\n        : '#748791',\n      '800'\n    );\n\n    const presetW = 78;\n\n    for (\n      let i = 0;\n      i < schedule.presets.length;\n      i++\n    ) {\n      const preset = schedule.presets[i];\n\n      const x =\n        20 +\n        i * 88;\n\n      const active =\n        (\n          schedule.hours.openHour ===\n            preset.openHour &&\n          schedule.hours.closeHour ===\n            preset.closeHour\n        );\n\n      opUi.button(\n        ctx,\n        preset.name,\n        x,\n        205,\n        presetW,\n        30,\n        active\n          ? 'gold'\n          : null\n      );\n\n      this.addButton(\n        'hours:' +\n        preset.id,\n        x,\n        205,\n        presetW,\n        30\n      );\n    }\n\n    this.sectionCard(\n      ctx,\n      14,\n      268,\n      362,\n      86,\n      '当前在岗'\n    );\n\n    ui.text(\n      ctx,\n      schedule.coverage.activeStaff +\n      '/' +\n      schedule.coverage.totalStaff +\n      '人 · 班次产能 ' +\n      schedule.coverage.coveragePercent +\n      '%',\n      28,\n      302,\n      8,\n      schedule.coverage.underStaffed\n        ? '#C85242'\n        : '#248B63',\n      '800'\n    );\n\n    const role =\n      schedule.coverage.roleCoverage ||\n      {};\n\n    ui.text(\n      ctx,\n      '店长 ' +\n      (\n        role.manager\n          ? role.manager.active +\n            '/' +\n            role.manager.required\n          : '0/0'\n      ) +\n      ' · 厨师 ' +\n      (\n        role.chef\n          ? role.chef.active +\n            '/' +\n            role.chef.required\n          : '0/0'\n      ) +\n      ' · 服务 ' +\n      (\n        role.server\n          ? role.server.active +\n            '/' +\n            role.server.required\n          : '0/0'\n      ) +\n      ' · 前台 ' +\n      (\n        role.cashier\n          ? role.cashier.active +\n            '/' +\n            role.cashier.required\n          : '0/0'\n      ),\n      28,\n      329,\n      6.8,\n      '#607986',\n      '700'\n    );\n\n    this.sectionCard(\n      ctx,\n      14,\n      368,\n      362,\n      78,\n      '班次分布'\n    );\n\n    let sx = 26;\n\n    for (const shift of schedule.shifts) {\n      ui.text(\n        ctx,\n        shift.name +\n        ' ' +\n        shift.staffCount,\n        sx,\n        402,\n        7,\n        '#173D54',\n        '800'\n      );\n\n      ui.text(\n        ctx,\n        shift.label,\n        sx,\n        426,\n        6.4,\n        '#748791',\n        '600'\n      );\n\n      sx += 87;\n    }\n\n    const perPage =\n      opUi.viewHeight() <\n        740\n        ? 2\n        : 3;\n\n    const pages =\n      Math.max(\n        1,\n        Math.ceil(\n          schedule.staff.length /\n          perPage\n        )\n      );\n\n    this.schedulePage =\n      clamp(\n        this.schedulePage,\n        0,\n        pages - 1\n      );\n\n    const rows =\n      schedule.staff.slice(\n        this.schedulePage * perPage,\n        this.schedulePage * perPage +\n        perPage\n      );\n\n    let y = 460;\n\n    for (const staff of rows) {\n      ui.card(\n        ctx,\n        14,\n        y,\n        362,\n        46,\n        {\n          radius:11,\n          fill:\n            staff.active\n              ? '#F0FAF4'\n              : '#FFFDF8',\n          stroke:\n            staff.active\n              ? '#9CCBB0'\n              : '#DDD4C7',\n          shadow:false\n        }\n      );\n\n      ui.text(\n        ctx,\n        staff.name,\n        28,\n        y + 15,\n        7.8,\n        '#173D54',\n        '800'\n      );\n\n      ui.text(\n        ctx,\n        staff.active\n          ? '当前在岗'\n          : '当前不在岗',\n        28,\n        y + 33,\n        6.4,\n        staff.active\n          ? '#248B63'\n          : '#748791',\n        '700'\n      );\n\n      opUi.button(\n        ctx,\n        staff.shiftName +\n        ' ' +\n        staff.shiftLabel,\n        202,\n        y + 8,\n        160,\n        30,\n        staff.active\n          ? 'gold'\n          : null\n      );\n\n      this.addButton(\n        'shiftstaff:' +\n        staff.id,\n        194,\n        y + 4,\n        174,\n        38\n      );\n\n      y += 54;\n    }\n\n    if (!schedule.staff.length) {\n      ui.text(\n        ctx,\n        '暂无员工，录用员工后即可排班。',\n        195,\n        510,\n        8.5,\n        '#748791',\n        '700',\n        'center'\n      );\n    }\n\n    if (pages > 1) {\n      const py =\n        Math.min(\n          626,\n          opUi.viewHeight() -\n          96\n        );\n\n      opUi.button(\n        ctx,\n        '上一页',\n        14,\n        py,\n        82,\n        28\n      );\n\n      opUi.button(\n        ctx,\n        (\n          this.schedulePage +\n          1\n        ) +\n        '/' +\n        pages,\n        154,\n        py,\n        82,\n        28,\n        'gold'\n      );\n\n      opUi.button(\n        ctx,\n        '下一页',\n        294,\n        py,\n        82,\n        28\n      );\n\n      this.addButton(\n        'schedprev',\n        14,\n        py,\n        82,\n        28\n      );\n\n      this.addButton(\n        'schednext',\n        294,\n        py,\n        82,\n        28\n      );\n    }\n  }\n\n  renderCompetitors(\\n    ctx,\\n    shop\\n  ) {{",
      '接入营业时间与排班管理界面'
    );

  source =
    replaceOnce(
      source,
`      '经营、员工、竞品和商圈排名统一管理'`,
`      '经营、员工、排班、竞品和商圈排名统一管理'`,
      '更新经营管理说明'
    );

  source =
    replaceOnce(
      source,
`    if (
      this.tab ===
      'staff'
    ) {
      this.renderStaff(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'competitor'
    ) {`,
`    if (
      this.tab ===
      'staff'
    ) {
      this.renderStaff(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'schedule'
    ) {
      this.renderSchedule(
        ctx,
        shop
      );
    } else if (
      this.tab ===
      'competitor'
    ) {`,
      '排班页接入渲染分发'
    );

  source =
    replaceOnce(
      source,
`    if (
      target.id.indexOf(
        'staff:'
      ) ===
      0
    ) {`,
"    if (\n      target.id.indexOf(\n        'hours:'\n      ) ===\n      0\n    ) {\n      const shop =\n        operations\n          .getCurrentShop();\n\n      if (!shop) {\n        return true;\n      }\n\n      const result =\n        staffScheduleSystem\n          .setBusinessHoursPreset(\n            shop.id,\n            target.id.slice(6)\n          );\n\n      opUi.toast(\n        result.message\n      );\n\n      return true;\n    }\n\n    if (\n      target.id.indexOf(\n        'shiftstaff:'\n      ) ===\n      0\n    ) {\n      const shop =\n        operations\n          .getCurrentShop();\n\n      if (!shop) {\n        return true;\n      }\n\n      const result =\n        staffScheduleSystem\n          .cycleStaffShift(\n            shop.id,\n            target.id.slice(11)\n          );\n\n      opUi.toast(\n        result.message\n      );\n\n      return true;\n    }\n\n    if (\n      target.id ===\n      'schedprev'\n    ) {\n      this.schedulePage =\n        Math.max(\n          0,\n          this.schedulePage - 1\n        );\n\n      return true;\n    }\n\n    if (\n      target.id ===\n      'schednext'\n    ) {\n      this.schedulePage += 1;\n\n      return true;\n    }\n\n    if (\\n      target.id.indexOf(\\n        'staff:'\\n      ) ===\\n      0\\n    ) {{",
      '排班按钮接入真实操作'
    );

  fs.writeFileSync(
    file(rel),
    source
  );
}

patchRestaurantSimulation();
patchBusinessScene();

const pkgPath = file('package.json');
const pkg =
  JSON.parse(
    fs.readFileSync(
      pkgPath,
      'utf8'
    )
  );

const installCommand =
  'node scripts/install-schedule-v086.js && ';

if (
  pkg.scripts &&
  typeof pkg.scripts.pretest ===
    'string'
) {
  pkg.scripts.pretest =
    pkg.scripts.pretest.replace(
      installCommand,
      ''
    );
}

pkg.version = '0.8.6';

fs.writeFileSync(
  pkgPath,
  JSON.stringify(
    pkg,
    null,
    2
  ) + '\n'
);

for (
  const target
  of [
    'src/operations/restaurantSimulationV081.js',
    'src/scenes/businessScene.js',
    'src/world/staffScheduleSystemV086.js',
    'tests/staffScheduleV086.test.js'
  ]
) {
  const result =
    cp.spawnSync(
      process.execPath,
      [
        '--check',
        file(target)
      ],
      {
        encoding:'utf8'
      }
    );

  if (result.status !== 0) {
    throw new Error(
      '[V0.8.6] 语法检查失败：' +
      target +
      '\n' +
      (
        result.stderr ||
        result.stdout ||
        ''
      )
    );
  }
}

console.log(
  '[V0.8.6] 营业时间与排班系统接线完成'
);

try {
  fs.unlinkSync(__filename);
  console.log(
    '[V0.8.6] 安装器已自清理'
  );
} catch (error) {
  console.warn(
    '[V0.8.6] 安装器自清理失败：' +
    error.message
  );
}
