'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const TARGET_VERSION = '0.8.53';

function read(rel) {
  return fs.readFileSync(path.join(ROOT, rel), 'utf8');
}

function write(rel, content) {
  fs.writeFileSync(path.join(ROOT, rel), content, 'utf8');
}

function replaceOnce(rel, search, replacement, label) {
  const before = read(rel);
  if (before.includes(replacement)) return false;
  if (!before.includes(search)) {
    throw new Error('补丁锚点不存在：' + (label || rel));
  }
  const after = before.replace(search, replacement);
  write(rel, after);
  return true;
}

function replaceRegex(rel, regex, replacement, label) {
  const before = read(rel);
  if (regex.test(before)) {
    const after = before.replace(regex, replacement);
    write(rel, after);
    return true;
  }
  if (before.includes(replacement)) return false;
  throw new Error('补丁正则锚点不存在：' + (label || rel));
}

function patchPackageVersion() {
  const rel = 'package.json';
  const pkg = JSON.parse(read(rel));
  pkg.version = TARGET_VERSION;
  write(rel, JSON.stringify(pkg, null, 2) + '\n');
}

function patchAndroidVersion() {
  const rel = 'android/app/build.gradle';
  let src = read(rel);
  src = src.replace(/versionCode\s+\d+/, 'versionCode 853');
  src = src.replace(/versionName\s+'[^']+'/, "versionName '0.8.53'");
  write(rel, src);
}

function patchSaveVersion() {
  replaceRegex(
    'src/core/saveSystem.js',
    /const GAME_VERSION = '[^']+';/,
    "const GAME_VERSION = '0.8.53';",
    'save game version'
  );
}

function patchOperatingCycle() {
  replaceRegex(
    'src/operations/dailyOperatingCycleV0840.js',
    /const VERSION =\s*\n\s*'0\.8\.40';/,
    "const VERSION =\n  '0.8.52';",
    'daily operating cycle version'
  );

  const rel = 'src/operations/dailyOperatingCycleV0840.js';
  const src = read(rel);
  const oldBlock = `      state.metrics\n        .goalStreak =\n        0;`;
  const newBlock = `      // V0852_STREAK_DECAY\n      // 目标失败不再把长期经营节奏直接清零，\n      // 改为衰减一半，降低一次失误带来的挫败。\n      state.metrics\n        .goalStreak =\n        Math.max(\n          0,\n          Math.floor(\n            (\n              Number(\n                state.metrics\n                  .goalStreak\n              ) ||\n              0\n            ) /\n            2\n          )\n        );`;

  if (!src.includes('V0852_STREAK_DECAY')) {
    if (!src.includes(oldBlock)) throw new Error('经营连续目标衰减锚点不存在');
    write(rel, src.replace(oldBlock, newBlock));
  }
}

function patchMainScene() {
  replaceOnce(
    'src/main.js',
    `const featureHubScene =\n  require('./scenes/featureHubSceneV0810.js');`,
    `const featureHubScene =\n  require('./scenes/featureHubSceneV0810.js');\n\nconst advancedManagementScene =\n  require('./scenes/advancedManagementSceneV0853.js');`,
    'main require advanced management'
  );

  replaceOnce(
    'src/main.js',
    `sceneManager.register(\n  'featureHub',\n  featureHubScene\n);`,
    `sceneManager.register(\n  'featureHub',\n  featureHubScene\n);\n\nsceneManager.register(\n  'advancedManagement',\n  advancedManagementScene\n);`,
    'main register advanced management'
  );
}

function patchFeatureHub() {
  replaceOnce(
    'src/scenes/featureHubSceneV0810.js',
    `  ['business', '经营数据'],\n  ['dynamicWorld', '城市动态'],`,
    `  ['business', '经营数据'],\n  ['advancedManagement', '经营中心'],\n  ['dynamicWorld', '城市动态'],`,
    'feature hub advanced management item'
  );
}

function patchFeaturePolicy() {
  replaceOnce(
    'src/core/featureAccessPolicyV0837.js',
    `    'supply',\n    'business'`,
    `    'supply',\n    'business',\n    'advancedManagement'`,
    'feature policy shop required'
  );

  replaceOnce(
    'src/core/featureAccessPolicyV0837.js',
    `        'schedule',\n        'business'`,
    `        'schedule',\n        'business',\n        'advancedManagement'`,
    'feature policy trial routes'
  );
}

patchPackageVersion();
patchAndroidVersion();
patchSaveVersion();
patchOperatingCycle();
patchMainScene();
patchFeatureHub();
patchFeaturePolicy();

console.log('V0.8.53 核心内容补丁已应用。');
