'use strict';

const gameState = require('../core/gameState.js');
const saveSystem = require('../core/saveSystem.js');
const sceneManager = require('../core/sceneManager.js');
const operations = require('../operations/operationsStoreV080.js');
const weeklyMilestones = require('../progress/weeklyMilestoneSystemV0853.js');
const ui = require('../ui/premiumUi.js');
const opUi = require('../ui/operationsUiV080.js');

const VERSION = '0.8.53';
const TABS = [
  ['marketing','营销'],
  ['member','会员'],
  ['supplier','供应商'],
  ['growth','成长']
];

function num(v, fallback=0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function money(v) {
  return opUi.money(num(v));
}

function safeArray(v) {
  return Array.isArray(v) ? v : [];
}

function textValue(v, fallback='—') {
  return v === undefined || v === null || v === '' ? fallback : String(v);
}

class AdvancedManagementScene {
  constructor() {
    this.id = 'advancedManagement';
    this.tab = 'marketing';
    this.buttons = [];
    this.selectedCampaign = 0;
    this.selectedPlatform = 0;
    this.selectedSupplier = 0;
    this.lastQuote = null;
    this.lastMessage = '';
  }

  enter(params) {
    if (params && TABS.some(x => x[0] === params.tab)) this.tab = params.tab;
    this.buttons = [];
  }

  exit() {
    this.buttons = [];
  }

  update() {}

  shop() {
    return operations.getCurrentShop();
  }

  runtime(shopId) {
    return operations.getRuntime(shopId);
  }

  addButton(id,x,y,w,h) {
    this.buttons.push({id,x,y,w,h});
  }

  hit(x,y) {
    for (let i=this.buttons.length-1;i>=0;i--) {
      const b=this.buttons[i];
      if (x>=b.x && x<=b.x+b.w && y>=b.y && y<=b.y+b.h) return b;
    }
    return null;
  }

  card(ctx,x,y,w,h,title) {
    ui.card(ctx,x,y,w,h,{radius:14,fill:'#FFFDF8',stroke:'#DDD4C7',shadow:false});
    if (title) ui.text(ctx,title,x+14,y+22,8.5,'#173D54','800');
  }

  button(ctx,id,label,x,y,w,tone) {
    opUi.button(ctx,label,x,y,w,36,tone || null);
    this.addButton(id,x,y,w,38);
  }

  renderHeader(ctx) {
    opUi.header(ctx,'经营中心','把已存在的深层经营系统真正交给玩家操作');
    this.button(ctx,'back','返回',14,92,66,null);

    const startX = 88;
    const width = 68;
    TABS.forEach((tab,index) => {
      this.button(ctx,'tab:'+tab[0],tab[1],startX+index*72,92,width,this.tab===tab[0]?'gold':null);
    });
  }

  renderNoShop(ctx) {
    this.card(ctx,14,150,362,160,'尚未建立门店');
    ui.text(ctx,'经营中心会在签下首店后开放。',28,206,8,'#71858F','700');
    this.button(ctx,'go-property','去找铺',230,248,126,'gold');
  }

  renderMarketing(ctx,shop) {
    const overview = operations.marketingMembershipSnapshot(shop.id) || {};
    const catalog = safeArray(operations.marketingCatalog());
    const platforms = safeArray(operations.marketingPlatformCatalog());
    if (this.selectedCampaign >= catalog.length) this.selectedCampaign = 0;
    if (this.selectedPlatform >= platforms.length) this.selectedPlatform = 0;
    const campaign = catalog[this.selectedCampaign] || {};
    const platform = platforms[this.selectedPlatform] || {};
    const platformState = overview.platforms && platform.id ? overview.platforms[platform.id] : null;

    this.card(ctx,14,146,362,112,'营销概览');
    ui.text(ctx,'活跃活动 '+safeArray(overview.activeCampaigns).length+' · 获客倍率 ×'+num(overview.demandMultiplier,1).toFixed(2),28,184,7.2,'#173D54','800');
    ui.text(ctx,'累计营销 '+money(overview.metrics && overview.metrics.marketingSpend)+' · 活动 '+num(overview.metrics && overview.metrics.campaignsStarted),28,211,6.8,'#71858F','700');
    ui.text(ctx,'会员 '+num(overview.memberCount)+' 人 · 会员营收 '+money(overview.metrics && overview.metrics.memberRevenue),28,236,6.8,'#71858F','700');

    this.card(ctx,14,270,362,176,'营销活动');
    ui.text(ctx,textValue(campaign.name,'暂无活动'),28,307,8.1,'#173D54','800');
    ui.text(ctx,'活动库 '+catalog.length+' 项 · 当前第 '+(catalog.length ? this.selectedCampaign+1 : 0)+' 项',28,333,6.5,'#71858F','700');
    this.button(ctx,'campaign:prev','上一个',28,354,90,null);
    this.button(ctx,'campaign:next','下一个',126,354,90,null);
    this.button(ctx,'campaign:start:500','投放¥500',224,354,132,'gold');
    this.button(ctx,'campaign:start:1500','投放¥1500',224,398,132,'gold');
    ui.text(ctx,'每次投放持续5个经营日，费用直接进入真实财务账。',28,424,6.1,'#71858F','600');

    this.card(ctx,14,458,362,158,'渠道管理');
    ui.text(ctx,textValue(platform.name,'暂无渠道'),28,495,8,'#173D54','800');
    ui.text(ctx,'基础费率 '+Math.round(num(platform.feeRate)*100)+'% · 状态 '+(platformState && platformState.enabled ? '已启用':'未启用'),28,522,6.8,platformState&&platformState.enabled?'#248B63':'#71858F','700');
    this.button(ctx,'platform:prev','上一个',28,545,90,null);
    this.button(ctx,'platform:next','下一个',126,545,90,null);
    this.button(ctx,'platform:toggle',platformState&&platformState.enabled?'停用渠道':'启用渠道',224,545,132,platformState&&platformState.enabled?'danger':'gold');

    if (this.lastMessage) ui.text(ctx,this.lastMessage,28,642,6.3,'#C08824','700');
  }

  renderMember(ctx,shop) {
    const overview = operations.marketingMembershipSnapshot(shop.id) || {};
    const runtime = this.runtime(shop.id) || {};
    const customers = Object.values(runtime.customers || {});
    const tiers = overview.tierCounts || {};

    this.card(ctx,14,146,362,130,'会员池');
    ui.text(ctx,'会员总数 '+num(overview.memberCount)+' · 到店顾客档案 '+customers.length,28,184,7.4,'#173D54','800');
    ui.text(ctx,'普通 '+num(tiers.member)+' · 银卡 '+num(tiers.silver)+' · 金卡 '+num(tiers.gold),28,211,6.7,'#71858F','700');
    ui.text(ctx,'铂金 '+num(tiers.platinum)+' · 核心会员 '+num(tiers.vip),28,236,6.7,'#71858F','700');

    this.card(ctx,14,290,362,154,'会员运营');
    ui.text(ctx,'会员积分发放 '+num(overview.metrics && overview.metrics.pointsIssued)+' · 已兑换 '+num(overview.metrics && overview.metrics.pointsRedeemed),28,329,6.8,'#173D54','700');
    ui.text(ctx,'会员消费累计 '+money(overview.metrics && overview.metrics.memberRevenue),28,355,7,'#71858F','700');
    this.button(ctx,'member:enroll','吸纳一位到店顾客',28,382,150,'gold');
    this.button(ctx,'go-marketing','去做营销',190,382,150,null);

    this.card(ctx,14,458,362,188,'经营建议');
    const memberCount = num(overview.memberCount);
    const customerCount = customers.length;
    const ratio = customerCount > 0 ? memberCount/customerCount : 0;
    const tip = customerCount === 0
      ? '先正常营业积累顾客档案，再做会员转化。'
      : ratio < 0.15
        ? '会员覆盖偏低，建议优先把满意顾客沉淀进会员池。'
        : ratio < 0.35
          ? '会员基础已经形成，可以用活动提升复购。'
          : '会员覆盖较高，下一步重点放在高等级会员和客单价。';
    ui.text(ctx,'会员覆盖约 '+Math.round(ratio*100)+'%',28,497,7.5,'#173D54','800');
    ui.text(ctx,tip,28,527,6.5,'#71858F','700');
    ui.text(ctx,'会员体系直接读取真实顾客档案，不生成虚假“会员人数”。',28,570,6.1,'#71858F','600');
    if (this.lastMessage) ui.text(ctx,this.lastMessage,28,616,6.3,'#C08824','700');
  }

  supplierIngredient(supplier) {
    const ids = supplier && (supplier.ingredientIds || supplier.ingredients || []);
    if (Array.isArray(ids) && ids.length) {
      const first = ids[0];
      return typeof first === 'string' ? first : first && (first.id || first.ingredientId);
    }
    return null;
  }

  renderSupplier(ctx,shop) {
    const suppliers = safeArray(operations.supplierCatalog(shop.id,{}));
    if (this.selectedSupplier >= suppliers.length) this.selectedSupplier = 0;
    const supplier = suppliers[this.selectedSupplier] || {};
    const ingredientId = this.supplierIngredient(supplier);
    const runtime = this.runtime(shop.id) || {};
    const purchaseOrders = safeArray(runtime.procurement && runtime.procurement.purchaseOrders);
    const pending = purchaseOrders.filter(po => po && !['received','cancelled'].includes(po.status));
    const due = pending.filter(po => num(po.expectedDay,Infinity) <= num(runtime.day,1));

    this.card(ctx,14,146,362,126,'供应网络');
    ui.text(ctx,'供应商网络 '+suppliers.length+' 家 · 采购单 '+purchaseOrders.length+' 笔',28,184,7.2,'#173D54','800');
    ui.text(ctx,'待执行 '+pending.length+' · 已到期可收货 '+due.length,28,211,6.8,due.length?'#C08824':'#71858F','700');
    ui.text(ctx,'这里使用真实供应商网络、起订量、交期和采购单。',28,237,6.1,'#71858F','600');

    this.card(ctx,14,286,362,212,'当前供应商');
    ui.text(ctx,textValue(supplier.name || supplier.supplierName,'暂无供应商'),28,324,8,'#173D54','800');
    ui.text(ctx,'类别 '+textValue(supplier.category && (supplier.category.name || supplier.category),textValue(supplier.type,'综合')),28,350,6.6,'#71858F','700');
    ui.text(ctx,'覆盖食材 '+num(supplier.ingredientCount, safeArray(supplier.ingredientIds).length)+' · 当前采购 '+textValue(ingredientId),28,375,6.3,'#71858F','700');
    this.button(ctx,'supplier:prev','上一个',28,402,90,null);
    this.button(ctx,'supplier:next','下一个',126,402,90,null);
    this.button(ctx,'supplier:quote','比价10kg',224,402,132,'gold');
    this.button(ctx,'supplier:order','议价下单10kg',224,446,132,'gold');

    const quoteText = this.lastQuote
      ? '当前最低报价 '+money(this.lastQuote.total)+' · '+textValue(this.lastQuote.supplierName || this.lastQuote.name)
      : '点击比价后显示最低报价。';
    ui.text(ctx,quoteText,28,484,6.3,'#C08824','700');

    this.card(ctx,14,512,362,136,'采购执行');
    ui.text(ctx,'采购单不会“点一下瞬间消失”，会按预计到货日进入收货。',28,548,6.1,'#71858F','600');
    this.button(ctx,'supplier:receive','收货到期采购单',28,575,150,due.length?'gold':null);
    this.button(ctx,'go-supply','回库存页',190,575,150,null);
    if (this.lastMessage) ui.text(ctx,this.lastMessage,28,631,6.2,'#C08824','700');
  }

  renderGrowth(ctx,shop) {
    const growth = operations.growthSnapshot(shop.id) || {};
    const portfolio = operations.brandPortfolioSnapshot() || {};
    const cycle = operations.operatingDaySnapshot(shop.id) || {};
    const history = operations.operatingDayHistory(shop.id,120) || [];
    const runtime = this.runtime(shop.id) || {};
    const day = num(runtime.day,1);
    const week = weeklyMilestones.overview(shop.id,day,history,cycle.metrics || {});
    const achievements = safeArray(growth.achievements);
    const unlocked = safeArray(growth.unlockedFeatures);
    const milestones = safeArray(week.milestones);

    this.card(ctx,14,146,362,116,'品牌成长');
    ui.text(ctx,'品牌 Lv.'+num(growth.brand && growth.brand.level,1)+' · '+textValue(growth.brand && growth.brand.name,'起步品牌'),28,184,7.5,'#173D54','800');
    ui.text(ctx,'成就 '+achievements.length+'/'+safeArray(growth.achievementCatalog).length+' · 成就点 '+num(growth.achievementPoints),28,211,6.8,'#71858F','700');
    ui.text(ctx,'门店 '+num(portfolio.storeCount,1)+' / 容量 '+num(growth.brand && growth.brand.storeCap,1)+' · 已解锁 '+unlocked.length+' 项',28,237,6.5,'#71858F','700');

    this.card(ctx,14,276,362,176,'本周经营目标');
    ui.text(ctx,'第 '+week.week.index+' 周 · 管理点 '+week.managementPoints+' · 可领取 '+week.claimableTasks,28,313,7,'#173D54','800');
    week.tasks.slice(0,4).forEach((task,index) => {
      const y = 341 + index*24;
      const pct = Math.min(100,Math.round(num(task.current)/Math.max(1,num(task.target))*100));
      ui.text(ctx,(task.completed?'✓ ':'')+task.name+' '+task.current+'/'+task.target+' · '+pct+'%',28,y,6.3,task.completed?'#248B63':'#71858F','700');
    });
    this.button(ctx,'weekly:claim','领取已完成目标',224,403,132,week.claimableTasks?'gold':null);

    this.card(ctx,14,466,362,174,'长期里程碑');
    const next = milestones.filter(x => !x.completed).slice(0,3);
    const done = milestones.filter(x => x.completed).length;
    ui.text(ctx,'已完成 '+done+'/'+milestones.length+' · 里程碑自动记录，不清零。',28,503,6.8,'#173D54','800');
    if (next.length) {
      next.forEach((m,index) => {
        ui.text(ctx,m.name+' '+Math.floor(num(m.current))+'/'+m.target,28,531+index*25,6.3,'#71858F','700');
      });
    } else {
      ui.text(ctx,'当前里程碑已全部完成。',28,538,7,'#248B63','800');
    }
    this.button(ctx,'growth:expand','去扩张门店',224,594,132,growth.brand && growth.brand.canOpenStore?'gold':null);
    if (this.lastMessage) ui.text(ctx,this.lastMessage,28,654,6.2,'#C08824','700');
  }

  render(ctx) {
    const h = opUi.viewHeight();
    this.buttons = [];
    ctx.save();
    opUi.background(ctx,h);
    this.renderHeader(ctx);
    const shop = this.shop();
    if (!shop) {
      this.renderNoShop(ctx);
    } else if (this.tab === 'marketing') {
      this.renderMarketing(ctx,shop);
    } else if (this.tab === 'member') {
      this.renderMember(ctx,shop);
    } else if (this.tab === 'supplier') {
      this.renderSupplier(ctx,shop);
    } else {
      this.renderGrowth(ctx,shop);
    }
    ctx.restore();
  }

  save() {
    saveSystem.autoSave(true);
  }

  handleTap(x,y) {
    const target = this.hit(x,y);
    if (!target) return false;
    const id = target.id;

    if (id === 'back') { sceneManager.switchTo('featureHub'); return true; }
    if (id === 'go-property' || id === 'growth:expand') { sceneManager.switchTo('propertyMarket'); return true; }
    if (id === 'go-supply') { sceneManager.switchTo('supply'); return true; }
    if (id === 'go-marketing') { this.tab='marketing'; return true; }
    if (id.indexOf('tab:') === 0) { this.tab=id.slice(4); this.lastMessage=''; return true; }

    const shop = this.shop();
    if (!shop) return true;

    if (id === 'campaign:prev' || id === 'campaign:next') {
      const catalog = safeArray(operations.marketingCatalog());
      if (catalog.length) this.selectedCampaign = (this.selectedCampaign + (id.endsWith('next')?1:-1) + catalog.length) % catalog.length;
      return true;
    }

    if (id.indexOf('campaign:start:') === 0) {
      const budget = num(id.split(':').pop());
      const catalog = safeArray(operations.marketingCatalog());
      const campaign = catalog[this.selectedCampaign];
      if (!campaign) return true;
      const result = operations.startMarketingCampaign(shop.id,campaign.id,budget,5,{});
      this.lastMessage = result && result.ok ? '营销活动已启动，预算 '+money(budget) : textValue(result && (result.reason || result.message),'启动失败');
      if (result && result.ok) this.save();
      return true;
    }

    if (id === 'platform:prev' || id === 'platform:next') {
      const list = safeArray(operations.marketingPlatformCatalog());
      if (list.length) this.selectedPlatform = (this.selectedPlatform + (id.endsWith('next')?1:-1) + list.length) % list.length;
      return true;
    }

    if (id === 'platform:toggle') {
      const list = safeArray(operations.marketingPlatformCatalog());
      const p = list[this.selectedPlatform];
      const snap = operations.marketingMembershipSnapshot(shop.id) || {};
      if (!p) return true;
      const current = snap.platforms && snap.platforms[p.id];
      const result = operations.configureMarketingPlatform(shop.id,p.id,{enabled:!(current && current.enabled)});
      this.lastMessage = result && result.ok ? p.name+' 已'+(current&&current.enabled?'停用':'启用') : textValue(result && result.reason,'渠道设置失败');
      if (result && result.ok) this.save();
      return true;
    }

    if (id === 'member:enroll') {
      const runtime = this.runtime(shop.id) || {};
      const customers = Object.keys(runtime.customers || {});
      let result = null;
      for (const customerId of customers) {
        const r = operations.enrollMember(shop.id,customerId,{day:runtime.day});
        if (r && r.ok && !r.existing) { result=r; break; }
      }
      this.lastMessage = result ? '已新增1名会员' : (customers.length ? '现有顾客均已进入会员池' : '暂无顾客档案，先完成营业');
      if (result) this.save();
      return true;
    }

    if (id === 'supplier:prev' || id === 'supplier:next') {
      const list = safeArray(operations.supplierCatalog(shop.id,{}));
      if (list.length) this.selectedSupplier = (this.selectedSupplier + (id.endsWith('next')?1:-1) + list.length) % list.length;
      this.lastQuote = null;
      return true;
    }

    if (id === 'supplier:quote' || id === 'supplier:order') {
      const suppliers = safeArray(operations.supplierCatalog(shop.id,{}));
      const supplier = suppliers[this.selectedSupplier];
      const ingredientId = this.supplierIngredient(supplier);
      if (!supplier || !ingredientId) { this.lastMessage='当前供应商没有可采购食材'; return true; }
      if (id === 'supplier:quote') {
        const quotes = safeArray(operations.compareSupplierQuotes(shop.id,ingredientId,10,{}));
        this.lastQuote = quotes[0] || null;
        this.lastMessage = this.lastQuote ? '已完成供应商比价' : '当前没有可执行报价';
        return true;
      }
      const result = operations.createManualPurchaseOrder(shop.id,supplier.id,ingredientId,10,{negotiate:true,rounds:2});
      this.lastMessage = result && result.ok ? '采购单已创建，按交期等待收货' : textValue(result && result.reason,'下单失败');
      if (result && result.ok) this.save();
      return true;
    }

    if (id === 'supplier:receive') {
      const runtime = this.runtime(shop.id) || {};
      const pos = safeArray(runtime.procurement && runtime.procurement.purchaseOrders);
      const po = pos.find(item => item && !['received','cancelled'].includes(item.status) && num(item.expectedDay,Infinity) <= num(runtime.day,1));
      if (!po) { this.lastMessage='目前没有到期可收货采购单'; return true; }
      const result = operations.receiveManualPurchaseOrder(shop.id,po.id,{});
      this.lastMessage = result && result.ok ? '收货完成，货款已进入真实财务流水' : textValue(result && result.reason,'收货失败');
      if (result && result.ok) this.save();
      return true;
    }

    if (id === 'weekly:claim') {
      const runtime = this.runtime(shop.id) || {};
      const cycle = operations.operatingDaySnapshot(shop.id) || {};
      const history = operations.operatingDayHistory(shop.id,120) || [];
      const result = weeklyMilestones.claimWeekly(shop.id,num(runtime.day,1),history,cycle.metrics || {});
      this.lastMessage = result.ok ? '领取成功：管理点 +'+result.awarded : '当前没有可领取的周目标';
      if (result.ok) this.save();
      return true;
    }

    return false;
  }
}

const scene = new AdvancedManagementScene();
scene.VERSION = VERSION;
module.exports = scene;
