'use strict';

const gameState = require('../core/gameState.js');

const VERSION = '0.8.53';

const WEEK_TASKS = Object.freeze([
  {id:'operate_days', name:'稳定营业', target:5, points:8},
  {id:'profit_days', name:'保持盈利', target:3, points:10},
  {id:'weekly_revenue', name:'周营收推进', target:12000, points:12},
  {id:'goal_days', name:'完成每日目标', target:3, points:10}
]);

const MILESTONES = Object.freeze([
  {id:'days_7', name:'站稳一周', metric:'daysOpened', target:7, points:15},
  {id:'days_30', name:'经营满月', metric:'daysOpened', target:30, points:35},
  {id:'days_100', name:'百日老店', metric:'daysOpened', target:100, points:80},
  {id:'goals_10', name:'十次改善', metric:'goalsCompleted', target:10, points:20},
  {id:'goals_30', name:'经营节奏', metric:'goalsCompleted', target:30, points:45},
  {id:'revenue_50k', name:'累计营收五万', metric:'totalRevenue', target:50000, points:20},
  {id:'revenue_300k', name:'累计营收三十万', metric:'totalRevenue', target:300000, points:50},
  {id:'revenue_1m', name:'累计营收百万', metric:'totalRevenue', target:1000000, points:100},
  {id:'stores_2', name:'第二家店', metric:'storeCount', target:2, points:30},
  {id:'stores_5', name:'五店连锁', metric:'storeCount', target:5, points:90}
]);

function clone(value) {
  return value === undefined ? undefined : JSON.parse(JSON.stringify(value));
}

function getRoot() {
  const business = gameState.getBusiness();
  business.weeklyMilestones = business.weeklyMilestones && typeof business.weeklyMilestones === 'object'
    ? business.weeklyMilestones
    : {version:VERSION, managementPoints:0, shops:{}, milestones:{}};

  const root = business.weeklyMilestones;
  root.version = VERSION;
  root.managementPoints = Math.max(0, Number(root.managementPoints) || 0);
  root.shops = root.shops && typeof root.shops === 'object' ? root.shops : {};
  root.milestones = root.milestones && typeof root.milestones === 'object' ? root.milestones : {};
  return root;
}

function ensureShop(shopId) {
  const root = getRoot();
  const id = String(shopId);
  if (!root.shops[id]) {
    root.shops[id] = {version:VERSION, shopId:id, weekIndex:null, claimed:{}};
  }
  const state = root.shops[id];
  state.version = VERSION;
  state.claimed = state.claimed && typeof state.claimed === 'object' ? state.claimed : {};
  return state;
}

function weekIndex(day) {
  return Math.max(1, Math.floor((Math.max(1, Number(day) || 1) - 1) / 7) + 1);
}

function weekBounds(day) {
  const index = weekIndex(day);
  const start = (index - 1) * 7 + 1;
  return {index, start, end:start + 6};
}

function completedHistory(history, bounds) {
  return (Array.isArray(history) ? history : []).filter(item =>
    item && item.status === 'closed' && Number(item.day) >= bounds.start && Number(item.day) <= bounds.end
  );
}

function taskProgress(task, rows) {
  if (task.id === 'operate_days') return rows.length;
  if (task.id === 'profit_days') return rows.filter(x => Number(x.financial && x.financial.profit) > 0).length;
  if (task.id === 'weekly_revenue') return Math.round(rows.reduce((sum,x) => sum + (Number(x.financial && x.financial.revenue) || 0), 0));
  if (task.id === 'goal_days') return rows.filter(x => x.goalResult && x.goalResult.completed).length;
  return 0;
}

function syncMilestones(cycleMetrics) {
  const root = getRoot();
  const business = gameState.getBusiness();
  const metrics = Object.assign({}, cycleMetrics || {}, {
    storeCount:(business.shops || []).filter(x => x && x.status !== 'closed').length
  });
  const newlyCompleted = [];

  for (const def of MILESTONES) {
    const value = Math.max(0, Number(metrics[def.metric]) || 0);
    if (value >= def.target && !root.milestones[def.id]) {
      root.milestones[def.id] = {id:def.id, completed:true, completedAt:Date.now(), points:def.points};
      root.managementPoints += def.points;
      newlyCompleted.push(def.id);
    }
  }

  return {metrics, newlyCompleted};
}

function overview(shopId, day, history, cycleMetrics) {
  const root = getRoot();
  const state = ensureShop(shopId);
  const bounds = weekBounds(day);

  if (state.weekIndex !== bounds.index) {
    state.weekIndex = bounds.index;
    state.claimed = {};
  }

  const rows = completedHistory(history, bounds);
  const tasks = WEEK_TASKS.map(def => {
    const current = taskProgress(def, rows);
    return {
      ...def,
      current,
      completed:current >= def.target,
      claimed:!!state.claimed[def.id]
    };
  });

  const milestoneSync = syncMilestones(cycleMetrics);
  const milestones = MILESTONES.map(def => {
    const current = Math.max(0, Number(milestoneSync.metrics[def.metric]) || 0);
    return {
      ...def,
      current,
      completed:current >= def.target,
      rewarded:!!root.milestones[def.id]
    };
  });

  return {
    version:VERSION,
    managementPoints:root.managementPoints,
    week:bounds,
    tasks,
    completedTasks:tasks.filter(x => x.completed).length,
    claimableTasks:tasks.filter(x => x.completed && !x.claimed).length,
    milestones,
    newlyCompletedMilestones:milestoneSync.newlyCompleted
  };
}

function claimWeekly(shopId, day, history, cycleMetrics) {
  const root = getRoot();
  const state = ensureShop(shopId);
  const snap = overview(shopId, day, history, cycleMetrics);
  let awarded = 0;
  const claimed = [];

  for (const task of snap.tasks) {
    if (!task.completed || state.claimed[task.id]) continue;
    state.claimed[task.id] = true;
    awarded += task.points;
    claimed.push(task.id);
  }

  root.managementPoints += awarded;
  return {ok:claimed.length > 0, claimed, awarded, managementPoints:root.managementPoints};
}

module.exports = {
  VERSION,
  WEEK_TASKS,
  MILESTONES,
  weekIndex,
  weekBounds,
  overview,
  claimWeekly
};
