商铺动态界面图标资源 V1

新增两个文件：
assets/images/ui/property_icons_01.png
src/property/propertyIconAtlas.js

property_icons_01.png 是 576×576 透明 PNG 图标图集。
包含 27 个商铺/找铺图标：
租金、面积、楼层、户型、门宽、进深、排烟、燃气、三相电、排水、隔油、消防、
卫生间、停车、骑手、可见度、风险、竞争者、新上架、降价、热门、筛选、排序、
市场事件、中介、房东、合同。

后续商圈找铺 UI 直接读取这张图集，不再用纯文字顶替所有信息。
