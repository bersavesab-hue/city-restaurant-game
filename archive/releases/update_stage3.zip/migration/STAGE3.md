REAL_COMPLETE_UPDATE_STAGE3

真实路径修改：
- src/main.js

新增：
- src/bootstrap/AppBootstrap.js
- src/core/GameStateV2.js

原则：
不删除旧系统，逐步迁移。
