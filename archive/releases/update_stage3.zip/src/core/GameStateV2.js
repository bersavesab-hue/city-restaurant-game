'use strict';

class GameStateV2 {
  constructor() {
    this.player = {};
    this.restaurant = {};
    this.food = {};
    this.staff = {};
    this.finance = {};
    this.rating = {};
    this.customer = {};
  }
}

module.exports = GameStateV2;
