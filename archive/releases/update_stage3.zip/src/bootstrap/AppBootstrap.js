'use strict';

class AppBootstrap {
  constructor(registry) {
    this.registry = registry || {};
  }

  register(name, module) {
    this.registry[name] = module;
  }

  get(name) {
    return this.registry[name];
  }
}

module.exports = AppBootstrap;
