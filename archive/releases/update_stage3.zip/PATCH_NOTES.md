Stage3真实补丁

已修改真实入口：
src/main.js

已增加：
统一模块注册入口
统一状态容器基础

下一阶段：
继续迁移food/finance/rating初始化。
