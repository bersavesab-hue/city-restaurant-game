"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const main = fs.readFileSync(
  path.join(ROOT, "src/main.js"),
  "utf8"
);

assert.ok(
  main.includes("V27_TARGET_REFERENCE_SKIN"),
  "V27目标图原版皮肤必须写入 src/main.js"
);

assert.ok(
  main.includes("v27_target_home_full"),
  "V27必须加载目标图完整游戏区域"
);

assert.ok(
  main.includes("assets/images/target_home/reference/target_game_ui.png"),
  "V27必须直接使用目标图游戏区域资源"
);

assert.ok(
  main.includes("V27_DISTRICT_HOTSPOTS"),
  "V27必须使用目标图商圈像素坐标"
);

assert.ok(
  main.includes("const V27_REF_W = 691") &&
  main.includes("const V27_REF_H = 1231"),
  "V27必须按691×1231参考尺寸缩放"
);

assert.ok(
  main.includes("drawMapBase = function ()") &&
  main.includes("drawTopHud = function ()") &&
  main.includes("drawDistrictMarker = function (district)") &&
  main.includes("drawDistrictCard = function ()") &&
  main.includes("drawBottomNav = function ()"),
  "V27必须最终接管完整主页视觉层"
);

const requiredAssets = [
  "assets/images/target_home/reference/target_game_ui.png",
  "assets/images/target_home/reference/map_visual_reference.png",
  "assets/images/target_home/markers/university.png",
  "assets/images/target_home/markers/hightech.png",
  "assets/images/target_home/markers/cbd.png",
  "assets/images/target_home/markers/oldtown.png",
  "assets/images/target_home/markers/village.png",
  "assets/images/target_home/markers/industry.png",
  "assets/images/target_home/markers/market.png",
  "assets/images/target_home/detail/enter_button.png"
];

for (const rel of requiredAssets) {
  assert.ok(
    fs.existsSync(path.join(ROOT, rel)),
    "缺少目标图资源: " + rel
  );
}

console.log("V27 target reference skin regression tests passed");
